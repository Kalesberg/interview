<?php

declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use Log;
use Flash;
use Artisan;
use ScriptSender\Printers;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use ScriptSender\Console\Commands\printers as PrintersCommand;

class PrinterController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|alpha_dash',
            'groups' => 'Array',
            'destination' => 'required|string', # TBD: Should be a valid directory
        ]);

        $name = $request->input('name');
        $destination = $request->input('destination');
        $groups = $request->input('groups');
        $comment = $request->input('comment');

        if (isPublicServer() || isIBM()) {
            $destination = join_paths(config('settings.hosted_ss_base_folder'), "/$destination");
        }

        $data = [
            '--add' => true,
            '--name' => $name,
            '--destination' => $destination,
            '--comment' => $comment,
        ];
        if (!empty($groups)) {
            $data['--groups'] = implode(',', $groups);
        }

        $exitCode = Artisan::call('scriptsender:printers', $data);

        if (PrintersCommand::EXIT_SUCCESS === $exitCode) {
            info('Added new printer', compact('name'));
        }
        else {
            $msg = "Failed to add new printer '$name'";
            Log::error($msg);
            Flash::error($msg);
        }
    }

    /**
     * Update given printer
     * @param Request $request
     * @param $id
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required|alpha_dash',
            'groups' => 'Array',
            'destination' => 'required|string', # TBD: Should be a valid directory
        ]);

        $name = $request->input('name');
        $groups = $request->input('groups');
        $destination = $request->input('destination');
        $comment = $request->input('comment');

        $existingPrinter = Printers::findOrFail($id);

        info('Received printer update request', [
            'printer' => $existingPrinter->name, 'name' => $name, 'destination' => $destination, 'comment' => $comment
            ]);

        $newData = [
            '--modify' => true,
            '--name' => $existingPrinter->name,
            '--new-name' => $name,
            '--new-destination' => $destination,
            '--new-comment' => $comment,
        ];
        if (!empty($groups)) {
            $newData['--new-groups'] = implode(',', $groups);
        }

        $exitCode = Artisan::call('scriptsender:printers', $newData);

        if (PrintersCommand::EXIT_SUCCESS === $exitCode) {
            $msg = 'Updated printer ' . $existingPrinter->name;
            Log::info($msg);
        }
        else {
            $msg = 'Failed to update printer ' . $existingPrinter->name;
            Log::error($msg);
            Flash::error($msg);
        }
    }

    /**
     * Delete printer
     * @param $id
     * @return JsonResponse
     */
    public function destroy($id): JsonResponse
    {
        $existingPrinter = Printers::findOrFail($id);

        Log::info("Received delete request for printer '" . $existingPrinter->name);

        $exitCode = Artisan::call('scriptsender:printers', [
            '--remove' => true,
            '--name' => $existingPrinter->name,
        ]);

        if (PrintersCommand::EXIT_SUCCESS === $exitCode) {
            $msg = 'Removed printer ' . $existingPrinter->name;
            Log::info($msg);
            Flash::success($msg);
            return response()->json(['message' => $msg], 200);
        }
        Log::error('Failed to remove printer', ['name' => $existingPrinter->name]);
        return response()->json(['message' => "Failed to remove printer {$existingPrinter->name}"], 500);
    }

    private function validateDir($dir)
    {
        $errorCode = '';
        $errorMsg = '';

        // Append '/' to the directory if not already present
        if (!preg_match('|/$|', $dir)) {
            $dir .= '/';
        }

        if (!is_dir($dir)) {
            $errorCode = 404;
            $errorMsg = "\n\nDirectory '$dir' does not exist.\n\nTo create it, run following command on server:\n\tmkdir -p $dir && chmod 770 $dir && chown www-data:lpadmin $dir";
        }
        elseif ('www-data' !== getOwner($dir)) {
            $errorCode = 403;
            $errorMsg = "\n\nOwner of directory '$dir' is not 'www-data'.\n\nTo set proper permissions and owner, run following command on server:\n\tchmod 770 $dir && chown www-data:lpadmin $dir";
        }
        elseif (!_is_writable($dir)) {
            $errorCode = 403;
            $errorMsg = "\n\nDirectory '$dir' is not writable for user 'www-data'.\n\nTo set proper permissions and owner, run following command on server:\n\tchmod 770 $dir && chown www-data:lpadmin $dir";
        }

        return [$dir, $errorCode, $errorMsg];
    }
}
