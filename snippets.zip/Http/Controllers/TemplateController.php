<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use File;
use Illuminate\View\View;
use Log;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use ScriptSender\Exceptions\FileAndDirectoryException;
use ScriptSender\Exceptions\ParseException;
use ScriptSender\Exceptions\PdfToTextException;
use ScriptSender\Services\Document;
use ScriptSender\Services\OrderService;
use ScriptSender\Services\Parser\Parser;
use ScriptSender\Services\YouTrackService;
use Illuminate\Support\Facades\Storage;

/**
 * Class TemplateController
 * @package ScriptSender\Http\Controllers
 */
class TemplateController extends Controller
{
    protected $document;
    protected $pdf;
    protected $orderService;

    /**
     * TemplateController constructor.
     *
     * @param OrderService $orderService
     * @throws FileAndDirectoryException
     * @throws PdfToTextException
     */
    public function __construct(OrderService $orderService)
    {
        $this->orderService = new OrderService();
        if (request()->hasSession() && request()->session()->has('document')) {
            $this->pdf = request()->session()->get('document');
            $this->document = (new Document($this->pdf, $orderService));
        }
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|View
     */
    public function index()
    {
        $templates = (new Parser(''))->getSupportedTypesAndFormats();
        return view('template')->with([
            'types' => array_map('str_singular', array_keys($templates)),
        ]);
    }

    /**
     * Return existing formats
     *
     * @return false|string
     */
    public function formats()
    {
        $templates = (new Parser(''))->getSupportedTypesAndFormats();
        return json_encode(array_values(array_unique(array_flatten(array_values($templates)))));
    }

    /**
     * Get text version of the PDF
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getText(): JsonResponse
    {
        try {
            $file = request()->session()->get('document');
            $document = new Document($file, $this->orderService);
            $textContent = $document->toText();
            $ocr = $document->isOCR();
        } catch (Exception $e) {
            return response()->json(['failed to generate text'], 500);
        }

        return response()
            ->json(['content' => $textContent, 'isOCR' => $ocr])
            ->header('Cache-Control', 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    }

    /**
     * Get JSON data generated from the pdf
     *
     * @param Request $request
     * @return JsonResponse
     * @throws \Throwable
     */
    public function getJson(Request $request): JsonResponse
    {
        $docType = $request->query('doctype', '');
        $changed = $request->query('changed', '');
        $docFormat = null;
        if ($changed) {
            $json = $this->getFinalJSONFromTemplate($docType);
        }
        else {
            try {
                $file = request()->session()->get('document');
                $document = new Document($file, $this->orderService);
                $json = json_decode($document->toJson(true), true);
                $typeAndFormat = $document->getTypeAndFormat();
                [$docType, $docFormat] = [$typeAndFormat['type'], $typeAndFormat['format']];
            } catch (Exception $e) {
                $json = $this->getFinalJSONFromTemplate($docType);
            }
        }

        return response()
            ->json(['content' => $json, 'docType' => $docType, 'docFormat' => $docFormat])
            ->header('Cache-Control', 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    }

    /**
     * @param Request $request
     * @param YouTrackService $youTrackService
     * @return JsonResponse
     * @throws Exception
     */
    public function submit(Request $request, YouTrackService $youTrackService): JsonResponse
    {
        $validated = $request->validate([
            'type' => 'required',
            'format' => 'required',
            'notes' => 'nullable',
            'json' => 'required',
            // 'image' => 'required',
        ]);
        $type = $validated['type'];
        $format = $validated['format'];
        $notes = $validated['notes'];
        $json = $validated['json'];
        // $image = $validated['image'];

        $rand = random_int(1, 9) . random_int(1, 9) . random_int(1, 9);

        $path = join_paths('parser', "parsed_$rand.json");
        Storage::put($path, $json);
        $jsonFile = join_paths(Storage::path('parser'), basename($path));

        $path = join_paths('parser', "parsed_$rand.txt");
        $file = $request->session()->get('document');
        $document = new Document($file, $this->orderService);
        Storage::put($path, $document->toText());
        $textFile = join_paths(Storage::path('parser'), basename($path));

        // $image = str_replace('data:image/png;base64,', '', $image);
        // $image = str_replace(' ', '+', $image);
        // $path = join_paths('parser', "ocr_$rand.png");
        // Storage::put($path, base64_decode($image));
        // $imageFile = join_paths(Storage::path('parser'), basename($path));

        $pdfFile = request()->session()->get('document');
        info('Ready to submit YT ticket', compact(['pdfFile', 'jsonFile', 'textFile']));

        if (! env('CAN_CREATE_TICKETS')) {
            return response()->json(['Creating ticket not allowed on this server'], 401);
        }
        if ($youTrackService->ticketExists(md5_file($pdfFile))) {
            return response()->json(['A ticket on this file already exists in YouTrack'], 401);
            // TODO: Return ticket number
            // TODO: Offer to add this file as a sample to the same ticket
        }

        try {
            $ticket = $youTrackService
                ->createTicket([
                    'title' => "[Parser][New Template] $type : $format",
                    'description' => $notes,
                    'assignee' => env('NO_MATCH_TICKET_ASSIGNEE'),
                    'priority' => 'Normal',
                    'subsystem' => 'Document Parser',
                ]);

            $ticket->attachFiles([$pdfFile, $jsonFile, $textFile]);
            $youTrackService->ticketCreated(md5_file($pdfFile));
        } catch (Exception $e) {
            Log::error('Failed to create ticket', ['error' => $e->getMessage()]);
            return response()->json(['status' => 'failed'], 500);
        }
        return response()->json(['status' => 'success']);
    }

    /**
     * @param $docType
     * @return array
     * @throws \ScriptSender\Exceptions\ParseException
     * @throws \Throwable
     */
    public function getFinalJSONFromTemplate(string $docType): array
    {
        $parserPath = app_path('Services/Parser');
        if (File::exists("$parserPath/" . str_singular($docType) . 'Data.php')) {
            $dataFile = "$parserPath/" . str_singular($docType) . 'Data.php';
        }
        elseif (File::exists("$parserPath/" . str_plural($docType) . 'Data.php')) {
            $dataFile = "$parserPath/" . str_plural($docType) . 'Data.php';
        }
        else {
            throw new ParseException("No such data file: '$parserPath/{$docType}Data.php'");
        }
        $templateData = include $dataFile;
        $templateView = (new Parser(''))->getTemplateView($docType);
        $json = json_decode(
            preg_replace('/[\r\n]/', '', view($templateView)->with(['data' => $templateData])->render()),
            true
        );
        return $json;
    }
}
