<?php

namespace ScriptSender\Http\Controllers;

use ScriptSender;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class ICD10sController extends Controller
{
    public function index()
    {
        $ICD10 = icd10s::all();
        return Response::json($ICD10);
    }

    public function autocomplete()
    {
        $term = Input::get('term');
        $delimiter = " "; // Delimit on space
        $terms = explode($delimiter, $term);
        $results = array();
        $query = "SELECT * FROM icd10s WHERE (code like '%$terms[0]%' or description LIKE '%$terms[0]%')";
        // this will query the icd10 table matching the code or description.
        for ($i = 1; $i < count($terms); $i++) {
            $query = $query . " and (code like '%$terms[$i]%' or description Like '%$terms[$i]%') ";
        }
        $query = $query . " LIMIT 12";
        $codes = DB::select(DB::raw($query));
        foreach ($codes as $code) {
            $results[] = ['id' => $code->code, 'value' => $code->description];
        }
        return Response::json($results);
    }
}
