<?php
namespace ScriptSender\Http\Controllers;

use DB;
use Auth;
use ScriptSender\User;
use File;
use Flash;
use Log;
use Mail;
use ScriptSender;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use ScriptSender\Services\HL7Service;
use ScriptSender\Mail\NotifyAdmin;
use ScriptSender\HL7Connection;
use ScriptSender\ConnectionNotification;
use ScriptSender\Events\NotificationLog;
use ScriptSender\Events\SignalConnection;

class HL7Controller extends Controller
{
    protected $data;

    public function __construct(Request $data)
    {
        $this->data = $data;
    }

    /**
      * Add new HL7 connection to database
      */
    public function addConnections(Request $request)
    {
        $req = $request->validate([
            'name'              => 'required',
            'conn_type'         => 'required',
            'inboundType'       => 'nullable',
            'isInbound'         => 'nullable',
            'outboundType'      => 'nullable',
            'isOutbound'        => 'nullable',
            'ip'                => 'required',
            'destinationPort'   => 'required',
            'listeningPort'     => 'required',
            'HL7_template'      => 'nullable',
            'group_id'          => 'nullable',
            'default_interval'  => 'required'
        ]);
        
        $req['isInbound'] === 'true' ? $req['isInbound'] = 1 : $req['isInbound'] = 0;
        $req['isOutbound'] === 'true' ? $req['isOutbound'] = 1 : $req['isOutbound'] = 0;

        $addFields = [
            'user_id'           => Auth::user()->id,
            'name'              => $req['name'],
            'connection_type'   => $req['conn_type'],
            'inboundType'       => $req['inboundType'],
            'isInbound'         => $req['isInbound'],
            'outboundType'      => $req['outboundType'],
            'isOutbound'        => $req['isOutbound'],
            'ip'                => $req['ip'],
            'destinationPort'   => $req['destinationPort'],
            'listeningPort'     => $req['listeningPort'],
            'HL7_template'      => $req['HL7_template'],
            'group_id'          => $req['group_id'],
            'default_interval'  => $req['default_interval']
        ];

        $result = HL7Connection::create($addFields);
        return['success' => true, 'message'=> 'Connection added successfully'];
    }
    
    /**
      * Add new mapped drive connection to database
      */
    public function addMapDriveData(Request $request)
    {
        $req = $request->validate([
            'userID'    => 'required',
            'conn_type' => 'required',
            'inTime'    => 'required',
        ]);

        $userName = User::select(DB::raw('CONCAT(FirstName, " ", LastName) AS full_Name'))->where('id', $req['userID'])->get();
        $groupID  = User::select('Group_id')->where('id', $req['userID'])->get();
        
        $addFields = [
            'user_id'          => $req['userID'],
            'name'             => $userName[0]->full_Name,
            'group_id'         => $groupID[0]->Group_id,
            'connection_type'  => $req['conn_type'],
            'default_interval' => $req['inTime'],
        ];

        $result = HL7Connection::create($addFields);
        return['success' => true, 'message'=> 'Map Drive Connection added successfully'];
    }

    /**
      * Get HL7 connection from database using connection id
      *
      * @return array
      */
    public function getConnection($connID, $userID)
    {
        $connection = HL7Connection::findOrFail($connID);
        
        $user_name = User::select(DB::raw('CONCAT(FirstName, " ", LastName) AS full_Name'))->where('id', $userID)->get();
        
        return [
            'connData' => HL7Connection::findOrFail($connID),
            'userName' => $user_name,
        ];
    }

    /**
      * Edit HL7 connection using connection id and updating to database
      *
      * @return array
      */
    public function editConnection(Request $request)
    {
        $req                    = $request->all();
        $connectionId           = $request->input('id');
        $conn                   = HL7Connection::find($connectionId);
        $conn->name             = $request->input('name');
        $conn->inboundType      = $request->input('inboundType');
        $request->input('isInbound') === 'true' ? $conn->isInbound = 1 : $conn->isInbound = 0;
        $conn->outboundType     = $request->input('outboundType');
        $request->input('isOutbound') === 'true' ? $conn->isOutbound = 1 : $conn->isOutbound = 0;
        $conn->ip               = $request->input('ip');
        $conn->destinationPort  = $request->input('destinationPort');
        $conn->listeningPort    = $request->input('listeningPort');
        $conn->HL7_template     = $request->input('HL7_template');
        $conn->group_id         = $request->input('group_id');
        $conn->default_interval = $request->input('default_interval');
        $conn->save();

        $conn                   = HL7Connection::with('Group')->find($connectionId);

        return['success' => true, 'message'=> 'Connection updated successfully', 'data' => $req];
    }
    
    /**
      * Edit mapped drive connection using connection id and updating to database
      *
      * @return array
      */
    public function updateMapDriveData(Request $request)
    {
        $req                    = $request->all();
        $connectionId           = $request->input('id');
        $conn                   = HL7Connection::find($connectionId);
        $conn->default_interval = $request->input('inTime');
        $conn->save();

        return['success' => true, 'message'=> 'Connection updated successfully'];
    }

    public function getAllConnections(Request $request)
    {
        $page = $request->get('page', 1);
        $per_page = $request->get('per_page', 10);
        $ret = array();
        $connections = DB::table('HL7_connections')
            ->join('group', 'HL7_connections.group_id', '=', 'group.id')
            ->join('users', 'HL7_connections.user_id', '=', 'users.id')
            ->select('HL7_connections.*', 'group.Name as group_name', DB::raw('CONCAT(users.FirstName, " ", users.LastName) AS full_name'))
            ->orderBy('HL7_connections.created_at', 'DESC')
            ->paginate($per_page);
            
        $ret['connections'] = $connections;
        $ret['yellowStatus'] = ConnectionNotification::where('notification_type', '=', 'yellow_status')->first();
        $ret['redStatus'] = ConnectionNotification::where('notification_type', '=', 'red_status')->first();

        return['response' => $ret];
    }

    /**
      * Check if difference between current time and recent ping for each connection is more than default interval
      * and ping the given IP and connection to check connection health
      * @return JSON
      */
    public function ipLog(Request $request)
    {
        $yellowStatus = ConnectionNotification::where("notification_type", '=', "yellow_status")->first();
        $redStatus    = ConnectionNotification::where("notification_type", '=', "red_status")->first();

        $HLService      = new HL7Service();
        $allConnections = HL7Connection::all();
        foreach ($allConnections as $connection) {
            $to_time    = strtotime($connection->recent_ping);
            $from_time  = strtotime(date('Y-m-d H:i:s'));
            if ($connection->connection_type === 'hl7') {
                if (round(abs($to_time - $from_time) / 60) >= $connection->default_interval) {
                    $data = $HLService->pingIP($connection);
                }
            } else if ($connection->connection_type === 'map_drive') {
                if (round(abs($to_time - $from_time) / 60) >= $connection->default_interval) {
                    $connection->failed_attempts += 1;
                    if ($connection->failed_attempts >= $redStatus->no_of_failed_attempts) {
                        Mail::to(['script@mailinator.com'])->send(new NotifyAdmin($connection, $redStatus));
                        
                        $rLog = 'Red status is generated for Mapped drive of '.$connection->name.'. Alert email to '.$redStatus->email_id;
                        /* Log::info($rLog, ["notification"]); */
                        
                        $result = $HLService->saveNotificationLog($connection->id, $rLog);
                        Log::info($result, ["notification red status log added"]);
                
                        $nLog = json_encode(['timestamp' => date('Y-m-d H:i:s'), 'log'=> 'Red status is generated for Mapped drive of '.$connection->name.'. Alert email to '.$redStatus->email_id]);
                        event(new NotificationLog($nLog));

                        $connectionData = json_encode(['status' => 'red', 'id' => $connection->id]);
                        event(new SignalConnection($connectionData));
                    } elseif ($connection->failed_attempts >= $yellowStatus->no_of_failed_attempts) {
                        Mail::to(['script@mailinator.com'])->send(new NotifyAdmin($connection, $yellowStatus));
                        
                        $yLog = 'Yellow status is generated for Mapped drive of '.$connection->name.'. Alert email to '.$yellowStatus->email_id;
                       /*  Log::info($yLog, ["notification"]); */
                        
                        $result = $HLService->saveNotificationLog($connection->id, $yLog);
                        Log::info($result, ["notification yellow status log added"]);
                        
                        $nLog = json_encode(['timestamp' => date('Y-m-d H:i:s'), 'log'=> 'Yellow status is generated for Mapped drive of '.$connection->name.'. Alert email to '.$yellowStatus->email_id]);
                        event(new NotificationLog($nLog));
                        
                        $connectionData = json_encode(['status' => 'yellow', 'id' => $connection->id]);
                        event(new SignalConnection($connectionData));
                    }

                    $connection->recent_ping = date('Y-m-d H:i:s');
                    $connection->save();
                }
            }
        }

        return response()->json(['success' => true, 'message' => 'log created'], 200);
    }

    /**
      * Add Notification emails to database
      *
      * @return array
      */
    public function addNotification(Request $request)
    {
        $req = $request->all();

        foreach ($req['data'] as $key => $value) {
            if (!isset($value['id'])) {
                $addFields = [
                    'notification_type'     => $value['chbox'],
                    'email_id'              => $value['email'],
                    'no_of_failed_attempts' => $value['failed_attempts']
                ];
                $result = ConnectionNotification::create($addFields);
            } else {
                $notification = ConnectionNotification::find($value['id']);
                $notification->notification_type     = $value['chbox'];
                $notification->email_id              = $value['email'];
                $notification->no_of_failed_attempts = $value['failed_attempts'];
                $notification->save();
            }
        }

        return response()->json([
            'success' => true,
            'message' => 'Data updated successfully'
        ], 200);
    }
}
