<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use Auth;
use Excel;
use Redirect;
use ScriptSender\CustomersExam;
use ScriptSender\Exams;
use ScriptSender\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

/**
 * Class ExamsController
 * @package ScriptSender\Http\Controllers
 */
class ExamsController extends Controller
{
    /**
     * @var User logged in user
     */
    protected $user;

    /**
     * Create a new controller instance.
     *
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->user = Auth::user();
    }

    /**
     * Fetch all uploaded exams and Show it on uploaded_exams blade file.
     * TODO: Rename to customerExams
     *
     */
    public function uploadedExams()
    {
        return view('uploaded_exams')->with('exams', $this->getAllCustomerExams());
    }

    /**
     * Get all user uploaded exams and send json array to vue.
     * @return array
     */
    public function allUploadedExams(): array
    {
        return ['allUploadedExams' => CustomersExam::orderBy('code')->select('id', 'code','description')->get()];
    }

    public function getAllCustomerExams()
    {
        return CustomersExam::orderBy('created_at', 'desc')->select('id', 'code','description')->get();
    }

    public function getAllOutsideOrderExams()
    {
        return Exams::orderBy('created_at', 'desc')->get();
    }

    /**
     * Fetch all outside order exams and Show it on exam blade file.
     *
     */
    public function getAllExams()
    {
        return view('exam')->with('exams', $this->getAllOutsideOrderExams());
    }

    /**
     * Get all exams added by users from table to display in dropdown.
     * TODO: Remove this method and use allUploadedExams() instead
     * @return array
     */
    public function dropdownData(): array
    {
        return ['dropdownData' => $this->getAllCustomerExams()];
    }

    /**
     * Get all unmatched exams from table and send json array to vue.
     *
     * @return array
     */
    public function unmatchData(): array
    {
        return ['unmatchData' => Exams::orderBy('created_at', 'desc')->get()];
    }

    /**
     * Add a new user exam in table.
     *
     * @param  \Illuminate\Http\Request $request
     * @return array
     */
    public function addExam(Request $request): array
    {
        $valid = $request->validate([
            'code'        => 'required',
            'description' => 'required',
        ]);

        $code = trim($valid['code']);
        $description = trim($valid['description']);
        CustomersExam::create(['code' => $code, 'description' => $description]);

        info('Added customer exam in Database', [
            'user'        => $this->user,
            'code'        => $code,
            'description' => $description
        ]);
        return ['success' => true, 'message' => 'Exam added successfully'];
    }

    /**
     * Map a outside order exam with another exam.
     *
     * @param  \Illuminate\Http\Request $request
     * @return array
     */
    public function map(Request $request): array
    {
        $valid = $request->validate([
            'exams_id'          => 'required|integer',
            'customers_exam_id' => 'required|integer',
        ]);

        $outsideExam = Exams::findOrFail($valid['exams_id']);
        $outsideExam->customers_exam_id = $valid['customers_exam_id'];
        $outsideExam->save();

        info('Exam matched by user', [
            'user'         => $this->user,
            'outside_code' => $outsideExam->code,
            'matched_code' => $outsideExam->matchedCode(),
        ]);

        return ['success' => true, 'message' => 'Exam mapped successfully'];
    }

    /**
     * Delete mapped exam from table.
     *
     * @param  \Illuminate\Http\Request $request
     * @return array
     */
    public function unMap(Request $request): array
    {
        $valid = $request->validate([
            'id'     => 'required|integer|exists:exams',
            'eName'  => 'nullable',
            'eDesc'  => 'nullable',
        ]);
        $exam = Exams::find($valid['id']);
        $exam->customers_exam_id = null;
        $exam->save();
        info('Exam mapping removed by user', [
            'user'        => $this->user,
            'code'        => $valid['eName'],
            'description' => $valid['eDesc'],
        ]);

        return ['success' => true, 'message' => 'Exam unmapped successfully'];
    }

    /**
     * Update customers exam record
     *
     * @param  \Illuminate\Http\Request $request
     * @return array
     */
    public function updateExam(Request $request): array
    {
        $valid = $request->validate([
            'id'       => 'required|integer|exists:customers_exam',
            'eName'    => 'required',
            'eDesc'    => 'required',
            'prevCode' => 'required',
            'prevDesc' => 'required',
        ]);

        $id          = $valid['id'];
        $code        = trim($valid['eName']);
        $description = trim($valid['eDesc']);
        $prevCode    = trim($valid['prevCode']);
        $prevDesc    = trim($valid['prevDesc']);

        CustomersExam::find($id)->update(['code' => $code, 'description' => $description]);

        info('Exam updated by user', [
            'user'                 => $this->user,
            'previous_code'        => $prevCode,
            'new_code'             => $code,
            'previous_description' => $prevDesc,
            'new_description'      => $description,
        ]);

        return ['success' => true, 'message' => 'Exam updated successfully'];
    }

    /**
     * Delete customers exam from table.
     *
     * @param  \Illuminate\Http\Request $request
     * @return array
     * @throws \Exception
     */
    public function deleteCustomersExam(Request $request): array
    {
        $valid = $request->validate([
            'id'    => 'required|integer|exists:customers_exam',
            'eName' => 'required',
            'eDesc' => 'required',
        ]);
        $id    = $valid['id'];
        $eName = $valid['eName'];
        $eDesc = $valid['eDesc'];


        CustomersExam::find($id)->delete();
        info('Exam removed by user', [
            'user'        => $this->user,
            'code'        => $eName,
            'description' => $eDesc,
        ]);

        return ['success' => true, 'message' => 'Customers exam deleted successfully'];
    }

    /**
     * Delete exam from table.
     *
     * @return array
     * @throws \Exception
     */
    public function delete(int $id): array
    {
        Exams::findOrFail($id)->delete();
        info('Exam removed by user', ['user' => $this->user]);
        return ['success' => true, 'message' => 'Customers exam deleted successfully'];
    }

    /**
     * Upload list of exams from excel file in table.
     *
     * Redirect to ExamsController@uploadedExams
     */
    public function importExcel()
    {
        if (Input::hasFile('import_file')) {
            $path = Input::file('import_file')->getRealPath();
            $data = Excel::load($path, function ($reader) {
            })->get();

            if (!empty($data) && count($data)) {
                $insert = null;
                foreach ($data as $key => $value) {
                    if (!empty($value->code) && !empty($value->description)) {
                        $insert = [
                            'code'        => trim($value->code),
                            'description' => trim($value->description),
                        ];
                        CustomersExam::create($insert);
                    }
                }
                if (!empty($insert)) {
                    info('Exams imported by user', ['user' => $this->user]); // Number of rows imported
                    return Redirect::action('ExamsController@uploadedExams');
                }
            }
        }
        return back();
    }
}
