<?php namespace ScriptSender\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use ScriptSender\Services\FeedService;
use ScriptSender\User;

class FeedController extends Controller
{
    /**
     * Register notification feeds
     * @param Request $request
     * @param FeedService $feedService
     */
    public function setFeed(Request $request, FeedService $feedService)
    {
        $this->validate($request, [
            'notifications.unread_report.enable' => 'required|in:enable,disabled',
            'notifications.unread_report.frequency' => 'required_if:notifications.unread_report.enable,enable',
            'notifications.unread_report.to' => 'required_if:notifications.unread_report.enable,enable',

            'notifications.submitted_jobs.enable' => 'required|in:enable,disabled',
            'notifications.submitted_jobs.frequency' => 'required_if:notifications.submitted_jobs.enable,enable',
            'notifications.submitted_jobs.to' => 'required_if:notifications.submitted_jobs.enable,enable',
        ]);
        $userId = $request->input('userId');
        if(empty($userId)){
            $user = Auth::user();
        }
        else {
            preg_match('/user-(\d+)/i', $userId, $match);
            $userId = $match[1];
            $user = User::findOrFail($userId);
        }
        $notifications = $request->input('notifications');
        $feedService->setNotificationFeed($user, $notifications);
    }
}
