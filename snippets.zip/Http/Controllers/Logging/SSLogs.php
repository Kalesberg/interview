<?php

namespace ScriptSender\Http\Controllers\Logging;

# If the log file is too big, we need a huge memory to hold it in array and reverse it...
ini_set('memory_limit', '1024M');

use Illuminate\Http\Request;
use ScriptSender\Http\Controllers\Controller;
use ScriptSender\Logging\CustomizeLogger;

class SSLogs extends Controller
{
    protected $linesPerPage = 20;
    private $pattern = "/\[(.+?)(?:,\d+)?\]\s*(dev|local|production)\.(INFO|WARNING):\s*(\S[^[{]+)[\[{](.*?)[\]}]\s*[\[{](.*?)[\]}]/";
    protected $log;
    protected $request;

    public function __construct(Request $request)
    {
        $this->middleware('admin');
        $logs = (new CustomizeLogger())->getLogFileNames();
        $this->log = $logs['mainLog'];
        $this->request = $request;
    }

    public function ss()
    {
        $q = $this->request->input('q');
        $fromDate = $this->request->input('from_date');
        $toDate = $this->request->input('to_date');

        $lastTimestamp = $this->request->input('lastTimestamp');
        $lastTimestamp_unix = strtotime($lastTimestamp);

        $fromDate = $fromDate ?: '1970-01-01 00:00';
        $toDate = $toDate ?: date('Y-m-d H:i:s');

        $logs = [];
        $ret = null;

        // Take lines from last upwards
        // If total lines thus collected gets greater than linesPerPage, stop collecting lines
        $lines = array_reverse(file($this->log)); // read from last line upwards
        $numRecords = 0;

        foreach ($lines as $line) {
            # Construct condition-1 if this method is called to search for log
            $cond1 = $q ? preg_match("/$q/i", $line) : 1;
            $matchesSSComponent = preg_match('/.component.:.ss./', $line);

            if ($cond1 && preg_match($this->pattern, $line, $matches) && $matchesSSComponent) {
                $numRecords++;

                [$timestamp, $appEnv, $LogLevel, $msg, $context, $metaData] = \array_slice($matches, 1);

                $timestamp_unix = strtotime($timestamp);

                # If it's a search
                if ($q) {
                    $fromDate_unix = strtotime($fromDate);
                    $toDate_unix = strtotime($toDate);

                    $cond1 = $fromDate_unix ? ($fromDate_unix <= $timestamp_unix) : 1;
                    $cond2 = $toDate_unix ? ($timestamp_unix <= $toDate_unix) : 1;

                    if ($cond1 && $cond2) {
                        $logs[] = ['timestamp' => $timestamp, 'message' => $msg . $context, 'severity' => $LogLevel];
                    }
                }
                else { # Usual realtime log
                    # If in app.js, in search functionality, createPagination() is defined, put this if outside the
                    # just-outer if-else
                    if ((count($logs) < $this->linesPerPage) && ($timestamp_unix > $lastTimestamp_unix)) {
                        $logs[] = ['timestamp' => $timestamp, 'message' => $msg . $context, 'severity' => $LogLevel];
                    }
                }
            }
        }

        if (empty($logs)) {
            $ret = 'No new data';
        }
        else {
            $logs = $this->sortWithTimestamp($logs);
            $lastTimestamp = end($logs)['timestamp']; // Get the timestamp from the last log entry

            if ($q) {
                $totalPages = 1; # Remove this if loop if in app.js, createPagination() is defined for search
            }
            else {
                $totalPages = ceil($numRecords / $this->linesPerPage);
                $lastPageLines = $numRecords - (($totalPages - 1)* $this->linesPerPage);
                $logs = \array_slice($logs, -$lastPageLines);
            }

            $ret = array('totalPages' => $totalPages, 'lastTimestamp' => $lastTimestamp, 'Logs' => $logs);
        }

        return json_encode($ret);
    }

    // Sort the given array with timestamp. The array should have 'timestamp' as a key
    // TBD: This method is identical to the one in SysteLogs.php. Put it in getLogs.php and call
    private function sortWithTimestamp($arr)
    {
        usort($arr, function ($a, $b) {
            $ad = strtotime($a['timestamp']);
            $bd = strtotime($b['timestamp']);

            if ($ad === $bd) {
                return 0;
            }
            return $ad < $bd ? -1 : 1;
        });
        return $arr;
    }

    // Method called when user clicks on a page number
    public function ssByPage($pageNo)
    {
        $lineFrom = ($pageNo - 1) * $this->linesPerPage + 1; # One line after last page's last line
        $lineTo = $pageNo * $this->linesPerPage;

        $logs = array();

        $lines = file($this->log);

        $index = $lineFrom;
        for ($ii = $lineFrom - 1; $index <= $lineTo && $ii < count($lines); $ii++) {
            $line = $lines[$ii];
            $matchesSSComponent = preg_match('/.component.:.ss./', $line);
            if (preg_match($this->pattern, $line, $matches) && $matchesSSComponent) {
                // $timestamp = $matches[1];
                // $LogLevel = $matches[3];
                // $log = $matches[4];
                [$timestamp, $appEnv, $LogLevel, $msg, $context, $metaData] = \array_slice($matches, 1);

                $logs[] = ['timestamp' => $timestamp, 'message' => trim($msg . $context), 'severity' => $LogLevel];
                $index++;
            }
        }

        $ret = array('Logs' => $logs);
        return json_encode($ret);
    }
}
