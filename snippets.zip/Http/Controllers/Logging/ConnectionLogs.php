<?php

namespace ScriptSender\Http\Controllers\Logging;

# If the ss.log is too big, we need a huge memory to hold it in array and reverse it...
ini_set('memory_limit', '1024M');

use Illuminate\Http\Request;
use Illuminate\Support\Collection;
// use Illuminate\Database\Eloquent\Collection\toSql;
use ScriptSender\Http\Controllers\Controller;
use ScriptSender\User;
use ScriptSender\Logins;
use ScriptSender\HL7Connection;
use ScriptSender\HL7ConnectionLog;
use ScriptSender\ConnectionNotification;
use ScriptSender\Connection_Logs;
use ScriptSender\HL7MessageLog;
use ScriptSender\NotificationLogs;
use DB;
use \Datetime;
use Auth;
use Carbon\Carbon;
use Log;
use ScriptSender\Services\HL7Service;
use ScriptSender\Events\HL7MsgEvent;

class ConnectionLogs extends Controller
{
    protected $linesPerPage = 20;
    protected $ConnLogPattern = '/\[(.+?)\]\s*(local|production)\.(INFO)?:(.*?)(\["connectivity"\](.*?)|\["notification"\](.*?))/'; // TBD: Inherit from getLogs.php
    protected $conn_log;
    protected $request;

    public function __construct(Request $request)
    {
        $this->middleware('admin');
        $this->conn_log = config('settings.output_paths.logs.main'); # TBD global;
        $this->request = $request;
    }

    /**
      * Save the HL7 Message
      *
      * @return array
      */
    public function saveHL7Msg(Request $request)
    {
        // to resend the hl7msg
        $conn_ID = $this->request->input('conn_ID');
        $hl7Msg = $this->request->input('hl7msg');
        $hl7log = HL7MessageLog::where('id', $conn_ID)->with('connection')->first();
        $cName  = HL7Connection::where('id', $hl7log->connection->id)->first();
        
        $HLService = new HL7Service();
        $file_path = $HLService->archive($hl7Msg, $cName->destinationPort, $cName->name);
        Log::info($file_path, ["$file_path--------------saveHL7 Message"]);
        $HLService->send($file_path, $cName->ip, $cName->destinationPort);
        return['success' => true, 'message'=> 'Resend HL7 Message successfully'];
    }
    
    /**
      * Get HL7 message from the file path passed
      *
      * @return array
      */
    public function getHl7Msg(Request $request)
    {
        $file_path = $this->request->input('file_path');
        $cid = $this->request->input('cID');
        $ret = [];
        $hl7message = HL7MessageLog::find($cid);
        $ret['msg_type'] = $hl7message->msg_type;
        $ret['ack_type'] = $hl7message->ack_type;
        if (file_exists($file_path)) {
            info('file path', ['file path' => $file_path]);
            $hl7file = fopen($file_path, "r") or die("Unable to open file!");
            $fileData = fread($hl7file, filesize($file_path));
            fclose($hl7file);
            $ret['fileName'] = $file_path;
            $ret['fileData'] = $fileData;
        } else {
            info('in file path not exists', ['path' => $file_path]);
            $ret['fileName'] = 'no file';
            $ret['fileData'] = 'No HL7 message found';
        }

        return json_encode($ret);
    }
    
    /**
      * Fetch the HL7 Message logs
      *
      * @return array
      */
    public function getHL7Logs(Request $request){
        $lastTimestamp = $this->request->input('lastTimestamp');
        $lastTimestamp = ($lastTimestamp) ? $lastTimestamp : null;
        $per_page = $request->get('per_page', 10);
        $keyword = $request->get('searchVal');
        $keyword = ($keyword) ? $keyword : null;
        
        $sDate = $request->get('sDate');
        $sDate = ($sDate) ? $sDate : null;
        $eDate = $request->get('eDate');
        $eDate = ($eDate) ? $eDate : null;
        
        $ret = array();
        
        if ($keyword!=null) {
            // DB::enableQueryLog();
            // $ret['hl7message'] = HL7MessageLog::with('connection')->where('ack', 'LIKE', '%'.$keyword.'%')->orWhere('timestamp', 'LIKE', '%'.$keyword.'%')->orderBy('timestamp', 'desc')->paginate($per_page);
            
            $ret['hl7message'] = DB::table('hl7_message_logs')
                ->select('hl7_message_logs.*', 'HL7_connections.name', 'HL7_connections.id')
                ->where('hl7_message_logs.ack', 'LIKE', '%'.$keyword.'%')
                ->orWhere('HL7_connections.name', 'LIKE', '%'.$keyword.'%')
                ->orWhere('hl7_message_logs.timestamp', 'LIKE', '%'.$keyword.'%')
                ->orderBy('hl7_message_logs.timestamp', 'desc')
                ->join('HL7_connections', 'hl7_message_logs.connection_id', '=', 'HL7_connections.id')
                ->paginate($per_page);
            // $query = DB::getQueryLog();
            // dd($query);
        } else if ($sDate!=null && $eDate!=null) {
            $ret['hl7message'] = HL7MessageLog::with('connection')->whereBetween('timestamp', [$sDate, $eDate])->orderBy('timestamp', 'desc')->paginate($per_page);
        } else {
            $ret['hl7message'] = HL7MessageLog::with('connection')->orderBy('timestamp', 'desc')->paginate($per_page);
        }
        return['response' => $ret];
    }
    
    public function getSearchData(Request $request){
        $per_page = $request->get('per_page', 10);
        $keyword = $request->get('searchVal');
        $keyword = ($keyword) ? $keyword : null;
        
        $ret = array();
            
        $ret['hl7message'] = DB::table('hl7_message_logs')
                ->select('hl7_message_logs.*', 'HL7_connections.name', 'HL7_connections.id')
                ->where('hl7_message_logs.ack', 'LIKE', '%'.$keyword.'%')
                ->orWhere('HL7_connections.name', 'LIKE', '%'.$keyword.'%')
                ->orWhere('hl7_message_logs.timestamp', 'LIKE', '%'.$keyword.'%')
                ->orderBy('hl7_message_logs.timestamp', 'desc')
                ->join('HL7_connections', 'hl7_message_logs.connection_id', '=', 'HL7_connections.id')
                ->paginate($per_page);
                
        return['response' => $ret];
    }
    
    /**
      * Get notification logs
      *
      * @return array
      */
    public function getNotificationLogs(Request $request){
        $lastTimestamp = $this->request->input('lastTimestamp');
        $lastTimestamp = ($lastTimestamp) ? $lastTimestamp : null;
        $per_page = $request->get('per_page', 10);
        
        $ret = array();
        
        $ret['notifications'] = NotificationLogs::with('connection')->orderBy('timestamp', 'desc')->paginate($per_page);
        return['response' => $ret];
    }
}
