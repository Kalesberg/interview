<?php namespace ScriptSender\Http\Controllers\Logging;

use ScriptSender\Http\Controllers\Controller;

class GetLogs extends Controller
{
    protected $systemAppLogPattern = "/\[(.+?)\]\s*local.INFO:\s*(\S.+\S)/";

    public function __construct()
    {
        $this->middleware('admin');
    }
}
