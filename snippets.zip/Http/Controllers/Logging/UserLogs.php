<?php namespace ScriptSender\Http\Controllers\Logging;

use Illuminate\Http\Request;
use ScriptSender\Http\Controllers\Controller;
use ScriptSender\User;
use ScriptSender\Logins;
use DB;

class UserLogs extends Controller
{
    protected $request;

    public function __construct(Request $request)
    {
        $this->middleware('admin');
        $this->request = $request;
    }

    // Send user logs to the client
    public function user()
    {
        $logs = null;
        $lastTimestamp = $this->request->input('lastTimestamp');

        // Get all the records from all relevant tables, where created_at is greater than last timestamp
        $qry = "SELECT * FROM 
		            (SELECT created_at, Report_Name, Created, Viewed, Downloaded, Archived, Unarchived, login_id, NULL AS user_id, NULL AS IP, 'report_activities' AS table_name FROM report_activities WHERE created_at > '$lastTimestamp') AS dummy 
		        UNION ALL
		            (SELECT created_at, NULL AS Report_Name, NULL AS Created, NULL AS Viewed, NULL AS Downloaded, NULL AS Archived, NULL AS Unarchived, NULL AS login_id, user_id, IP, 'login_details' AS table_name FROM login_details WHERE created_at > '$lastTimestamp') 
		        ORDER BY created_at";

        $logs = DB::select(DB::raw($qry));

        $ret = null;
        if (empty($logs)) {
            $ret = "No new data";
        } else {
            $ret = $this->convertDBRowToLog($logs);
        }

        return json_encode($ret);
    }

    // Get DB rows from user table, and construct a presentable log array in JSON
    private function convertDBRowToLog($logs)
    {
        $ret = array();
        $lastTimestamp = "";

        foreach ($logs as $log) {
            $message = "";

            // Logic to convert report_activity record into $message
            if ($log->table_name == "report_activities") {
                $performed = null;

                if ($log->Created) {
                    $performed = "Created";
                } elseif ($log->Viewed) {
                    $performed = "Viewed";
                } elseif ($log->Downloaded) {
                    $performed = "Downloaded";
                } elseif ($log->Archived) {
                    $performed = "Archived";
                } elseif ($log->Unarchived) {
                    $performed = "Unarchived";
                }

                $login_id = $log->login_id;
                $loginObj = Logins::findOrFail($login_id);
                $userObj = $loginObj->user;
                $user = $userObj->FirstName . " " . $userObj->LastName;

                $message = $user . " $performed '" . $log->Report_Name . "'";
            } // Logic to convert a login record into $message
            elseif ($log->table_name == "login_details") {
                $user_id = $log->user_id;
                $userObj = User::findOrFail($user_id);
                $user = $userObj->FirstName . " " . $userObj->LastName;
                $fromIP = $log->IP;
                $message = "$user Logged in from IP <span class='client-ip'>$fromIP</span>";
            }

            array_push($ret, array('timestamp' => $log->created_at, 'message' => $message));

            $lastTimestamp = $log->created_at;
        }

        $result = array('lastTimestamp' => $lastTimestamp, 'Logs' => $ret);
        return $result;
    }

    public function searchUserLogs()
    {
        $q = $this->request->input('q');
        $fromDate = $this->request->input('from_date');
        $toDate = $this->request->input('to_date');

        $fromDate = ($fromDate) ? $fromDate : '1970/01/01 00:00';
        $toDate = ($toDate) ? $toDate : date("Y/m/d H:i:s");

        // Get all the records from all relevant tables, where created_at is greater than last timestamp
        $qry = "SELECT * FROM 
		            (SELECT created_at, Report_Name, Created, Viewed, Downloaded, Archived, Unarchived, login_id, NULL AS user_id, NULL AS IP, 'report_activities' AS table_name FROM report_activities WHERE created_at > '$fromDate' AND updated_at < '$toDate') AS dummy 
		        UNION ALL
		            (SELECT created_at, NULL AS Report_Name, NULL AS Created, NULL AS Viewed, NULL AS Downloaded, NULL AS Archived, NULL AS Unarchived, NULL AS login_id, user_id, IP, 'login_details' AS table_name FROM login_details WHERE created_at > '$fromDate' AND updated_at < '$toDate') 
		        ORDER BY created_at";

        $logs = DB::select(DB::raw($qry));

        $ret = null;
        if (empty($logs)) {
            $ret = "No new data";
        } else {
            $ret = $this->convertDBRowToLog($logs);

            $Logs = array_where($ret['Logs'], function ($key, $value) use ($q) {
                if (preg_match("/$q/i", $value['message'])) {
                    return 1;
                }
            });

            $ret = array('lastTimestamp' => $ret['lastTimestamp'], 'Logs' => $Logs);
        }
        return json_encode($ret);
    }
}
