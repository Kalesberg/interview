<?php

namespace ScriptSender\Http\Controllers\Logging;

use Illuminate\Http\Request;
use DB;
use Log;
use Mail;
use File;
use Auth;
use ScriptSender\Logging\CustomizeLogger;
use ZipArchive;
use ScriptSender\Http\Controllers\Controller;
use ScriptSender\User;
use ScriptSender\Logins;
use ScriptSender\Mail\Admin\SendLogs;

class LogShare extends Controller
{
    private $RSLogPattern = "/\[(.+?)(?:,\d+)?\]\s*(dev|local|production)\.(INFO|WARNING):\s*(\S[^[{]+)(?:\[|{)/";
    private $SSLogPattern = "/\[(.+?)(?:,\d+)?\]\s*(dev|local|production)\.(INFO|WARNING|ERROR|CRITICAL|FATAL)?:\s*(\S.+?)\[.+component.:.ss./";
    protected $logFile;
    protected $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
        $logs = (new CustomizeLogger())->getLogFileNames();
        $this->logFile = $logs['mainLog'];
    }

    public function logshare()
    {
        $all_logs_file = [];
        $fromDate = $this->request->input('from_date');
        $toDate = $this->request->input('to_date');

        $lastTimestamp = $this->request->input('lastTimestamp');
        $lastTimestamp_unix = strtotime($lastTimestamp);

        $fromDate = $fromDate ?: '1970/01/01 00:00';
        $toDate = $toDate ?: date('Y/m/d H:i:s');
        $all_logs_file['share_system_logs_file'] = $this->shareSystemLogs($fromDate, $toDate, $lastTimestamp_unix);
        $all_logs_file['share_ss_logs_file'] = $this->shareSsLogs($fromDate, $toDate, $lastTimestamp_unix);
        $all_logs_file['share_user_logs_file'] = $this->shareUserLogs($fromDate, $toDate, $lastTimestamp_unix);
        if ($all_logs_file['share_system_logs_file'] || $all_logs_file['share_system_logs_file'] || $all_logs_file['share_system_logs_file']) {
            $zip_file_name = $this->zipLogs($all_logs_file);
            if ($zip_file_name) {
                $send_email = $this->sendLogsToEmail($zip_file_name);
                if ($send_email) {
                    File::delete(storage_path('logs/' . $zip_file_name));
                    return response()->json(['status' => true, 'message' => 'Logs Zip Sent Successfully.']);
                }

                return response()->json(['status' => false, 'message' => 'Count\'t Email Zip File!']);
            }

            return response()->json(['status' => false, 'message' => 'Count\'t Create Zip File!']);
        }

        return response()->json(['status' => false, 'message' => 'No Log Data Found!']);
    }

    private function shareSystemLogs($fromDate = '', $toDate = '', $lastTimestamp_unix = '')
    {
        $logs = [];

        $lines = array_reverse(file($this->logFile));
        $numRecords = 0;

        foreach ($lines as $line) {
            $matchesSSComponent = preg_match('/.component.:.ss./', $line);
            if (preg_match($this->RSLogPattern, $line, $matches) && !$matchesSSComponent) {
                $numRecords++;
                $timestamp = $matches[1];
                $log = $matches[3];

                $timestamp_unix = strtotime($timestamp);
                if ($fromDate && $toDate) {
                    $fromDate_unix = strtotime($fromDate);
                    $toDate_unix = strtotime($toDate);
                    $cond1 = $fromDate_unix ? ($fromDate_unix <= $timestamp_unix) : 1;
                    $cond2 = $toDate_unix ? ($timestamp_unix <= $toDate_unix) : 1;

                    if ($cond1 && $cond2) {
                        $logs[] = ['timestamp' => $timestamp, 'message' => trim($log)];
                    }
                }
                else {
                    if ($timestamp_unix > $lastTimestamp_unix) {
                        $logs[] = ['timestamp' => $timestamp, 'message' => trim($log)];
                    }
                }
            }
        }

        if (!empty($logs)) {
            $logs = $this->sortWithTimestamp($logs);
            return $this->createLogFiles('system', $logs);
        }

        return false;
    }

    private function shareSsLogs($fromDate = '', $toDate = '', $lastTimestamp_unix = '')
    {
        $logs = [];

        $lines = array_reverse(file($this->logFile));
        $numRecords = 0;

        foreach ($lines as $line) {
            if (preg_match($this->SSLogPattern, $line, $matches)) {
                $numRecords++;

                $timestamp = $matches[1];
                $severity = $matches[2];
                $jobSource = $matches[3];
                $jobName = $matches[4];
                $log = "$jobSource: $jobName";

                $timestamp_unix = strtotime($timestamp);
                if ($fromDate && $toDate) {
                    $fromDate_unix = strtotime($fromDate);
                    $toDate_unix = strtotime($toDate);

                    $cond1 = $fromDate_unix ? ($fromDate_unix <= $timestamp_unix) : 1;
                    $cond2 = $toDate_unix ? ($timestamp_unix <= $toDate_unix) : 1;

                    if ($cond1 && $cond2) {
                        $logs[] = ['timestamp' => $timestamp, 'message' => trim($log)];
                    }
                }
                else {
                    if ($timestamp_unix > $lastTimestamp_unix) {
                        $logs[] = ['timestamp' => $timestamp, 'message' => trim($log)];
                    }
                }
            }
        }

        if (!empty($logs)) {
            $logs = $this->sortWithTimestamp($logs);
            return $this->createLogFiles('ss', $logs);
        }

        return false;
    }

    private function shareUserLogs($fromDate = '', $toDate = '', $lastTimestamp_unix = '')
    {
        $qry = "SELECT * FROM 
                    (SELECT created_at, Report_Name, Created, Viewed, Downloaded, Archived, Unarchived, login_id, NULL AS user_id, NULL AS IP, 'report_activities' AS table_name FROM report_activities WHERE created_at > '$fromDate' AND updated_at < '$toDate') AS dummy 
                UNION ALL
                    (SELECT created_at, NULL AS Report_Name, NULL AS Created, NULL AS Viewed, NULL AS Downloaded, NULL AS Archived, NULL AS Unarchived, NULL AS login_id, user_id, IP, 'login_details' AS table_name FROM login_details WHERE created_at > '$fromDate' AND updated_at < '$toDate') 
                 ORDER BY created_at";

        $logs = DB::select(DB::raw($qry));

        if (!empty($logs)) {
            $ret = $this->convertDBRowToLog($logs);
            return $this->createLogFiles('users', $ret['Logs']);
        }

        return false;
    }

    private function convertDBRowToLog($logs)
    {
        $ret = [];
        $lastTimestamp = '';
        foreach ($logs as $log) {
            $message = '';
            if ($log->table_name === 'report_activities') {
                $performed = null;
                if ($log->Created) {
                    $performed = 'Created';
                }
                elseif ($log->Viewed) {
                    $performed = 'Viewed';
                }
                elseif ($log->Downloaded) {
                    $performed = 'Downloaded';
                }
                elseif ($log->Archived) {
                    $performed = 'Archived';
                }
                elseif ($log->Unarchived) {
                    $performed = 'Unarchived';
                }
                $login_id = $log->login_id;
                $loginObj = Logins::findOrFail($login_id);
                $userObj = $loginObj->user;
                $user = $userObj->FirstName . ' ' . $userObj->LastName;
                $message = $user . " $performed '" . $log->Report_Name . "'";
            }
            elseif ($log->table_name === 'login_details') {
                $user_id = $log->user_id;
                $userObj = User::findOrFail($user_id);
                $user = $userObj->FirstName . " " . $userObj->LastName;
                $fromIP = $log->IP;
                $message = "$user Logged in from IP $fromIP";
            }

            $ret[] = ['timestamp' => $log->created_at, 'message' => $message];

            $lastTimestamp = $log->created_at;
        }

        return ['lastTimestamp' => $lastTimestamp, 'Logs' => $ret];
    }

    private function createLogFiles($name = '', $logs = [])
    {
        $file_name = $name . '_log_' . time() . '.txt';
        $log_path = storage_path('logs/' . $file_name);
        $fp = fopen($log_path, 'w');
        foreach ($logs as $value) {
            fwrite($fp, $value['timestamp'] . ' - ' . $value['message'] . "\n");
        }
        fclose($fp);
        return $file_name;
    }

    private function zipLogs($logs = [])
    {
        $zipFile = storage_path('logs/logs_' . time() . '.zip');
        $zip = new ZipArchive();

        if ($zip->open($zipFile, ZipArchive::CREATE) !== true) {
            Log::debug('Failed to create zip object');
            return false;
        }

        Log::debug("Created zip file $zipFile");
        foreach (['share_system_logs_file', 'share_ss_logs_file', 'share_user_logs_file'] as $log) {
            $file = storage_path("logs/" . $logs[$log]);
            if (isset($logs[$log]) and is_file($file) and file_exists($file) and filesize($file) > 0) {
                $zip->addFile($file, $logs[$log]);
                # TBD: mark $logs[$log] to delete
            }
        }
        $zip->close();
        # TBD: Delete $logs[$log]
        File::delete($file);
        return $zipFile;
    }

    private function sendLogsToEmail(string $zip_file_name)
    {
        $from_email = Auth::user()->email;
        $to_email = 'logs@scriptsender.com';
        Mail::send(new SendLogs($from_email, $to_email, $zip_file_name));
        return true;
    }

    private function sortWithTimestamp($arr)
    {
        usort($arr, function ($a, $b) {
            $ad = strtotime($a['timestamp']);
            $bd = strtotime($b['timestamp']);
            if ($ad == $bd) {
                return 0;
            }
            return $ad < $bd ? -1 : 1;
        });
        return $arr;
    }
}
