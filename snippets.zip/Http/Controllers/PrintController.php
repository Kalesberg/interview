<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use Log;
use Auth;
use File;
use Illuminate\Http\JsonResponse;
use ScriptSender;
use Illuminate\Http\Request;
use ScriptSender\Services\PrintService;

class PrintController extends Controller
{
    /**
     * Delete print
     * @param Request $request
     * @return JsonResponse
     */
    public function delete(Request $request): JsonResponse
    {
        $selected_value_print = $request->input('selected_value_print');
        if (!$selected_value_print) {
            return response()->json([
                'msg' => 'No print order found. Please select print order first to delete.',
                'status' => 0
            ]);
        }

        $error = 0;
        foreach ($selected_value_print as $print_file_data) {
            if (File::delete($print_file_data['file'])) {
                info('Deleted printed file', ['file' => $print_file_data['file']]);
            }
            else {
                Log::error('Failed to deleted printed file', ['file' => $print_file_data['file']]);
                $error = 1;
            }
        }
        if ($error) {
            return response()->json([
                'msg' => 'Some problem occurred during print order delete. Please reload the page and try again.',
                'status' => 0
            ]);
        }
        return response()->json(['msg' => 'Successfully Deleted All Selected Print Orders.', 'status' => 1]);
    }

    public function reprocess(Request $request, PrintService $printService)
    {
        $validated = $request->validate([
            'filePath' => 'required'
        ]);
        info('Print Reprocess: request initiated', ['user' => Auth::user()->identity()]);
        $printService->reprocess($validated['filePath']);
        return response()->json(['msg' => 'Reprocessed Print Order']);
    }

    public function toggleStatus(Request $request, PrintService $printService)
    {
        $validated = $request->validate([
            'filePath' => 'required',
            'changeTo' => 'required|in:fail,success'
        ]);
        $printService->toggleStatus($validated['filePath'], $validated['changeTo']);
        return response()->json(['msg' => 'Changed print order status to ' . $validated['changeTo']]);
    }
}
