<?php

namespace ScriptSender\Http\Controllers;

use Illuminate\Http\Request;
use ScriptSender\Services\WebDAVInstallerService;
use ScriptSender\Services\ScriptSenderInstallerService;

/**
 * Create downloadable printer installation file
 * Class InstallerController
 * @package ScriptSender\Http\Controllers
 */
class InstallerController extends Controller
{
    /**
     * Create and Download OS-specific installer to install WebDAV network drive
     * @param WebDAVInstallerService $webDAVInstallerService
     * @return string|\Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function downloadRSInstaller(WebDAVInstallerService $webDAVInstallerService)
    {
        return $webDAVInstallerService->create(config('settings.dav_name'), 'enable_reportsender');
    }

    /**
     * Download ScriptSender OS-specific installer
     * @param Request $r
     * @param ScriptSenderInstallerService $scriptSenderInstallerService
     * @return string|\Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function downloadSSInstaller(Request $r, ScriptSenderInstallerService $scriptSenderInstallerService)
    {
        $r->validate([
            'printers.*' => 'required|alpha_dash|exists:printers,name',
            'operatingSystem' => 'nullable|string|in:windows,mac',
        ]);

        return $scriptSenderInstallerService->create($r->input('printers'), $r->input('operatingSystem'));
    }

    /**
     * Create and Download OS-specific installer to install WebDAV network drive
     * @param WebDAVInstallerService $webDAVInstallerService
     * @return string|\Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function downloadSSDavInstaller(WebDAVInstallerService $webDAVInstallerService)
    {
        return $webDAVInstallerService->create(config('settings.ss_dav_name'), 'ss_drive_installer');
    }
}
