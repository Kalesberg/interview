<?php namespace ScriptSender\Http\Controllers;

use DB;
use Auth;
use ScriptSender\User;
use ScriptSender\Rules;
use ScriptSender\Group;
use ScriptSender\Order;
use ScriptSender\Printers;
use ScriptSender\Printjobs;
use ScriptSender\HL7Connection;
use ScriptSender\ConnectionNotification;

class HomeController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Home Controller
    |--------------------------------------------------------------------------
    |
    | This controller renders "dashboard" for users that
    | are authenticated.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @internal param \Illuminate\Contracts\Auth\PasswordBroker $passwords
     */
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['getAllPrinters']]);
    }

    /**
     * Show the application dashboard to the user.
     * @return $this
     */
    public function index()
    {
        $user_id = Auth::user()->id;

        $yellowStatus = ConnectionNotification::where("notification_type", '=', "yellow_status")->first();
        $redStatus = ConnectionNotification::where("notification_type", '=', "red_status")->first();

        $notifications = [];
        $notifications['yellow_status'] = $yellowStatus;
        $notifications['red_status'] = $redStatus;

        $webOrders = (new Order())->getWebOrders()->get();
        $printOrders = Printjobs::get()->filter(function ($printJob) {
            $printerName = Printers::find($printJob['printer_id'])->name;
            return ! Printers::isReportPrinter($printerName);
        });

        // Without toBase(), rows in printOrders with same id as those in webOrders will get overwritten!
        $allOrders = $printOrders->toBase()->merge($webOrders)->sortByDesc('updated_at');
        $doc_types = [
            'Order', 'Clinical Notes', 'Lab Results','Insurance Card', 'Identification Card', 'Form A','Questionnaire'
        ];

        $customers = DB::table('customer')
            ->join('printers', 'customer.printer_id', '=', 'printers.id')
            ->select('customer.*', 'printers.id as printerId', 'printers.name as printer_name', 'printers.destination as destination')
            ->orderBy('customer.created_at', 'desc')
            ->get();
        $loginCount = DB::table('login_details')->where('user_id','=', $user_id)->count();

        return view('home')
                ->with('users', User::where('email', '!=', 'unregistered_user@scriptsender.com')->get())
                ->with('rules', Rules::all())
                ->with('printers', Printers::all())
                ->with('admin', (Auth::user()->isAdmin() || Auth::user()->isSuperAdmin()) ? 1 : 0)
                ->with('groups', Group::all())
                ->with('notification', $notifications)
                ->with('users_type', User::withRole('Server'))
                ->with('allOrders', $allOrders)
                ->with('doc_types', $doc_types)
                ->with('customers', $customers)
                ->with('loginCount', $loginCount);
    }

    public function getAllPrinters()
    {
        return Printers::with('groups')->get();
    }
}
