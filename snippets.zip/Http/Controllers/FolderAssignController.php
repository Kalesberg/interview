<?php

namespace ScriptSender\Http\Controllers;

use Illuminate\Http\JsonResponse;
use DataTables;
use ScriptSender\Services\ReportService;
use ScriptSender\User;
use ScriptSender\Folders;
use Illuminate\Http\Request;

class FolderAssignController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Process datatables ajax request. Return all folders.
     *
     * @param Request $request
     * @return JsonResponse
     * @throws \Exception
     */
    public function getFolders(Request $request): JsonResponse
    {
        $this->validate($request, [
           'userId' => 'required|integer'
        ]);
        $userId = $request->input('userId');

        $user = User::findOrFail($userId);
        $ret = collect([]);
        $assignedFoldersForThisUser = $user->folders; // Get list of folders assigned for this user

        foreach (Folders::all() as $folder) {
            $assigned = '0';
            if ($assignedFoldersForThisUser->contains('FolderId', $folder->FolderId)) {
                $assigned = '1';
            }

            $ret->push(['DT_RowId' => 'row_' . $folder->FolderId, 'name' => $folder->name, 'assigned' => $assigned]);
        }

        return Datatables::of($ret)->make(true);
    }

    /**
     * Assign/unassign folders to the given user.
     * Sync the pivot table 'folder_user' using the list of folder IDs and corresponding assign/unassign flags
     *
     * @param Request $request
     * @param ReportService $reportService
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function assignPermissions(Request $request, ReportService $reportService)
    {
        $userId = $request->input('userId');
        $folderIDs = $request->input('folderIDs');
        $folderIDs = json_decode($folderIDs, true);
        preg_match('/user-(\d+)/i', $userId, $match);
        $ID = $match[1];

        $user = User::findOrFail($ID);

        if ($request->input('assign_to_group') === 'true') {
            $user
                ->group
                ->users
                ->each(function ($user) use ($folderIDs, $reportService) {
                    $reportService->assignFoldersToUser($folderIDs, $user);
                });
        }
        else {
            $reportService->assignFoldersToUser($folderIDs, $user);
        }

        $reportService->setUserAssignedFlag($user->email);
    }
}
