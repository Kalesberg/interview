<?php

namespace ScriptSender\Http\Controllers;

use Auth;
use Log;
use Flash;
use ScriptSender\Rules;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use ScriptSender\Services\PrinterService;

class RulesController extends Controller
{
    protected $PrinterService;

    public function __construct(PrinterService $PrinterService)
    {
        $this->middleware('admin');
        $this->PrinterService = $PrinterService;
    }

    /**
     * Sync rules with database
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $rules = $request->input('data');

        // Validations:
            // If no rule is empty
            // If email IDs are valid
            // If paths are absolute
        // TBD: Use Laravel validator instead
        if (!empty($rules)) {
            foreach ($rules as $newRule) {
                if ($newRule['action'] === 'move') {
                    $destination = $newRule['destination'];
                    # As per hosted model requirement, all move rules would move files relative to SS default path.
                    # e.g., if a move rule has target as '/target1', it's converted into /var/www/Inbound/target1
                    if (isPublicServer() || isIBM()) {
                        $ssPath = Auth::user()->group->printer->destination;
                        # If user has provided absolute path by mistake, extract only the relative part
                        $destination = preg_replace("|$ssPath|", '', $destination);
                        $destination = $ssPath . '/' . $destination;
                        $destination = preg_replace('|//|', '/', $destination); # If any
                        $newRule['destination'] = $destination;
                    }
                    [$dir, $errorCode, $errorMsg, $todo] = $this->validateDir($destination);
                    if ($errorMsg) {
                        return response(json_encode(['msg' => $errorMsg, 'todo' => $todo, 'path' => $dir]), $errorCode);
                    }
                }
            }
        }

        $this->syncRules($rules);
        Flash::success('Updated all rules');
    }

    // TBD Move this method to a service
    private function syncRules($rules)
    {
        // Delete rules from DB that are not present in the incoming data
        foreach (Rules::all() as $existingRule) {
            $exists = 0;
            if (!empty($rules)) {
                foreach ($rules as $r) {
                    if ($r['DB_Id'] == $existingRule->id) {
                        $exists = 1;
                        break;
                    }
                }
            }
            if (!$exists) {
                $pattern = $existingRule->pattern;
                $action = $existingRule->action;
                $destination = $existingRule->destination;
                $existingRule->delete();
                Log::info("Deleted rule: if '$pattern', then '$action' to '$destination'");
            }
        }

        // Update existing rules, add new ones
        if (!empty($rules)) {
            foreach ($rules as $newRule) {
                $pattern = $newRule['pattern'];
                $action = $newRule['action'];
                $enabled = $newRule['enabled'];
                $destination = $newRule['destination'];
                $DB_Id = $newRule['DB_Id'];

                $rule = Rules::find($DB_Id); # Do not use findOrFail here, as the id may or may not exist.
                // If the given pattern is present, update it
                if ($rule) {
                    $msg = 'Updated';
                }
                // else, create a new rule
                else {
                    $rule = new Rules;
                    $msg = 'Added new';
                }

                $rule->pattern = $pattern;
                $rule->action = $action;
                $rule->enabled = ($enabled == 'true') ? '1' : '0';
                $rule->destination = $destination;
                $rule->save();

                Log::info("$msg rule: if '$pattern', then '$action' to '$destination'");
            }
        }
    }

    private function validateDir($dir)
    {
        $errorCode = "";
        $errorMsg = "";
        $todo = "";

        // Append '/' to the directory if not already present
        if (!preg_match('|/$|', $dir)) {
            $dir .= "/";
        }

        if (!is_dir($dir)) {
            $errorCode = 404;
            $errorMsg = "\n\nDirectory '$dir' does not exist.\nDo you want to create it?";
            $todo = 'create';
        }

        elseif ('www-data' !== $this->getOnwer($dir)) {
            $errorCode = 403;
            $errorMsg = "\n\nOwner of directory '$dir' is not 'www-data'.\nDo you want to set proper owenership and permissions?";
            $todo = 'set_permissions';
        }

        elseif (!_is_writable($dir)) {
            $errorCode = 403;
            $errorMsg = "\n\nDirectory '$dir' is not writable for user 'www-data'.\nDo you want to set proper owenership and permissions?";
            $todo = 'set_permissions';
        }

        return array($dir, $errorCode, $errorMsg, $todo);
    }

    # TBD: Move to helper
    private function getOnwer($node)
    {
        return posix_getpwuid(fileowner($node))['name'];
    }
}
