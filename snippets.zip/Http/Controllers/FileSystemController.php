<?php namespace ScriptSender\Http\Controllers;

use Auth;
use File;
use Illuminate\Http\Response;
use Log;
use ScriptSender\Services\HL7Service;
use ZipArchive;
use Illuminate\Http\Request;
use ScriptSender\Folders;
use ScriptSender\Child;
use ScriptSender\Services\ReportService;
use ScriptSender\Services\FileSystemService;

class FileSystemController extends Controller
{
    protected $basePath;
    protected $currentLogin;

    protected $reportService;
    protected $hl7Service;
    protected $request;
    protected $initialized;

    public function __construct(ReportService $reportService, HL7Service $hl7Service, Request $request)
    {
        $this->reportService = $reportService;
        $this->hl7Service = $hl7Service;
        $this->request = $request;
    }

    private function init()
    {
        if ($this->initialized === true) {
            return;
        }
        $this->currentLogin = Auth::user()->lastLogin();

        $this->basePath = config('settings.base_folder') . '/';

        $this->initialized = true;
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        if (Auth::check()) {
            $this->init();
        }
        $operation = $this->request->input('operation');

        $ret = "";
        switch ($operation) {
            case 'get_tree':
                $mode = $this->request->input('mode');    # Mode: "archived" / "active" / "all"
                $ret = $this->reportService->buildJsTree(Auth::user(), $mode);
                break;

            case 'archive':
                $IDs = $this->request->input('IDs');
                $mode = $this->request->input('mode');
                $this->reportService->archiveNodes($IDs, $this->currentLogin);
                $ret = $this->reportService->buildJsTree(Auth::user(), $mode);
                break;

            case 'unarchive':
                $IDs = $this->request->input('IDs');
                $mode = $this->request->input('mode');
                $this->reportService->unarchiveNodes($IDs, $this->currentLogin);
                $ret = $this->reportService->buildJsTree(Auth::user(), $mode);
                break;

            case 'view_request':
                $ID = $this->request->input('ID');
                // fileName will be null in case of text files, fileContent will be null in case of pdf files
                list($fileName, $fileContent) = $this->viewRequest($ID);
                $ret = json_encode(array('fileName' => $fileName, 'fileContent' => $fileContent));
                break;

            case 'mark_unread':
                $IDs = $this->request->input('IDs');
                $this->reportService->setReportAsUnseen($IDs, Auth::user());
                $ret = json_encode(array('success' => true));
                break;

            default:
                break;
        }

        return $ret;
    }

    /**
     * User selected a report and clicked on the "view" link...
     * 1) If a pdf file is requested, copy it as report_<random>.pdf under public/. This file
     * will be used by PDFJs to display the file in our modal iframe
     *    If a text file is requested, it may or may not be present in the directory. Invoke
     *    output_format converter tool to generate it.
     *
     * 2) Update the 'seen' field in DB for this report
     *
     * @return array
     * @throws \Exception
     */
    private function viewRequest($ID)
    {
        preg_match('/report-(.+)/i', $ID, $match);
        $fileName = $match[1];
        $path = $this->basePath.$fileName;

        $reportFile = $fileContent = "";

        // PDF file
        if (preg_match('/.pdf$/', $path)) {
            $randomString = generateRandomString(10);

            // Delete the existing report_<random>.pdf file and create a new one
            array_map('unlink', glob(public_path('files/report*.pdf')));
            $reportFile = "report_$randomString.pdf";
            File::copy($path, public_path("files/$reportFile"));
        }

        // Text file
        else {
            $parentPDF = preg_replace('/_HL7.+/i', '.pdf', $path);
            $this->hl7Service->convertToHL7('report', $parentPDF, Auth::user()->output_format);

            Log::info($path);
            // Read the text and send it verbatim
            $contents = File::get($path);
            $fileContent = htmlspecialchars($contents);
        }

        $this->reportService->setReportAsSeen($fileName, $this->currentLogin);
        return array($reportFile, $fileContent);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     * @throws \Exception
     */
    public function download()
    {
        if (Auth::check()) {
            $this->init();
        }

        $IDs = $this->request->input('IDs');
        $files = array();
        foreach ($IDs as $id) {
            if (preg_match('/report-(.+)/i', $id, $match)) {
                $reportName = $match[1];
                $path = $this->basePath.$reportName;
                $files[] = $path;
                // Set the 'Seen' and 'Downloaded' flag
                $this->reportService->setReportAsDownloaded($reportName, $this->currentLogin);
            }
        }

        $fileToDownload = null;

        // For multiple files, zip all together
        if (count($files) > 1) {
            $fileToDownload = public_path('files/archive.zip');
            File::delete($fileToDownload); // Remove if existing
            $zip = new ZipArchive;
            $zip->open($fileToDownload, ZipArchive::CREATE);
            foreach ($files as $file) {
                $this->hl7Service->convertToHL7('report', $file, Auth::user()->output_format);

                // From the full path, get the last two nodes, i.e. parent/report
                // This is so that when it's unzipped, it presents only the immediate parent folder and the report file
                $pathParts = explode('/', $file);
                $filename = array_pop($pathParts);
                $parentFolder = array_pop($pathParts);

                $zip->addFile($file, $parentFolder . '/' . $filename);
            }
            $zip->close();
        }
        else {
            $this->hl7Service->convertToHL7('report', $files[0], Auth::user()->output_format);
            $fileToDownload = $files[0];
        }

        return response()->download($fileToDownload);
    }

    /**
     * Create given file or directory
     *
     */
    public function create()
    {
        if (Auth::check()) {
            $this->init();
        }
        $path = $this->request->input('path');
        $permissions = $this->request->input('permissions') ?: '0770';

        $owner = $this->request->input('owner') ?: 'www-data';
        $group = $this->request->input('group') ?: 'lpadmin';
        $sudo = $this->request->input('as_sudo') ?: true;

        Log::info("'$path', '$permissions', '$owner', '$group', '$sudo'");
        /* If request is for file */
        if ('file' === $this->request->input('type')) {
            $content = $this->request->input('content') ?: '';
            $sudo
                ? writeToFileAsSudo($path, $content, 'write')
                : file_put_contents($path, $content);

            changePerms($path, $permissions, $owner, $group, $sudo);
        }

        /* If request is for directory */
        elseif ('directory' === $this->request->input('type')) {
            mkdirMinusP($path, $permissions, ['owner' => $owner, 'group' => $group], $sudo);
        }
    }

    /**
     * Set permissions to given file or directory
     *
     */
    public function set_permissions()
    {
        if (Auth::check()) {
            $this->init();
        }
        $path = $this->request->input('path');
        $permissions = $this->request->input('permissions') ?: '';

        $owner = $this->request->input('owner') ?: 'www-data';
        $group = $this->request->input('group') ?: 'lpadmin';
        $sudo = $this->request->input('as_sudo') ?: true;

        /* If request is for file */
        changePerms($path, $permissions, $owner, $group, $sudo);
    }

    // Get the folder that contains the given report
    private function getFolder($report)
    {
        $dirName = explode('/', $report);
        array_pop($dirName);
        return $dirName;
    }

    public function showSSPdf(FileSystemService $fileSystemService)
    {
        if (Auth::check()) {
            $this->init();
        }
        $this->validate($this->request, [
            'filePath' => 'required'
        ]);
        $downloadedFileName = '';
        return $fileSystemService->showFile($this->request->input('filePath'), $downloadedFileName);
    }
}
