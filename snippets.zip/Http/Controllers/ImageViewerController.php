<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use ScriptSender\Imageshare_study;
use ScriptSender\Services\FileSystemService;
use ScriptSender\Services\ImageViewerService;
use GuzzleHttp\Client;
use GuzzleHttp\TransferStats;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Cookie\CookieJar;
use Log;
use Cache;
use Agent;
use Auth;
use Illuminate\Support\Facades\Redis;
use Exception;
use ScriptSender\IPAddress;
use ScriptSender\Services\PACS\OrthancService;
use ScriptSender\Services\StudyService;
use ScriptSender\Services\UsageAuditService;
use ScriptSender\Study;
use ScriptSender\Physician;
use ScriptSender\Group;
use Illuminate\Support\Facades\DB;
use ScriptSender\Imageshare_share;
use ScriptSender\User;
use ScriptSender\Order;
use ScriptSender\Rules;
use ScriptSender\Printers;
use ScriptSender\Printjobs;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use File;
use ScriptSender\OrderStatus;
use ScriptSender\Repository\Order\OrderRepositoryInterface;
use ScriptSender\Services\OrderService;
use Illuminate\Support\Facades\Input;

class ImageViewerController extends Controller
{
    use AuthenticatesUsers;

    protected $imageViewerService;

    public function __construct(ImageViewerService $imageViewerService)
    {
        $this->imageViewerService = $imageViewerService;
    }

    // public function patient(Request $request, $pid)
    // {
    //     $data = $this->imageViewerService->patientJSON($pid);
    //     return view('image_viewer.landing_page')
    //         ->with('data', $data)
    //         ->with('type', 'patient')
    //         ->with('pid', $pid)
    //         ->with('accessionNumber', '');
    // }

    /**
     * @param string $encryptedString
     * @return RedirectResponse
     * @throws \ScriptSender\Exceptions\PACSException
     */
    public function index(string $encryptedString): RedirectResponse
    {
        $studyInstanceUid = $this->imageViewerService->getStudyInstanceUidFromEncryptedString($encryptedString);
        //$url = secure_url("imageviewer/viewer/{$studyInstanceUid}");
		$user = Auth::user();
		$physician_id = '0';
		if ($user->Privilege === 'Physician') {
			$physician = Physician::select('id')->where('user_id', $user->id)->first();
			$physician_id = $physician->id;
		}		
		$url = secure_url("imageviewer/sso/{$studyInstanceUid}/{$user->id}/{$user->Privilege}/{$user->Organization}/{$physician_id}");		
        return redirect()->to($url);
    }

    public function study(string $encryptedString)
    {
        // PID/accession/DOB/sex, e.g. 1111111/22222/19971025/F
        $urlElements = explode('/', $this->imageViewerService->decrypt($encryptedString));
        [$pid, $accession, $DOB, $sex] = array_pad($urlElements, 4, null); // pad with null if link has no DOB/sex
        Log::debug('Request from user', compact('accession', 'pid', 'DOB', 'sex'));
        $patientJSON = null;
        try {
            $patientJSON = $this->imageViewerService->patientJSON($pid, $accession, $DOB, $sex);
        }
        catch (Exception $e) {
            return response()->json(['error' => 500, 'message' => $e->getMessage()], 500);
        }

        $this->logViewerAccess('ScriptSender', $accession, $DOB, $sex);
        return [
            'typeToOpenOnLoad' => 'study', // patient / study / series / instance
            'pid' => $pid,
            'accessionNumber' => $accession,
            'patientJSON' => $patientJSON,
        ];
    }

    /**
     * @param $encryptedString
     * @return string
     * @throws Exception
     */
    public function studyTest(string $encryptedString)
    {
        $urlElements = explode('/', $this->imageViewerService->decrypt($encryptedString)); // PID/accession/DOB/sex, e.g. 1111111/22222/19971025/F
        [$pid, $accession, $DOB, $sex] = array_pad($urlElements, 4, null); // pad with null if link has no DOB/sex
        if ($this->imageViewerService->searchStudy($accession, $pid, $DOB, $sex)) {
            return 'success';
        }
        abort(500, "Study search failed for PID $pid, Accession $accession, DOB $DOB, Sex $sex");
    }

    // /**
    //  * Download image file
    //  * @param string $uuid
    //  * @return mixed
    //  */
    // public function image_file(string $uuid)
    // {
    //     return response()->file($this->imageViewerService->imageFile($uuid));
    // }

    public function reasonfordelay()
    {
        return Redis::get('image_viewer:reasonfordelay');
    }

    /**
     * @param string $studyInstanceUid
     * @return mixed
     * @throws \ScriptSender\Exceptions\PACSException
     */
    public function exportDicom(string $studyInstanceUid)
    {
        $zipFile = (new OrthancService())->createDICOMZipped($studyInstanceUid);
        return response()->download($zipFile);
    }

    /**
     * This method is specific only to NERAD.
     * When image view request arrives (i.e., when an image hyperlink is clicked on reports), the user has to be
     * redirected to Nerad's PACS server 'eRAD'. eRAD requires login, but user can't be bothered with remembering login
     * id/password etc. So this method logs-in on behalf of the user, retrieves the session-id and redirects to the
     * eRAD URL with study ACC and PID along with the login session-id. For reference on the URL (on how to pass-on
     * session id, study acc, pid etc.) check eRAD HTTP Interface Specification.
     * @param string
     * @return RedirectResponse
     * @throws \InvalidArgumentException
     */
    public function redirect_Nerad(string $encryptedString)
    {
        $base_uri = 'http://pacs.nerad.com';
        $decryptedString = $this->imageViewerService->decrypt($encryptedString); # ACCN=1111111&PAID=22222
        $url_path = '/EPVWeb/EPVWeb.jsp?' . $decryptedString;
        $session_id = Cache::remember('erad_session', 10, function () use ($callback, $base_uri, $url_path) {
            return $callback($base_uri, $url_path);
        });
        preg_match('/ACCN=(\S+?)&PAID=/', $decryptedString, $matched);
        $this->logViewerAccess('eRAD', $matched[1]);
        return redirect()->away($base_uri.$url_path."&sessionid=$session_id", 302);
    }

    /**
     * This method is specific only to NERAD.
     * Perform login to eRAD viewer and return session-id thus received.
     * Note: This login is performed using Guzzle library, but can also be performed using eRAD API, documented in eRAD
     * HTTP Interface Specification.
     *
     * @param string $base_uri
     * @param string $url_path
     * @return string
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    private function loginToNerad($base_uri, $url_path)
    {
        $username = 'medinfoapi';
        $password = 'Medinfoapi2016!';
        $ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0';
        $url = null;
        $session_id = null;

        try {
            $client = new Client([
                'base_uri' => $base_uri,
                'timeout'  => 60.0,
                'verify'   => false,
                'cookies'  => true,
            ]);

            $jar = new CookieJar;
            $client->request('GET', $url_path, [
                'headers' => [
                    'User-Agent' => $ua,
                ],
                'cookies'  => $jar,
                'on_stats' => function (TransferStats $stats) use (&$url) {
                    $url = $stats->getEffectiveUri();
                }
            ]);

            $client->request('POST', '/main/login.jsp', [
                'form_params' => [
                    'reg_user' => $username,
                    'reg_passwd' => $password,
                    'x' => '46',
                    'y' => '8',
                    'reg_dest' => str_replace('#studyview', '', $url),
                ],
                'headers' => [
                    'User-Agent' => $ua,
                ],
                'cookies' => $jar,
                'on_stats' => function (TransferStats $stats) use (&$url) {
                    $url = (string) $stats->getEffectiveUri();
                }
            ]);

            $arr = array_values(
                array_filter($jar->toArray(), function ($v) {
                    return $v['Name'] === 'sessionid';
                }, ARRAY_FILTER_USE_BOTH)
            );
            $session_id = $arr[0]['Value'];
        }
        catch (RequestException $e) {
            echo $e->getRequest();
            echo "\n\n";
            if ($e->hasResponse()) {
                echo $e->getResponse();
            }
        }

        if (empty($session_id)) {
            throw new Exception('Failed to login at eRAD');
        }
        Log::debug('Login to eRAD successful');
        return $session_id;
    }

    /**
     * Send filename of PDF report based on PID and Study ID of the study
     * @param Request $request
     * @param FileSystemService $fileSystemService
     * @return null|string
     * @throws \Exception
     */
    public function view_report(Request $request, FileSystemService $fileSystemService, StudyService $studyService)
    {
        $pid = $request->input('pid');
        $study_id = $request->input('study_id');
        // $cmd = 'perl ' . base_path('ss_toolbox/StudyManager.pm') . " --getFileName --pid=$pid --study=$study_id";
        // $report = runCmd($cmd);
        // if (empty($report)) {
        //     throw new \Exception("Study not found with pid=$pid, study id=$study_id");
        // }
        // $reportFilePath = config('settings.base_folder') . "/$report";
        // return $fileSystemService->showFile($reportFilePath);
        $pid = trim($pid, '"');
        $study_id = trim($study_id, '"');
        $reportFilePath = join_paths(config('settings.base_folder'), $studyService->findReport($pid, $study_id, true));
        return $fileSystemService->showFile($reportFilePath);
    }

    /**
     * This method allows PACS Server searching (based on Patient Name, Patient ID, Accession Number,
     * Study Date and Modality - including the use of wildcards, e.g. Betty*, *201505*, etc)
     * @param $patientName
     * @param $pid
     * @param $accession
     * @param $studydate
     * @param $modality
     * @return mixed
     * @throws \ScriptSender\Exceptions\PACSException
     */
    public function studySearch($patientName, $pid, $accession, $studydate, $modality)
    {
        return (new OrthancService())->studySearch($patientName, $pid, $accession, $studydate, $modality);
    }

    /**
     * @param string $viewer
     * @param $accession
     * @param $DOB
     * @param $sex
     */
    private function logViewerAccess(string $viewer, $accession, $DOB = null, $sex = null)
    {
        // Find local username
        // exec("wmic /node:$_SERVER[REMOTE_ADDR] COMPUTERSYSTEM Get UserName", $user);
        // dd($user[1]);

        $platform = Agent::platform();
        $platformVersion = Agent::version($platform);

        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $user = null;
        if (Auth::check()) {
            $user = Auth::user();
            $ip = $user->IP;
        } else {
            if (IPAddress::where('ip_address', $ip)->first()) {
                $user = IPAddress::where('ip_address', $ip)->first()->user;
            }
        }

        $email = $user ? $user->email : "Not Registered with IP $ip!";

        Imageshare_study::firstOrCreate(['study_id' => $accession])->setAccessed();
        (new UsageAuditService())->setCountForService('imageViewer');
        Log::info('Image viewer has been accessed', [
            'Viewer' => $viewer, 'Study' => $accession, 'DOB' => $DOB, 'sex' => $sex, 'User' => $email, 'IP' => $ip,
            'OS' => "$platform ($platformVersion)"
        ]);
    }

    /**
     * Handle an authentication attempt.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return Response
     * @throws \ScriptSender\Exceptions\PACSException
     */
    public function authenticate(Request $request)
    {
        $credentials = $request->only('email', 'password');
        $encryptedString = $request->imageshare;
        if (!empty($encryptedString)) {
            $credentials = $this->credentials($request);
            $decryptedString = $this->imageViewerService->decrypt($encryptedString);
            $id = explode('|', $decryptedString)[0];
            // If Success
            if (Auth::guard('image_share')->attempt(['id' => $id, 'password' => $credentials['password']])) {
                //return redirect('/image_viewer/share/view/' . $request->route('encrypted_string'));
                $share = Imageshare_share::getShareFromURL($encryptedString);
                $user = User::find($share->created_by);
                $studyInstanceUid = $this->imageViewerService->getStudyInstanceUidFromEncryptedString($encryptedString);
                info('Shared image viewed', [
                    'accession' => $share->study()->first()->study_id,
                    'shared_by' => $user->identity()
                ]);
                return json_encode([
                    'status' => true,
                    'user_id' => $id,
                    'Privilege' => 'Share',
                    'Organization' => $user->Organization,
                    'studyInstanceUid' => $studyInstanceUid
                ]);
            }
            return json_encode(['status' => false]);
        }
        if (Auth::attempt($credentials)) {
            // Authentication passed...
            $user = Auth::user();
            if ($user->isPhysician() || $user->isSuperAdmin()) {
                $data = [
                    'status' => true,
                    'user_id' => $user->id,
                    'Privilege' => $user->roles()->first()->role,
                    'Organization' => $user->Organization
                ];
                if ($user->isPhysician()) {
                    $physician = Physician::select('id')->where('user_id', $user->id)->first();
                    $data['physician_id'] = $physician->id;
                }
                return json_encode($data);
            }

            return json_encode(['status' => false]);
        }

        return json_encode(['status' => false]);
    }

    /**
     * Handle an study list.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return string
     */
    public function getPatientList(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|alpha',
            'organization' => 'nullable',
            'physician_id' => 'nullable|exists:study,id'
        ]);

        $type = $validated['type'];
        $organization = $validated['organization'];
        $physicianId = $validated['physician_id'];

        $patientList = [];
        if ($type === 'myStudies') {
            $study = Study::select('pid')->where('physician_id', $physicianId)->get();
        } elseif ($type === 'myGroupStudies') {
            $group = Group::select('id')->where('Name', $organization)->first();
            $study = DB::table('study')
                ->join('patients', 'study.pid', '=', 'patients.pid')
                ->join('users', 'patients.user_id', '=', 'users.id')
                ->select('study.pid')
                ->where('users.Group_id', $group->id)
                ->get();
        } elseif ($type === 'allStudies') {
            $study = Study::select('pid')->get();
        }
        foreach ($study as $key => $value) {
            if (!empty($value->pid)) {
                $patientList[] = $value->pid;
            }
        }
        return json_encode(['status' => true, 'patientList' => $patientList]);
    }

    /**
     * Remove comments from given JSON string
     *
     * @param $json
     * @return string
     */
    public function cleanJson(string $json): string
    {
        return preg_replace("#(/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+/)|([\s\t]//.*)|(^//.*)#", '', $json);
    }

    /**
     * @param Request $request
     * @return string
     */
    public function getOrderData(Request $request)
    {
        $user_id = $request->user_id;
        $user = User::find($user_id);

        $webOrders = (new Order())->getWebOrders()->get();
        $printOrders = Printjobs::get();
        // Without toBase(), rows in printOrders with same id as those in webOrders will get overwritten!
        $allOrders = $printOrders->toBase()->merge($webOrders)->sortByDesc('updated_at');
        $orderArr = [];
        if (count($allOrders) > 0) {
            foreach ($allOrders as $order) {
                if ($order->getTable() === 'printjobs') {
                    $orderArr[] = [
                        'orderType' => 'Print',
                        'patientName' => $order->order['FirstName'] . ' ' . $order->order['LastName'],
                        'RefDr' => $order->order['RefDr'],
                        'exams' => '-',
                        'queue_name' => $order->printer ? $order->printer['name'] : '-',
                        'pdfPath' => config('settings.output_paths.printOrders') . '/' . $order->Filename,
                        'user' => $order->user()->first(),
                        'orderOwner' => $user_id,
                        'org' => $user ? $user->Organization : '-',
                        'username' => $user ? "$user->FirstName $user->LastName" : '-',
                        'accession_number' => $order->order['AccessionNumber'],
                        'document_type' => $order->order['DocumentType'],
                        'template' => $order->format,
                        'orderId' => $order->order['id'],
                        'status' => $order->order['Status'],
                        'hl7SubmissionStatus' => $order->order['HL7SubmissionStatus'],
                        'ip' => $order->IP ? $order->IP : '-',
                        'created_at' => $order->created_at->format('Y-m-d')
                    ];
                } else {
                    $orderArr[] = [
                        'orderType' => 'Web',
                        'patientName' => $order->FirstName . ' ' . $order->LastName,
                        'RefDr' => $order->RefDr,
                        'exams' => is_array($order->modalities) ? implode(', ', $order->modalities) : $order->modalities,
                        'queue_name' => '-',
                        'pdfPath' => $order->fileURL,
                        'orderOwner' => $user->FirstName . ' ' . $user->LastName,
                        'org' => $order->RefDrPractice,
                        'username' => $order->RefDr,
                        'accession_number' => $order->AccessionNumber,
                        'document_type' => $order->DocumentType,
                        'template' => '-',
                        'orderId' => $order->id,
                        'status' => $order->Status,
                        'hl7SubmissionStatus' => $order->HL7SubmissionStatus,
                        'ip' => $order->IP ? $order->IP : '-',
                        'created_at' => $order->created_at->format('Y-m-d')
                    ];
                }
            }
        }
        $doc_types = [
            'Order',
            'Clinical Notes',
            'Lab Results',
            'Insurance Card',
            'Identification Card',
            'Form A',
            'Questionnaire'
        ];

        $customers = DB::table('customer')
            ->join('printers', 'customer.printer_id', '=', 'printers.id')
            ->select('customer.*', 'printers.id as printerId', 'printers.name as printer_name',
                'printers.destination as destination')
            ->orderBy('customer.created_at', 'desc')
            ->get();
        $loginCount = DB::table('login_details')->where('user_id', '=', $user_id)->count();
        $allusers = User::where('email', '!=', 'unregistered_user@scriptsender.com')->get();
        $dataArr = [
            'users' => $allusers,
            'rules' => Rules::all(),
            'printers' => Printers::all(),
            'admin' => ($user->isAdmin() || $user->isSuperAdmin()) ? 1 : 0,
            'allOrders' => $orderArr,
            'doc_types' => $doc_types,
            'customers' => $customers,
            'loginCount' => $loginCount
        ];
        return json_encode(['status' => true, 'data' => $dataArr]);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteOrder(Request $request)
    {
        $selected_value_print = $request->input('selected_value_print');

        if (!$selected_value_print) {
            return response()->json([
                'msg' => 'No print order found. Please select print order first to delete.',
                'status' => 0
            ]);
        }
        $error = 0;
        foreach ($selected_value_print as $print_file_data) {
            if (File::delete($print_file_data)) {
                info('Deleted printed file', ['file' => $print_file_data]);
            } else {
                Log::error('Failed to deleted printed file', ['file' => $print_file_data]);
                $error = 1;
            }
        }
        if ($error) {
            return response()->json([
                'msg' => 'Some problem occurred during print order delete. Please reload the page and try again.',
                'status' => 0
            ]);
        }
        return response()->json(['msg' => 'Successfully Deleted All Selected Print Orders.', 'status' => 1]);
    }
    /**
     * @param  Request $request Post fields data
     * @param  FileSystemService $fileSystemService used file system service to process file
     * @return string
     * @throws \ScriptSender\Exceptions\FileAndDirectoryException
     */
    public function viewOrderPDF(Request $request, FileSystemService $fileSystemService)
    {
        //return $request->filePath;
        // $downloadedFileName = '';
        //return $request->filePath;
        if (file_exists($request->filePath)) {
            return json_encode(['status' => true, 'data' => $fileSystemService->showFile($request->filePath)]);
        }

        return json_encode(['status' => false, 'data' => 'File does not exist or has been moved.']);
        //return $fileSystemService->showFile($request->filePath);
    }
    /**
     * Create Order.
     *
     * @param \Illuminate\Http\Request $request Post fields data
     *
     * @return string
     */
    public function createOrder(Request $request)
    {
        try{
            $user_id = $request->input('user_id');
            $form_id = $request->input('form_id');
            $form_data = json_decode($request->input('form_data'));
            $form_id || abort('form_id variable empty!');
            /* $validator = Validator::make($form_data, $this->orderService->rules); */
            /* if ($validator->errors() && !empty($validator->errors()->messages())) {
                return response()->json($validator->errors(), 400);
            } */
            $ordersPath = storage_path('orders/');
            $orderFile = (new orderService())->generateNameForOrderFile($ordersPath);
            if (!$orderFile) {
                abort("Couldn't generate a random number to create order file");
            }
            mkdirMinusP($ordersPath);
            $pdfFile = (new orderService())->convertHTMLIntoPDF($request->input('pdf_html'));
            File::move($pdfFile, $ordersPath . $orderFile);
            $attachments_folder = null;
            $attachments_temp_folder = storage_path("orders/attached_files/temp/$form_id");
            // We are removing .pdf extension to create name of the folder same as file name
            if (File::exists($attachments_temp_folder) && count(glob("$attachments_temp_folder/*")) !== 0) {
                $attachments_folder = storage_path('orders/attached_files/' . basename($orderFile, '.pdf') . '/');
                File::move($attachments_temp_folder, $attachments_folder);
            }
            $order = $this->order->saveOrder($ordersPath . $orderFile, $attachments_folder, $form_data->addCC, $form_data->bpBtn, $form_data->modalityBtn, $form_data->prArr);
        } catch (RequestException $e) {
            return 'error';
        }
        if (preg_match('/Submit|save/i', $request->input('button'))) {
            (new UsageAuditService())->setCountForService('webOrder');
        } else {
            // If button is 'download'
            // Delete the existing report_<random>.pdf file and create a new one
            array_map('unlink', glob(public_path('files/order*.pdf')));
            File::copy($pdfFile, public_path("files/$orderFile"));
        }
        info('Added new order', ['user' => $user_id]);
        return response()->json(['message' => 'Order added successfully'], 200);
    }
    /**
     * Returns order settings.
     *
     * @param \Illuminate\Http\Request $request Post fields data
     *
     * @return string
     */
    public function getOrdersSettings(Request $request)
    {
        $user_id = $request->input('user_id');
        $dataArr = array("user" => User::find($user_id),
            "locations" => $this->order->locations(),
            "modalities" => $this->order->modalities(),
            "bodyparts" => $this->order->getBodyParts()
        );
        return json_encode(['status' => true, 'data' => $dataArr]);
    }
    /**
     * Returns Bodyparts.
     *
     * @param \Illuminate\Http\Request $request Post fields data
     * 
     * @return string
     */
    public function getBodyparts(Request $request) 
    {
        $locations = $request->input('locations');
        return json_encode(['status' => true, 'data' => $this->order->getBodyParts($locations)]);
    }
    /**
     * Returns ICD codes in JSON string
     *
     * @return string
     */
    public function getICDCodes()
    {
        $results = array();
        $query = "SELECT * FROM icd10s";
        $codes = DB::select(DB::raw($query));
        foreach ($codes as $code) {
            $results[] = $code->description;
        }
        return json_encode(['status' => true, 'data' => $results]);
    }
}
