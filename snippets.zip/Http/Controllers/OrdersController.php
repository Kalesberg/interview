<?php

namespace ScriptSender\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;
use ScriptSender\Order;
use ScriptSender\OrderStatus;
use ScriptSender\Printjobs;
use ScriptSender\Repository\Order\OrderRepositoryInterface;
use ScriptSender\Services\OrderService;
use ScriptSender\Services\UsageAuditService;
use Auth;
use File;
use Flash;
use Validator;

class OrdersController extends Controller
{
    protected $order;
    protected $orderService;

    /**
     * OrdersController constructor.
     * @param OrderRepositoryInterface $order
     * @param OrderService $orderService
     */
    public function __construct(OrderRepositoryInterface $order, OrderService $orderService)
    {
        $this->order = $order;
        $this->orderService = $orderService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return View
     * @return $this
     */
    public function index(): View
    {
        $view = isReno() ? 'orders.orders_Reno' : 'orders.orders';
        return view($view)
            ->with('user', auth()->user())
            ->with('locations', $this->order->locations())
            ->with('modalities', $this->order->modalities())
            ->with('bodyparts', $this->order->getBodyParts());
    }

    /**
     * @param Request $request
     * @param $form_id
     * @return JsonResponse
     * @throws \Symfony\Component\HttpFoundationFile\ExceptionFileException
     */
    public function uploadFiles(Request $request, $form_id): JsonResponse
    {
        $form_id || abort(400, 'form_id variable empty!');
        $attachmentsPath = storage_path("orders/attached_files/temp/$form_id/");
        $fileName = $request->file('orderAttachment')->getClientOriginalName();
        $request
            ->file('orderAttachment')
            ->move($attachmentsPath, $fileName);

        return response()->json(['files' => [['name' => $fileName]]]);
    }

    /**
     * @param Request $request
     * @return bool|JsonResponse|string
     * @throws \InvalidArgumentException
     * @throws \ScriptSender\ExceptionsFileAndDirectoryException
     */
    public function store(Request $request)
    {
        $form_id = $request->input('form_id');
        $form_data = $request->input('form_data');

        $form_id || abort(400, 'form_id variable empty!');

        $validator = Validator::make($form_data, $this->orderService->rules);

        if ($validator->errors() && !empty($validator->errors()->messages())) {
            return response()->json($validator->errors(), 400);
        }

        $ordersPath = storage_path('orders/');

        $orderFile = $this->orderService->generateNameForOrderFile($ordersPath);

        if (!$orderFile) {
            abort(500, "Couldn't generate a random number to create order file");
        }

        mkdirMinusP($ordersPath);

        $pdfFile = $this->orderService->convertHTMLIntoPDF($request->input('pdf_html'));

        File::move($pdfFile, $ordersPath . $orderFile);

        $attachments_folder = null;
        $attachments_temp_folder = storage_path("orders/attached_files/temp/$form_id");

        // We are removing .pdf extension to create name of the folder same as file name
        if (File::exists($attachments_temp_folder) && count(glob("$attachments_temp_folder/*")) !== 0) {
            $attachments_folder = storage_path('orders/attached_files/' . basename($orderFile, '.pdf') . '/');
            File::move($attachments_temp_folder, $attachments_folder);
        }

        $this->order->saveWebOrder(
            $ordersPath . $orderFile,
            $attachments_folder,
            $form_data['codeArr'],
            $form_data['prArr'],
            $form_data['modalityBtn'],
            $form_data['bpBtn'],
            $form_data['addCC']
        );

        if (preg_match('/Submit|save/i', $request->input('button'))) {
            (new UsageAuditService())->setCountForService('webOrder');
            Flash::success('Order added successfully');
        }
        else {
            // If button is 'download'
            // Delete the existing report_<random>.pdf file and create a new one
            array_map('unlink', glob(public_path('files/order*.pdf')));
            File::copy($pdfFile, public_path("files/$orderFile"));
            return $orderFile;
        }
        info('Added new order', ['user' => Auth::user()->identity()]);
        return response()->json(['message' => 'Order added successfully'], 200);
    }

    /**
     * @param $locations
     * @return JsonResponse
     */
    public function bodyParts($locations): JsonResponse
    {
        return response()->json($this->order->getBodyParts($locations));
    }

     /**
     * Delete given order and related files, if any
     * @param Request $request
     * @return JsonResponse
     */
    public function delete(Request $request): JsonResponse
    {
        $selected_web_order = $request->input('selected_value_web');
        if ($selected_web_order) {
            $error = false;
            foreach ($selected_web_order as $id) {
                $order = $this->order->findOrderByID($id);
                if (File::delete($order->fileURL)) {
                    File::deleteDirectory($order->AttachmentsPath);
                    $this->order->deleteOrder($order->id);
                    info('Deleted Order', ['order_id' => $order->id, 'user' => Auth::user()->identity()]);
                }
                else {
                    $error = true;
                }
            }
            if (!$error) {
                return response()->json(['msg' => 'Successfully Deleted All Selected Orders.', 'status' => 1]);
            }

            return response()->json([
                'msg' => 'Some Problem Occurred During Order Delete. Please reload the page and try again.',
                'status' => 0
            ]);
        }

        return response()->json([
            'msg' => 'No web order found. Please select web order first to delete.',
            'status' => 0
        ]);
    }

    /**
     * Assign accession number to web order
     * @param $id
     * @param Request $request
     * @return JsonResponse
     */
    public function assignAccession($id, Request $request): JsonResponse
    {
        $accNumber = $request->input('accession_number');
        $docType   = $request->input('document_type');

        $this->order->assignAccessionNumberToOrder($id, $accNumber, $docType);

        return response()->json(['message' => 'accession number assigned'], 200);
    }

    public function changeStatus(int $id, Request $request)
    {
        $validated = $request->validate([
            'status' => 'required|exists:order_status,status',
        ]);
        $order = Order::find($id) ?? Printjobs::find($id);
        $status = OrderStatus::where('status', $validated['status'])->first();
        $order->status()->associate($status);
        $order->save();
        info('Changed order status', [
            'user' => Auth::user()->identity(), 'order' => $id, 'status' => $validated['status']]);
    }

    public function comment(int $id, Request $request)
    {
        $validated = $request->validate([
            'comment' => 'nullable',
        ]);
        Order::findOrFail($id)->update(['AddNotes' => $validated['comment']]);
        info('Updated order comment', [
            'user' => Auth::user()->identity(), 'order' => $id, 'comment' => $validated['comment']]);
    }
}
