<?php

namespace ScriptSender\Http\Controllers;

use Hash;
use Log;
use Redis;
use Sabre\DAV;
use Sabre\DAV\Auth\Backend\BasicCallBack;
use Sabre\DAV\Auth\Plugin as AuthPlugin;
use Sabre\DAV\Collection;
use Sabre\DAV\FS;
use Jenssegers\Agent\Agent;

// require __DIR__ . '/../../vendor/autoload.php';

// The autoloader
// use Illuminate\Contracts\Console\Kernel;
// require __DIR__.'/../../bootstrap/autoload.php';
// $app = require __DIR__.'/../../bootstrap/app.php';
// $app->make(Kernel::class)->bootstrap();
# ------------------------------------------------------------------------
use Carbon\Carbon;
use Sabre\DAV\Server;
use ScriptSender\User;
use ScriptSender\Logins;
use ScriptSender\Services\ReportService;
use ScriptSender\Services\HL7Service;
use ScriptSender\Report_Activities;
use Exception;

class HomeCollection extends Collection
{
    protected $basePath;
    protected $authPlugin;
    protected $output_formats;
    protected $user;

    public function __construct($base_folder, $output_formats, AuthPlugin $authPlugin = null)
    {
        $this->basePath = $base_folder;
        if ($authPlugin) {
            $this->authPlugin = $authPlugin;
        }
    }

    /**
     * {@inheritdoc}
     * @return array
     * @throws Exception
     */
    public function getChildren()
    {
        $this->user = getUser($this->authPlugin);
        $folders = $this->user
            ->folders()
            ->get()
            ->map(function ($folder) {
                return "$this->basePath/$folder->path";
            })
            ->all();
Log::debug($this->user->email);
        $reportPaths = [];
        foreach ($folders as $subFolder) {
            // 'Server' type users need to have all files under a single large directory instead of doctor-by-doctor
            // folders. Simulate this by returning array of Dav/File classes for each file instead of Dav/Directory
            // classes.
            if ($this->user->isServer()) {
                // (new HL7Service())->convertToHL7($subFolder, $this->user->output_format);
                $paths = $this->user
                    ->getActiveReportsInDirectory($subFolder, true)
                    ->map(function ($name) {
                        return new MyFile($name, $this->output_formats, $this->user);
                    })
                    ->toArray();
                $reportPaths = array_merge($reportPaths, $paths);
            }
            else {
                array_push($reportPaths, new MyDirectory($subFolder, $this->output_formats, $this->user));
            }
        }
        return $reportPaths;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return '';
    }
}

/**
 * Class to handle Directory operations - e.g., listing files.
 * Overrides FS\Directory class, to add additional logic to monitor and control directory handling
 * Class MyDirectory
 */
class MyDirectory extends FS\Directory
{
    protected $output_formats;
    protected $user;

    public function __construct($path, $output_formats, $currentUser)
    {
        $this->user = $currentUser;
        $this->output_formats = $output_formats;
        parent::__construct($path);
    }

    /**
     * Make the dav share read-only
     * {@inheritdoc}
     * @throws DAV\Exception\Forbidden
     */
    public function createFile($name, $data = null) {
        throw new DAV\Exception\Forbidden('File creation not allowed here!');
    }

    /**
     * Returns an array with all the child nodes
     *
     * {@inheritdoc}
     * @return DAV\INode[]
     */
    public function getChildren()
    {
        $reportPaths = $this->user
            ->getActiveReportsInDirectory($this->path)
            ->map(function ($reportPath) {
                return $this->getChild(basename($reportPath));
            })
            ->toArray();
        return $reportPaths;
    }

    /**
     * {@inheritdoc}
     * @param string $name
     * @return MyDirectory|MyFile
     * @throws DAV\Exception\NotFound
     */
    public function getChild($name)
    {
        $path = $this->path . '/' . $name;
        if (!file_exists($path)) {
            throw new DAV\Exception\NotFound('File with name ' . $path . ' could not be located');
        }

        if (is_dir($path)) {
            return new MyDirectory($path, $this->output_formats, $this->user);
        }
        return new MyFile($path, $this->output_formats, $this->user);
    }
}

/**
 * Class to handle File operations - delete, download, list etc.
 * Overrides FS\File class, to add additional logic to monitor and control file handling
 * Class MyFile
 */
class MyFile extends FS\File
{
    protected $currentUser;
    protected $reportService;

    public function __construct($path, $output_formats, $currentUser)
    {
        $this->output_formats = $output_formats;
        $this->currentUser = $currentUser;
        $this->reportService = new ReportService();
        parent::__construct($path);
    }

    /**
     * Delete the current file
     *
     * Overridden from FS\File, so that instead of deleting, we can mark it archived and log the activity in database.
     * If multiple files are selected to be deleted, this method gets called once for each node.
     *
     * We can't just archive the file! After calling delete() method, SabreDav does some followup to remove the entry
     * from the client. It maintains it's own database of file and their properties etc. If the file is not actually
     * deleted, sabreDAV fails. So we need to fake a delete -
     *
     * This operation is same as done in FileSystemController.php. So this has to be generalized as a refactoring step!
     * @return void
     */
    public function delete()
    {
        $this->reportService->archiveNodes(['report-' .$this->path], $this->getCurrentLogin());
    }

    /**
     * Download file
     * @return string
     * @throws \Exception
     */
    public function get()
    {
        $reportName = $this->reportService->fileNameToReportName($this->path);
        $currentLogin_Id = $this->getCurrentLogin()->id;

        # If an entry already exists for this report, that is, if the user already viewed/downloaded this file earlier
        $report_activity = Report_Activities::where([['Report_Name', $reportName], ['login_id', $currentLogin_Id]])
            ->get()
            ->first();

        if ($report_activity) {
            $report_activity->Downloaded ++;
            $report_activity->Seen = 1;
            $report_activity->save();
        }
        else {
            $now = now()->toDateTimeString();
            Report_Activities::insert([
                'Report_Name' => $reportName,
                'Downloaded' => 1,
                'Seen' => 1,
                'login_id' => $currentLogin_Id,
                'created_at' => $now,
                'updated_at' => $now
            ]);
        }

        if ($this->currentUser->isServer()) {
            $parentPDF = preg_replace('/_HL7.+/i', '.pdf', $this->path);
            if (!empty($this->currentUser)) {
                (new HL7Service())->convertToHL7($parentPDF, $this->currentUser->output_format);
            }
        }

        return parent::get();
    }

    private function getCurrentLogin()
    {
        return $this->currentUser->lastLogin();
    }

    /**
     * {@inheritdoc}
     */
    public function getLastModified()
    {
        if (!file_exists($this->path)) {
            return null;
        }
        return parent::getLastModified();
    }

    /**
     * {@inheritdoc}
     */
    public function getSize()
    {
        if (!file_exists($this->path)) {
            return null;
        }
        return parent::getSize();
    }

    /**
     * {@inheritdoc}
     */
    public function getETag()
    {
        if (!file_exists($this->path)) {
            return null;
        }
        return parent::getETag();
    }
}

class DAVController extends Controller
{
    public function index()
    {
        $base_path = config('settings.base_folder');
        $davName = config('settings.dav_name');
        $output_formats = output_formats();

        # Logic to authenticate user.
        # User gets authenticated when the closure returns true.
        $authBackend = new BasicCallBack(function ($username, $password)
        {
            $user = User::where('email', $username)->get()->first();
            return Hash::check($password, $user->password);
        });

        $authPlugin = new AuthPlugin($authBackend); # 'SabreDAV' This is the 'realm' name. parameterize it
        $rootNode = new HomeCollection($base_path, $output_formats, $authPlugin);

        $server = new Server($rootNode);

        $server->setBaseUri("/dav1/");
        $server->addPlugin($authPlugin);
        $server->addPlugin(new DAV\Browser\Plugin());

        ob_start();
        $server->exec();
        $status = $server->httpResponse->getStatus();
        $content = ob_get_contents();
        ob_end_clean();

        return response($content, $status);
    }
}

function getUser($authPlugin)
{
    $principal = $authPlugin->getCurrentPrincipal();
    if (empty($principal)) {
        return null;
    }
    $user = null;
    if ($currentUserEmail = (explode("/", $principal))[1]) {
        $user = User::where('email', $currentUserEmail)->get()->first();
        if (!$user) {
            throw new Exception("Email '$currentUserEmail' not found in Database'");
        }
    }
    return $user;
}
