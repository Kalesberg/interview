<?php

namespace ScriptSender\Http\Controllers;

use ScriptSender\Location;
use Illuminate\Http\Request;

class LocationsController extends Controller
{

    protected $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    public function index()
    {
        //
        /*
         * Begin add for orders.
         */
        $locations = Location::all();

        return view('orders.locations')
            ->with('locations', $locations);
    }


    public function create(Request $data)
    {
        $loc = new Location();
        $loc->SiteName = $data['SiteName'];
        $loc->Address = $data['Address'];
        $loc->City = $data['City'];
        $loc->State = $data['State'];
        $loc->Zip = $data['Zip'];
        $loc->Country = "USA";
        $loc->save();
        return back();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //return $request->all();
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $location = Location::find($id);
        $exam = $location->exams->first();
        $bp = $exam->bodyparts->first();
        return $bp->procs;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     * @return \Illuminate\Http\Response
     * @internal param Request $request
     * @internal param int $id
     */
    public function update()
    {
        $locationId = $this->request->input('locationId');
        $newData = $this->request->input('newData');

        $location = Location::findOrFail($locationId);

        foreach ($newData as $key => $value) {
            $location->$key = $value;
        }

        $location->save();
        return back();
    }

    /**
     * Remove the specified resource from storage.
     * @return \Illuminate\Http\Response
     * @internal param int $id
     */
    public function destroy()
    {
        $locationId = $this->request->input('locationId');

        preg_match('/(\d+)/i', $locationId, $match);
        $locationId = $match[1];
        // Will return a ModelNotFoundException if no user with that id
        try {
            $location = Location::findOrFail($locationId);
        } // catch(Exception $e) catch any exception
        catch (ModelNotFoundException $e) {
            dd(get_class_methods($e)); // lists all available methods for exception object
            dd($e);
        }

        // TBD: Remove this once main.js doesn't send the previously deleted userID anymore
        if (!$location) {
            return "";
        }

//		$name = $user->FirstName . " " . $user->LastName;
//		$email = $user->email;

        $location->delete();
    }

    public function getLocationInfo()
    {
        $ret = array();

        $locationId = $this->request->input('locationId');

        preg_match('/(\d+)/i', $locationId, $match);
        $locationId = $match[1];

        $location = Location::findOrFail($locationId);

        $arr = array('SiteName', 'Address', 'City', 'State', 'Zip', 'Country');

        foreach ($arr as $key) {
            $ret[$key] = $location->$key;
        }

        // TBD: error: $ret["Error"] = "<error message>";
        return json_encode($ret);
    }
}
