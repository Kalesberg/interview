<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use Auth;
use Mail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use ScriptSender\Imageshare_study;
use ScriptSender\Imageshare_share;
use ScriptSender\Services\ImageViewerService;
use ScriptSender\Services\PACS\OrthancService;
use ScriptSender\Services\SMSService;
use ScriptSender\Mail\ImageViewer\ImageShared;
use ScriptSender\User;

/**
 * Class ImageShareController
 * @package ScriptSender\Http\Controllers
 */
class ImageShareController extends Controller
{
    protected $imageViewerService;

    /**
     * ImageShareController constructor.
     * @param ImageViewerService $imageViewerService
     */
    public function __construct(ImageViewerService $imageViewerService)
    {
        $this->imageViewerService = $imageViewerService;
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     * @throws \ScriptSender\Exceptions\PACSException
     */
    public function create(Request $request)
    {
        $validatedData = $request->validate([
            'studyInstanceUID' => 'required',
            'email'     => 'required|email',
            'mobile'    => 'nullable',
            'password'  => 'required',
            'message'   => 'required',
            'duration'  => 'required|integer',
            'url'       => 'required',
        ]);

        // auth()->setUser(User::find(1)); // TODO: Hardcoded for show in March, 2018
        $user = Auth::user();
        $studyJson = (new OrthancService())->getStudyFromUid($validatedData['studyInstanceUID']);
        $pid = $studyJson['PatientMainDicomTags']['PatientID'];
        $accession = $studyJson['MainDicomTags']['AccessionNumber'];

        $target_email = $validatedData['email'];
        $password = $validatedData['password'];
        $imageshareMessage = $validatedData['message'];
        $imageshareMobile = $validatedData['mobile'] ?? null;
        $duration = $validatedData['duration'];
        $url = $validatedData['url'];

        // If a study/image Share was not already created in the DB, create it
        $study = Imageshare_study::where('pid', $pid)->where('study_id', $accession)->first();
        if (!$study) {
            $study = new Imageshare_study([
                'pid'                   => $pid,
                'study_id'              => $accession,
                'study_description'     => $studyJson['MainDicomTags']['StudyDescription'],
                'study_date'            => new Carbon($studyJson['MainDicomTags']['StudyDate']),
            ]);
            $study->save();
            info('Study registered', ['study_id' => $accession, 'user' => $user->identity()]);
        }

        // Now create the sharing.
        // A sharing can happen multiple times for a given share details (created or retrieved in the above step)
        $shareShare = new Imageshare_share([
            'target_patient_email'  => $target_email,
            'password'              => bcrypt($password),
            'duration'              => $duration,
            'expires_at'            => now()->addDays($duration)->toDateTimeString(),
            'message'               => $imageshareMessage,
            'mobile'                => $imageshareMobile,
        ]);
        $shareShare->sharer()->associate($user);
        $shareShare->study()->associate($study);
        $shareShare->save();

        if ($imageshareMobile) {
            $smsText = 'A study has been shared with you from ' . $user->identity() .
                ' via email. Please click the link provided in the email and enter this password: ' . $password;
            (new SMSService())->sms($imageshareMobile, $smsText);
        }

        // Send email to target user with the URL
        // Include share in the encrypted URL. This will be required when the link is viewed
        // $shareLink = secure_url('/image_viewer/share/view/' .
        //     urlencode($this->imageViewerService->encrypt($shareShare->id . "|$pid/$accession")));
        $shareLink = $url . '/imageviewer/login/'.urlencode($this->imageViewerService->encrypt($shareShare->id . "|$pid/$accession"));
        Mail::send(new ImageShared($target_email, $shareLink, $imageshareMessage));
        info('Image Share created', [
            'share_id' => $shareShare->id, 'created_by' => $user->identity(), 'shared_with' => $target_email]);
        return response('Share created successfully');
    }
    /**
     * Rshare study.
     *
     * @param \Illuminate\Http\Request $request Post fields data
     *
     * @return string
     */
    public function reshare(Request $request)
    {
        $this->validate($request, [
            'imageShareEmail' => 'required|email',
            'imageSharePassword' => 'required',
            'imageShareMessage' => 'required|alpha_num',
            'duration' => 'required|integer',
        ]);
        try {
            $share_id = $request->shareID;
            $study = Imageshare_share::findOrFail($share_id)->study()->first();

            $pid = $study->pid;
            $accession = $study->study_id;
            $target_email = $request->imageShareEmail;
            $password = $request->imageSharePassword;
            $message = $request->imageShareMessage;
            $duration = $request->duration;
            $imageShareMobile = $request->imageShareMobile;
            $user_id = $request->user_id;
            $url = $request->url;

            // Now create the sharing
            // A sharing can happen multiple times for a given share details (created or retrieved in the above step)
            $shareShare = new Imageshare_share([
                'target_patient_email' => $target_email,
                'password' => bcrypt($password),
                'duration' => $duration,
                'expires_at' => now()->addDays($duration)->toDateTimeString(),
                'message' => $message,
            ]);
            $user = User::find($user_id);
            $shareShare->sharer()->associate($user);
            $shareShare->study()->associate($study);
            $shareShare->save();

            // Send email to target user with the URL
            // Include share in the encrypted URL. This will be required when the link is viewed
            $shareLink = $url . '/login/' . base64_encode($share_id);
            /* $shareLink = secure_url('/image_viewer/share/view/' .
                urlencode($this->imageViewerService->encrypt($shareShare->id . "|$pid/$accession"))); */
            Mail::send(new ImageShared($target_email, $shareLink, $message));
            info('Image reshared', [
                'share_id' => $share_id,
                'created_by' => $user->identity(),
                'shared_with' => $target_email
            ]);
            return json_encode(['status' => true, 'data' => $shareLink]);
        }
        catch (Exception $e) {
            return response()->json(['error' => 500, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Cancel the given image share
     *
     * @param Request $request
     * @return string
     */
    public function cancel(Request $request): string
    {
        $share_id = $request->share_id;
        $share = Imageshare_share::findOrFail($share_id);
        $share->active = '0';
        $share->save();
        $user_id = $request->user_id;
        $user = User::find($user_id);
        info('Image share canceled', ['share_id' => $share_id, 'user' => $user->identity()]);
        return json_encode(['status' => true, 'data' => $share]);
    }

    /**
     * Change duration of the given image share
     *
     * @param  Request $request
     * @return string
     */
    public function updateDuration(Request $request): string
    {
        $share_id = $request->share_id;
        $new_duration = $request->new_duration;
        $share = Imageshare_share::findOrFail($share_id);
        $share->duration = $new_duration;
        $share->expires_at = now()->addDays($new_duration)->toDateTimeString();
        $share->save();
        $user_id = $request->user_id;
        $user = User::find($user_id);
        info('Duration for share ID changed', [
            'share_id' => $share_id,
            'new_duration' => $new_duration,
            'user' => $user->identity()
        ]);
        return json_encode(['status' => true, 'data' => $share]);
    }

    /**
     * @param string $encryptedString
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \ScriptSender\Exceptions\PACSException
     */
    public function view(string $encryptedString)
    {
        $share = Imageshare_share::getShareFromURL($encryptedString);
        $user = User::find($share->created_by);
        $studyInstanceUid = $this->imageViewerService->getStudyInstanceUidFromEncryptedString($encryptedString);
        info('Shared image viewed', [
            'accession' => $share->study()->first()->study_id, 'shared_by' => $user->identity()]);
        return redirect()->to("http://demo.scriptsender.com:3000/viewer/$studyInstanceUid");
    }

    /**
     * @return string
     */
    public function getImageShareData()
    {
        $imageShareData = Imageshare_share::all();
        $index = 1;
        $dataArr = [];
        if (count($imageShareData) > 0) {
            foreach ($imageShareData as $share) {
                $shareOwner = $share->sharer->id;
                $name = $share->sharer->FirstName . ' ' . $share->sharer->LastName;
                $study_description = $share->study->study_description;
                $pid = $share->study->pid;
                $pname = $this->imageViewerService->patientName($pid);
                $dataArr[] = [
                    'index' => $index,
                    'shareOwner' => $shareOwner,
                    'sharer_name' => $pname,
                    'study_description' => $study_description,
                    'study_date' => $share->study->study_date->format('Y-m-d h:i:s A'),
                    'created_at' => $share->created_at->format('Y-m-d h:i:s A'),
                    'target_patient_email' => $share->target_patient_email,
                    'duration' => $share->duration,
                    'activeControls' => $share->active,
                    'share_id' => $share->id
                ];
                $index++;
            }
        }
        return json_encode(['status' => true, 'data' => $dataArr]);
    }
}
