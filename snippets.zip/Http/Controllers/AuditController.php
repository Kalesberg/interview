<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use ScriptSender\Services\UsageAuditService;

class AuditController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('audit');
    }

    /**
     * Display the specified resource.
     *
     * @param Request $request
     * @return array
     */
    public function show(Request $request): array
    {
        $fromDate = $request->input('from_date');
        $toDate = $request->input('to_date');
        return (new UsageAuditService())->getUsage(new Carbon($fromDate), new Carbon($toDate));
    }
}
