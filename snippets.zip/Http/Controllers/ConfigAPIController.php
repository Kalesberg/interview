<?php
namespace ScriptSender\Http\Controllers;

use Auth;
use Illuminate\Http\Response;
use Illuminate\Http\Request;

class ConfigAPIController extends Controller
{

    /**
     * @param string $name - settings property name
     * @return string - JSON with settings property name and its value
     */
    public function index($name = 'all')
    {
            if ($name === 'all') {
                return json_encode([$name => config('settings')]);
            }
            else {
                return json_encode([$name => config('settings.' . $name)]);
            }
    }

    /**
     * @param Request $request with 2 parameters: propertyName and PropertyValue
     * @return string  - JSON with updated settings property name and its value
     */
    public function setSettingsProperty(Request $request)
    {
            config(['settings.' . $request->input('propertyName') => $request->input('propertyValue')]);
            return json_encode([$request->input('propertyName') => config('settings.' . $request->input('propertyName'))]);
    }
}

