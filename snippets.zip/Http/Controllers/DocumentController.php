<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use File;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use ScriptSender\Services\Document;
use ScriptSender\Services\HL7Service;
use ScriptSender\Services\OrderService;
use ScriptSender\Services\YouTrackService;
use Illuminate\Support\Facades\Storage;
use Validator;

/**
 * Allow uploading text for HL7s
Show PDF file
Add a "copy to clipboard" option next to dropdown
 * Class DocumentController
 * @package ScriptSender\Http\Controllers
 */
class DocumentController extends Controller
{
    protected $hl7Service;
    protected $orderService;

    /**
     * ParserController constructor.
     * @param HL7Service $hl7Service
     * @param OrderService $orderService
     */
    public function __construct(HL7Service $hl7Service, OrderService $orderService)
    {
        $this->hl7Service = $hl7Service;
        $this->orderService = $orderService;
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $formats = array_values(array_diff(output_formats(), ['pdf']));
        // $formats = array_prepend($formats, 'array');
        $formats = array_prepend($formats, 'json');
        $formats = array_prepend($formats, 'text');

        return view('document')->with('formats', $formats);
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function template()
    {
        $types = ['Order', 'Note', 'Report', 'Labs', 'PatientInfo', 'Referral', 'Results'];

        return view('template')->with('types', $types);
    }

    /**
     * @param Request $request
     * @return JsonResponse|string
     */
    public function ajaxUpload(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'document' => 'required|max:4096|mimes:pdf,txt'
        ]);

        if ($validator->fails()) {
            return $validator->errors()->first('document');
        }

        $document = $request->file('document');
        if ($document->getMimeType() === 'application/pdf') {
            $extension = 'pdf';
        }
        elseif ($document->getMimeType() === 'text/plain') {
            $extension = 'txt';
        }
        $path = join_paths(
            Storage::path('parser'),
            'uploaded_' . random_int(1, 9) . random_int(1, 9) . random_int(1, 9) . ".{$extension}"
        );
        $document->storeAs('parser', basename($path));
        $request->session()->put('document', $path);
        return response()->json(['message' => 'success']);
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function getPdf(Request $request)
    {
        $headers = [
            'Cache-Control' => 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0'
        ];
        $file = $request->session()->get('document');
        if (File::exists($file)) {
            return response()->file($file, $headers);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     * @throws \ScriptSender\Exceptions\FileAndDirectoryException
     * @throws \Throwable
     */
    public function parsedContent(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'format' => 'required',
        ]);
        $doctype = $request->query('doctype', '');
        $docformat = $request->query('docformat', '');

        $file = $request->session()->get('document');
        $format = strtolower($validated['format']);
        $content = null;
        $document = new Document($file, $this->orderService);

        try {
            if (false !== strpos($format, 'json')) {
                $content = stripslashes(json_encode($document->toArray(), JSON_PRETTY_PRINT));
            }
            if (false !== strpos($format, 'array')) {
                $content = $document->toArray();
            }
            if (false !== strpos($format, 'text')) {
                $content = $document->toText();
            }
            elseif (false !== strpos($format, 'hl7')) {
                $hl7File = join_paths(
                    Storage::path('parser'),
                    'generated_' . random_int(1, 9) . random_int(1, 9) . random_int(1, 9) . '.hl7'
                );
                [$parsedData] = $this->orderService->parsePDF($file);
                $this->hl7Service->convertArrayToHL7($parsedData, $format, $hl7File);
                $content = file_get_contents($hl7File);
                File::exists($hl7File) ? File::delete($hl7File) : null;
            }
        } catch (\Throwable $e) {
            if (false !== strpos($format, 'json')) {
                $template = include app_path('Services/Parser/' . $doctype . 'Data.php');
                $content = stripslashes(json_encode($template, JSON_PRETTY_PRINT));
            }
        }

        return response()
            ->json(['status' => 'success', 'content' => $content])
            ->header('Cache-Control', 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    }

    public function createTicket(Request $request): JsonResponse
    {
        $type = $request->get('type', '');
        $format = $request->get('format', '');
        $notes = $request->get('notes', '');
        $json = $request->get('json', '');
        $image = $request->get('image', '');

        if (!$type || !$format) {
            return response()
                ->json(['status' => 'failed'], 400);
        }

        $path = join_paths(
            'parser',
            'parsed_' . random_int(1, 9) . random_int(1, 9) . random_int(1, 9) . '.json'
        );
        Storage::put($path, $json);
        $json_file = join_paths(
            Storage::path('parser'),
            basename($path)
        );

        $image = str_replace('data:image/png;base64,', '', $image);
        $image = str_replace(' ', '+', $image);
        $path = join_paths(
            'parser',
            'ocr_' . random_int(1, 9) . random_int(1, 9) . random_int(1, 9) . '.png'
        );
        Storage::put($path, base64_decode($image));
        $image_file = join_paths(
            Storage::path('parser'),
            basename($path)
        );
        $pdf_file = $request->session()->get('document');

         // Logging
        info('Ready to submit YT ticket', compact('pdf_file', 'json_file', 'image_file'));

        return response()
            ->json(['status' => 'success']);

        try {

            $ticket = (new YouTrackService())
                ->createTicket([
                    'title' => $type . ': ' . $format,
                    'description' => $notes,
                    'assignee' => env('NO_MATCH_TICKET_ASSIGNEE'),
                    'priority' => 'Normal',
                    'subsystem' => 'Document Parser',
                ]);

            $ticket->attachFiles([$pdf_file, $json_file, $image_file]);
        } catch (Exception $e) {
            Log::error('Failed to create ticket', ['error' => $e->getMessage()]);
        }
    }
}
