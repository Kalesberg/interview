<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use ScriptSender\Printers;

class WelcomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Show the application welcome screen to the user.
     *
     */
    public function index()
    {
        if(isIBM()){
            $view = 'IBM.welcome';
        }
        elseif (isLIRA()){
            $view = 'LIRA.welcome';
        }
        else {
            $view = 'welcome';
        }
        return view($view)
            ->with('printers', Printers::allNonReport());
    }
}
