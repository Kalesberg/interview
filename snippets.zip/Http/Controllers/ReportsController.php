<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use Illuminate\Http\Request;
use ScriptSender\Services\ReportCacheService;

class ReportsController extends Controller
{
    /**
     * Bust reports cache
     *
     * @param ReportCacheService $reportCacheService
     */
    public function delete(ReportCacheService $reportCacheService)
    {
        $reportCacheService->flush();
    }
}
