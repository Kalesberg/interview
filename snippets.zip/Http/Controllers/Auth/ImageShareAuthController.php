<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers\Auth;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use ScriptSender\Http\Controllers\Controller;
use ScriptSender\Services\ImageViewerService;

/**
 * Image Share Login Controller
 * This controller handles the authentication of an image share.
 *
 * Class ImageShareAuthController
 * @package ScriptSender\Http\Controllers\Auth
 */
class ImageShareAuthController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectAfterLogout = '/image_viewer/share/auth/login';
    protected $request;

    /**
     * @var ImageViewerService
     */
    private $imageViewerService;

    /**
     * Create a new authentication controller instance.
     *
     * @param Request $request
     * @param ImageViewerService $imageViewerService
     */
    public function __construct(Request $request, ImageViewerService $imageViewerService)
    {
        $this->request = $request;
        $this->imageViewerService = $imageViewerService;
    }

    public function show_password_form(Request $request)
    {
        return view('image_viewer.auth.share_login')->with('encrypted_string', $request->route('encrypted_string'));
    }

    /**
     * Handle a login request to the application. This is an override of the method defined in
     * AuthenticatesAndRegistersUsers.php. The override is created to log the login
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function postLogin(Request $request)
    {
        $this->validate($request, [
            'password' => 'required',
        ]);

        $credentials = $this->credentials($request);
        $decryptedString = $this->imageViewerService->decrypt(urldecode($request->route('encrypted_string')));
        $id = explode('|', $decryptedString)[0];
        // If Success
        if (Auth::guard('image_share')->attempt(['id' => $id, 'password' => $credentials['password']])) {
            return redirect('/image_viewer/share/view/' . $request->route('encrypted_string'));
        }

        return $this->sendFailedLoginResponse($request);
    }

    /**
     * Log the user out of the application.
     *
     * @return \Illuminate\Http\Response
     */
    public function logout()
    {
        Auth::guard('image_share')->logout();
        return back();
    }
}
