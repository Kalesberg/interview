<?php

namespace ScriptSender\Http\Controllers\Auth;

use ScriptSender\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use DB;
use Password;
use Hash;

class ResetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Display the password reset view for the given token.
     *
     * If no token is present, display the link request form.
     *
     * (This overrides the method from ResetsPasswords.php)
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string|null  $token
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function myShowResetForm(\Illuminate\Http\Request $request, $token = null)
    {
        $tokenExpired = null;
        try {
            $tokenExpired = $this->isTokenExpired($token);
        } catch (\Exception $e) {
            # Ignore any exception. The token checking will fall back to usual Laravel code, that is, after user enters
            # email and password
        }

        if ($tokenExpired) {
            return view('auth.password_token_expired');
        }

        return $this->showResetForm($request, $token);
    }

    // This logic is borrowed from DatabaseTokenRepository. We can't re-use the one from there as it is protected!
    protected function isTokenExpired($token)
    {
        // $user = Password::getUser(['email' => $email]);
        // return Password::tokenExists($user, $token);
        $created_at = DB::table('password_resets')
            ->pluck('created_at', 'token')
            ->reject(function ($value, $key) use ($token) {
                return ! Hash::check($token, $key);
            })
            ->values()
            ->first();

        $expirationTime = strtotime($created_at) + config('auth.passwords.users.expire') * 60;
        return $expirationTime < time();
    }

    /**
     * Reset the given user's password (This overrides the method from ResetsPasswords.php).
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function reset(\Illuminate\Http\Request $request)
    {
        $this->validate($request, $this->rules(), $this->validationErrorMessages());

        $credentials = $request->only('email', 'password', 'password_confirmation', 'token');

        Password::broker()->getRepository()->deleteExpired();
        $response = Password::reset($credentials, function ($user, $password) {
            $user->password = bcrypt($password);
            $user->save();
        });

        // If the password was successfully reset, we will redirect the user back to
        // the application's home authenticated view. If there is an error we can
        // redirect them back to where they came from with their error message.
        return $response == Password::PASSWORD_RESET
            ? $this->sendResetResponse($response)
            : $this->sendResetFailedResponse($request, $response);
    }
}
