<?php

namespace ScriptSender\Http\Controllers\Auth;

use Auth;
use Response;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use ScriptSender\Account_Activities;
use ScriptSender\Http\Controllers\Controller;
use ScriptSender\Logging\CustomizeLogger;
use ScriptSender\User;
use ScriptSender\Physician;
use ScriptSender\Patient;
use ScriptSender\IPAddress;
use ScriptSender\Child;
use ScriptSender\Group;
use Log;
use Flash;

class UserController extends Controller
{

    protected $admin;
    protected $request;

    public function __construct(Request $request)
    {
        (new CustomizeLogger())->setComponent('UserManagement');
        $this->middleware('admin');
        $this->request = $request;
    }

    /**
     * Return user notifications info
     * @return mixed
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function getUserNotifications()
    {
        $userId = $this->request->input('userId');
        preg_match('/user-(\d+)/i', $userId, $match);
        $userId = $match[1];

        $user = User::findOrFail($userId);

        return $user->makeHidden([
            'id', 'FirstName', 'MI', 'LastName', 'email', 'password', 'Organization',
            'username', 'AddressLine1', 'AddressLine2', 'City',
            'State', 'Country', 'Zip', 'Phone', 'WorkPhone','CellPhone',
            'NPI',
            //'unread_report_FeedEnabled', 'unread_report_FeedFrequency', 'unread_report_FeedTo',
            // 'submitted_jobs_FeedEnabled', 'submitted_jobs_FeedFrequency', 'submitted_jobs_FeedTo',
            'TotalPrintJobsSubmitted', 'remember_token', 'SMS', 'created_at', 'updated_at', 'output_format',
            //'per_submitted_jobs_FeedEnabled', 'per_submitted_jobs_FeedTo',
            'LoginUpdatesIP', 'Group_id', 'ReceivingFacility'
        ]);
    }

    /**
     * Return user info
     * @return mixed
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function getUserInfo()
    {
        $userId = $this->request->input('userId');

        $user = User::with('ipAddresses')->findOrFail($userId);

        if ($user->isPhysician()) {
            $user = User::with('ipAddresses')->with('physician')->findOrFail($userId);
        }
        elseif ($user->Patient()) {
            $user = User::with('ipAddresses')->with('patient')->with('child')->findOrFail($userId);
        }
        elseif ($user->Customer()) {
            $user = User::with('ipAddresses')->with('customer')->findOrFail($userId);
        }
        $user->Privilege = $user->roles()->first()->role;
        return $user->makeHidden([
            'id', 'password', 'username',
            'unread_report_FeedEnabled', 'unread_report_FeedFrequency',
            'unread_report_FeedTo', 'per_submitted_jobs_FeedEnabled', 'per_submitted_jobs_FeedTo',
            'submitted_jobs_FeedFrequency', 'submitted_jobs_FeedEnabled', 'submitted_jobs_FeedTo', 'Group_id',
            'TotalPrintJobsSubmitted', 'created_at', 'updated_at'
        ]);
    }

    /**
     * Return values for the requested field that match the given query string
     *
     * @param  Request $request
     * @param  int $fieldName
     * @return string
     */
    public function getUserFieldInfo(Request $request, $fieldName): string
    {
        $q = $request->input('q');

        // For each organizations
        // 	if it contains $q, push to an array
        // Return array
        $ret = [];
        foreach (Group::all() as $group) {
            $org = $group->Name;
            if (stripos($org, $q) !== false) {
                // If it is not null and is not already added to $ret
                if ($org && !\in_array(['org_value' => $org], $ret, true)) {
                    $ret[] = ['org_value' => $org];
                }
            }
        }
        return json_encode($ret);
    }

    /**
     * Return all values in the DB columns for the requested field
     * @return string
     */
    public function getUserFieldInfoAll(): string
    {
        // For each organizations
        // 	if it contains $q, push to an array
        // Return array
        $ret = [];
        foreach (User::all() as $user) {
            $org = $user->Organization;
            // If it is not null and is not already added to $ret
            if ($org && !\in_array(['org_value' => $org], $ret, true)) {
                $ret[] = ['org_value' => $org];
            }
        }
        return json_encode($ret);
    }

    public function isEmailUnique()
    {
        $email = $this->request->input('email');
        return (User::where('email', $email)->count() > 0) ? '0' : '1';
    }

    /**
     * Update the IP address
     *
     * @param Request $request
     * @return Response
     */
    public function updateIP(Request $request): JsonResponse
    {
        $ip_id = $request->input('ip_id');

        $ip_address = IPAddress::findOrFail($ip_id);
        $ip_address->ip_address = $request->input('ip_address');
        $ip_address->save();
        return response()->json(['success' => true,'message' => $ip_address], 200);
    }

    /**
     * Remove the given IP address
     *
     * @param Request $request
     * @return Response
     * @throws \Exception
     */
    public function deleteIP(Request $request): Response
    {
        $ip_id = $request->input('ip_id');
        $ip_address = IPAddress::findOrFail($ip_id);
        $ip_address->delete();
        return response()->json(['success' => true,'message' => 'Deleted successfully'], 200);
    }

    /**
     * Add new IP addresses
     *
     * @param Request $request
     * @return JsonResponse
     * @throws \Exception
     */
    public function addIPs(Request $request): JsonResponse
    {
        $userId = $request->input('userId');
        preg_match('/user-(\d+)/i', $userId, $match);
        $userId = $match[1];

        $user = User::findOrFail($userId);

        $ips = $request->input('ip_addresses');
        if (count($ips) > 0) {
            $now = now()->toDateTimeString();
            foreach ($ips as $ip) {
                IPAddress::create([
                    'user_id'       => $user->id,
                    'ip_address'    => $ip,
                    'created_at'    => $now,
                    'updated_at'    => $now
                ]);
            }
        }
        $deletedIPs = $request->input('deletedIPs');
        if (count($deletedIPs) > 0) {
            foreach ($deletedIPs as $ip) {
                $ip_address = IPAddress::findOrFail($ip);
                $ip_address->delete();
            }
        }

        return response()->json(['success' => true,'message' => 'Updated successfully']);
    }

    /**
     * Remove the given child from database
     *
     * @param Request $request
     * @return Response
     * @throws \Exception
     */
    public function deleteChild(Request $request): \Response
    {
        $request->validate([
            'child_id' => ['required'],
        ]);
        $childId = $request->input('child_id');
        $child = Child::findOrFail($childId);
        $child->delete();
        return response()->json(['success' => true,'message' => 'Deleted successfully'], 200);
    }

    /**
     * Add new Child
     *
     * @param Request $request
     * @return Response
     */
    public function addChildren(Request $request): \Response
    {
        $request->validate([
            'userId' => ['required'],
            'children' => ['required'],
        ]);
        $userId = $request->input('userId');
        preg_match('/user-(\d+)/i', $userId, $match);
        $userId = $match[1];

        $user = User::findOrFail($userId);

        $children = $request->input('children');

        $returnChild = null;
        foreach ($children as $child) {
            if (isset($child['id'])) {
                $existingChild = Child::findOrFail($child['id']);
                $existingChild->fname = $child['fname'];
                $existingChild->lname = $child['lname'];
                $existingChild->dob = $child['dob'];
                $existingChild->PID = $child['PID'];
                $existingChild->save();
                $returnChild = $existingChild;
            }
            else {
                $returnChild = Child::create([
                    'parent_id' => $user->id,
                    'fname'     => $child['fname'],
                    'lname'     => $child['lname'],
                    'dob'       => $child['dob'],
                    'PID'       => $child['PID']
                ]);
            }
        }
        return response()->json(['success' => true, 'child' => $returnChild, 'message' => 'Added successfully'], 200);
    }

    /**
     * Remove the given child from database
     *
     * @param Request $request
     * @return Response
     */
    public function getChildren(Request $request): \Response
    {
        $request->validate([
            'user_id' => ['required'],
        ]);
        $userId = $request->input('user_id');
        preg_match('/user-(\d+)/i', $userId, $match);
        $userId = $match[1];

        $child = Child::where('parent_id', $userId)->get();
        return response()->json(['success' => true, 'children' => $child], 200);
    }

    /**
     * Remove the given user
     *
     * @return Response
     * @throws \Exception
     */
    public function removeUser()
    {
        $userId = $this->request->input('userId');

        // Do not allow to remove the user who is logged in now
        if (Auth::user()->id === "$userId") {
            return response()->json(['success' => false, 'message' => "Error: Can't delete the logged-in user!"], 400);
        }

        $user = User::findOrFail($userId);

        // The JavaScript code officially prevents an admin to change a SuperAdmin.
        // This is to prevent any hack attempt outside the browser
        if ($user->isSuperAdmin() && ! Auth::user()->isSuperAdmin()) {
            Log::warning('An attempt has been made outside the browser to remove SuperAdmin! Please investigate!');
            return response()->json(
                [
                'success' => false,
                'message' => 'Only a super-admin can remove another super-admin'],
                403
            );
        }

        $name = $user->FirstName . ' ' . $user->LastName;
        $email = $user->email;
        if ($user->isPhysician()) {
            $physician = Physician::where('user_id', $user->id)->first();
            $physician->delete();
        }
        if ($user->isPatient()) {
            $patient = Patient::where('user_id', $user->id)->first();
            $patient->delete();
        }
        $user->delete();

        $this->setUserDeletedFlag($email);
        Log::info("User '$name' (Email: '$email') has been removed by Admin/SuperAdmin '" . Auth::user()->email . "'"); # TBD: This should be a user-log

        Flash::success("User '$name' (Email: '$email') removed");
    }

    private function setUserDeletedFlag($email)
    {
        Account_Activities::create(['User_Email' => $email, 'Deleted' => '1', 'Performed_By' => Auth::user()->email]);
    }
}
