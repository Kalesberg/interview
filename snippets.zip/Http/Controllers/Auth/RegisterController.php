<?php

namespace ScriptSender\Http\Controllers\Auth;

use Auth;
use Hash;
use Response;
use Schema;
use Log;
use Mail;
use Flash;
use Artisan;
use Exception;
use ScriptSender\Group;
use ScriptSender\PasswordHistory;
use ScriptSender\Printers;
use ScriptSender\Http\Controllers\Controller;
use Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use ScriptSender\User;
use ScriptSender\Physician;
use ScriptSender\Patient;
use ScriptSender\Customer;
use ScriptSender\Child;
use ScriptSender\Account_Activities;
use ScriptSender\Services\SMSService;
use Illuminate\Http\Request;
use ScriptSender\Mail\User\Welcome;
use ScriptSender\Mail\User\Modified;
use ScriptSender\Mail\SuperAdmin\NewGuestUser;
use ScriptSender\Console\Commands\printers as PrintersCommand;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Handle a registration request for the application.
     * Overrides from RegistersUsers.php
     * Overridden so that:
     *   In the original method, the user registers himself, and gets logged in after a successful registration.
     *   In our case, the admin adds an user. So we don't want the admin to get logged out and user getting logged in
     *   automatically!
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Exception
     */
    public function register(Request $request)
    {
        $req = $request->all();
        if ($request->ajax()) {
            $req = $req['newData']['DB'];
        }
        else {
            if (array_key_exists('userId', $req)) {
                $req = $req['newData'];
            }
        }
        Log::info('City ZIP State ,' .$req['City']. ',' .$req['State']. ',' .$req['Zip']. ',');
        $rules = [
            'FirstName'    => 'required|max:25|regex:/^[\pL\s]+$/u',
            'LastName'     => 'required|max:25|regex:/^[\pL\s]+$/u',
            'email'        => 'required|email|max:255|unique:users',
            'Organization' => 'required|min:3',
            'City'         => 'nullable|regex:/^[\pL\s]+$/u',
            'State'        => 'nullable|regex:/^[\pL\s]+$/u',
            'Zip'          => 'nullable|regex:/^[0-9]{5}(\-[0-9]{4})?$/',
            'IP'           => 'nullable|ip',
        ];

        if (isset($req['Privilege']) && $req['Privilege'] !== 'Patient') {
            $rules['Organization'] = 'required|min:3';
        }

        $validator = Validator::make($req, $rules);

        if ($request->ajax()) {
            $errors = $validator->errors();
            $errors = json_decode($errors);
            if (!empty($errors)) {
                return response()->json([
                    'success' => false,
                    'message' => $errors
                ], 422);
            }
        }
        if ($validator->fails()) {
            return redirect()->route('home')->withInput()->withErrors($validator);
        }

        $password = null;
        if (isPublicServer()) {
            $password = 'sspass' . random_int(1, 9) . random_int(1, 9) . random_int(1, 9) . random_int(1, 9);
            $req['password'] = $password;
        }

        $user = $this->create($req);

        $this->setUserCreatedFlag($req['email']); # Create a log entry that an user is created

        $name = $req['FirstName'] . ' ' . $req['LastName'];
        $email = $req['email'];
        $password = (array_key_exists('password', $req) and $req['password'])
                    ?$req['password']
                    :env('DEFAULT_USER_PASSWORD');
        if (array_key_exists('mail-to-user', $req)) {
            Mail::send(new Welcome($user, $password));
        }

        PasswordHistory::create(['user_id' => $user->id, 'password' => $user->password]);

        if ($req['Privilege'] === 'Patient' && $req['SMS'] !== '') {
            $pass = (array_key_exists('password', $req) and $req['password']) ?
                    $req['password'] :
                    env('DEFAULT_USER_PASSWORD');
            $SMStext = "Please use '".$pass."' as your password to login into scriptsender.com";
            $SMSService = new SMSService();
            $SMSService->sms('+1' .$req['SMS'], $SMStext);
        }

        # TBD: This should be a user log
        Log::info("New user created: Name: '$name', E-mail: '$email' (created by '" . Auth::user()->email . "')");

        Flash::success("Added user '$name', with email ID: $email");
        return redirect()->route('home');
    }

    /**
     * Modify data for the given user
     *
     * @param Request $request
     * @return string
     */
    public function modify(Request $request)
    {
        $userId = $request->input('userId');
        $newData = $request->input('newData');

        preg_match('/user-(\d+)/i', $userId, $match);
        $userId = $match[1];

        $user = User::findOrFail($userId);

        if ($user->isPhysician()) {
            $physician = Physician::where('user_id', $user->id)->first();
        }
        if ($user->isCustomer()) {
            $customer = Customer::where('user_id', $user->id)->first();
        }
        if ($user->isPatient()) {
            $patient = Patient::where('user_id', $user->id)->first();
        }
        $req = $request->all();
        if ($request->ajax()) {
            $req = $req['newData']['DB'];
        }

        if (isset($req['Privilege']) && !$user->hasRole($req['Privilege'])) {
            if ($req['Privilege'] === 'Patient') {
                $now = now()->toDateTimeString();
                $patient_fields = [
                    'user_id'       => $user->id,
                    'PID'           => $req['PID'],
                    'created_at'    => $now,
                    'updated_at'    => $now
                ];
                $patient = Patient::create($patient_fields);
            }
            if ($req['Privilege'] === 'Physician') {
                $now = now()->toDateTimeString();
                $physician_fields = [
                    'user_id'       => $user->id,
                    'NPI'           => $req['NPI'],
                    'RIS_ID'        => $req['RIS_ID'],
                    'PACS_ID'       => $req['PACS_ID'],
                    'ACCOUNT_ID'    => $req['ACCOUNT_ID'],
                    'created_at'    => $now,
                    'updated_at'    => $now
                ];
                $physician = Physician::create($physician_fields);
            }
        }

        $rules = [
            'FirstName'    => 'required|max:25|regex:/^[\pL\s]+$/u',
            'LastName'     => 'required|max:25|regex:/^[\pL\s]+$/u',
            'email'        => 'required|email|max:255',
            'Organization' => 'required|min:3',
            'City'         => 'nullable|regex:/^[\pL\s]+$/u',
            'State'        => 'nullable|regex:/^[\pL\s]+$/u',
            'Zip'          => 'nullable|regex:/^[0-9]{5}(\-[0-9]{4})?$/',
            'IP'           => 'nullable|ip',
        ];

        if (isset($req['Privilege']) && $req['Privilege'] !== 'Patient') {
            $rules['Organization'] = 'required|min:3';
        }

        $validator = Validator::make($req, $rules);

        if (!isset($req['password']) && $request->ajax()) {
            $errors = $validator->errors();
            $errors = json_decode($errors);
            if (!empty($errors)) {
                return response()->json([
                    'success' => false,
                    'message' => $errors
                ], 422);
            }
        }

        // The markup officially prevents an admin to change a SuperAdmin.
        // This is to prevent any hack attempt outside the browser
        // TBD: This should be in a guard middleware
        if ($user->isSuperAdmin() && ! Auth::user()->isSuperAdmin()) {
            Log::warning('An attempt has been made outside the browser to change SuperAdmin! Please investigate!');
            return false;  # TBD: Put it in validation
        }

        if (isset($req['password'])) {
            $validator = Validator::make(
                $req, [
                'password'          => 'required',
                'confirmPassword'   => 'required|same:password'
                ]
            );

            $errors = $validator->errors();
            $errors = json_decode($errors);
            if (!empty($errors)) {
                return response()->json([
                    'success' => false,
                    'message' => $errors
                ], 422);
            }

            $user->password = bcrypt($req['password']);
            $user->save();
            $this->setUserModifiedFlag($user->email);

            PasswordHistory::create(['user_id' => $user->id, 'password' => $user->password]);

            $name = $user->FirstName . ' ' . $user->LastName;
            # TBD: This should be a user log
            Log::info("Password for user '$name' has been modified by Admin/SuperAdmin '" . Auth::user()->email);

            Flash::success("Password updated for user '$name'");
            return $name;
        }

        foreach ($newData['DB'] as $key => $value) {
            if ($key === 'password') {
                if (!empty($value)) {
                    $user->password = bcrypt($value);
                }
            }
            elseif ($key === 'email') {
                $user->username = $value;
                $user->email = $value;
            }
            elseif ($key === 'Organization' && ! $user->isPatient()) {
                $group = Group::firstOrCreate(['Name' => $value]);
                $user->Group_id = $group->id;
            }
            elseif ($key === 'Privilege') {
                $user->setRole($value);
            }
            elseif (Schema::hasColumn('users', $key)) {
                $user->$key = $value;
                if ($user->isPhysician() && $key === 'NPI') {
                    $physician->$key = $value;
                    $physician->save();
                }
            }
            elseif ($user->isPatient() && $key === 'PID') {
                $patient->$key = $value;
                $patient->save();
            }
            elseif ($user->isPhysician() && ($key === 'RIS_ID' || $key === 'PACS_ID')) {
                $physician->$key = $value;
                $physician->save();
            }
            elseif ($user->isPhysician() && ($key === 'ACCOUNT_ID')) {
                $physician->$key = $value;
                $physician->save();
            }
            elseif ($user->isCustomer() && ($key === 'customer_id' || $key === 'location_id')) {
                $customer->$key = $value;
                $customer->save();
            }
            else {
                Log::warning("User modification: Column '$key' doesn't exist in 'users' table in database!");
            }
        }

        $user->save();
        $this->setUserModifiedFlag($user->email);

        $name = $user->FirstName . ' ' . $user->LastName;

        if (array_key_exists('mail-to-user', $newData)) {
            Mail::send(new Modified($user));
        }

        # TBD: This should be a user log
        Log::info("User '$name' has been modified by Admin/SuperAdmin '" . Auth::user()->email);

        Flash::success("Modified user '$name'");
        return $name;
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data): \Illuminate\Contracts\Validation\Validator
    {
        return Validator::make($data, [
            'email' => 'required|email|max:255|unique:users',
            'Organization' => 'required|min:3'
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array $data
     * @return \ScriptSender\User
     * @throws Exception
     */
    protected function create(array $data)
    {
        // TBD: Add remember_token
        // TBD: Users should be able to change password
        $email = $data['email'];
        $phone = $data['Phone'];
        $NPI = ($data['Privilege'] !== 'Patient' && isset($data['NPI']) && $data['NPI'] !== null) ? $data['NPI'] : '';
        $organization = $data['Organization'];
        $addressLine1 = $data['AddressLine1'];
        $addressLine2 = $data['AddressLine2'];
        $city = $data['City'];
        $state = $data['State'];
        $zip = $data['Zip'];
        $country = 'USA';
        $output_format = $data['output_format'] ?? 'pdf';
        $receivingFacility = $data['Privilege'] === 'Server' ? $data['ReceivingFacility'] : '';

        $pass = (array_key_exists('password', $data) and $data['password'])
            ? $data['password']
            : env('DEFAULT_USER_PASSWORD'); // TBD: This should be encrypted by Registrar service, isn't it?

        $now = now()->toDateTimeString();

        if ($data['Privilege'] !== 'Patient') {
            $group = Group::firstOrCreate(['Name' => $organization]);
        }
        if (isPublicServer() || isIBM()) {
            $printerName = sanitizeString($organization);

            // If the printer doesn't exist, create it
            if (Printers::where('name', $printerName)->count() >= 1) {
                Log::info("Printer '$printerName' exists.");
            }
            else {
                $printerData = [
                    '--add' => true,
                    '--name' => $printerName,
                    '--destination' => join_paths(config('settings.hosted_ss_base_folder'), "$printerName"),
                ];
                if (!empty($organization)) {
                    $printerData['--groups'] = $organization;
                }

                $exitCode = Artisan::call('scriptsender:printers', $printerData);

                if (PrintersCommand::EXIT_SUCCESS === $exitCode) {
                    Log::info("Added new printer '$printerName'");
                }
                else {
                    throw new Exception("Failed to add printer '$printerName'");
                }
            }
            if ($data['Privilege'] !== 'Patient') {
                $group->Printer_id = Printers::where('name', $printerName)->first()->id;
                $group->save();
            }
        }

        $DB_fields = [
            'FirstName'         => $data['FirstName'],
            'LastName'          => $data['LastName'],
            'password'          => bcrypt($pass),
            'email'             => $email,
            'Phone'             => $phone,
            'NPI'               => $NPI,
            'output_format'     => $output_format,
            'AddressLine1'      => $addressLine1,
            'AddressLine2'      => $addressLine2,
            'City'              => $city,
            'State'             => $state,
            'Country'           => $country,
            'ReceivingFacility' => $receivingFacility,
            'Zip'               => $zip,
            'username'          => $email,
            'created_at'        => $now,
            'updated_at'        => $now,
        ];

        if ($data['Privilege'] === 'Patient') {
            $DB_fields['SMS'] = $data['SMS'];
        }
        if ($data['Privilege'] !== 'Patient') {
            $DB_fields['Group_id'] = $group->id;
        }

        $user = User::create($DB_fields);
        $user->setRole($data['Privilege']);

        // Creating physician
        if ($data['Privilege'] === 'Physician') {
            $physician_fields = [
                'user_id'       => $user->id,
                'NPI'           => $NPI,
                'RIS_ID'        => $data['RIS_ID'],
                'PACS_ID'       => $data['PACS_ID'],
                'ACCOUNT_ID'    => $data['ACCOUNT_ID'],
                'created_at'    => $now,
                'updated_at'    => $now
            ];
            Physician::create($physician_fields);
        }

        // Creating patient
        if ($data['Privilege'] === 'Patient') {
            $patient_fields = [
                'user_id'       => $user->id,
                'PID'           => $data['PID'],
                'created_at'    => $now,
                'updated_at'    => $now
            ];
            Patient::create($patient_fields);

            if (isset($data['childFName']) && count($data['childFName']) > 0) {
                for ($i = 0, $iMax = count($data['childFName']); $i < $iMax; $i++) {
                    $child_fields = [
                        'parent_id'     => $user->id,
                        'fname'         => $data['childFName'][$i],
                        'lname'         => $data['childLName'][$i],
                        'dob'           => $data['childDOB'][$i],
                        'PID'           => $data['childPID'][$i],
                        'created_at'    => $now,
                        'updated_at'    => $now
                    ];
                    Child::create($child_fields);
                }
            }
        }

        // Creating customer
        if ($data['Privilege'] === 'Customer') {
            $customer_fields = [
                'user_id'       => $user->id,
                'customer_id'   => $data['customer_id'],
                'location_id'   => $data['location_id'],
            ];
            Customer::create($customer_fields);
        }

        return $user;
    }

    private function setUserCreatedFlag($email)
    {
        Account_Activities::create(['User_Email' => $email, 'Created' => '1', 'Performed_By' => Auth::user()->email]);
    }

    private function setUserModifiedFlag($email)
    {
        Account_Activities::create(['User_Email' => $email, 'Modified' => '1', 'Performed_By' => Auth::user()->email]);
    }

    public function guest(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'FirstName'             => 'required|max:25|regex:/^[\pL\s]+$/u',
            'LastName'              => 'required|max:25|regex:/^[\pL\s]+$/u',
            'title'                 => 'required|max:25|regex:/^[\pL\s]+$/u',
            'email'                 => 'required|email|max:255|unique:users',
            'Organization'          => 'required|min:3',
            'g-recaptcha-response'  => 'required|captcha',
        ]);
        if ($request->ajax()) {
            $errors = $validator->errors();
            $errors = json_decode($errors);
            if (!empty($errors)) {
                return response()->json([
                    'success' => false,
                    'message' => $errors
                ], 422);
            }
        }

        Log::info('New guest user request');
        $userDetails = [
            'FirstName' => $request->input('FirstName'),
            'LastName' => $request->input('LastName'),
            'title' => $request->input('title'),
            'email' => $request->input('email'),
            'Organization' => $request->input('Organization'),
        ];
        Mail::send(new NewGuestUser($userDetails));
        return response()->json([ 'success' => true, 'message' => 'Sent request to ScriptSender'], 200);
    }

    /**
     * Check if the given password was used earlier
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function wasPasswordUsed(Request $request): \Illuminate\Http\JsonResponse
    {
        $validated = $request->validate([
            'id' => 'sometimes|integer|exists:users,id',
            'email' => 'sometimes|email|exists:users,email',
            'password' => 'required|string',
            'recency'  => 'required|integer|min:1|max:25',
        ]);

        $user = !empty($validated['id'])
            ? User::find($validated['id'])
            : User::where('email', $validated['email'])->first();

        $wasUsed = $user
                ->passwords()
                ->get()
                ->sortByDesc('created_at')
                ->take($validated['recency'])
                ->contains(function ($v) use ($validated) {
                    return Hash::check($validated['password'], $v['password']);
                });

        return response()->json(['used' => $wasUsed]);
    }
}
