<?php

namespace ScriptSender\Http\Controllers\Auth;

use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Auth;
use ScriptSender\Http\Controllers\Controller;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Force logout and redirect to change password page
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @internal param Request $request
     */
    public function change_password()
    {
        Auth::logout();
        return redirect('/password/email');
    }
}
