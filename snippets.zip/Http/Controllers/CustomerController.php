<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use ScriptSender\Printers;
use ScriptSender\Customer;
use Illuminate\Http\Request;
use Artisan;
use Log;
use Flash;
use Exception;
use ScriptSender\Console\Commands\printers as PrintersCommand;

/**
 * Class CustomerController
 * @package ScriptSender\Http\Controllers
 */
class CustomerController extends Controller
{
    /**
     * @param Request $request
     * @return array
     * @throws Exception
     */
    public function add(Request $request): array
    {
        $customer = $request->validate([
            'name' => 'required|min:3|max:255|unique:customer',
            'printer_name' => 'required|alpha_dash',
            'target_destination' => 'required',
            'customer_id' => 'required',
            'location_id' => 'required',
        ]);

        $printerName = $customer['printer_name'];

        // If the printer doesn't exist, create it
        if (Printers::where('name', $printerName)->count() >= 1) {
            Log::info("Printer '$printerName' exists.");
        }
        else {
            $printerData = [
                '--add' => true,
                '--name' => $printerName,
                '--destination' => $customer['target_destination'],
            ];
            $exitCode = Artisan::call('scriptsender:printers', $printerData);
            if (PrintersCommand::EXIT_SUCCESS === $exitCode) {
                Log::info("Added new printer '$printerName'");
            }
            else {
                throw new Exception("Failed to add printer '$printerName'");
            }
        }

        Customer::create([
            'name'          => $customer['name'],
            'customer_id'   => $customer['customer_id'],
            'location_id'   => $customer['location_id'],
            'active'        => 1,
        ])
            ->printer()
            ->associate(Printers::where('name', $printerName)->first()->id)
            ->save();

        return ['success' => true, 'message' => 'Customer added successfully'];
    }

    /**
     * Return array containing customer and corresponding printer
     * @param int $id
     * @return array
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function get(int $id): array
    {
        $customer = Customer::findOrFail($id);
        return [
            'customer' => $customer,
            'printer' => $customer->printer,
        ];
    }

    public function updateStatus(Request $request)
    {
        $req = $request->validate([
            'newStatus' => 'required|min:6',
            'customer_id' => 'required',
            'printer_id' => 'required',
        ]);

        // get printer with given printerID
        $existingPrinter = Printers::findOrFail($req['printer_id']);

        $name = null;
        if ($req['newStatus'] === 'disable') {
            $name = "_disabled_{$existingPrinter->name}";
        }
        elseif ($req['newStatus'] === 'enable') {
            $name = str_replace('_disabled_', '', $existingPrinter->name);
        }
        Log::info("Renaming printer '" . $existingPrinter->name . "' to '$name'");

        $newData = [
            '--modify' => true,
            '--name' => $existingPrinter->name,
            '--new-name' => $name,
        ];

        $exitCode = Artisan::call('scriptsender:printers', $newData);

        if (PrintersCommand::EXIT_SUCCESS === $exitCode) {
            $msg = "Updated printer {$existingPrinter->name}";
            Log::info($msg);

            $customer = Customer::findOrFail($req['customer_id']);

            $customer->active = $req['newStatus'] === 'disable' ? 0 : 1;
            $customer->save();
            $msg = "Customer $customer->name {$req['newStatus']}d successfully";
            Log::info($msg);
            return ['printer_name' => $name, 'message' => $msg];
        }

        $msg = 'Failed to update printer ' . $existingPrinter->name;
        Log::error($msg);
        return response()->json(['success' => false, 'message' => $msg], 500);
    }

    public function update(Request $request)
    {
        $req = $request->validate([
            'name'                  => 'required|min:3|max:255',
            'printer_name'          => 'required|alpha_dash',
            'target_destination'    => 'required',
            'customer_id'           => 'required',
            'location_id'           => 'required',
            'id'                    => 'required',
            'printerID'             => 'required',
        ]);

        // get printer with given printerID
        $existingPrinter = Printers::findOrFail($req['printerID']);
        $name        = $req['printer_name'];
        $destination = $req['target_destination'];
        Log::info("Received update request for printer '" .
            $existingPrinter->name . "' -> name: '$name', destination: '$destination'");

        $newData = [
            '--modify' => true,
            '--name' => $existingPrinter->name,
            '--new-name' => $name,
            '--new-destination' => $destination,
        ];

        $exitCode = Artisan::call('scriptsender:printers', $newData);

        if (PrintersCommand::EXIT_SUCCESS === $exitCode) {
            $msg = "Updated printer {$existingPrinter->name}";
            Log::info($msg);
        }
        else {
            $msg = "Failed to update printer {$existingPrinter->name}";
            Log::error($msg);
            Flash::error($msg);
        }

        $customer = Customer::findOrFail($req['id']);

        $customer->customer_id = $req['customer_id'];
        $customer->location_id = $req['location_id'];
        $customer->name = $req['name'];
        $customer->save();

        return ['success' => true, 'message' => 'Customer updated successfully'];
    }
}
