<?php
declare(strict_types=1);

namespace ScriptSender\Http\Controllers;

use ScriptSender\Pacs;
use Illuminate\Http\Request;

/**
 * Class PacsController
 * @package ScriptSender\Http\Controllers
 */
class PacsController extends Controller
{
    public function add(Request $request)
    {
        $pacs = new Pacs();
        $pacs->ae_title = $request->ae_title;
        $pacs->ip = $request->ip;
        $pacs->port = $request->port;
        $pacs->common_name = $request->name;
        $pacs->type = $request->type;
        $pacs->purge_studies = $request->purgeStudies;
        $pacs->save();
        $pac_id = $pacs->id;
        return json_encode(['status' => true, 'data' => $pacs, 'pac_id' => $pac_id]);
    }

    /**
     * @param Request $request
     * @return string
     */
    public function get(Request $request)
    {
        $pageNo = $request->page;
        $limit = $request->limit;
        $offset = $pageNo / $limit;
        $pacs = Pacs::paginate($limit);
        $pacsCount = Pacs::select()->get();
        return json_encode([
            'status' => true,
            'pacs' => $pacs,
            'page' => $pageNo,
            'offset' => $offset,
            'count' => count($pacsCount)
        ]);
    }

    /**
     * @param Request $request
     * @return string
     */
    public function disable(Request $request)
    {
        $pacId = $request->pacId;
        $type = $request->type;
        Pacs::find($pacId)->update(['disable' => $type]);
        return json_encode(['status' => true]);
    }


    /**
     * @param Request $request
     * @return string
     */
    public function getPacsDetail(Request $request): string
    {
        $pacId = $request->pacId;
        $pacDetail = Pacs::select()->where('id', $pacId)->first();
        return json_encode(['status' => true, 'pacId' => $pacId, 'data' => $pacDetail]);
    }

    /**
     * @param Request $request
     * @return string
     */
    public function update(Request $request): string
    {
        $pacs = new Pac();
        $pacs->exists = true;
        $pacs->id = $request->id;
        $pacs->ae_title = $request->ae_title;
        $pacs->ip = $request->ip;
        $pacs->port = $request->port;
        $pacs->common_name = $request->name;
        $pacs->type = $request->type;
        $pacs->purge_studies = $request->purgeStudies;
        $pacs->save();
        return json_encode(['status' => true, 'data' => $pacs]);
    }

    /**
     * @param Request $request
     * @return string
     * @throws \Exception
     */
    public function destory(Request $request): string
    {
        $pacId = $request->pacId;
        $pac = Pacs::find($pacId);
        $pac->delete();
        return json_encode(['status' => true]);
    }

    /**
     * @param Request $request
     * @return string
     */
    public function addPacsToOrthanc(Request $request)
    {
        $ae_title = $request->ae_title;
        $ip = $request->ip;
        $port = $request->port;

        $dir = $_SERVER['DOCUMENT_ROOT'];
        $content = file_get_contents($dir . "/orthanc.json");
        $decodeContent = json_decode($this->cleanJson($content));
        $dicomModalities = $decodeContent->DicomModalities;

        $arr = [];
        $arr[] = $ae_title;
        $arr[] = $ip;
        $arr[] = $port;
        $carbon = today();
        $timestamp = $carbon->timestamp;

        $dicomModalities->$ae_title = $arr;

        $mainfile = $dir . '/orthanc.json';
        $renmfile = $mainfile . $timestamp;
        rename($mainfile, $renmfile);
        $filepath = $dir . '/orthanc.temp';
        $newfile = fopen($filepath, 'wb') or abort('Unable to open file!');
        fwrite($newfile, json_encode($decodeContent));
        fclose($newfile);
        $nmfile = $dir . '/orthanc.json';
        rename($filepath, $nmfile);
        return json_encode(['status' => true, 'path' => $dicomModalities]);
    }
}
