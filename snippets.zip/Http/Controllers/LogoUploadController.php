<?php namespace ScriptSender\Http\Controllers;

use Illuminate\Http\Request;
use ScriptSender\Services\LogoService;

class LogoUploadController extends Controller
{
    protected $request;
    protected $logoService;

    public function __construct(Request $request, LogoService $logoService)
    {
        $this->middleware('auth');
        $this->request = $request;
        $this->logoService = $logoService;
    }

    public function upload()
    {
        return redirect()->route('home');
    }

    public function urladd()
    {
        $this->logoService->addCustomerUrl($this->request->input('siteurl'));
        return redirect()->route('home');
    }
}
