<?php

namespace ScriptSender\Http\Middleware;

use Closure;
use Auth;
use Agent;
use ScriptSender\Logins;
use ScriptSender\IPAddress;
use Carbon\Carbon;

class LogLoginAction
{
    /**
     * Log a login action to DB. Perform this middleware _after_ login is performed.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $response = $next($request);
        if (Auth::check()) {
            $this->logThisLogin();
        }
        return $response;
    }

    # Create a log-entry for this login. This should probably go into a service
    # TBD: Refactor logic to have less DB entries:
    #    Have a column login_count.
    #    When same user logs in again from same IP, Browser etc, just increment the counter instead of adding new record
    private function logThisLogin()
    {
        $user = Auth::user();

        $browser = Agent::browser();
        $browserVersion = Agent::version($browser);

        $platform = Agent::platform();
        $platformVersion = Agent::version($platform);

        $ip = (isset($_SERVER['REMOTE_ADDR'])) ? $_SERVER['REMOTE_ADDR'] : "";

        $data = [
            'IP' => $ip,
            'Workstation_ID' => "abcd",
            'Browser' => $browser,
            'Browser-version' => $browserVersion,
            'Device' => Agent::device(),
            'OS' => $platform,
            'OS-version' => $platformVersion,
            'isDekstop' => Agent::isDesktop(),
            'isRobot' => Agent::isRobot(),
        ];

        $IPAddresses = IPAddress::where('user_id', $user->id)->get();
        $newIPAddress = true;
        foreach ($IPAddresses as $IPAddress) {
            if ($IPAddress->ip_address == $ip) {
                $newIPAddress = false;
            }
        }
        // if($user->LoginUpdatesIP == '1' and (!$user->IP or $user->IP != $ip)) {
            // $user->IP = $ip;
            // $user->save();
        // }
        if ($user->LoginUpdatesIP == '1' and $newIPAddress) {
            $now = now()->toDateTimeString();
            $ipAddress = [
                'user_id'       => $user->id,
                'ip_address'    => $ip,
                'created_at'    => $now,
                'updated_at'    => $now
            ];
            $newip = IPAddress::create($ipAddress);
        }

        $login = new Logins($data);
        $login->user()->associate($user);
        $login->save();
    }
}
