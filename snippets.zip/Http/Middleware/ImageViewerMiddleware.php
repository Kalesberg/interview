<?php

namespace ScriptSender\Http\Middleware;

use Closure;

class ImageViewerMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!is_image_viewer_enabled()) {
            abort(403, "Image viewer Not enabled"); // Nice error page
        }
        return $next($request);
    }
}
