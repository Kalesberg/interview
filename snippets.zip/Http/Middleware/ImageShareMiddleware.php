<?php
declare(strict_types=1);

namespace ScriptSender\Http\Middleware;

use Closure;
use Auth;
use ScriptSender\Imageshare_share;

class ImageShareMiddleware
{
    /**
     * Handle an incoming request.
     * @param $request
     * @param Closure $next
     * @param string $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = 'image_share')
    {
        $encryptedString = $request->route('encrypted_string');
        $share = Imageshare_share::getShareFromURL($encryptedString);

        if (!$share) {
            return redirect('/image_viewer/share/image_does_not_exist');
        }

        if (!$share->isActive()) {
            return redirect('/image_viewer/share/image_not_active');
        }

        if ($share->isExpired()) {
            return redirect('/image_viewer/share/image_expired');
        }

        if (!Auth::guard($guard)->check()) {
            return redirect()->guest("image_viewer/share/auth/login/$encryptedString");
        }
        return $next($request);
    }
}
