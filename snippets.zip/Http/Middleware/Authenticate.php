<?php namespace ScriptSender\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Guard;
use File;
use Log;
use Response;

class Authenticate
{
    /**
     * The Guard implementation.
     *
     * @var Guard
     */
    protected $auth;

    /**
     * Create a new filter instance.
     *
     * @param  Guard $auth
     */
    public function __construct(Guard $auth)
    {
        $this->auth = $auth;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($this->auth->guest()) {
            if ($request->ajax()) {
                return Response::json(array('error' => 'Your session has expired. Please log in again'), 403);
            }
            else {
                return redirect()->guest('auth/login');
            }
        }

        return $next($request);
    }
}
