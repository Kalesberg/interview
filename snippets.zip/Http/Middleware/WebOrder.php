<?php

namespace ScriptSender\Http\Middleware;

use Closure;

class WebOrder
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!is_web_order()) {
            abort(403, "Web Orders Not enabled"); // Nice error page
        }
        return $next($request);
    }
}
