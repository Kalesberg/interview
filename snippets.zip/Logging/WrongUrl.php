<?php

namespace ScriptSender\Logging;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

class WrongUrl extends CustomizeLogger
{
    /**
     * @throws \Exception
     */
    protected function initHandlers(): void
    {
        $logFiles = $this->getLogFileNames();
        $this->handlers[] = new StreamHandler($logFiles['wrongUrlLog'], Logger::ERROR, false);
    }
}
