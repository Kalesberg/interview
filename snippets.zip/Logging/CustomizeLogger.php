<?php

namespace ScriptSender\Logging;

use Config;
use Monolog\Logger;
use Monolog\Formatter\LineFormatter;
use Monolog\Handler\StreamHandler;
use Monolog\Processor\IntrospectionProcessor;
use Monolog\Processor\UidProcessor;
use Monolog\Processor\WebProcessor;

/**
 * Customize application logging.
 * Laravel uses Monolog logger. This class uses processors, handlers etc. to customize logging according to need.
 * Read through this before any changes here: https://github.com/Seldaek/monolog/blob/master/doc/01-usage.md
 *
 * Class LoggingService
 * @package ScriptSender\Services
 */
class CustomizeLogger
{
    private $logFormat = "[%datetime%] %env%.%level_name%: %message% %context% %extra%\n";
    private $timeFormat = 'Y-m-d H:i:s,v';
    private $uidLength = 8;
    protected $handlers = [];

    /**
     * Create a custom Monolog instance.
     *
     * @param  array $config
     * @return \Monolog\Logger
     * @throws \Exception
     */
    public function __invoke(array $config): Logger
    {
        $this->initHandlers();
        $this->changeLineFormatting();
        return new Logger($config['driver'], $this->handlers, $this->createProcessors($config));
    }

    /**
     * Add the given component name in logs.
     *  e.g.: 'some message {"a":10} {"component":"Parser"," ...'
     *
     * @param string $component
     */
    public function setComponent(string $component): void
    {
        config(['logging.channels.custom.component' => $component]);
    }

    /**
     * Generate log file names from config. If config doesn't have any logfile names, return default locations.
     *
     * @return array
     */
    public function getLogFileNames(): array
    {
        $fallbackLogPath = storage_path('logs/');
        return [
            'debugLog' => config('settings.output_paths.logs.debug', "{$fallbackLogPath}/debug.log"),
            'mainLog' => config('settings.output_paths.logs.main', "{$fallbackLogPath}/main.log"),
            'errorLog' => config('settings.output_paths.logs.error', "{$fallbackLogPath}/error.log"),
            'wrongUrlLog' => config('settings.output_paths.logs.wrongUrl', "{$fallbackLogPath}/wrongUrl.log"),
        ];
    }

    /**
     * Add extra information in each log
     *
     * @param array $config
     * @return array
     */
    protected function createProcessors(array $config): array
    {
        $excludeClasses = ['Illuminate\\'];
        $processors[] = new IntrospectionProcessor(Logger::DEBUG, $excludeClasses); // Add file, class, line and method
        $processors[] = new WebProcessor(); // Add web related stuff like URL, IP etc.
        $processors[] = function ($record) use ($config) {
            $record['env'] = $config['env']; // For the %env% part in log format

            // Add component. If this does not work as intended, use Config::get(logging.component) as for UUID below.
            $record['extra']['component'] = $config['component'];

            // Add per-request UUID in log
            // ideally this should be used: $processors[] = new UidProcessor($this->uidLength);
            // But from v5.6 every Log:: call seems to call this __invoke() method, resulting in different UUID even in a single
            // session! Hence use a Config value to hold a temporary UUID for each session.
            if (!Config::get('logging.uuid')) {
                config(['logging.uuid' => (new UidProcessor($this->uidLength))->getUid()]);
            }
            $record['extra']['uuid'] = config('logging.uuid');

            return $record;
        };
        return $processors;
    }

    /**
     * How each log line should look like..
     *
     * @return void
     */
    protected function changeLineFormatting(): void
    {
        // Change format for all existing streams. If you want different format for some stream, exclude that from this
        // loop and set the formatter separately.
        $formatter = new LineFormatter($this->logFormat, $this->timeFormat);
        foreach ($this->handlers as $stream) {
            $stream->setFormatter($formatter);
        }
    }

    /**
     * @throws \Exception
     */
    protected function initHandlers(): void
    {
        $logFiles = $this->getLogFileNames();
        $this->handlers[] = new StreamHandler($logFiles['errorLog'], Logger::ERROR, true);
        $this->handlers[] = new StreamHandler($logFiles['mainLog'], Logger::INFO, false);
        $this->handlers[] = new StreamHandler($logFiles['debugLog'], Logger::DEBUG, false);
    }
}
