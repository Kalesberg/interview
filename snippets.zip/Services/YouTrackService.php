<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use Exception;
use GuzzleHttp\Client;
use Log;
use File;
use Redis;
use ScriptSender\Exceptions\YouTrackServiceException;
use YouTrack\Connection;
use YouTrack\Attachment;

/**
 * YouTrack ticket manager (create / update etc.)
 * Use this class to automatically log issues in our YouTrack project.
 *
 * Class YouTrackService
 * @package ScriptSender\Services
 */
class YouTrackService
{
    protected $youtrack;
    protected $lastResult;
    protected $ticketId;
    protected $site;
    protected $title;
    protected $description;
    protected $priority;
    protected $assignee;
    protected $subsystem;
    protected $type;
    protected $baseUri;
    protected $token;

    /**
     * YouTrackService constructor.
     * @throws YouTrackServiceException
     */
    public function __construct()
    {
        $this->baseUri = env('YOUTRACK_BASE_URI');
        $this->token = env('YOUTRACK_TOKEN');
        $this->site = config('settings.site_name');
        $this->checkConnectivity();
        $this->youtrack = new Connection($this->baseUri, $this->token, null, null, null, false);
        // $this->youtrack->setVerifySsl(false);
    }

    /**
     * @param array $details
     * @return YouTrackService
     * @throws \YouTrack\Exception
     */
    public function createTicket(array $details): YouTrackService
    {
        $this->title = $details['title'];
        $this->description = $this->createGenericDescription() . $details['description'];
        $this->priority = $details['priority'];
        $this->assignee = $details['assignee'];
        $this->subsystem = $details['subsystem'];
        $this->type = $details['type'] ?? 'Bug';
        $this->lastResult = $this->youtrack->createIssue(env('YOUTRACK_PROJECT_ID'), $this->title, [
            'Type' => $this->type,
            'Site' => $this->site,
            'description' => $this->description,
        ]);
        $this->ticketId = $this->lastResult->getId();
        $this->updateTicketDetails();
        info('Created ticket', ['id' => $this->ticketId]);
        return $this;
    }

    /**
     * @param array $files
     * @param bool $stopOnFailure Abort operation even if one file fails to attach
     * @return $this
     * @throws YouTrackServiceException
     */
    public function attachFiles(array $files, bool $stopOnFailure = false): YouTrackService
    {
        foreach ($files as $file) {
            if (!File::exists($file)) {
                $msg = "File $file does not exist";
                if ($stopOnFailure) {
                    throw new YouTrackServiceException($msg);
                }
                Log::error($msg);
            }
            $attachment = new Attachment();
            $attachment->setUrl($file)->setName(basename($file));
            $this->lastResult = $this->youtrack->createAttachmentFromAttachment($this->ticketId, $attachment);
        }
        return $this;
    }

    /**
     * @throws \YouTrack\Exception
     */
    public function updateTicketDetails(): YouTrackService
    {
        // To have "Site $this->site", we need to first get the correct site name at YouTrack.
        $cmd = "Type $this->type Priority $this->priority Assignee $this->assignee Subsystem $this->subsystem";
        $this->lastResult = $this->youtrack->executeCommand($this->ticketId, $cmd);
        return $this;
    }

    /**
     * Test if YouTrack is accessible
     *
     * @throws YouTrackServiceException
     */
    protected function checkConnectivity(): void
    {
        try {
            (new Client())->head($this->baseUri, ['connect_timeout' => 2, 'verify' => false]);
        }
        catch (Exception $e) {
            throw new YouTrackServiceException('YouTrack not accessible: ' . getExceptionSummary($e));
        }
    }

    /**
     * Create a generic description that'll be used in all YouTrack tickets
     *
     * @return string
     */
    protected function createGenericDescription(): string
    {
        return
            'Site: ' . config('settings.site_name') . "\n" .
            'URL: ' . url('/') . "\n" .
            'Timestamp: ' . now()->format('Y-m-d h:i:s A') . "\n";
    }

    /**
     * Check if a ticket was created for the given file
     *
     * @param string $identifier Some sort of unique identifier to mark the ticket, e.g. md5 hash of a file attached
     * @return bool
     */
    public function ticketExists(string $identifier): bool
    {
        $redis = Redis::connection();
        return (bool) $redis->hexists('YouTrack_ticket', $identifier);
    }

    /**
     * Mark the ticket being created, to avoid creating duplicate tickets for the same file
     *
     * @param string $identifier
     */
    public function ticketCreated(string $identifier): void
    {
        $redis = Redis::connection();
        $redis->hset('YouTrack_ticket', $identifier, '1');
    }
}
