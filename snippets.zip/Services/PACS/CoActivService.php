<?php
declare(strict_types=1);

namespace ScriptSender\Services\PACS;

use File;
use ScriptSender\Exceptions\CoActivException;
use Illuminate\Support\Collection;
use Log;

class CoActivService
{
    protected $remotePACSModality;
    protected $remotePACSIP;
    protected $remotePACSPort;
    protected $localPACSModality;
    protected $dcmqr;
    private $dumpFile;

    public function __construct()
    {
        if (!config('settings.remotePACS.enable_QR')) {
            return;
        }
        $this->dcmqr = base_path('dcm4che-2.0.29/bin/dcmqr');
        $this->remotePACSModality = config('settings.remotePACS.AETitle');
        $this->remotePACSIP = config('settings.remotePACS.IP');
        $this->remotePACSPort = config('settings.remotePACS.port');
        $this->localPACSModality = config('settings.PACS.AETitle');
        if (!is_file($this->dcmqr)) {
            throw new CoActivException("DCMQR was not found in path: '$this->dcmqr'");
        }
        if (!is_executable($this->dcmqr)) {
            $processUser = posix_getpwuid(posix_geteuid());
            throw new CoActivException("DCMQR '$this->dcmqr' not executable for user '" . $processUser['name'] ."'");
        }
        if (!($this->remotePACSModality && $this->remotePACSIP && $this->remotePACSPort && $this->localPACSModality)) {
            throw new CoActivException('PACS / Remote PACS configuration missing!');
        }
        $this->dumpFile = '/tmp/remotePACSQR.dump';
    }

    /**
     * @param string $accession
     * @param string $DOB Expected format: YYYYmmdd (e.g., 20021224)
     * @param string $sex Expected format: M/F
     * @param string|null $pid
     * @return bool
     * @throws CoActivException
     */
    public function queryStudy(string $accession, $pid = null, $DOB = null, $sex = null): bool
    {
        $pid = null; # Disable $pid based QR for now, as CoActiv doesn't store actual PID but SSN as PID!

        $cmd = "sudo $this->dcmqr -highprior {$this->remotePACSModality}@{$this->remotePACSIP}:{$this->remotePACSPort}".
               " -L {$this->localPACSModality}" .
               " -qAccessionNumber=$accession" .
               ($pid ? " -qPatientID=$pid" : ' -rPatientID') .
               ($DOB ? " -qPatientBirthDate=$DOB" : ' -rPatientBirthDate') .
               ($sex ? " -qPatientSex=$sex" : ' -rPatientSex');
        $output = runCmd($cmd);
        if (preg_match('/Received 0 matching entries/', $output)) {
            throw new CoActivException("No study found in CoActiv! ACCN:'$accession', PID: $pid, DOB: $DOB, sex: $sex");
        }
        if (preg_match('/Received \d+ matching entries in/', $output)) {
            return true;
        }
        return false;
    }

    /**
     * @param string $accession
     * @param string $DOB
     * @param string $sex
     * @param string|null $pid
     * @throws CoActivException
     */
    public function retrieveStudy(string $accession, $pid = null, $DOB = null, $sex = null): void
    {
        $pid = null; # Disable $pid based QR for now, as CoActiv doesn't store actual PID but SSN as PID!
        $cmd =
            "sudo $this->dcmqr -highprior {$this->remotePACSModality}@{$this->remotePACSIP}:{$this->remotePACSPort} " .
            " -L {$this->localPACSModality}" .
            " -cmove {$this->localPACSModality}" .
            " -qAccessionNumber=$accession" .
            ($pid ? " -qPatientID=$pid" : ' -rPatientID') .
            ($DOB ? " -qPatientBirthDate=$DOB" : ' -rPatientBirthDate') .
            ($sex ? " -qPatientSex=$sex" : ' -rPatientSex') .
            ' -rPatientName -rModalitiesInStudy -rStudyDescription';
        $output = runCmd($cmd);
        if (!preg_match('/Received \d+ matching entries in/', $output)) {
            throw new CoActivException("Study not found in CoActiv.  ACCN: '$accession', PID: $pid, DOB: $DOB, sex: $sex");
        }

        if (preg_match('/Received 0 matching entries/', $output)) {
            throw new CoActivException("Study not found in CoActiv.  ACCN: '$accession', PID: $pid, DOB: $DOB, sex: $sex");
        }

        if (!preg_match('/Retrieved (\d+) objects \(warning: 0, failed: 0\)/', $output, $match)) {
            File::put($this->dumpFile, $output);
            throw new CoActivException("Failed to retrieve study. ACCN: '$accession', PID: $pid, DOB: $DOB, sex: $sex. Dump: {$this->dumpFile}");
        }

        if ($match[1] === 0) {
            File::put($this->dumpFile, $output);
            throw new CoActivException("Failed to retrieve study. ACCN: '$accession', PID: $pid, DOB: $DOB, sex: $sex. Dump: {$this->dumpFile}");
        }

        info('Retrieved study from CoActiv', [
            'accession' => $accession, 'DOB' => $DOB, 'sex' => $sex, 'pid' => $pid,
            'remote' => "$this->remotePACSIP:$this->remotePACSPort"
        ]);
    }

    /**
     * @param string $pid
     * @param null $DOB
     * @param null $sex
     * @throws CoActivException
     */
    public function getPatient(string $pid, $DOB = null, $sex = null): void
    {
        $cmd = "$this->dcmqr -highprior {$this->remotePACSModality}@{$this->remotePACSIP}:{$this->remotePACSPort}" .
            " -L {$this->localPACSModality}" .
            " -cmove {$this->localPACSModality}" .
            " -qPatientID=$pid" .
            ($DOB ? " -qPatientBirthDate=$DOB" : ' -rPatientBirthDate') .
            ($sex ? " -qPatientSex=$sex" : ' -rPatientSex') .
            ' -rPatientName -rModalitiesInStudy -rStudyDescription -rAccessionNumber';
        $output = runCmd($cmd);
        if (!preg_match('/Retrieved \d+ objects \(warning: 0, failed: 0\) in ([\d.]+)s/', $output)) {
            File::put($this->dumpFile, $output);
            throw new CoActivException("Failed to retrieve patient. PID: $pid, DOB: $DOB, sex: $sex. Dump: {$this->dumpFile}");
        }
        Log::info('Retrieved patient from CoActiv', [
            'pid' => $pid, 'DOB' => $DOB, 'sex' => $sex, 'remote' => "$this->remotePACSIP:$this->remotePACSPort"]);
    }

    /**
     * @param string $pid
     * @param null $DOB
     * @param null $sex
     * @return Collection
     * @throws CoActivException
     */
    public function queryAllStudiesForPatient(string $pid, $DOB = null, $sex = null): Collection
    {
        $cmd = "$this->dcmqr -highprior {$this->remotePACSModality}@{$this->remotePACSIP}:{$this->remotePACSPort}" .
            " -L {$this->localPACSModality}" .
            " -qPatientID=$pid" .
            ($DOB ? " -qPatientBirthDate=$DOB" : ' -rPatientBirthDate') .
            ($sex ? " -qPatientSex=$sex" : ' -rPatientSex') .
            ' -rPatientName -rModalitiesInStudy -rStudyDescription -rAccessionNumber';
        $output = runCmd($cmd);
        if (!preg_match('/Received \d+ matching entries in ([\d.]+)s/', $output)) {
            File::put($this->dumpFile, $output);
            throw new CoActivException("Failed to query patient with PID $pid from CoActiv. Dump:\n $file");
        }
        Log::debug('Queried all studies for patient from CoActiv', [
            'pid' => $pid, 'remote' => "$this->remotePACSIP:$this->remotePACSPort"]);
        preg_match_all('/\[(\S+)\] Accession Number/', $output, $matches);
        return collect($matches[1]);
    }
}
