<?php
declare(strict_types=1);

namespace ScriptSender\Services\PACS;

# Studies with lot of instances exceed default timeout of 30 seconds, so give curl 60 seconds
ini_set('max_execution_time', '120');

use File;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Log;
use ScriptSender\Exceptions\PACSException;
use ZipArchive;

/**
 * Use REST API to get/set info from Orthanc
 *
 * TODO: Use Orthanc query, as in test_rest_find() in https://bitbucket.org/sjodogne/orthanc-tests/src/default/Tests/Tests.py?fileviewer=file-view-default
 * TODO: e.g., curl http://localhost:8043/tools/find -X POST -d '{"Level":"Patient", "Query": {"PatientSex":"F"}}'
 * TODO: Ref: https://www.orthanc-server.com/static.php?page=dicomweb
 * Class OrthancService
 * @package ScriptSender\Services\PACS
 */
class OrthancService
{
    protected $PACS_url;
    protected $ch;
    protected $guzzle;

    public function __construct()
    {
        $this->PACS_url = config('settings.PACS.url');
        $this->ch = curl_init();

        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($this->ch, CURLOPT_CONNECTTIMEOUT, 240);
        curl_setopt($this->ch, CURLOPT_TIMEOUT, 240);

        // This is equivalent to Curl command line option --insecure. This is required
        // when the site is https, and curl doesn't have certificate keys
        // TBD: No need for this when using a server with real purchased certificate
        if (preg_match('/https:/', $this->PACS_url)) {
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, 0);
        }
        // $this->studyCacheLife = config('settings.study.cache_life');
        // $this->studyRefreshOnAccess = config('settings.study.refresh_on_access');
        $this->guzzle = new Client(['base_uri' => $this->PACS_url]);
    }

    /**
     *  TBD: cleanup cache: If there is some id in cache that's not present in array $all_ids_at_pacs,
     *  Cache::forget(that id)
     * Call it from cronjob
     */
    public function clearPatientJSONCache()
    {
        // foreach (get all keys from cache with tags ['DICOM', 'patient', 'IDs'] as $cached_pid) {
        //     if $cached_pid is not present in array $all_ids_at_pacs
        //         remove it from cache
        // }
    }

    /**
     * Execute API on PACS
     * @param string $endpoint
     * @param string $method
     * @return bool|mixed
     * @throws PACSException
     */
    public function pacsAPI(string $endpoint, string $method = 'GET')
    {
        curl_setopt($this->ch, CURLOPT_URL, $endpoint);

        if ($method === 'GET') {
            $returnJSON = curl_exec($this->ch);

            $err = curl_error($this->ch);
            if ($err) {
                throw new PACSException("Failed to communicate with PACS: URL: $endpoint. Error: $err");
            }
            if (empty($returnJSON)) {
                throw new PACSException("API '$endpoint' returned empty string");
            }
            // Log::debug('Curl: successfully executed', [
            //     'endpoint' => $endpoint, 'method' => $method, 'response' => $returnJSON]);
            return json_decode($returnJSON, true);
        }

        curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, $method);
        $return = curl_exec($this->ch);
        $err = curl_error($this->ch);
        if ($err) {
            throw new PACSException("Failed to communicate with PACS: URL: $endpoint. Error: $err");
        }
        curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, 'GET'); // Restore to default 'GET'

        // Log::debug('Curl: successfully executed', [
        //     'endpoint' => $endpoint, 'method' => $method, 'response' => $return]);
        return true;
    }

    /**
     * Return Patient UUID of an instance
     * @param string $instanceUUID
     * @return string $patientUUID
     * @throws PACSException
     */
    public function getPatientFromInstance(string $instanceUUID): string
    {
        $seriesUUID = $this->getSeriesFromInstance($instanceUUID);
        $studyUUID = $this->getStudyFromSeries($seriesUUID);
        return $this->getpatientFromStudy($studyUUID);
    }

    public function getSeriesFromInstance(string $instanceUUID): string
    {
        $instanceJSON = $this->pacsAPI("$this->PACS_url/instances/$instanceUUID");
        if (empty($instanceJSON)) {
            throw new PACSException("No instance found with UUID '$instanceUUID'");
        }
        return $instanceJSON['ParentSeries'];
    }

    public function getStudyFromSeries(string $seriesUUID): string
    {
        $seriesJSON = $this->pacsAPI("$this->PACS_url/series/$seriesUUID");
        if (empty($seriesJSON)) {
            throw new PACSException("No series found with UUID '$seriesUUID'");
        }
        return $seriesJSON['ParentStudy'];
    }

    public function getpatientFromStudy(string $studyUUID): string
    {
        $studyJSON = $this->pacsAPI("$this->PACS_url/studies/$studyUUID");
        if (empty($studyJSON)) {
            throw new PACSException("No study found with UUID '$studyUUID'");
        }
        return $studyJSON['ParentPatient'];
    }

    /**
     * Retrieve study from Orthanc using StudyInstanceUID
     *
     * @param string $studyInstanceUID
     * @return array
     * @throws PACSException
     */
    public function getStudyFromUid(string $studyInstanceUID): array
    {
        $response = null;
        try {
            $response = $this->guzzle->post('tools/find', [
                'json' => [
                    'Level' => 'Study',
                    'Query' => [
                        'StudyInstanceUID' => $studyInstanceUID,
                    ],
                ],
            ]);
        } catch (RequestException $e) {
            $this->handleGuzzleException($e);
        }

        $response = json_decode($response->getBody()->getContents(), true);
        if (empty($response)) {
            throw new PACSException("No study found with StudyInstanceUID: '$studyInstanceUID'");
        }
        $response = $this->guzzle->get("studies/{$response[0]}");
        return json_decode($response->getBody()->getContents(), true);
    }

    /**
     * Prepare a DICOM file for exporting
     *
     * @param string $studyInstanceUid
     * @return string $zipFile Path of zipfile
     * @throws PACSException
     */
    public function createDICOMZipped(string $studyInstanceUid)
    {
        logger('createDICOMZipped', compact('studyInstanceUid'));
        $zipFile = public_path('/files/image_viewer_dicom_export.zip');
        $studyJson = $this->getStudyFromUid($studyInstanceUid);
        $uuid = $studyJson['ID'];
        try {
            $data = $this->guzzle->get("/studies/$uuid/archive");
        }
        catch (RequestException $e) {
            $this->handleGuzzleException($e);
        }
        File::delete($zipFile); // Remove if existing

        $file = fopen($zipFile, 'wb+');
        fwrite($file, $data->getBody()->getContents());
        fclose($file);

        $zip = new ZipArchive;

        // open() is working now. If fails, try ZIPARCHIVE::OVERWRITE or ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE
        $res = $zip->open($zipFile, ZIPARCHIVE::CREATE);
        if (!$res) {
            throw new FileAndDirectoryException("Failed to open zip archive: '$zipFile'");
        }
        if ($zip->setArchiveComment('Created by ScriptSender') === true) {
            Log::debug('Changed zipfile comment');
        }
        else {
            Log::error("Couldn't change zipfile comment");
        }
        $zip->close();
        info('Prepared DICOM zip file', compact('studyInstanceUid'));
        return $zipFile;
    }

    public function studySearch($patientName, $pid, $accession, $studyDate, $modality)
    {
        try {
            $response = $this->guzzle->post('/tools/find', [
                'json' => [
                    'Expand'        => true,
                    'CaseSensitive' => false,
                    'Level'         => 'Study',
                    'Query'         => [
                        'PatientName'     => $patientName,
                        'PatientID'       => $pid,
                        'AccessionNumber' => $accession,
                        'StudyDate'       => $studyDate,
                        'Modality'        => $modality,
                    ]
                ]
            ]);

            return json_decode($response->getBody()->getContents(), true);
        }
        catch (RequestException $e) {
            $this->handleGuzzleException($e);
        }
    }

    public function handleGuzzleException(RequestException $e): void
    {
        // If there are network errors, we need to ensure the application doesn't crash.
        // if $e->hasResponse is not null we can attempt to get the message
        // Otherwise, we'll just pass a network unavailable message.
        if ($e->hasResponse()) {
            $exception = (string) $e->getResponse()->getBody()->getContents();
            $exception = json_decode($exception);
            throw new PACSException("Failed to execute API. error: $exception, error_code: " . $e->getCode());
        }
        throw new PACSException("Failed to execute API. error: " . $e->getMessage() . ", error_code: 503");
    }
}
