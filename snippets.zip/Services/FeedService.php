<?php namespace ScriptSender\Services;

use Mail;
use Schema;
use ScriptSender\User;
use ScriptSender\Mail\Stats\UnreadReports;
use ScriptSender\Mail\Stats\Prints;

/**
 * Manage Notification Feeds: Register feed requests from user, send those when triggered.
 * Class FeedService
 * @package ScriptSender\Services
 */
class FeedService
{
    /**
     * @param User $user
     * @param array $notifications
     */
    public function setNotificationFeed(User $user, array $notifications): void
    {
        foreach ($notifications as $key => $value) {
            $feedEnabled = $key . '_FeedEnabled';
            $feedFrequency = $key . '_FeedFrequency';
            $feedTo = $key . '_FeedTo';

            $user->$feedEnabled = preg_match('/enable/i', $value['enable']) ? true : false;

            # Some feeds may not have a frequency (e.g. per_submitted_jobs)
            if (Schema::hasColumn('users', $feedFrequency)) {
                $user->$feedFrequency = $value['frequency'];
            }

            # if Multiple email IDs are given, create a comma-separated string like email1,email2,email3
            $user->$feedTo = implode(',', array_map('trim', preg_split('/[,;]/', trim($value['to'], ',;'))));

            $user->save();
        }
    }

    /**
     *  For each user, go through each notification types, and send mail if the notification conditions are met
     *   TBD: Shall I schedule the cron based on scheduled time?
     * @param ReportService $reportService
     */
    public function sendFeed(ReportService $reportService): void
    {
        $notifications = ['unread_report', 'submitted_jobs'];
        foreach (User::all() as $user) {
            foreach ($notifications as $type) {
                $feedEnabled = $type . '_FeedEnabled';
                $feedFrequency = $type . '_FeedFrequency';

                if (empty($user->$feedFrequency)) {
                    continue;
                }

                if ($user->$feedEnabled && is_time_cron(time(), $user->$feedFrequency)) {
                    switch ($type) {
                        case 'unread_report':
                            $unreadReportCount = $reportService->getNoOfUnreadReports($user);

                            // Do not send a notification if there is no unread reports
                            if ($unreadReportCount === 0) {
                                break;
                            }
                            Mail::send(new UnreadReports($unreadReportCount, $user));
                            break;

                        case 'submitted_jobs':
                            Mail::send(new Prints($user));
                            break;

                        default:
                            break;
                    }
                }
            }
        }
    }
}
