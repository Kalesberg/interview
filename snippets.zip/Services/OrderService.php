<?php

namespace ScriptSender\Services;

use AlbanyDesigns\NPPESApi\NPPESApi;
use File;
use Illuminate\Database\Eloquent\Model;
use Log;
use ScriptSender\Exceptions\FileAndDirectoryException;
use ScriptSender\Exceptions\NpiLookupFailureException;
use ScriptSender\Exceptions\ParseException;
use ScriptSender\Order;
use Exception;
use ScriptSender\OrderStatus;

class OrderService
{
    /**
     * @param array $parsedData
     * @param Order|null $orderRecord
     * @return Model
     */
    public function createOrderFromParsedData(array $parsedData, Order $orderRecord = null): Model
    {
        error_reporting(0);
        $order = [
            'FirstName' => $parsedData['patient']['firstname'],
            'LastName' => $parsedData['patient']['lastname'],
            'dob' => $parsedData['patient']['DOB'],
            'PatNumber' => $parsedData['PID']['id'],
            'AppNumber' => null,
            'Insurance' => null,
            'InsuranceID' => null,
            'PhonePref' => 'Home',
            'PrevFilms' => null,
            'RefDr' => $parsedData['referringDr']['firstname'] . ' ' . $parsedData['referringDr']['lastname'],
            'RefDrPhone' => $parsedData['referringDr']['phone'],
            'RefDrID' => $parsedData['referringDr']['code'],
            'RefDrPractice' => null,
            'EmergPhone' => null,
            'Height' => null,
            'Weight' => null,
            'Gender' => $parsedData['patient']['sex'],
            'HL7SubmissionStatus' => $parsedData['HL7SubmissionStatus'] ?: 'NotSubmitted',
        ];
        error_reporting(1);

        if ($orderRecord) { # If an earlier order exists (e.g., in case of an order re-process)
            $orderRecord->update($order);
            $order = $orderRecord;
        }
        else { # For a new print
            $order = Order::firstOrCreate($order);
            $order->status()->associate(OrderStatus::getDefault())->save(); // Attach default order status
        }
        return $order;
    }

    /**
     * @param string $file FIle to be parsed
     * @param bool $newParser
     * @return array
     * @throws \ScriptSender\Exceptions\ParseException
     * @throws Exception
     * @throws FileAndDirectoryException
     */
    public function parsePDF(string $file, bool $newParser = false): array
    {
        if (!is_readable($file)) {
            throw new FileAndDirectoryException("File '$file' not readable'");
        }
        $newParserArg = $newParser ? '--new_parser' : '';
        $report = isTextFile($file) ? "--textFile='$file'" : "--report='$file'";
        $parseReportScript = base_path('ss_toolbox/ParseReport.pm');
        $cmd = "perl $parseReportScript $report --json $newParserArg 2>&1";
        $parseReportOutput = runCmd($cmd, true);
        Log::debug($parseReportOutput);
        $order = $template = $parsedData = null;

        if (! preg_match("/Detected radiology as:\s*'(\S.+)'/", $parseReportOutput, $match)) {
            throw new Exception("PDF $file could not be parsed");
        }

        $template = $match[1];
        preg_match("/(\{.+patient.+\})/", $parseReportOutput, $match);
        if (!$match) {
            throw new ParseException('No "patient" in parsed output. parsed output: ' . $parseReportOutput);
        }
        $parsedData = json_decode($match[1]);

        if (!$parsedData) {
            $json_errors = getJsonErrorStrings();
            throw new ParseException('Failed to decode JSON: ' . $json_errors[json_last_error()]);
        }

        $parsedData = json_decode(json_encode($parsedData), true); // TBD: remove prev json_decode($match[1])?
        $parsedData['patient']['sex'] = $parsedData['patient']['sex'] ?? 'U'; // Is this a good place for this?

        return [$parsedData, $template];

        // TBD: Uncomment and put this snippet in place if selective formats are getting ready for production
        // $template = $parseReportOutput = null;
        //
        // // Use new parse engine to get pdf template. If the template is implemented and tested, go with the new parser
        // // else use old Perl based parser.
        // // Once all parsers are served from PHP parse engine, remove try-catch, and the else part.
        // try {
        //     $parseReportOutput = parsePdf($pdf, 'json'); // TBD: replace json with array for less conversions
        //     $template = $parseReportOutput['sendingApplication'];
        // } catch (ParseException $e) {
        //     Log::warning('New parser not implemented yet or not working', ['pdf' => $pdf]);
        // }
        //
        // if ($template && $template === 'practice fusion') {
        //     $parsedData = (new CoreEngine())->newToOld($parseReportOutput, $template);
        // }
        // else {
        //     $parseReportScript = base_path('ss_toolbox/ParseReport.pm');
        //     $cmd = "perl $parseReportScript --report=$pdf --json 2>&1";
        //     $parseReportOutput = runCmd($cmd, true);
        //     if (!preg_match("/Detected radiology as:\s*'(\S.+)'/", $parseReportOutput, $match)) {
        //         throw new ParseException("PDF $pdf could not be parsed");
        //     }
        //     $template = $match[1];
        //     preg_match("/(\{.+patient.+\})/", $parseReportOutput, $match);
        //     $parsedData = json_decode($match[1]);
        // }
        // Log::debug($parseReportOutput);
    }

    /**
     * @param $html
     * @return string
     * @throws FileAndDirectoryException
     */
    public function convertHTMLIntoPDF(String $html)
    {
        $htmlLocation = '/tmp';
        $htmlFile = "$htmlLocation/submitOrder.html";
        mkdirMinusP("$htmlLocation/images");
        mkdirMinusP("$htmlLocation/files");
        File::copy(public_path('images/ss_logo.jpeg'), "$htmlLocation/images/ss_logo.jpeg");
        // File::copy(public_path("images/rx.jpg"), "$htmlLocation/images/rx.jpg");
        $logoService = new LogoService;
        $logoPath = $logoService->getCustomerLogoPath();
        File::copy(public_path($logoPath), $htmlLocation . $logoPath);
        File::copy(public_path('css/orders.css'), "$htmlLocation/orders.css");
        $html = '
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8">
                    <meta http-equiv="cache-control" content="public" />
                    <meta http-equiv="pragma" content="public" />
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="csrf-token" content="wGl2APkE7rORTN1SizF0zEwFor0Uv1svpNCDdXgu">

                    <title>ScriptSender Order</title>

                    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,600,400italic|Roboto:400,300" rel="stylesheet" type="text/css">
                    <link href="https://cdn.jsdelivr.net/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
                    <link href="orders.css" rel="stylesheet">
                    
                    <style>
                    body {font-size: 3em;}
                    </style>
                    
                </head>
                <body>
                    <div class="orders-main-div">
                        <div class="container scriptPaper">'
            . $html
            . '</div>
                </body>
                </html>';

        // Remove leading slash (/) from paths
        $html = preg_replace('|/(files/logo\.jpe?g)|', '$1', $html);
        $html = preg_replace('|/(files/logo\.png)|', '$1', $html);
        $html = preg_replace('|/(images/ss_logo\.jpeg)|', '$1', $html);

        file_put_contents($htmlFile, $html);

        $pdfFile = '/tmp/submitOrder.pdf';
        File::delete($pdfFile); # Remove any previous instance of it
        $html_to_pdf_converter = isReno()
            ? base_path('wkhtmltox/bin/wkhtmltopdf_Reno --page-size A3')
            : base_path('wkhtmltox/bin/wkhtmltopdf --page-size A3');
        runCmd("$html_to_pdf_converter '$htmlFile' '$pdfFile' > /tmp/webOrder_html_to_pdf.log 2>&1", true);
        if (!File::exists($pdfFile)) {
            abort(500, "Couldn't convert from html to pdf");
        }
        return $pdfFile;
    }

    /**
     * @param $ordersPath
     * @return bool|string
     */
    public function generateNameForOrderFile(String $ordersPath)
    {
        $done = false;
        $orderFile = '';
        for ($i = 0; $i < 200; $i++) {
            $rand = generateRandomString(10);
            $orderFile = "order_$rand.pdf";
            if (!File::exists($ordersPath . $orderFile)) {
                $done = true;
                break;
            }
        }
        return $done ? $orderFile : false;
    }

    /**
     * Looks up for NPI using third party API.
     *
     * This function needs to be in parserService. Move it there once parser is merged
     * @param array $referringDr
     * @return int
     * @throws NpiLookupFailureException
     */
    public function lookUpNPI(array $referringDr): int
    {
        $client = new NPPESApi();
        $data = [
            'last_name' => $referringDr['lastname'],
            'first_name' => $referringDr['firstname'],
            'city' => $referringDr['city'],
            'postal_code' => explode('-', $referringDr['zip'])[0],
        ];
        $results = $client->search($data)->getResults();
        if (empty($results)) {
            throw new NpiLookupFailureException('Failed to retrieve NPI from NPPES registry for physician: '
                . json_encode($referringDr));
        }
        $npi = $results[0]->getNumber();
        info('Retrieved NPI from NPPES registry', ['data' => $data, 'NPI' => $npi]);
        return $npi;
    }

    /**
     * @param array $parsedData
     * @return bool
     */
    public function isClinicalNote(array $parsedData): bool
    {
        return false !== stripos($parsedData['document_type'], 'Note');
    }

    /**
     * @param array $parsedData
     * @return bool
     */
    public function isPatientInfo(array $parsedData): bool
    {
        return false !== stripos($parsedData['document_type'], 'PatientInfo');
    }

    /**
     * @param array $parsedData
     * @return bool
     */
    public function isReferral(array $parsedData): bool
    {
        return false !== stripos($parsedData['document_type'], 'Referral');
    }

    /**
     * @param array $parsedData
     * @return bool
     */
    public function isSummary(array $parsedData): bool
    {
        return false !== stripos($parsedData['document_type'], 'Summary');
    }

    /**
     * @param array $parsedData
     * @return bool
     */
    public function isOrder(array $parsedData): bool
    {
        return !empty($parsedData['document_type']) && false !== stripos($parsedData['document_type'], 'order');
    }

    /**
     * @param array $parsedData
     * @return bool
     */
    public function isCCDXml(array $parsedData): bool
    {
        return false !== stripos($parsedData['document_type'], 'CCD');
    }

    /**
     * Check if given data came from a report
     *
     * @param array $parsedData
     * @return bool
     */
    public function isReport(array $parsedData): bool
    {
        return false !== stripos($parsedData['document_type'], 'report');
    }

    /**
     * Copy given file to a Windows shared drive
     *
     * @param string $file
     * @param string|null $newFileName
     * @param array $remote
     * @throws FileAndDirectoryException
     */
    public function copyFileToSharedDrive(string $file, string $newFileName = null, array $remote): void
    {
        $remoteDrive = $remote['share'];
        $domain = $remote['domain'];
        $user = $remote['user'];
        $password = $remote['password'];

        $localDrive = '/mnt/ScriptSender';
        mountWinDrive($remoteDrive, $localDrive, $user, $password, $domain);
        $newFileName = preg_replace("/[\"']/", '', $newFileName);
        $destFile = join_paths($localDrive, $newFileName ?: basename($file));
        runCmd("sudo cp $file '$destFile'");
        if (!File::exists($destFile)) {
            throw new FileAndDirectoryException("Failed to copy file '$file' to shared drive as $destFile");
        }
        unmount($localDrive);
        info('Copied file to shared drive', [
            'file' => $file, 'remote' => $remoteDrive, 'copied_as' => $newFileName]);
    }

    /**
     * Generate a PID.
     * This is used when a PID isn't available in the parsed data.
     *
     * @return string
     */
    public function generatePID(): string
    {
        $pid = 'SS' . now()->format('Himdy');
        logger('Generated PID', compact('pid'));
        return $pid;
    }

    public $rules = [
        'fname' => 'required|min:3|max:80|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'mi' => 'nullable|max:1|alpha',
        'lname' => 'required|min:3|max:80|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'pnum' => 'required|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'appnumber' => 'nullable|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'dob' => 'required|date',
        'hphone' => 'nullable|regex:/^(\+0?1\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/',
        'wphone' => 'nullable|regex:/^(\+0?1\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/',
        'cphone' => 'nullable|regex:/^(\+0?1\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/',
        'insur' => 'required|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'insurID' => 'required|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'city' => 'regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/', //  'alpha',
        'state' => 'regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/', //  'required|alpha|size:2',
        'country' => 'regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/', //  'required|alpha',
        'zip' => 'alpha_dash', // 'required|numeric',
        'prevFilms' => 'regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'prevFilmLoc' => 'nullable|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'prevFilmLocDateTime' => 'nullable|date|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'priorAuth',
        'authNum' => 'regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'refDr' => 'required|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'refDrID' => 'required|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'pracName' => 'required|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'refDrPhone' => 'required|regex:/^(\+0?1\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/',
        'emrgPhone' => 'nullable|regex:/^(\+0?1\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/',
        'ccAdd' => 'regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'clinHistory' => 'nullable|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
//            'appReason' => 'required|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'addNotes' => 'nullable|regex:/^[a-zA-Z0-9?$@#()\'!,+\-=_:.&€£*%\s]+$/',
        'ht' => 'nullable|numeric',
        'wt' => 'nullable|numeric',
        'gender' => 'required',
        'contrast',
        'noContrast',
        'claus',
        'recon',
        'modalityBtn' => 'required',
        'bpBtn' => 'required',
        'prArr' => 'required',
        'codeArr' => 'required',
    ];
}
