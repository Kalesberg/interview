<?php

declare(strict_types=1);

namespace ScriptSender\Services;

use Cache;
use Carbon\Carbon;
use File;
use ScriptSender\Exceptions\PrinterException;
use ScriptSender\Exceptions\PrintException;
use ScriptSender\Printers;
use Log;
use Mail;
use Exception;
use ScriptSender\Logins;
use ScriptSender\Sites\SitesInterface;
use ScriptSender\User;
use ScriptSender\Printjobs;
use ScriptSender\Mail\SS\Processed;

class PrintService
{
    protected $site;

    protected $printerService;

    public function __construct()
    {
        $this->site = resolve(SitesInterface::class);
        $this->printerService = new PrinterService();
    }

    /**
     * @param string $printedFilePath
     */
    public function reprocess(string $printedFilePath): void
    {
        $orderService = new OrderService();
        $printJob = Printjobs::where('Filename', File::basename($printedFilePath))->firstOrFail();
        $printer = $printJob->printer()->first()->name;
        $user = $printJob->user()->first();
        $orderRecord = $printJob->order()->first();
        $template = 'No match';
        $parsedData = [];
        $HL7SubmissionStatus = 'NotSubmitted';
        info('Print re-processing: Retrieved database records', ['file' => $printedFilePath]);

        // A workaround for IBM, where duplicate orders are normally discarded. Other sites would ignore this...
        Cache::tags(['Order', 'Print', 'Reprocess'])->put($printedFilePath, true, 1);

        try {
            [$HL7SubmissionStatus]
                = $this->site->incomingPrint($printer, $printedFilePath, '', $user);
            [$parsedData, $template] = $orderService->parsePDF($printedFilePath);
        } catch (Exception $e) {
            Log::error(getExceptionSummary($e));
        }
        $parsedData['HL7SubmissionStatus'] = $HL7SubmissionStatus;
        $order = $orderService->createOrderFromParsedData($parsedData, $orderRecord); // update order record
        $printJob->update([
            'format' => $template,
            'order_id' => $order->id, // Associate order, if there's none. For existing associations, this won't affect
        ]);
        info('Print re-processing: Updated database records', ['file' => $printedFilePath]);
        info('Print re-processing: Complete.', ['file' => $printedFilePath]);
    }

    /**
     * @param string $printedFilePath
     * @throws Exception
     */
    public function process(string $printedFilePath): void
    {
        (new UsageAuditService())->setCountForService('printInbound');
        $time_start = microtime(true);
        [$printer, $ip, $printedFilePath] = $this->getPrintDetails($printedFilePath);
        info('New print submitted', ['IP' => $ip, 'Printer' => $printer, 'File' => $printedFilePath]);
        [$newFileName, $printerDestination] = $this->moveAndRename($printedFilePath, $printer);
        $finalDestination = $printerDestination;
        $finalFilename = $filename = basename($newFileName);
        # Temporary workaround for Queensland Imaging's requirement of JPG instead of PDF
        $jpegFileName = null;
        if (isJpegRequired()) {
            $jpegFileName = preg_replace('/\.pdf/i', '.jpg', $finalFilename);
            $this->convertPDFToJpeg($printerDestination, $newFileName, $jpegFileName);
        }
        $printedFile = $this->copyFileToArchive($printerDestination, $newFileName);
        $user = $this->getUserFromIP($ip);
        $HL7SubmissionStatus = 'NotSubmitted';
        logger('Attempting site-specific processing', ['site' => \get_class($this->site)]);
        try {
            [$HL7SubmissionStatus, $fileMovedTo, $filename]
                = $this->site->incomingPrint($printer, $printedFile, $newFileName, $user);
            $finalDestination = $fileMovedTo ?: $finalDestination;
            $finalFilename = $filename ?: $finalFilename;
        } catch (Exception $e) {
            Log::error(getExceptionSummary($e));
        }

        $appliedRules = [];
        if (is_rs() && !Printers::isReportPrinter($printer)) {
            try {
                [$appliedRules, $fileMovedTo] = (new RulesService())
                    ->applyRules($printedFile, $ip, $printerDestination, $jpegFileName);
                $finalDestination = $fileMovedTo ?: $finalDestination;
            } catch (Exception $e) {
                Log::error(getExceptionSummary($e));
            }
        }

        // Store record in DB
        $user->TotalPrintJobsSubmitted++;
        $user->save();
        logger("Incremented 'TotalPrintJobsSubmitted' field", [
            'TotalPrintJobsSubmitted' => $user->TotalPrintJobsSubmitted]);
        $group = $user->Organization;
        info('Printed by', ['User' => $user->identity(), 'Group' => $group]);

        $orderService = new OrderService();
        $order = null;
        $template = 'No match';
        if (!Printers::isReportPrinter($printer)) {
            $parsedData = [];
            try {
                [$parsedData, $template] = $orderService->parsePDF($printedFile);
            }
            catch (Exception $e) {
                Log::error(getExceptionSummary($e));
            }
            $parsedData['HL7SubmissionStatus'] = $HL7SubmissionStatus;
            $order = $orderService->createOrderFromParsedData($parsedData);
        }

        $printjob = Printjobs::create([
            'IP' => $ip,
            'Filename' => $finalFilename,
            'Path' => $finalDestination,
            'Pagecount' => File::exists($printedFile) ? $this->getPageCount($printedFile) : 0,
            'User_id' => $user->id,
            'printer_id' => Printers::getPrinterModelFromName($printer)->id,
            'order_id' => !empty($order['id']) ? $order['id'] : null,
            'format' => $template,
            'Print_successful' => true]);

        if (!empty($appliedRules)) {
            $printjob->rules()->attach($appliedRules);
        }

        // Send email if per-submission feed is enabled
        if ($user->per_submitted_jobs_FeedEnabled && $user->per_submitted_jobs_FeedTo) {
            Mail::send(new Processed($user->per_submitted_jobs_FeedTo));
        }

        # Temporary workaround for requirement from Queensland Imaging
        if (isJpegRequired()) {
            unlink("$finalDestination/$finalFilename"); # Remove the PDF file
            logger('Removed temporary PDF', ['file' => "$finalDestination/$finalFilename"]);
        }

        $timeTaken = number_format(microtime(true) - $time_start, 2, '.', '');
        info('Print processing complete.', ['duration' => "$timeTaken Seconds"]);
    }

    /** From the IP address, find out the user who has given this print (clue: when a user logs in from the IP,
     * the IP and the user get mapped in DB)
     * @param $ip
     * @return mixed
     */
    protected function getUserFromIP(string $ip)
    {
        $user = null;

        # Get all the logins from this IP in reverse order, i.e. most recent login at the top
        $logins = Logins::where('IP', $ip)->orderBy('updated_at', 'desc')->get();
        if ($logins->count() > 0) {
            // Try to find a non-admin user
            $nonAdminUserfound = false;
            foreach ($logins as $login) {
                $u = User::findOrFail($login->user_id);
                if (($u->isUser() || $u->isServer() || $u->isPhysician()) && !preg_match('/Unregistered/i', $u->FirstName)) {
                    $user = $u;
                    $nonAdminUserfound = true;
                    break;
                }
            }

            if (!$nonAdminUserfound) {
                Log::warning("No non-admin user has logged in from IP '$ip'. Please log in at least once to " .
                    "register this IP'");
                # Just get the last logged in user. Usually an admin at this stage!
                $user = User::findOrFail($logins->first()->user_id);
                info('Fallback user', ['user' => $user->identity(), 'Role' => $user->roles()->first()->role]);
            }
        }
        elseif (User::where('FirstName', 'Unregistered')->count() > 0) {
            $user = User::where('FirstName', 'Unregistered')->first();
            Log::warning("IP $ip unknown! Login from this IP to register it in the system. Falling back to ".
                "user '$user->FirstName $user->LastName ($user->email)'");
        }
        elseif (User::withRole('Admin')->count() > 0) {
            $user = User::withRole('Admin')->first();
            Log::warning("IP $ip unknown! Login from this IP to register it in the system. Falling back to " .
                "admin account '$user->email'");
        }
        else {
            $user = User::withRole('SuperAdmin')->first();
            Log::warning("IP $ip unknown! Login from this IP to register it in the system. Falling back to ".
                "super-admin account '$user->email'");
        }

        return $user;
    }

    /**
     * Convert given PDF file to JPEG
     * @param string $printerDestination
     * @param string $newFileName
     * @param string $jpegFileName
     * @throws Exception
     */
    protected function convertPDFToJpeg(string $printerDestination, string $newFileName, string $jpegFileName): void
    {
        $cmd = "convert -quality 100 -density 150x150 -flatten $printerDestination/$newFileName $printerDestination/$jpegFileName && chmod a+r $printerDestination/$jpegFileName";
        runCmd($cmd);
        if (!(filesize("$printerDestination/$jpegFileName") > 0)) {
            throw new Exception('Failed to convert to JPEG');
        }
        info('Converted PDF to JPEG', compact('jpegFileName'));
    }

    /**
     * Return details of print, e.g. printed filename, source IP, printer name etc.
     * @param string $printedFilePath
     * @return array
     * @throws PrinterException
     */
    private function getPrintDetails(string $printedFilePath): array
    {
        $cupsLogFile = '/var/log/cups/page_log';
        $lines = file($cupsLogFile);
        if (empty($lines)) {
            throw new PrinterException("CUPS page log '$cupsLogFile' empty!");
        }

        $lastLine = end($lines);

        // A log line sample:
        //    secureinbox windows_username1 15 [31/Jul/2015:08:07:38 -0400] 1 1 - 10.56.1.22 Untitled - Notepad - -
        if (!preg_match('/\s*(\S+)\s+.+\[(.+?)\]\s*\d+\s+\d+\s+-\s+(\S+)\s+(\S.+\S)\s+/', $lastLine, $match)) {
            throw new PrinterException("Last line in CUPS log '$cupsLogFile' not in expected format. Line: '$lastLine'");
        }

        $printer = $match[1];
        $ip = $match[3];
        return [$printer, $ip, $printedFilePath];
    }

    /**
     * 1) Move the file to the printer's destination
     * 2) Rename the generated file with the user-defined prefix and timestamp
     * @param string $printedFilePath Full path of the printed file
     * @param string $printer Printer name using which the file was printed
     * @return array
     * @throws Exception
     */
    private function moveAndRename(string $printedFilePath, string $printer): array
    {
        $prefix = config('settings.cups_file_prefix');
        if (!preg_match('/(.+)(job_.+?\.pdf)/i', $printedFilePath, $matches)) {
            throw new PrintException("Pattern mismatch at filename received at command-line: $printedFilePath");
        }
        $curPath = $matches[1];
        $curFileName = $matches[2];
        $replacement = "${prefix}_" . date('d_M_o-G_i_s') . '-$1' . '$2';
        $newFileName = preg_replace('/job_(\d+).*(\.pdf)/i', $replacement, $curFileName);

        $printerDestination = Printers::getPrinterModelFromName($printer)->destination;
        runCmd("mv $curPath/$curFileName $printerDestination/$newFileName");
        // moveFile($curPath, $curFileName, $printerDestination, $newFileName);
        if (!file_exists("$printerDestination/$newFileName")) {
            throw new PrintException("Failed to move $curPath/$curFileName to $printerDestination/$newFileName");
        }
        logger("Moved '$newFileName' to '$printer's destination: $printerDestination");
        return [$newFileName, $printerDestination];
    }

    /**
     * Keep a duplicate of the file under storage/archives/print_orders/. The original file would likely be moved by
     * a rule or cronjob etc. to some shared network folder.
     * @param string $printerDestination
     * @param string $newFileName
     * @return string
     * @throws Exception
     */
    private function copyFileToArchive(string $printerDestination, string $newFileName): string
    {
        $archiveDir = config('settings.output_paths.printOrders');
        copyFile($printerDestination, $newFileName, $archiveDir);
        if (!file_exists("$archiveDir/$newFileName")) {
            throw new PrintException("Failed to copy $printerDestination/$newFileName to $archiveDir");
        }
        $printedFile = "$archiveDir/$newFileName";
        info("Copied as archive: '$printedFile'");
        return $printedFile;
    }

    /**
     * Get total pages in given PDF document
     * @param string $pdf
     * @return int
     */
    public function getPageCount(string $pdf): int
    {
        $pageCount = runCmd("pdftk $pdf dump_data output");
        preg_match("/NumberOfPages: (\d+)/", $pageCount, $matches);
        $pageCount = (int) $matches[1];
        return $pageCount;
    }

    /**
     * Retrieve data and time from printed filename
     *
     * @param string $printedFilename
     * @return string
     * @throws \InvalidArgumentException
     */
    public function getPrintDateTimeFromFilename(string $printedFilename): string
    {
        preg_match("/(\d+_\w+_\d+-\d+_\d+_\d+)/", $printedFilename, $matches);
        $printDateTime = Carbon::createFromFormat('d_M_Y-H_i_s', $matches[1])->toDateTimeString();
        return $printDateTime;
    }

    /**
     * @param string $printedFilePath
     * @param string $changeTo
     */
    public function toggleStatus(string $printedFilePath, string $changeTo): void
    {
        $printJob = Printjobs::where('Filename', File::basename($printedFilePath))->firstOrFail();
        if ($printJob->update(['Print_successful' => $changeTo === 'fail' ? 0 : 1])) {
            info('Toggled print status', ['file' => $printedFilePath, 'to' => $changeTo]);
        }
        else {
            Log::error('Failed to toggle print status', ['file' => $printedFilePath, 'to' => $changeTo]);
        }
    }
}
