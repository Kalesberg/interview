<?php

declare(strict_types=1);

namespace ScriptSender\Services\HL7;

use Aranyasen\HL7\Message;

abstract class BaseTemplate
{
    protected $data;

    /**
     * @var
     */
    protected $hl7Msg;

    /**
     * Type of HL7 message: ORM / ORU / ADT
     * @var
     */
    protected $messageType;

    public function __construct(array $data, MessageInterface $messageInterface)
    {
        $this->data = $data;
        $this->addMissingInfo();
        $this->hl7Msg = $messageInterface->create($this->data);
    }

    /**
     * Return HL7 as a Message object
     * @return Message
     */
    public function get(): Message
    {
        return $this->hl7Msg;
    }

    /**
     * Return HL7 Message as a string
     * @return Message
     */
    public function getHL7String(): string
    {
        return $this->hl7Msg->toString(true);
    }

    /**
     * Add missing info in data array
     * TODO: Use HL7 configuration settings for these three? Ask Chris if these three are always same for a given customer, or based on what do they vary
     */
    protected function addMissingInfo(): void
    {
        $this->data['sendingApplication'] = $this->data['sendingApplication'] ?? 'SCRIPTSENDER';
        $this->data['receivingApplication'] = $this->data['receivingApplication'] ?? 'Corepoint';
        $this->data['receivingFacility'] = $this->data['receivingFacility'] ?? 'TRC';
    }
}
