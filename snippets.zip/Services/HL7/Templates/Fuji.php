<?php

declare(strict_types=1);

namespace ScriptSender\Services\HL7\Templates;

use InvalidArgumentException;
use ScriptSender\Services\HL7\BaseTemplate;
use ScriptSender\Services\HL7\ORM;

/**
 * To use:
 *  $hl7Obj = new Fuji($data, ORM')->get();
 *  $hl7String = new Fuji($data,'ORM')->getHL7String();
 *
 * Class Fuji
 * @package ScriptSender\Services\HL7\Templates
 */
class Fuji extends BaseTemplate
{
    public function __construct(array $data, string $messageType = 'ORM')
    {
        if (!($messageType === 'ORM' || $messageType === 'ORU' || $messageType === 'ADT')) {
            throw new InvalidArgumentException("Message type should be one of ORM/ORU/ADT. Given: '$messageType");
        }
        parent::__construct($data, new ORM());
        $this->override();
    }

    /**
     * Override some fields with values specific to Fuji
     */
    protected function override(): void
    {
        $msh = $this->hl7Msg->getSegmentsByName('MSH')[0];
        $msh->setField(11, 'T');
        $msh->setField(15, 'AL');
        $msh->setField(16, 'NE');

        $orc = $this->hl7Msg->getSegmentsByName('ORC')[0];
        $orc->orderControl('NW');

        $pv1 = $this->hl7Msg->getSegmentsByName('PV1')[0];
        $pv1->patientClass('O');
    }
}
