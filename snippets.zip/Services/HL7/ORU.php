<?php

declare(strict_types=1);

namespace ScriptSender\Services\HL7;

use Carbon\Carbon;
use Aranyasen\HL7\Message;
use Aranyasen\HL7\Segments\DG1;
use Aranyasen\HL7\Segments\IN1;
use Aranyasen\HL7\Segments\IN3;
use Aranyasen\HL7\Segments\MSH;
use Aranyasen\HL7\Segments\NTE;
use Aranyasen\HL7\Segments\OBR;
use Aranyasen\HL7\Segments\OBX;
use Aranyasen\HL7\Segments\ORC;
use Aranyasen\HL7\Segments\PID;
use Aranyasen\HL7\Segments\PV1;
use ScriptSender\Exceptions\HL7Exception;
use ScriptSender\Services\HL7Service;

class ORU implements MessageInterface
{
    protected $hl7Msg;
    protected $msgType;
    protected $hl7String;

    public function __construct(string $hl7String = null)
    {
        $this->msgType = 'ORU^R01';
        $this->hl7Msg = new Message();
        $this->hl7String = $hl7String;
    }

    /**
     * @param array $data
     * @return Message
     * @throws \Exception
     */
    public function create(array $data): Message
    {
        error_reporting(0);

        $this->setMSH($data);
        $this->setPID($data);
        $this->setPV1($data);
        $this->setIN1($data);
        $this->setIN3($data);
        $this->setORC($data);
        $this->setOBR($data);
        $this->setNTE($data);
        $this->setDG1($data);
        $this->setOBX($data);
        error_reporting(1);
        return $this->hl7Msg;
    }

    /**
     * Build MSH segment
     *  From Chris:
     *   Sending Application - %CustomerEMRName% or %InterfaceEngine% it is different, system by system, but will
     *      normally default to ScriptSender, if we are the interface Engine, but could say Corepoint, if the customer
     *      prefers that.
     *   Sending Facility - %CustomerName%
     *   Receiving Application - %HL7TemplateSelected%  // For HL7TemplateSelected, we are sending it in the selected
     *      format in their user profile, if they choose HL7_Allscripts, we would just send Allscripts in that segment.
     *   Receiving Facility - %ReferringProvider%
     * @param array $data
     * @throws \Exception
     * @throws \InvalidArgumentException
     */
    protected function setMSH(array $data): void
    {
        $msh = new MSH();
        $sendApp = config('settings.HL7.customer_EMR_name') ?? config('settings.HL7.interface_engine', 'ScriptSender');
        $msh->setSendingApplication($sendApp);
        $msh->setSendingFacility(config('settings.site_name'));
        $msh->setReceivingApplication(); // Merge / Fuji / Allscripts etc. Should be set inside those respective classes
        $msh->setReceivingFacility($data['referringDr']['sendingFacility']); // TODO: Should be named as $data['provider']['name']
        $msh->setDateTimeOfMessage(strftime('%Y%m%d%H%M%S'));
        $msh->setMessageType($this->msgType);
        $msh->setMessageControlId(HL7Service::getNextMsgId());

        $this->hl7Msg->addSegment($msh);
    }

    protected function setPID($data)
    {
        $pid = new PID();
        $p = $data['patient'];
        $pid->setPatientID($data['PID']['id']);
        $pid->setPatientIdentifierList($data['PID']['id']);
        $pid->setAlternatePatientID($p['']);
        $pid->setPatientName([$p['lastname'], $p['firstname'], $p['middlename'], $p['suffix']]);
        $pid->setMothersMaidenName($p['']);
        $pid->setDateTimeOfBirth($p['DOB']);
        $pid->setSex($p['sex']);
        $pid->setPatientAlias($p['']);
        $pid->setRace($p['race']);
        $pid->setPatientAddress([$p['address1'], $p['address2'], $p['city'], $p['state'], $p['zip']]);
        $pid->setCountryCode($p['']);
        $pid->setPhoneNumberHome($p['phone']);
        $pid->setPhoneNumberBusiness($p['']);
        $pid->setPrimaryLanguage($p['language']);
        $pid->setMaritalStatus($p['']);
        $pid->setReligion($p['']);
        $pid->setPatientAccountNumber($data['PID']['id']); // For Merge. If this is different for any other format, make it custom
        $pid->setSSNNumber($p['']);
        $pid->setDriversLicenseNumber($p['']);
        $pid->setMothersIdentifier($p['']);
        $pid->setEthnicGroup($p['']);
        $pid->setBirthPlace($p['']);
        $pid->setMultipleBirthIndicator($p['']);
        $pid->setBirthOrder($p['']);
        $pid->setCitizenship($p['']);
        $pid->setVeteransMilitaryStatus($p['']);
        $pid->setNationality($p['']);
        $pid->setPatientDeathDateAndTime($p['deathDateAndTime']);
        $pid->setPatientDeathIndicator($p['deathIndicator']);

        $this->hl7Msg->addSegment($pid);
    }

    protected function setORC(array $data)
    {
        $orc = new ORC();
        $attDr = $data['attendingDr'];
        $refDr = $data['referringDr'];
        $refDr['address'] = [$refDr['address1'], $refDr['address2'], $refDr['city'], $refDr['state'], $refDr['zip']];
        $orc->setOrderControl($data['']);
        $orc->setPlacerOrderNumber($data['placer_order_number']);
        $orc->setFillerOrderNumber($data['']);
        $orc->setPlacerGroupNumber($data['']);
        $orc->setOrderStatus($data['']);
        $orc->setResponseFlag($data['']);
        $orc->setQuantityTiming($data['']);
        $orc->setParentOrder($data['']);
        $orc->setDateTimeofTransaction($data['patient']['DOS']);
        $orc->setEnteredBy($data['enteredBy']);
        $orc->setVerifiedBy($data['']);
        $orc->setOrderingProvider([$attDr['code'], $attDr['lastname'], $attDr['firstname']]);
        $orc->setEnterersLocation($data['']);
        $orc->setCallBackPhoneNumber($data['']);
        $orc->setOrderEffectiveDateTime($data['patient']['DOS']);
        $orc->setOrderControlCodeReason($data['']);
        $orc->setEnteringOrganization($data['']);
        $orc->setEnteringDevice($data['']);
        $orc->setActionBy($data['']);
        $orc->setAdvancedBeneficiaryNoticeCode($data['']);
        $orc->setOrderingFacilityName($data['referringDr']['sendingFacility']);
        $orc->setOrderingFacilityAddress($refDr['address']);
        $orc->setOrderingFacilityPhoneNumber($refDr['phone']);
        $orc->setOrderingProviderAddress($refDr['address']);
        $orc->setOrderStatusModifier($data['']);
        $orc->setAdvancedBeneficiaryNoticeOverrideReason($data['']);
        $orc->setFillersExpectedAvailabilityDateTime($data['']);
        $orc->setConfidentialityCode($data['']);
        $orc->setOrderType($data['']);
        $orc->setEntererAuthorizationMode($data['']);
        $orc->setParentUniversalServiceIdentifier($data['']);

        $this->hl7Msg->addSegment($orc);
    }

    protected function setOBR(array $data)
    {
        $attDr = $data['attendingDr'];
        foreach ($data['exams'] as $exam) {
            $reason_for_study = null;
            foreach ($exam['MultiDiagnosisList'] as $dx) {
                $reason_for_study = [$dx['code'], trim($dx['description'])]; // TODO: Should it be an array push?
            }
            $obr = new OBR();
            $obr->setPlacerOrderNumber($data['placer_order_number']);
            $obr->setFillerOrderNumber($data['']);
            $obr->setUniversalServiceID([$exam['procedure_code'], $exam['study']]);
            $obr->setPriority($data['']);
            $obr->setRequestedDatetime($data['patient']['DOS']);
            $obr->setObservationDateTime($data['patient']['DOS']);
            $obr->setObservationEndDateTime($data['']);
            $obr->setCollectionVolume($data['']);
            $obr->setCollectorIdentifier($data['']);
            $obr->setSpecimenActionCode($data['']);
            $obr->setDangerCode($data['']);
            $obr->setRelevantClinicalInfo($data['']);
            $obr->setSpecimenReceivedDateTime($data['']);
            $obr->setSpecimenSource($data['']);
            $obr->setOrderingProvider([$attDr['code'], $attDr['lastname'], $attDr['firstname']]);
            $obr->setOrderCallbackPhoneNumber($data['']);
            $obr->setPlacerfield1($data['']);
            $obr->setPlacerfield2($data['']);
            $obr->setFillerField1($data['referringDr']['sendingFacility']);
            $obr->setFillerField2($data['']);
            $obr->setResultsRptStatusChngDateTime($data['']);
            $obr->setChargetoPractice($data['']);
            $obr->setDiagnosticServSectID($data['']);
            $obr->setResultStatus($data['']);
            $obr->setParentResult($data['']);
            $obr->setQuantityTiming($data['quantity_timing']);
            $obr->setResultCopiesTo($data['']);
            $obr->setParent($data['']);
            $obr->setTransportationMode($data['transportation_mode']);
            $obr->setReasonforStudy($reason_for_study);
            $obr->setPrincipalResultInterpreter($data['']);
            $obr->setAssistantResultInterpreter($data['']);
            $obr->setTechnician($data['']);
            $obr->setTranscriptionist($data['']);
            $obr->setScheduledDateTime($data['patient']['DOS']);
            $obr->setNumberofSampleContainers($data['']);
            $obr->setTransportLogisticsofCollectedSample($data['']);
            $obr->setCollectorsComment($data['']);
            $obr->setTransportArrangementResponsibility($data['']);
            $obr->setTransportArranged($data['']);
            $obr->setEscortRequired($data['']);
            $obr->setPlannedPatientTransportComment($data['']);
            $this->hl7Msg->addSegment($obr);
        }
    }

    protected function setOBX(array $data)
    {
        $obx = new OBX();

        $obx->setValueType($data['']);
        $obx->setObservationIdentifier($data['']);
        $obx->setObservationSubId($data['']);
        $obx->setObservationValue($data['']);
        $obx->setUnits($data['']);
        $obx->setReferenceRange($data['']);
        $obx->setAbnormalFlags($data['']);
        $obx->setProbability($data['']);
        $obx->setNatureOfAbnormalTest($data['']);
        $obx->setObserveResultStatus($data['']);
        $obx->setDataLastObsNormalValues($data['']);
        $obx->setUserDefinedAccessChecks($data['']);
        $obx->setDateTimeOfTheObservation($data['']);
        $obx->setProducersId($data['']);
        $obx->setResponsibleObserver($data['']);
        $obx->setObservationMethod($data['']);

        $this->hl7Msg->addSegment($obx);
    }

    protected function setNTE(array $data)
    {
        $nte = new NTE();
        $nte->setSourceOfComment($data['']);
        $nte->setComment($data['']);
        $nte->setCommentType($data['']);
        $this->hl7Msg->addSegment($nte);
    }

    protected function setDG1(array $data)
    {
        foreach ($data['exams'] as $exam) {
            $dg1 = new DG1();
            foreach ($exam['MultiDiagnosisList'] as $dx) {
                $dg1->setDiagnosisCodingMethod($dx['coding_method']);
                $dg1->setDiagnosisCodeDG1($dx['code']);
                $dg1->setDiagnosisDescription($dx['description']);
                $dg1->setDiagnosisDateTime($data['']);
                $dg1->setDiagnosisType($data['']);
                $dg1->setMajorDiagnosticCategory($data['']);
                $dg1->setDiagnosticRelatedGroup($data['']);
                $dg1->setDRGApprovalIndicator($data['']);
                $dg1->setDRGGrouperReviewCode($data['']);
                $dg1->setOutlierType($data['']);
                $dg1->setOutlierDays($data['']);
                $dg1->setOutlierCost($data['']);
                $dg1->setGrouperVersionAndType($data['']);
                $dg1->setDiagnosisPriority($data['']);
                $dg1->setDiagnosingClinician($data['']);
                $dg1->setDiagnosisClassification($data['']);
                $dg1->setConfidentialIndicator($data['']);
                $dg1->setAttestationDateTime($data['']);
            }
        }
        $this->hl7Msg->addSegment($dg1);
    }

    protected function setPV1(array $data)
    {
        $pv1 = new PV1();
        $attDr = $data['attendingDr'];
        $refDr = $data['referringDr'];
        $pv1->setPatientClass($data['patientClass']);
        $pv1->setAssignedPatientLocation($data['']);
        $pv1->setAdmissionType($data['']);
        $pv1->setPreAdmitNumber($data['']);
        $pv1->setPriorPatientLocation($data['']);
        $pv1->setAttendingDoctor([$attDr['code'], $attDr['lastname'], $attDr['firstname'], '', '', $attDr['degree']]);
        $pv1->setReferringDoctor([$refDr['code'], $refDr['lastname'], $refDr['firstname'], '', '', $refDr['degree']]);
        $pv1->setConsultingDoctor($data['']);
        $pv1->setHospitalService($data['']);
        $pv1->setTemporaryLocation($data['']);
        $pv1->setPreAdmitTestIndicator($data['']);
        $pv1->setReAdmissionIndicator($data['']);
        $pv1->setAdmitSource($data['']);
        $pv1->setAmbulatoryStatus($data['']);
        $pv1->setVipIndicator($data['']);
        $pv1->setAdmittingDoctor($data['']);
        $pv1->setPatientType($data['']);
        $pv1->setVisitNumber($data['']);
        $pv1->setFinancialClass($data['']);
        $pv1->setChargePriceIndicator($data['']);
        $pv1->setCourtesyCode($data['']);
        $pv1->setCreditRating($data['']);
        $pv1->setContractCode($data['']);
        $pv1->setContractEffectiveDate($data['']);
        $pv1->setContractAmount($data['']);
        $pv1->setContractPeriod($data['']);
        $pv1->setInterestCode($data['']);
        $pv1->setTransferToBadDebtCode($data['']);
        $pv1->setTransferToBadDebtDate($data['']);
        $pv1->setBadDebtAgencyCode($data['']);
        $pv1->setBadDebtTransferAmount($data['']);
        $pv1->setBadDebtRecoveryAmount($data['']);
        $pv1->setDeleteAccountIndicator($data['']);
        $pv1->setDeleteAccountDate($data['']);
        $pv1->setDischargeDisposition($data['']);
        $pv1->setDischargedToLocation($data['']);
        $pv1->setDietType($data['']);
        $pv1->setServicingFacility($refDr['sendingFacility']);
        $pv1->setBedStatus($data['']);
        $pv1->setAccountStatus($data['']);
        $pv1->setPendingLocation($data['']);
        $pv1->setPriorTemporaryLocation($data['']);
        $pv1->setAdmitDateTime($data['']);
        $pv1->setDischargeDateTime($data['']);
        $pv1->setCurrentPatientBalance($data['']);
        $pv1->setTotalCharges($data['']);
        $pv1->setTotalAdjustments($data['']);
        $pv1->setTotalPayments($data['']);
        $pv1->setAlternateVisitID($data['']);
        $pv1->setVisitIndicator($data['']);
        $pv1->setOtherHealthcareProvider($data['']);

        $this->hl7Msg->addSegment($pv1);
    }

    protected function setIN1(array $data)
    {
        foreach ($data['insuranceList'] as $insurance) {
            $in1 = new IN1();
            $in1->setInsurancePlanID($insurance['policy']);
            $in1->setInsuranceCompanyID($insurance['companyID']);
            $in1->setInsuranceCompanyName($insurance['providerNetwork']);
            $in1->setInsuranceCompanyAddress([$insurance['address1'], '', $insurance['city'], $insurance['state'], $insurance['zip']]);
            $in1->setInsuranceCoContactPerson($insurance['']);
            $in1->setInsuranceCoPhoneNumber($insurance['']);
            $in1->setGroupNumber($insurance['group']);
            $in1->setGroupName($insurance['']);
            $in1->setInsuredsGroupEmpID($insurance['']);
            $in1->setInsuredsGroupEmpName($insurance['']);
            $in1->setPlanEffectiveDate($insurance['']);
            $in1->setPlanExpirationDate($insurance['']);
            $in1->setAuthorizationInformation($insurance['']);
            $in1->setPlanType($insurance['']);
            $in1->setNameOfInsured([$insurance['insured']['lastname'], $insurance['insured']['firstname'], $insurance['insured']['middlename']]);
            $in1->setInsuredsRelationshipToPatient($insurance['insured']['relationship']);
            $in1->setInsuredsDateOfBirth($insurance['']);
            $in1->setInsuredsAddress($insurance['']);
            $in1->setAssignmentOfBenefits($insurance['']);
            $in1->setCoordinationOfBenefits($insurance['']);
            $in1->setCoordOfBenPriority($insurance['']);
            $in1->setNoticeOfAdmissionFlag($insurance['']);
            $in1->setNoticeOfAdmissionDate($insurance['']);
            $in1->setReportOfEligibilityFlag($insurance['']);
            $in1->setReportOfEligibilityDate($insurance['']);
            $in1->setReleaseInformationCode($insurance['']);
            $in1->setPreAdmitCertPAC($insurance['']);
            $in1->setVerificationDateTime($insurance['']);
            $in1->setVerificationBy($insurance['']);
            $in1->setTypeOfAgreementCode($insurance['']);
            $in1->setBillingStatus($insurance['']);
            $in1->setLifetimeReserveDays($insurance['']);
            $in1->setDelayBeforeLRDay($insurance['']);
            $in1->setCompanyPlanCode($insurance['']);
            $in1->setPolicyNumber($insurance['']);
            $in1->setPolicyDeductible($insurance['']);
            $in1->setPolicyLimitAmount($insurance['']);
            $in1->setPolicyLimitDays($insurance['']);
            $in1->setRoomRateSemiPrivate($insurance['']);
            $in1->setRoomRatePrivate($insurance['']);
            $in1->setInsuredsEmploymentStatus($insurance['']);
            $in1->setInsuredsSex($insurance['']);
            $in1->setInsuredsEmployersAddress($insurance['']);
            $in1->setVerificationStatus($insurance['']);
            $in1->setPriorInsurancePlanID($insurance['']);
            $in1->setCoverageType($insurance['']);
            $in1->setHandicap($insurance['']);
            $in1->setInsuredsIDNumber($insurance['']);
            $this->hl7Msg->addSegment($in1);
        }
    }

    protected function setIN3(array $data)
    {
        $in3 = new IN3();

        $in3->setCertificationNumber($data['']);
        $in3->setCertifiedBy($data['']);
        $in3->setCertificationRequired($data['']);
        $in3->setPenalty($data['']);
        $in3->setCertificationDateTime($data['']);
        $in3->setCertificationModifyDateTime($data['']);
        $in3->setOperator($data['']);
        $in3->setCertificationBeginDate($data['']);
        $in3->setCertificationEndDate($data['']);
        $in3->setDays($data['']);
        $in3->setNonConcurCodeDescription($data['']);
        $in3->setNonConcurEffectiveDateTime($data['']);
        $in3->setPhysicianReviewer($data['']);
        $in3->setCertificationContact($data['']);
        $in3->setCertificationContactPhoneNumber($data['']);
        $in3->setAppealReason($data['']);
        $in3->setCertificationAgency($data['']);
        $in3->setCertificationAgencyPhoneNumber($data['']);
        $in3->setPreCertificationRequirement($data['']);
        $in3->setCaseManager($data['']);
        $in3->setSecondOpinionDate($data['']);
        $in3->setSecondOpinionStatus($data['']);
        $in3->setSecondOpinionDocumentationReceived($data['']);
        $in3->setSecondOpinionPhysician($data['']);

        $this->hl7Msg->addSegment($in3);
    }

    /**
     * @param array $data
     * @return mixed
     * @throws HL7Exception
     */
    protected function getSendingApp(array $data)
    {
        $sendingApplication = $data['format'] ?? $data['sendingApplication'];
        if (!$sendingApplication) {
            throw new HL7Exception('Sending application not defined in given data array');
        }
        return $sendingApplication;
    }

    public function toArray(): array
    {
        // Convert $this->hl7String to array
        $m = new Message($this->hl7String);
        $data = [];
        $data['report'] = $this->getReportInfo($m);
        $data['patient'] = $this->getPatientInfo($m);
        $data['referringDr'] = $this->getReferringDoctorInfo($m);
        $data['observation'] = $this->getObservationInfo($m);
        $data['exams'] = $this->getExams($m);
        $data['PID'] = $this->getPID($m);
        $data['ReadingRadiologist'] = $this->getReadingRadiologist($m);
        return $data;
    }

    protected function getPatientInfo(Message $m): array
    {
        $patient = [];
        $pid = $m->getSegmentsByName('PID')[0];
        [$patient['lastname'], $patient['firstname']] = $pid->getPatientName();
        $patient['DOB'] = $pid->getDateTimeOfBirth();
        $patient['sex'] = $pid->getSex();

        $obr = $m->getSegmentsByName('OBR')[0];
        $patient['DOS'] = Carbon::parse($obr->getObservationDateTime())->toDayDateTimeString();

        return $patient;
    }

    protected function getPID(Message $m)
    {
        $pid = $m->getSegmentsByName('PID')[0];
        return ['id' => $pid->getPatientIdentifierList()];
    }

    protected function getReferringDoctorInfo(Message $m): array
    {
        $referringDr = [];
        $obr = $m->getSegmentsByName('OBR')[0];
        [$referringDr['code'], $referringDr['firstname'], $referringDr['lastname']] = $obr->getOrderingProvider();

        try {
            $orc = $m->getSegmentsByName('ORC')[0];
            [$referringDr['address1'], $referringDr['address2'], $referringDr['city'], $referringDr['state'], $referringDr['zip']] = $orc->getOrderingProviderAddress();
        } catch (Exception $e) {
            Log::error(getExceptionSummary($e));
        }
        return $referringDr;
    }

    protected function getReadingRadiologist(Message $m): array
    {
        $readingRadiologist = [];
        $obr = $m->getSegmentsByName('OBR')[0];
        [$readingRadiologist['code'], $readingRadiologist['firstname'], $readingRadiologist['lastname']]
            = $obr->getPrincipalResultInterpreter();
        return $readingRadiologist;
    }

    protected function getObservationInfo(Message $m): array
    {
        $observation = [];
        $key = null;
        $OBXs = $m->getSegmentsByName('OBX');
        foreach ($OBXs as $obx) {
            $value = $obx->getObservationValue();
            if (isLIRA()) {
                $observation[] = $value;
                continue;
            }
            if (preg_match('/THIS IS AN ELECTRONICALLY VERIFIED REPORT/', $value)) {
                $observation[] = $value;
                $observation[] = end($OBXs)->getObservationValue();
                break;
            }
            if (preg_match('/(\w.+?):(.*)/', $value, $matched)) {
                $key = $matched[1];
                $observation[] = [$key => $matched[2]];
            }
            elseif ($key) {
                $oldValue = array_column($observation, $key) ? array_column($observation, $key)[0] : null;
                unset($observation[array_search([$key => $oldValue], $observation, true)]);
                $observation = array_values($observation); // Remove the gaps and make the array indices serial again
                $observation[] = [$key => $oldValue . $value];
            }
            else {
                $observation[] = [$value];
            }
        }
        return $observation;
    }

    protected function getExams(Message $m)
    {
        $exams = [];
        $obr = $m->getSegmentsByName('OBR')[0];
        [$exams['procedure_code'], $exams['study']] = $obr->getUniversalServiceID();
        return $exams;
    }

    protected function getReportInfo(Message $m)
    {
        $report = [];
        $msh = $m->getSegmentsByName('MSH')[0];
        $report['DateTimeOfMessage'] = Carbon::parse($msh->getDateTimeOfMessage())->toDayDateTimeString();

        $obr = $m->getSegmentsByName('OBR')[0];
        $report['accession'] = $obr->getPlacerOrderNumber();
        return $report;
    }
}
