<?php

namespace app\Services\HL7;

use Aranyasen\HL7\Message;

class PIDSegment
{
    public function getTest1()
    {
        $msg = new Message("MSH*^~\\&*1\rPID***xxx\r");
        return $msg->toString(true);
    }
}
