<?php

namespace ScriptSender\Services\HL7;

use Aranyasen\HL7\Message;

interface MessageInterface
{
    public function create(array $data): Message;
}
