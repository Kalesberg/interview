<?php namespace ScriptSender\Services;

class SearchService
{
    public function search($needle, $type, $haystack)
    {
        $cond = false;

        switch ($type) {
            case 'keyword':
                $cond = $this->keywordSearch($needle, $haystack);
                break;

            case 'regexp':
                $cond = $this->regexpSearch($needle, $haystack);
                break;
                
            default:
                break;
        }

        return $cond;
    }

    // TBD: Handle surrounding quotes, paranthesis of entire string
    // TBD: Handle complex paranthesis: (w1&(w2|w3))|w4
    private function keywordSearch($needle, $haystack)
    {
        $cond = false;
        if (preg_match('/\(.+\)/', $needle)) { // If string contains a paranthesis

            // If needle is of the form (...)&...
            $needles = explode('&', $needle);
            if (preg_grep('/^\(.+\)$/', $needles)) {
                $needles = preg_replace('/\(|\)/', '', $needles); # Remove paranthesis
                $cond = $this->andMatch($needles, $haystack);
            }

            // If needle is of the form (...)|...
            $needles = explode('|', $needle);
            if (preg_grep('/^\(.+\)$/', $needles)) {
                $needles = preg_replace('/\(|\)/', '', $needles); # Remove paranthesis
                $cond = $this->orMatch($needles, $haystack);
            }
        }
        else {
            $needles = explode('&', $needle);
            if(!empty($needles)) {
                $cond = $this->andMatch($needles, $haystack);
            }
            $needles = explode('|', $needle);
            if(!empty($needles)) {
                $cond = $this->orMatch($needles, $haystack);
            }
        }
        return $cond;
    }

    // $patterns = array, where all elements must match in $text
    function andMatch($patterns, $text) 
    {
        $match = true;
        foreach ($patterns as $subPattern) {
            if (!$this->does_match($subPattern, $text)) {
                $match = false;
                break;
            }
        }
        return $match;
    }

    // Check if any one of the given elements in the array matches in $text
    function orMatch($patterns, $text) 
    {
        $match = false;
        foreach ($patterns as $subPattern) {
            if ($this->does_match($subPattern, $text)) {
                $match = true;
                break;
            }
        }
        return $match;
    }

    // does_match("string1", $text)
    // does_match("string1|string2", $text)
    // does_match("string1&string2", $text)
    function does_match($string, $text) 
    {
        if (is_array($text)) {
            $text = implode('', $text);
        }

        $string = preg_replace('/[\'"]/', '', $string); // Remove any stray quotes

        $match;

        if(preg_match('/(.+)&(.+)/', $string, $matched)) {
            $string1 = trim($matched[1]);
            $string2 = trim($matched[2]);
            $match = (preg_match("/$string1/", $text) and preg_match("/$string2/", $text));
        }
        elseif(preg_match('/(.+)\|(.+)/', $string, $matched)) {
            $string1 = trim($matched[1]);
            $string2 = trim($matched[2]);
            $match = (preg_match("/$string1/", $text) or preg_match("/$string2/", $text));
        }
        else {
            $match = preg_match("/$string/", $text);
        }

        return (bool) $match;
    }
}