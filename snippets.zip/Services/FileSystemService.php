<?php namespace ScriptSender\Services;

/**
 * This class contains methods to handle everything related
 * to filesystem, that are not present in the helper.php class
 */

use Log;
use File;
use SplFileInfo;
use \ScriptSender\Exceptions\FileAndDirectoryException;

class FileSystemService
{
    /**
     * Prepare the given file so its contents can be displayed on web
     * (Copy the given file to public/files/ as a temporary file and return it)
     * @param string $filePath Full path of file
     * @param null|string $downloadedFileName (optional) Filename for the file to be downloaded as
     * @return null|string [type] [description]
     * @throws FileAndDirectoryException
     */
    public function showFile($filePath, $downloadedFileName = null): ?string
    {
        if (!file_exists($filePath)) {
            throw new FileAndDirectoryException("File '$filePath' doesn't exist");
        }
        $info = new SplFileInfo($filePath);
        $extension = $info->getExtension();

        if ($downloadedFileName) {
            # If no extension is provided with the target filename, add the source filename's extension
            $info = new SplFileInfo($downloadedFileName);
            $ext = $info->getExtension();
            if (!$ext) {
                $downloadedFileName .= ".$extension";
            }
        }
        else {
            $randomString = generateRandomString(10);
            $downloadedFileName = "temp_$randomString.$extension";
        }
        // Delete the existing temp_<random>.$extension file and create a new one
        array_map('unlink', glob(public_path("/files/temp*.$extension")));
        File::copy($filePath, public_path("/files/$downloadedFileName"));
        return $downloadedFileName;
    }
}
