<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use Cache;
use File;
use Illuminate\Support\Facades\Redis;
use Log;
use Illuminate\Http\Request;
use Route;
use ScriptSender\Exceptions\FileAndDirectoryException;
use ScriptSender\Exceptions\InsufficientDataInReportException;

/**
 * This adds a hyperlink to image viewer in the given report PDF
 *
 * Class HyperlinkService
 * @package ScriptSender\Services
 */
class HyperlinkService
{
    protected $pdf;

    /**
     * List of MD5 hashes of files that are processed by this script, stored in Redis
     *
     * @var string
     */
    protected $redisFilesTracker;
    protected $redis;
    protected $imageViewerService;
    protected $usageAuditService;

    public function __construct(ImageViewerService $imageViewerService)
    {
        $this->redisFilesTracker = 'ss_hyperlink_files_processed';
        $this->redis = Redis::connection();
        $this->imageViewerService = $imageViewerService;
        $this->usageAuditService = new UsageAuditService();
    }

    /**
     * Set PDF file path
     *
     * @param string $pdfFile
     * @return HyperlinkService
     * @throws FileAndDirectoryException
     */
    public function setPdf(string $pdfFile): HyperlinkService
    {
        if (!File::exists($pdfFile)) {
            throw new FileAndDirectoryException("Report $pdfFile not found");
        }
        $this->pdf = $pdfFile;
        return $this;
    }

    /**
     * @param bool $testUrl
     * @param string $pid
     * @param string $accession
     * @param string|null $dob
     * @param string|null $sex
     * @return string
     */
    public function createUrl(bool $testUrl = false, string $pid, string $accession, string $dob = null, string $sex = null)
    {
        $encryptedString = $this->imageViewerService->encrypt("$pid/$accession/$dob/$sex");
        return $testUrl
            ? route('image_viewer::test_study', ['encrypted_string' => $encryptedString])
            : route('image_viewer::study', ['encrypted_string' => $encryptedString]);
    }

    /**
     * Insert URL into PDF.
     *
     * @param bool $force Force inserting it. By default if it detects a link, it returns.
     * @throws \RuntimeException
     * @throws FileAndDirectoryException
     * @throws InsufficientDataInReportException
     * @throws \Exception
     * @throws \Throwable
     */
    public function insert(bool $force = false): void
    {
        if (!$force && $this->isAlreadyInserted()) {
            logger('Link was inserted earlier', ['pdf' => $this->pdf]);
            return;
        }
        [$pid, $accession, $dob, $sex] = $this->extractData();
        if (!$this->testUrl($pid, $accession, $dob, $sex)) {
            throw new \RuntimeException('Test URL not working! Aborting URL insertion');
        }
        $url = $this->createUrl(false, $pid, $accession, $dob, $sex);
        $this->callInserterScript($url);
        $this->markAsDone();
        $this->usageAuditService->setCountForService('imageViewer');
        info('Inserted link in pdf', ['pdf' => $this->pdf]);
    }

    /**
     * Return true if test URL works
     *
     * @param string $pid
     * @param string $accession
     * @param string $dob
     * @param string $sex
     * @return bool
     */
    public function testUrl(string $pid, string $accession, string $dob = null, string $sex = null): bool
    {
        $url = $this->createUrl(true, $pid, $accession, $dob, $sex);
        $request = Request::create($url);
        $response = Route::dispatch($request);
        if ($response->getStatusCode() === 200) {
            return true;
        }
        Log::error('URL not accessible', compact('pid', 'accession', 'dob', 'sex', 'url'));
        return false;
    }

    /**
     * @return array
     * @throws \ScriptSender\Exceptions\InsufficientDataInReportException
     * @throws FileAndDirectoryException
     * @throws \Exception
     * @throws \Throwable
     */
    public function extractData(): array
    {
        // We may already have its data parsed and cached, e.g. when it's from ORU
        if (Cache::has(realpath($this->pdf))) {
            $parsedData = Cache::get(realpath($this->pdf));
        }
        else {
            $parsedData = (new Document($this->pdf, new OrderService()))->toArray();
        }
        [$pid, $accession, $dob, $sex] = [
            $parsedData['report']['PID'] ?? $parsedData['PID']['id'],
            $parsedData['report']['accession'],
            substr($parsedData['patient']['DOB'], 0, 8),
            $parsedData['patient']['sex']
        ];
        $error = null;
        if (empty($pid)) {
            $error = 'PID not retrieved from report';
        }
        if (empty($accession)) {
            $error = 'Accession not retrieved from report';
        }
        if (isNERAD()) {
            if (!array_key_exists('DOB', $parsedData['patient']) || !$parsedData['patient']['DOB']) {
                $error = 'Patient\'s DOB not retrieved from report';
            }
            if (!array_key_exists('sex', $parsedData['patient']) || !$parsedData['patient']['sex']) {
                $error = 'Patient\'s sex not retrieved from report';
            }
        }
        if ($error) {
            throw new InsufficientDataInReportException($error);
        }
        return [$pid, $accession, $dob, $sex];
    }

    public function markAsDone()
    {
        $this->redis->hset($this->redisFilesTracker, md5_file($this->pdf), '1');
        logger('Saved file md5 in Redis', ['report' => $this->pdf]);
    }

    public function isAlreadyInserted(): bool
    {
        return (bool) $this->redis->hget($this->redisFilesTracker, md5_file($this->pdf));
    }

    /**
     * Call Python script to insert given URL in the pdf file
     *
     * @param string $url
     * @throws FileAndDirectoryException
     */
    protected function callInserterScript(string $url): void
    {
        $site = isNERAD() ? 'NERAD' : '';
        $pythonScript = base_path('ss_toolbox/add_in_pdf.py');
        runCmd("python $pythonScript -p \"$this->pdf\" -u \"$url\" -s \"$site\"");

        // The Python script creates the out file under /tmp/. Move it back to original location...
        $filename = basename($this->pdf);
        $outFile = "/tmp/$filename";
        if (!File::exists($outFile)) {
            Log::error('Could not insert url', ['pdf' => $this->pdf]);
        }
        File::move($outFile, \dirname($this->pdf) . "/$filename");
        changePerms($this->pdf, '0770', 'www-data', 'www-data', true);
    }
}
