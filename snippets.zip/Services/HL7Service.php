<?php

namespace ScriptSender\Services;

use Aranyasen\Exceptions\HL7ConnectionException;
use Aranyasen\HL7\Messages\ACK;
use Cache;
use Log;
use File;
use Mail;
use Config;
use Artisan;
use Exception;
use Carbon\Carbon;
use Aranyasen\HL7\Message;
use Aranyasen\HL7\Connection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use Aranyasen\HL7\Segments\OBX;
use ScriptSender\Exceptions\ReceivedHL7NACKException;
use ScriptSender\Services\HL7\ORM;
use ScriptSender\Services\HL7\Templates\Merge;
use ScriptSender\User;
use ScriptSender\Folders;
use ScriptSender\HL7Connection;
use ScriptSender\HL7MessageLog;
use ScriptSender\Connection_Logs;
use ScriptSender\HL7ConnectionLog;
use ScriptSender\NotificationLogs;
use ScriptSender\ConnectionNotification;
use ScriptSender\Events\HL7MsgEvent;
use ScriptSender\Events\ConnectionLog;
use ScriptSender\Events\NotificationLog;
use ScriptSender\Events\SignalConnection;
use ScriptSender\Mail\NotifyAdmin;
use ScriptSender\Sites\SitesInterface;
use ScriptSender\Logging\CustomizeLogger;
use ScriptSender\Http\Controllers\HL7;
use ScriptSender\Http\Controllers\Controller;
use ScriptSender\Exceptions\HL7Exception;
use ScriptSender\Exceptions\FileAndDirectoryException;
use ScriptSender\Services\HL7\ORU;
use ScriptSender\Services\Mailers\ClientUnresponsiveMailer;

class HL7Service
{
    protected $site;
    protected $usageAuditService;

    public function __construct()
    {
        (new CustomizeLogger())->setComponent('HL7');
        $this->site = resolve(SitesInterface::class);
        $this->usageAuditService = new UsageAuditService();
    }

    /**
     * Convert given file (or all files in given directory) to HL7
     *   TODO: Rename to: convertFileToHL7. This will make it more consistent with remaining converters in this class.
     * @param string $type 'order' or 'report'. Required for audit services
     * @param string $path Full path of file or directory that needs to be converted
     * @param string $format HL7 format to be converted to. Without this argument, it converts to all available formats
     * @param null $output_file Full path of output file
     * @param null $user
     * @throws Exception
     */
    public function convertToHL7(string $type, string $path, $format = null, $output_file = null, $user = null): void
    {
        if (!is_readable($path)) {
            throw new Exception("File or directory '$path' does not exist or not readable");
        }

        if (preg_match('/pdf$/i', $format)) {
            Log::debug("Format requested for file $path is 'pdf'. Skipping");
            return;
        }

        if ($this->isHL7File($path)) {
            Log::debug("File $path is already a valid HL7 file. Skipping...");
            return;
        }

        $script = base_path('ss_toolbox/output_format_converter/main.pl');
        $logdump = '/tmp/output_format_converter';
        $formatArg = $format ? "--format=$format" : '';

        if (is_file($path)) { # Single file...
            if (false !== stripos($format, 'Merge')) { // If Merge works, add eRad here, and in new Merge()...
                $outFile = preg_replace('/\.pdf$/', "_{$format}.hl7", $path);
                [$parsedData] = (new OrderService())->parsePDF($path);
                // Check if the hl7_xxx.pm file performs anything using $user. Do it here
                (new Merge($parsedData))->toFile($outFile);
                if ($output_file) {
                    File::move($path, $output_file);
                    Log::debug("Renamed $path to $output_file as per request");
                }
            }
            else {
                runCmd("sudo perl $script --report='$path' --user='$user' $formatArg --debug > $logdump 2>&1", true);
                if ($output_file) {
                    $path = preg_replace('/\.pdf$/i', "_${format}.hl7", $path);

                    runCmd("mv '$path' '$output_file' && sudo chmod 777 $output_file");
                    Log::debug("Renamed $path to $output_file as per request");
                }
            }
        }
        else { # All files in given directory
            throw new Exception("Multiple file HL7 generation not enabled. To be implemented");
            // $parentDir = is_dir($path) ? $path : \dirname($path);
            // runCmd("sudo perl $script --reports_dir='$parentDir' $formatArg > $logdump 2>&1", true);
        }

        Log::info("Translated $type to HL7", ['PDF' => $path, 'HL7' => $output_file, 'Format' => $format]);

        $this->usageAuditService->setCountForService('translation');
    }

    /**
     * Convert given file (or all files in given directory) to HL7
     * @param array $data complex array containing parsed data from PDF
     * @param string $format HL7 format to be converted to. Without this argument, it converts to all available formats
     * @param null|string $output_file Full path of output file
     * @param string|null $type report/order etc.
     * @throws Exception
     */
    public function convertArrayToHL7(array $data, string $format, string $output_file): void
    {
        if (false !== stripos($format, 'Merge')) {
            (new Merge($data))->toFile($output_file);
        }
        else {
            $script = base_path('ss_toolbox/jsonToHL7.pl');
            $logdump = '/tmp/array_to_hl7.log';
            $data_json = json_encode($data);
            $tempJsonFile = '/tmp/temp.json';
            file_put_contents($tempJsonFile, $data_json);
            runCmd("perl $script --file=$tempJsonFile --outputformat=$format --outFile=$output_file 2>&1 > $logdump", true);
        }
        if (!is_file($output_file)) {
            throw new Exception("convertArrayToHL7 failed: File $output_file does not exist after conversion");
        }
        if (!is_readable($output_file)) {
            throw new Exception("convertArrayToHL7 failed: File $output_file is not readable");
        }
        $this->usageAuditService->setCountForService('translation');
    }

    /**
     * Convert given HL7 message into PHP array
     * @param string $hl7
     * @return array
     * @throws \Exception
     */
    public function convertHL7ToArray(string $hl7): array
    {
        return (new ORU($hl7))->toArray();
    }

    /**
     * Return true if the given file contains HL7 string
     * @param string $path
     * @return bool
     */
    public function isHL7File(string $path): bool
    {
        if (! (is_file($path) && file_exists($path))) {
            return false;
        }
        $contents = file_get_contents($path);
        return preg_match('/MSH\|/', $contents) && preg_match('/PID\|/', $contents);
    }

    // /**
    //  * Send HL7 to remote listener
    //  *
    //  * @param string|Message $hl7Msg as a string or Messgae object
    //  * @param string $ip
    //  * @param int $port
    //  * @return bool
    //  */
    // public function sendHl7Message($hl7Msg, string $ip, int $port): bool
    // {
    //     // info('in ip');
    //     // info('send function', ['hl7File' => $hl7File]);
    //     // info('send function', ['ip' => $ip]);
    //     // info('send function', ['port' => $port]);
    //     $cName = HL7Connection::where('ip', $ip)->first();
    //
    //     if (!is_readable($hl7File)) {
    //         throw new Exception("File '$hl7File' does not exist or not readable");
    //     }
    //
    //     $script = base_path('ss_toolbox/hl7_sender.pm');
    //     $debugOpt = (config('app.log_level') === 'debug') ?'--debug' :'';
    //     $cmd = "perl $script --hl7_file=$hl7File --ip=$ip --port=$port $debugOpt | tee /tmp/hl7_sender.log 2>&1";
    //     $ret = runCmd($cmd, true);
    //
    //     if (preg_match('/Ack from server/', $ret)) {
    //         Log::info("Sent HL7 to $ip:$port");
    //         Log::info("ACK from server: {$ret}");
    //
    //         if(preg_match('/\|AE\|/', $ret) || preg_match('/\|CE\|/', $ret) || preg_match('/No plugin found for message type/', $ret)){
    //             // nack send
    //             info('send function nack');
    //             $result = $this->saveHL7MessageLog($cName->id, $hl7File, $ip, $port, 'outgoing', 'nack');
    //             Log::info($result, ["hl7 message log added"]);
    //         }else{
    //             // ack send
    //             info('send function ack');
    //             $result = $this->saveHL7MessageLog($cName->id, $hl7File, $ip, $port, 'outgoing', 'ack');
    //             Log::info($result, ["hl7 message log added"]);
    //         }
    //
    //         /* $hl7Log = json_encode(['cname' => $cName->name, 'cid' => $cName->id, 'file_path' => $hl7File]);
    //         Log::info($hl7Log, ["connectivity"]); */
    //
    //         event(new HL7MsgEvent($cName, $hl7File, $result));
    //         return true;
    //     }
    //     else {
    //         Log::error("HL7 to $ip:$port failed");
    //         return false;
    //     }
    //
    //     // if (!is_readable($hl7File)) {
    //     //     throw new Exception("File '$hl7File' does not exist or not readable");
    //     // }
    //     //
    //     // $message = new Message(File::get($hl7File));
    //     // $ret = (new Connection($ip, $port))->send($message);
    //     // $ret = $ret->toString(true);
    //     // if (false !== strpos($ret, 'MSH')) {
    //     //     Log::info('Sent HL7 to remote', ['IP' => $ip, 'Port' => $port]);
    //     //     Log::info('ACK from server', ['ACK' => $ret]);
    //     //     return true;
    //     // }
    //     // Log::error('Failed to send HL7 to', ['IP' => $ip, 'Port' => $port]);
    //     // return false;
    // }

    /**
     * @param string|Message $hl7Msg
     * @param string $ip
     * @param int $port
     * @return bool
     * @throws HL7ConnectionException
     * @throws ReceivedHL7NACKException
     * @throws \Aranyasen\Exceptions\HL7Exception
     */
    public function sendHl7Message($hl7Msg, string $ip, int $port)
    {
        $message = $hl7Msg;
        if (\is_string($hl7Msg)) {
            $message = new Message($hl7Msg);
        }
        elseif (!is_a($hl7Msg, Message::class)) {
            throw new \InvalidArgumentException('Type of argument not supported');
        }

        $ack = (new Connection($ip, $port))->send($message);
        $returnString = $ack->toString(true);
        if (strpos($returnString, 'MSH') === false) {
            throw new HL7ConnectionException("Failed to send HL7 to 'IP' => $ip, 'Port' => $port");
        }
        info('ACK from server', ['ACK' => $returnString]);
        $msa = $ack->getSegmentsByName('MSA')[0];
        $ackCode = $msa->getAcknowledgementCode();
        if ($ackCode[1] === 'A') {
            info('Sent HL7 to remote', ['IP' => $ip, 'Port' => $port, 'status' => 'Success']);
            return true; // TODO: Remove this and change all callers accordingly
        }

        throw new ReceivedHL7NACKException($ack);
    }

    /**
     * TODO: Probably not used. Remove it...
     *
     * @param string $printedFile
     * @param string $format
     * @param string $ip
     * @param string $port
     * @param string $type
     * @param string|null $printer
     * @return null|string
     * @throws Exception
     */
    public function sendFileAsHL7(string $printedFile, string $format, string $ip, string $port, string $type = 'order', string $printer = null): ?string
    {
        $hl7File = storage_path('app/temp/temp.hl7');
        $this->convertToHL7($type, $printedFile, $format, $hl7File, null, $printer);
        return $this->send($hl7File, $ip, $port) ? 'Submitted' : null;

        $message = $hl7Msg;
        if (\is_string($hl7Msg)) {
            $message = new Message($hl7Msg);
        }
        elseif (!is_a($hl7Msg, Message::class)) {
            throw new \InvalidArgumentException('Type of argument not supported');
        }

        $ret = (new Connection($ip, $port))->send($message);
        $ret = $ret->toString(true);
        if (false !== strpos($ret, 'MSH')) {
            info('Sent HL7 to remote', ['IP' => $ip, 'Port' => $port]);
            info('ACK from server', ['ACK' => $ret]);
            return true;
        }
        Log::error('Failed to send HL7 to', ['IP' => $ip, 'Port' => $port]);
        return false;
    }

    public function pollHL7ClientScript($user, ClientUnresponsiveMailer $mailer)
    {
        Log::info($user->email);

        // TBD: defaultInterval and currentInterval to be in number of minutes

        $lastLogin = $user->logins()->where('Browser', 'like', '%WebDAV%')->orderBy('updated_at', 'desc')->first()->updated_at;
        $gap = now()->subMinutes(2 * $user->EHRHL7Monitor->DefaultInterval);
        if ($lastLogin->lte($gap)) {
            $this->incrementDowntimeBy($user->EHRHL7Monitor->CurrentInterval);
            $mailer->notifyAdmin($user, $from, $to);
            $user->EHRHL7Monitor->CurrentInterval = 60;
        } else {
            $user->EHRHL7Monitor->DownTime = 0;
            $user->EHRHL7Monitor->CurrentInterval = $user->EHRHL7Monitor->DefaultInterval;
        }
        // if ($this->lastHL7ScriptConnected($user)) {
        //     $user->EHRHL7Monitor->DownCounter = 0;
        //     $user->EHRHL7Monitor->DownTime = 0;
        //     $user->EHRHL7Monitor->CurrentInterval = $user->EHRHL7Monitor->DefaultInterval;
        // }
        // else {
        //     $user->EHRHL7Monitor->DownCounter++;
        //     $this->incrementDowntimeBy($user->EHRHL7Monitor->CurrentInterval);
        // }
        //
        // if ($user->EHRHL7Monitor->DownCounter >= 2) {
        //     $mailer->notifyAdmin($user, $from, $to);
        //     $user->EHRHL7Monitor->CurrentInterval = 'hourly';
        // }
    }

    /**
     * Return a serial number and increment by 1.
     * @return string
     */
    public static function getNextMsgId(): string
    {
        $redis = Redis::connection();
        $key = 'msgControlID';
        if (!$redis->exists($key)) {
            $redis->set($key, 'MSGID000000000001');
        }
        $currentValue = $redis->get($key);
        $newValue = ++$currentValue;
        $redis->set($key, $newValue);
        return $newValue;
    }

    /**
      * Ping given connection IP
      * Check connection status and send mail to user as per connection status
      * Store Connection log into main.log file
      * Set recent ping time
      */
    public function pingIP($connection)
    {
        $yellowStatus = ConnectionNotification::where("notification_type", '=', "yellow_status")->first();
        $redStatus    = ConnectionNotification::where("notification_type", '=', "red_status")->first();

        // $logSent = $connection->name.' - SENT';
        // Log::info($logSent, ["connectivity"]);

        // $result = $this->saveConnectionLog('SENT', $connection->id);
        // Log::info($result, ["connection sent log added"]);

        // $ccLog = json_encode(['timestamp' => date('Y-m-d H:i:s'), 'connection_name'=> $connection->name, 'ack'=> 'SENT']);
        // event(new ConnectionLog($ccLog));

        $status = '';

        $connection->recent_ping = date('Y-m-d H:i:s');

        if (!$socket = @fsockopen($connection->ip, $connection->destinationPort, $errno, $errstr, 30)) {
            $status = "Offline!";
            $connection->failed_attempts += 1;
            if ($connection->failed_attempts >= $redStatus->no_of_failed_attempts) {
                Mail::to(['script@mailinator.com'])->send(new NotifyAdmin($connection, $redStatus));

                $nLog = 'Red status is generated for HL7 connection of '.$connection->name.'. Alert email to '.$redStatus->email_id;
                // Log::info($nLog, ["notification"]);

                $result = $this->saveNotificationLog($connection->id, $nLog);
                Log::info($result, ["notification red status log added"]);

                $notificationLog = json_encode(['timestamp' => date('Y-m-d H:i:s'), 'log'=> 'Red status is generated for HL7 connection of '.$connection->name.'. Alert email to '.$redStatus->email_id]);
                event(new NotificationLog($notificationLog));

                $connectionData = json_encode(['status' => 'red', 'id' => $connection->id]);
                event(new SignalConnection($connectionData));
            } elseif ($connection->failed_attempts >= $yellowStatus->no_of_failed_attempts) {
                Mail::to(['script@mailinator.com'])->send(new NotifyAdmin($connection, $yellowStatus));

                $nLog = 'Yellow status is generated for HL7 connection of '.$connection->name.'. Alert email to '.$yellowStatus->email_id;
                // Log::info($nLog, ["notification"]);

                $result = $this->saveNotificationLog($connection->id, $nLog);
                Log::info($result, ["notification yellow status log added"]);

                $notificationLog = json_encode(['timestamp' => date('Y-m-d H:i:s'), 'log'=> 'Yellow status is generated for HL7 connection of '.$connection->name.'. Alert email to '.$yellowStatus->email_id]);
                event(new NotificationLog($notificationLog));

                $connectionData = json_encode(['status' => 'yellow', 'id' => $connection->id]);
                event(new SignalConnection($connectionData));
            }
        } else {
            $status = "Online!";
            fclose($socket);

            // $logAck = $connection->name.' - ACK';
            // Log::info($logAck, ["connectivity"]);

            // $result = $this->saveConnectionLog('ACK', $connection->id);
            // Log::info($result, ["connection ack log added"]);

            // $ccLog = json_encode(['timestamp' => date('Y-m-d H:i:s'), 'connection_name'=> $connection->name, 'ack'=> 'ACK']);
            // event(new ConnectionLog($ccLog));

            $connectionData = json_encode(['status' => 'green', 'id' => $connection->id]);
            event(new SignalConnection($connectionData));

            $connection->failed_attempts = 0;
        }

        $connection->save();
    }

    /**
     * Test if given report file's folder is assigned to a ProHealth user
     * @param $path
     * @return bool
     */
    public function isReportAssignedToProHealth($path): bool
    {
        $parentDir = basename(\dirname($path));
        $user = Folders::where('name', $parentDir)
            ->first()
            ->user()
            ->where('email', 'REGEXP', 'pro[:blank:]*Health')
            ->first();

        if ($user) {
            Log::debug('Folder assigned to ProHealth user: ' . $user->email);
            return true;
        }
        return false;
    }

    /**
     * Convert given report into HL7 and send to ProHealth
     * @param $report
     * @throws Exception
     */
    public function sendHl7ToProHealth($report): void
    {
        $ip = config('Sites.ProHealth.hl7_destination.ip');
        $port = config('Sites.ProHealth.hl7_destination.port');
        $hl7Format = 'hl7_prohealth';
        $this->convertToHL7('report', $report, $hl7Format);
        $hl7_file = \dirname($report) . '/' . pathinfo($report, PATHINFO_FILENAME) . "_{$hl7Format}.hl7";
        if (!is_file($hl7_file)) {
            throw new Exception("Expected HL7 file '$hl7_file' does not exist");
        }

        if ($this->send($hl7_file, $ip, $port)) {
            Log::info("Sent HL7 '$hl7_file' to ProHealth $ip:$port");
        }
        if (file_exists($hl7_file)) {
            unlink($hl7_file);
        }
        Log::debug("Removed HL7 file: '$hl7_file'");
    }

    /**
     * Process incoming HL7 message
     * @param string $msg
     * @param string $ip
     * @param int $localPort
     * @throws \InvalidArgumentException
     */
    public function processIncoming(string $msg, string $ip, int $localPort, int $remotePort): void
    {
        $this->archive($msg, $localPort);
        $ack = new ACK(new Message($msg));
        try {
            $this->site->incomingHL7($msg, $ip, $localPort);
        } catch (Exception $e) {
            Log::error(getExceptionSummary($e));
            $ack->setErrorMessage($e->getMessage());
        }
        $ret = (new Connection($ip, $remotePort))->send($ack); // Should the client send this
    }

    /**
     * Archive incoming HL7 message
     *
     * @param string $msg
     * @param int $localPort
     */
    public function archive(string $msg, int $localPort)
    {
        $now = now();
        $file = config('settings.output_paths.incomingHL7') . "/$localPort/" .
            "{$now->year}_{$now->month}_{$now->day}_{$now->hour}_{$now->minute}_{$now->second}.hl7";
        $dir = \dirname($file);
        if (!is_dir($dir)) {
            File::makeDirectory($dir, 774, true);
        }
        file_put_contents($file, $msg);
        info('Saved incoming HL7', ['path' => $file]);
    }

    /**
     * Save ORU HL7 into PDF report. Use base64 in the ORU (if available) or a view template defined in site-specific
     * config.
     * @param string $hl7String
     * @param string|null $templatePath Path to blade file containing report PDF template. Required if base64 is absent
     * @throws FileAndDirectoryException
     * @throws Exception
     */
    public function saveORUAsPDF(string $hl7String, string $templatePath = null): void
    {
        $hl7 = $this->convertHL7ToArray($hl7String);

        error_reporting(0);
        $dos = (new Carbon($hl7['report']['DateTimeOfMessage']))->timestamp;
        $filename = "{$hl7['patient']['lastname']}.{$hl7['patient']['firstname']}.{$hl7['patient']['DOB']}.{$dos}.pdf"; # lastname.firstname.DoB.timestamp
        $physician = "{$hl7['referringDr']['lastname']}.{$hl7['referringDr']['firstname']}.{$hl7['referringDr']['code']}";
        error_reporting(1);
        $dir = config('settings.base_folder') . "/$physician";
        if (!is_dir($dir)) {
            File::makeDirectory($dir);
        }
        if (!is_dir($dir)) {
            throw new FileAndDirectoryException("Failed to create directory $dir");
        }
        $pdfPath = join_paths($dir, $filename);
        if ($hl7['base64']) {
            $pdf = base64_decode($hl7['base64']);
            if (!file_put_contents($pdfPath, $pdf) && !is_file($pdfPath)) {
                throw new \RuntimeException(sprintf('Failed to create report PDF "%s"', $pdfPath));
            }
        }
        elseif ($templatePath) {
            $html = view()->file(resource_path("views/$templatePath"), [
                'data' => $hl7,
            ])->render();
            htmlToPDF($html, $pdfPath);
            logger('Used view template to generate PDF', ['template' => resource_path("views/$templatePath")]);
        }
        else {
            throw new Exception('No base64 present in HL7 or no PDF template defined');
        }
        // Put data in cache, to be picked up when generating hyperlink (filesAdded), thus eliminating PDF parsing
        Cache::put(realpath($pdfPath), $hl7, 5);
        $this->usageAuditService->setCountForService('translation');
        info('Converted HL7 to PDF', ['path' => $pdfPath]);
    }

    /**
     * Parsing incoming HL7 message and creating PDF in reports folder
     *
     * @param string $hl7String
     * @throws HL7Exception
     * @throws \Aranyasen\Exceptions\HL7Exception
     */
    public function saveFromERadAsPdf(string $hl7String): void
    {
        $report = [];
        Log::info('Attempting to save eRad HL7 message as PDF');

        $ORU = new Message($hl7String, null, true);
        $pid = $ORU->getSegmentsByName('PID');
        if (!$pid) {
            throw new HL7Exception('No PID segment');
        }
        $pv1 = $ORU->getSegmentsByName('PV1');
        if (!$pv1) {
            throw new HL7Exception('No PV1 segment');
        }
        $obr = $ORU->getSegmentsByName('OBR');
        if (!$obr) {
            throw new HL7Exception('No OBR segment');
        }
        $obx = $ORU->getSegmentsByName('OBX');
        if (!$obx) {
            throw new HL7Exception('No OBX segment');
        }

        $pid = $pid[0];
        $report['patient']['lastname'] = $pid->getField(5)[0];
        $report['patient']['firstname'] = $pid->getField(5)[1];
        $report['patient']['DOB'] = $pid->getField(7);

        $pv1 = $pv1[0];
        $report['referringDr']['lastname'] = $pv1->getField(8)[1];
        $report['referringDr']['firstname'] = $pv1->getField(8)[2];

        $obr = $obr[0];
        $report['study'] = $obr->getField(4)[1];

        $obx = $obx[0];
        if (isReno()) {
            $report['base64'] = $obx->getField(5)[4];
        }
        else {
            $report['base64'] = $obx->getField(5);
        }

        if (!$report['base64']) {
            throw new HL7Exception('No base64 found in OBX');
        }

        // will return true if the variable is an empty string, false, array(), NULL, and an unset variable.
        if (empty($report['patient']['lastname']) || empty($report['patient']['firstname'])) {
            throw new HL7Exception('Failed to parse patient name from HL7');
        }

        if (empty($report['referringDr']['lastname']) || empty($report['referringDr']['firstname'])) {
            throw new HL7Exception('Failed to parse referring Dr name from HL7');
        }

        $physician = $report['referringDr']['lastname'] . $report['referringDr']['firstname'];
        $study = preg_replace('/\s+/', '_', $report['study']);
        $study = ($study !== '') ? "_$study" : '';
        //filename=lastname.firstname_DoB_ExamDescription.pdf
        $filename = $report['patient']['lastname'] . '.' . $report['patient']['firstname'] . '_' .
            $report['patient']['DOB'] . $study . '.pdf';
        $filename = preg_replace('|\/|', '', $filename);
        Log::debug('Constructed filename for PDF', compact('filename'));
        $directory = Config::get('settings.base_folder') . "/$physician";
        $reportPDF = "$directory/$filename";
        if (!file_exists($directory)) {
            if (!mkdir($directory, 0777, true) && !is_dir($directory)) {
                throw new \RuntimeException(sprintf('Directory "%s" was not created', $directory));
            }
            Log::info("Create directory: $directory");
        }
        $pdf = base64_decode($report['base64']);
        if (!file_put_contents($reportPDF, $pdf) && !is_file($reportPDF)) {
            throw new \RuntimeException(sprintf('Failed to create report PDF "%s"', $reportPDF));
        }
        $this->usageAuditService->setCountForService('translation');
        Log::info('Saved ORU as PDF', compact('reportPDF'));
    }

    /**
     * Check if given message is an ORU
     *
     * @param Message $m
     * @return bool
     */
    public function isOru(Message $m): bool
    {
        $msh = $m->getSegmentsByName('MSH')[0];
        return false !== strpos($msh->getMessageType(), 'ORU');
    }

    /*
    * Save the connections logs in db
    */
    public function saveConnectionLog(string $ack, int $cid)
    {
        $result = Connection_Logs::create([
            'connection_id' => $cid,
            'ack' => $ack,
            'timestamp' => date('Y-m-d H:i:s')
        ]);

        return $result;
    }

    /*
    * Save the connections logs in db
    */
    public function saveNotificationLog(int $cid, string $log)
    {
        $result = NotificationLogs::create([
            'connection_id' => $cid,
            'log' => $log,
            'timestamp' => date('Y-m-d H:i:s')
        ]);

        return $result;
    }

    /*
    * Save the hl7 message logs in db
    */
    public function saveHL7MessageLog(int $cid, string $file_path, string $ip, int $port, string $msg_type, string $ack_type, string $msg_id = "")
    {
        $result = HL7MessageLog::create([
            'connection_id' => $cid,
            'ack' => 'HL7 Message',
            'file_path' => $file_path,
            'remote_ip' => $ip,
            'local_port' => $port,
            'msg_type' => $msg_type,
            'msg_id' => $msg_id,
            'ack_type' => $ack_type,
            'timestamp' => date('Y-m-d H:i:s')
        ]);

        return $result;
    }

    /**
     * @param string $file
     * @param $msg
     * @return Message
     * @throws \Exception
     */
    public function addBase64InMessage(string $file, Message $msg): Message
    {
        $obx = new OBX();
        $obx->setValueType('ED');
        $obx->setObservationIdentifier('^Order');
        $obx->setObservationValue(encodeFileToBase64($file));
        $msg->addSegment($obx);
        $this->usageAuditService->setCountForService('translation');
        return $msg;
    }

    /**
     * @param array $fields
     * @return Message Empty HL7 message with base64 added in OBX segment
     * @throws HL7Exception
     */
    public function createEmptyHL7(array $fields = null): Message
    {
        $orm = new ORM();
        $orm->setMSH([
            'sendingApplication' => $fields['sendingApplication'] ?? 'ScriptSender',
            'receivingApplication' => $fields['receivingApplication'] ?? '',
            'referringDr' => [
                'sendingFacility' => $fields['sendingFacility'] ?? 'unknown',
                'receivingFacility' => $fields['receivingFacility'] ?? '',
            ],
        ]);
        return $orm->getMessage();
    }
}
