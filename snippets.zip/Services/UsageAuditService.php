<?php

declare(strict_types=1);

namespace ScriptSender\Services;

use Log;
use Carbon\Carbon;
use Illuminate\Support\Facades\Redis;

class UsageAuditService
{
    protected $timezone;

    protected $services;

    public function __construct()
    {
        $this->timezone = config('app.timezone');
        $this->services = ['printInbound', 'translation', 'RS', 'webOrder', 'imageViewer'];
    }

    private function getTimeNow(): string
    {
        return now()->format('Y-m-d H:i:s');
    }

    /**
     * Log the service-name and timestamp
     * TODO: Rename to setUsageDetails(string $service, array $details). $details containing per-service data
     * @param string $service 'printInbound', 'hl7Outbound' etc.
     * @throws \InvalidArgumentException
     */
    public function setCountForService(string $service): void
    {
        if (!\in_array($service, $this->services, true)) {
            throw new \InvalidArgumentException("Service '$service' not in: " . implode(', ', $this->services));
        }
        Redis::hset('ss_stats', "{$service}-" . $this->getTimeNow(), '1');
    }

    /**
     * @param Carbon $from
     * @param Carbon $to
     * @param string $service 'printInbound', 'hl7Outbound' etc.
     * @return int
     * @throws \InvalidArgumentException
     */
    public function getCountForService(string $service, Carbon $from, Carbon $to): int
    {
        if (!\in_array($service, $this->services, true)) {
            throw new \InvalidArgumentException("Service '$service' not in: " . implode(', ', $this->services));
        }

        $allEntries = Redis::hkeys('ss_stats');
        $target = array_filter($allEntries, function ($el) use ($service, $from, $to) {
            // Ignore all other services
            if (!preg_match("/$service-(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d)/", $el, $match)) {
                return false;
            }
            // Return true only if service date is greater than $from and less than $to
            $date = Carbon::createFromFormat('Y-m-d H:i:s', $match[1], $this->timezone);
            return $date->gt($from) && $date->lt($to);
        });
        return count($target);
    }

    // /**
    //  * $this->usageService()->reportOutbound($details)
    //  */
    // public function reportOutbound()
    // {
    //
    // }
    //
    // /**
    //  * HL7Service: send() ... On Success, $this->usageService()->hl7Outbound($details)
    //  */
    // public function hl7Outbound()
    // {
    //
    // }
    //
    // public function webOrder()
    // {
    //
    // }
    //
    // /**
    //  * Wherever "Image Viewer is accessed": POST /setusage/service/imageviewer
    //  */
    // public function imageViewer()
    // {
    //
    // }
    //
    // public function imageShare()
    // {
    //
    // }

    /**
     * Return an array of usage
     * @param Carbon $from
     * @param Carbon $to
     * @return array $usageDetails
     * @throws \InvalidArgumentException
     */
    public function getUsage(Carbon $from, Carbon $to): array
    {
        return [
            'customer' => config('settings.site_name') . ' (' . url('/') . ')',
            'from' => $from->toFormattedDateString(),
            'to' => $to->toFormattedDateString(),
            'printInbound' => [
                'count' => $this->getCountForService('printInbound', $from, $to),
            ],
            'translation' => [
                'count' => $this->getCountForService('translation', $from, $to),
            ],
            'RS' => [
                'count' => $this->getCountForService('RS', $from, $to),
            ],
            'webOrder' => [
                'count' => $this->getCountForService('webOrder', $from, $to),
            ],
            'imageViewer' => [ // When a viewer is accessed?
                'count' => $this->getCountForService('imageViewer', $from, $to),
            ],
        ];
    }
}
