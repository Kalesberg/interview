<?php

declare(strict_types=1);

namespace ScriptSender\Services;

use Log;
use ScriptSender\Exceptions\ApiException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;

/**
 * Class CurlService
 * @package ScriptSender\Services
 */
class CurlService
{
    protected $curl;
    protected $insecure;

    /**
     * CurlService constructor.
     * @param bool $insecure
     */
    public function __construct(bool $insecure = false)
    {
        $this->insecure = $insecure;
        $this->initCurl();
    }

    /**
     * Send JSON using IBM API
     * @param string $endpoint
     * @param string $method
     * @param string $user
     * @param string $password
     * @param null|string $body
     * @return mixed|null
     * @throws \Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException
     * @throws ApiException
     */
    public function sendUsingApi(string $endpoint, string $method, string $user, string $password, string $body = null)
    {
        if (!$this->curl) {
            $this->initCurl();
        }

        if (!preg_match('/GET|POST/', $method)) {
            throw new MethodNotAllowedHttpException(['GET', 'POST'], "Method $method is not supported");
        }

        curl_setopt($this->curl, CURLOPT_URL, $endpoint);
        curl_setopt($this->curl, CURLOPT_HEADER, 1);
        curl_setopt($this->curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($this->curl, CURLOPT_USERPWD, $user . ':' . $password);
        curl_setopt($this->curl, CURLOPT_CUSTOMREQUEST, strtoupper($method));

        if ($method === 'POST') {
            if ($body) {
                curl_setopt($this->curl, CURLOPT_HTTPHEADER, [
                    'Content-Type:application/json',
                    'Content-Length: ' . \strlen($body)]);
                curl_setopt($this->curl, CURLOPT_POSTFIELDS, $body);
            }
            else {
                Log::warning('No body specified for POST request', ['endpoint' => $endpoint]);
            }
        }

        $return = curl_exec($this->curl);

        $err = curl_error($this->curl);
        if ($err) {
            throw new ApiException("Failed to communicate with IBM! Endpoint: $endpoint. Error: $err");
        }

        if (empty($return)) {
            throw new ApiException("API '$endpoint' returned empty string");
        }

        $returnJSON = null;
        if (preg_match('/(\{.+\})/s', $return, $matched)) {
            $returnJSON = json_decode($matched[1], true);
        }
        else {
            throw new ApiException("No JSON found in return string. Return: '$return''");
        }

        logger('Curl: successfully executed', [
            'endpoint' => $endpoint, 'method' => $method, 'response' => $returnJSON]);
        return $returnJSON;
    }

    private function initCurl(): void
    {
        $this->curl = curl_init();
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, 1);

        // This is equivalent to Curl command line option --insecure. This is required
        // when the site is https, and curl doesn't have certificate keys
        // TBD: No need for this when using a server with real purchased certificate
        if ($this->insecure) {
            curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, 0);
        }
    }
}
