<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use Log;
use ScriptSender\Rules;
use ScriptSender\Mail\SS\RuleMatched;
use Mail;

/**
 * Apply "rules", if any, on printed Order.
 *
 * Class RulesService
 * @package ScriptSender\Services
 */
class RulesService
{
    /**
     * @param string $printedFile
     * @param string $ip
     * @param string $printerDestination
     * @param string|null $jpeg JPEG file path
     * @return array
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     * @throws \ScriptSender\Exceptions\FileAndDirectoryException
     */
    public function applyRules(string $printedFile, string $ip, string $printerDestination, string $jpeg = null): array
    {
        [$textFile] = pdfToText($printedFile);

        $appliedRules = [];
        $fileMovedTo = null;
        foreach (Rules::enabled()->get() as $rule) {
            $newFileName = basename($printedFile);

            # Temporary workaround for requirement from Queensland Imaging
            if (isJpegRequired()) {
                $newFileName = $jpeg;
            }

            if ($this->doesConditionMatch($rule, $ip, $textFile)) {
                $appliedRules[] = $rule->id;
                if ($rule->action === 'email') {
                    Mail::send(new RuleMatched($rule, $newFileName));
                }
                elseif ($rule->action === 'move') {
                    Log::info('Moving file as per rule...');
                    $fileMovedTo = $rule->destination;
                    if (file_exists("$printerDestination/$newFileName")) {
                        moveFile($printerDestination, $newFileName, $rule->destination);
                    }
                    else {
                        Log::error('Can\'t apply rule as file does not exist', [
                            'file' => "{$printerDestination}/{$newFileName}"
                        ]);
                    }
                }
            }
        }
        return [$appliedRules, $fileMovedTo];
    }

    /**
     * @param Rules $rule
     * @param string $ip
     * @param string $textFile
     * @return bool
     */
    private function doesConditionMatch(Rules $rule, string $ip, string $textFile): bool
    {
        $pattern = $rule->pattern;
        $cond = false;

        // Check if the file came from rule's IP
        if (preg_match('/IP=([\d\.]+)/i', $pattern, $matched)) {
            $ruleIP = trim(trim($matched[1], "'"), '"');
            $cond = ($ip === $ruleIP);
        }

        // Check if rule's pattern is present in the file
        if (preg_match('/keyword=(.+)/i', $pattern, $matched)) {
            $keyword = trim($matched[1], '"');
            $lines = file($textFile);
            $cond = (bool) (new SearchService())->search($keyword, 'keyword', $lines);
        }

        return $cond;
    }
}
