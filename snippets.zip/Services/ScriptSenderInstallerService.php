<?php namespace ScriptSender\Services;

use Agent;
use Auth;
use Log;

class ScriptSenderInstallerService
{
    /**
     * @param array $printerNames
     * @param null $operatingSystem
     * @return \Illuminate\Http\JsonResponse|\Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function create(array $printerNames, $operatingSystem = null)
    {
        $url = url('/');
        $cups_port = getEnvValue('cups_port') ?: '444';
        $installerFilePath = public_path('/files');

        $user = Auth::user()
            ?Auth::user()->firstName . ' ' . Auth::user()->firstName . '(' . Auth::user()->email .')'
            :'';

        $os = $this->getOS($operatingSystem);

        // Windows
        if (strtolower($os) === 'windows') {
            $installerFile = $this->createWindowsInstaller($printerNames, $installerFilePath, $url, $cups_port);
            $response = response()->download($installerFile);
            Log::info('ScriptSender installer downloaded', [
                'os' => 'Windows', 'user' => $user, 'printers' => $printerNames]);
        }

        // Mac
        elseif (strtolower($os) === 'mac') {
            $tarredFile = $this->createMacInstaller($printerNames, $url, $installerFilePath, $cups_port);
            $response = response()->download($tarredFile);

            Log::info('ScriptSender installer downloaded', [
                'os' => 'Mac', 'user' => $user, 'printers' => $printerNames]);
        }

        // Other OSs
        else {
            Log::warning('Download request for ScriptSender installer', [
                'os' => $os, 'user' => $user, 'printers' => $printerNames]);
            $response = response()->json("OS $os is not supported yet!", 501);
        }

        ob_end_clean();
        return $response;
    }

    /**
     * @param array $printerNames
     * @param $installerFilePath
     * @param $url
     * @param $cups_port
     * @return string
     */
    protected function createWindowsInstaller(array $printerNames, $installerFilePath, $url, $cups_port): string
    {
        $installerFile = $installerFilePath . (isIBM() ?'/enable_ordering_agent.bat' :'/enable_scriptsender.bat');
        $script = "@echo off\r\n" .
            "pushd %UserProfile%\r\n" .
            "cls\r\n" .
            (isIBM()
                ? "echo Enabling Ordering Agent...\r\n"
                : "echo Enabling ScriptSender now...\r\n"
            );

        foreach ($printerNames as $printer) {
            $script .= "rundll32 printui.dll,PrintUIEntry /b \"\\\\$url\\$printer\" /x /n \"$printer\"" .
                ' /if /f %windir%\\inf\\prnge001.inf /r "' . "$url:$cups_port/printers/$printer" .
                '" /m "MS Publisher Color Printer"' . "\r\n";
        }

        file_put_contents($installerFile, $script);
        Log::debug('Created SS installer', ['os' => 'Windows']);
        return $installerFile;
    }

    /**
     * @param array $printerNames
     * @param $url
     * @param $installerFilePath
     * @param $cups_port
     * @return string
     */
    protected function createMacInstaller(array $printerNames, $url, $installerFilePath, $cups_port): string
    {
        $fqdn = preg_replace('|http(s)?://|', '', $url);
        $installerFile = $installerFilePath . (isIBM()
                ?'/enable_ordering_agent.command'
                :'/enable_scriptsender.command');
        $script = null;
        $ppdFile = '/System/Library/Frameworks/ApplicationServices.framework/Versions/A/Frameworks/PrintCore.framework/Versions/A/Resources/GenericPrinter.ppd';
        foreach ($printerNames as $printer) {
            $script .= "/usr/sbin/lpadmin -p $printer -v 'https://$fqdn:$cups_port/printer" .
                "s/$printer' -m 'Generic PostScript Printer' -P '$ppdFile' -E \n";
        }
        $script .= "osascript -e 'tell application \"Terminal\" to quit' &\n";
        $script .= 'exit';

        file_put_contents($installerFile, $script);
        system("chmod 777 $installerFile");
        Log::debug('Created SS installer', ['os' => 'Mac']);
        return doTar($installerFile); # Tar it to retain executability when sending over HTTP
    }

    /**
     * Return requested OS, or detect it.
     * @param {$operatingSystem} Return this right away if provided
     * @return null|string
     */
    protected function getOS($operatingSystem = null): string
    {
        if ($operatingSystem) {
            return $operatingSystem;
        }

        $os = null;
        if (Agent::is('Windows')) {
            $os = 'Windows';
        }
        elseif (Agent::is('OS X')) {
            $os = 'Mac';
        }
        else {
            $os = Agent::platform();
        }

        return $os;
    }
}
