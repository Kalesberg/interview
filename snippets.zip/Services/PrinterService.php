<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use Illuminate\Support\Collection;
use Log;
use Exception;
use ScriptSender\Exceptions\PrinterException;
use ScriptSender\Exceptions\PrintException;
use ScriptSender\Group;
use ScriptSender\Printers;

class PrinterService
{
    /**
     * Add a new printer in CUPS.
     * @param string $printerName
     * @param string $destination
     * @param Collection $groups
     * @param string $comment
     * @return bool
     * @throws \Exception
     */
    public function add(string $printerName, string $destination, Collection $groups, $comment = null): bool
    {
        $this->validateGroups($groups);

        // TBD: Validate printerName and directory $destination - can be done later
        $sudo = 1;
        if (isLegacy()) {
            mkdirMinusP($destination, '0770', ['owner' => 'www-data', 'group' => 'lpadmin'], $sudo);
        }
        else {
            $lpadmin_gid = runCmd("cd " . env('APP_PATH') . " && docker-compose exec cups sh -c 'getent group lpadmin | cut -d: -f3'", true);
                mkdirMinusP($destination, '0770', ['owner' => 'www-data', 'group' => $lpadmin_gid], $sudo);
        }
        $this->stopCupsService();

        // Create printers.conf
        $conf = "
           <Printer $printerName>
           UUID urn:uuid:8631dbc3-587c-3fac-6860-1f05c620f2ed
           Info $printerName
           MakeModel Generic CUPS-PDF Printer
           DeviceURI cups-pdf:/
           PPDTimeStamp *
           State Idle
           StateTime 1451449181
           Type 8450124
           Accepting Yes
           Shared Yes
           ColorManaged Yes
           JobSheets none none
           QuotaPeriod 0
           PageLimit 0
           KLimit 0
           OpPolicy default
           ErrorPolicy retry-job
           </Printer>
        ";
        $conf = ltrim($conf); # Trim spaces from beginning of each line
        writeToFileAsSudo('/etc/cups/printers.conf', $conf, 'append');

        // Create <printerName>.ppd
        $ppd = rtrim(`ls -1 /etc/cups/ppd/*.ppd | head -1`); # Get an existing PPD filename
        runCmd("sudo /bin/cp $ppd /etc/cups/ppd/$printerName.ppd --preserve=mode,ownership");

        $this->startCupsService();

        $printer = Printers::create([
            'name'        => $printerName,
            'destination' => $destination,
            'comment'     => $comment,
        ]);

        $groups->each(function ($item) use ($printer) {
            Group::where('Name', $item)->update(['Printer_id' => $printer->id]);
        });

        return true;
    }

    /**
     * See cups files and add/remove/edit rows in DB accordingly.
     * If someone manually adds/removes a printer, this method can be used to
     * sync the DB accordingly.
     */
    public function syncFilesAndDB()
    {

    }

    /**
     * @param string $printerName
     * @return bool
     * @throws Exception
     * @throws PrintException
     * @throws PrinterException
     */
    public function remove(string $printerName): bool
    {
        $printer = Printers::getPrinterModelFromName($printerName);
        $this->stopCupsService();

        // Remove from printers.conf
        $conf = "<(Default)?Printer $printerName>.*?Info $printerName\\s*.*?<\\/Printer>";

        $lines = runCmd('sudo /bin/cat /etc/cups/printers.conf');
        $count = 0;
        $lines = preg_replace("/$conf/sm", '', $lines, -1, $count);
        if (1 !== $count) {
            echo "Couldn't remove entry from printers.conf";
            return false;
        }

        writeToFileAsSudo('/etc/cups/printers.conf', $lines, 'write');

        // Remove .ppd file
        runCmd("sudo /bin/rm /etc/cups/ppd/$printerName.ppd");

        $this->startCupsService();
        $printer->groups()->update(['Printer_id' => null]);
        $printer->delete();
        info('Removed printer', compact('printerName'));
        return true;
    }

    /**
     * Modify a given printer.
     * @param string $printerName
     * @param string $new_name
     * @param string|null $new_destination
     * @param Collection|null $new_groups
     * @param string|null $new_comment
     * @return bool
     * @throws Exception
     */
    public function modify(string $printerName, string $new_name, $new_destination = null, $new_groups = null, $new_comment = null): bool
    {
        $update = [];
        $changeLog = '';

        $this->validateGroups($new_groups);

        if ($new_name && $printerName !== $new_name) {
            $lines = runCmd('sudo /bin/cat /etc/cups/printers.conf');
            $count = 0;
            $lines = preg_replace("/(Printer|Info) $printerName/", "$1 $new_name", $lines, -1, $count);
            if (2 !== $count) {
                throw new PrinterException("Found $count occurrences of $printerName in /etc/cups/printers.conf. Expected 1!");
            }

            $this->stopCupsService();
            writeToFileAsSudo('/etc/cups/printers.conf', $lines, 'write');
            runCmd("sudo /bin/mv /etc/cups/ppd/$printerName.ppd /etc/cups/ppd/$new_name.ppd");
            $this->startCupsService();

            $update['name'] = $new_name;
            $changeLog = "name: '$new_name'";
        }

        if ($new_destination) {
            // TBD: If $destination !== $new_destination
            $sudo = 1;
            if(isLegacy()) {
                mkdirMinusP($new_destination, '0770', ['owner' => 'www-data', 'group' => 'lpadmin'], $sudo);
            }
            else {
                $lpadmin_gid = runCmd("cd " . env('APP_PATH') . " && docker-compose exec cups sh -c 'getent group lpadmin | cut -d: -f3'", true);
                mkdirMinusP($new_destination, '0770', ['owner' => 'www-data', 'group' => $lpadmin_gid], $sudo);
            }
            $update['destination'] = $new_destination;
            $changeLog .= ", dest: '$new_destination'";
        }

        if ($new_comment) {
            $update['comment'] = $new_comment;
            $changeLog .= ", comment: '$new_comment'";
        }
        $printer = Printers::where('name', $printerName)->firstOrFail();
        $printer->update($update);

        # If user wants to modify groups, the existing groups need to be removed before setting new ones
        if ($new_groups->count() > 0) {
            $printer->groups()->update(['Printer_id' => null]);
        }

        $new_groups->each(function ($item) use ($changeLog, $printer) {
            Group::where('Name', $item)->update(['Printer_id' => $printer->id]);
            $changeLog .= ", group: $item";
        });

        Log::info("Modified printer '$printerName': $changeLog");
        return true;
    }

    /**
     * Validate if a group exists
     * @param Collection $groups
     * @return bool
     * @throws \Exception
     */
    private function validateGroups(Collection $groups): bool
    {
        $groups->each(function ($item, $index) {
            if (Group::where('Name', $item)->count() === 0) {
                throw new Exception("Group '$item' not found. Please create it first'");
            }
        });

        return true;
    }

    /**
     * Stop CUPS service
     * @throws Exception
     */
    private function stopCupsService(): void
    {
        $ret = isLegacy()
            ? runCmd('sudo /usr/sbin/service cups stop', true)
            : runCmd("cd " . env('APP_PATH') . " && docker-compose stop cups", true); # Ignore failure, as CUPS may already be stopped
        Log::debug("Command output: '$ret'");
        // Wait till cups is stopped
        $port = getEnvValue('cups_port') ?: '444';
        $slept = 0;
        while (preg_match("/$port/", runCmd("netstat -tulpan | grep :$port | grep cupsd", true))) {
            sleep(1);
            ++$slept;
            if ($slept > 30) {
                throw new PrintException("Could not stop CUPS even after $slept seconds");
            }
        }
        Log::debug('cups process stopped successfully');
    }

    /**
     * Start CUPS service
     * @throws PrintException
     */
    private function startCupsService(): void
    {
        $ret = isLegacy()
            ? runCmd('sudo /usr/sbin/service cups start')
            : runCmd("cd " . env('APP_PATH') . " && docker-compose start cups");
        Log::debug("Command output: '$ret'");
        if (!$this->isCupsRunning()) {
            throw new PrintException("CUPS process couldn't be started!");
        }
        Log::debug('CUPS process started successfully');
    }

    /**
     * Check if cups process is running or not
     * @return bool
     */
    private function isCupsRunning(): bool
    {
        if (isLegacy()) {
            $ret = runCmd('/usr/sbin/service cups status');
            return preg_match("/cups start\/running/", $ret) ? true : false;
        }
        $ret = runCmd("cd " . env('APP_PATH') . " && docker-compose ps | grep cups");
        return (preg_match("/Up/", $ret)) ? true : false;
    }
}
