<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use Plivo\RestClient;

class SMSService
{
    protected $auth_id;
    protected $auth_token;

    public function __construct()
    {
        $this->auth_id = "MANZJMODAZZDIYMMY1MJ";
        $this->auth_token = "NDcyNjk0ZDAyNjkxZjJlYjcwZjk0OTBiZmQzZmUy";
    }

    /**
     * Send SMS to given number
     *
     * @param string $mobile Phone number the SMS is to be sent to
     * @param string $text
     */
    public function sms(string $mobile, string $text): void
    {
        $mobile = $this->normalize($mobile);
        $client = new RestClient($this->auth_id, $this->auth_token);
        $response = $client->messages->create(
            '15614405533',
            [$mobile],
            $text
        );
        info('Response for sms', ['response' => json_encode($response)]);
    }

    /**
     * @param string $mobile
     * @return mixed|string
     */
    protected function normalize(string $mobile): string
    {
        $mobile = str_replace(['(', ')', '-', ' ', '.'], '', $mobile); // Remove special characters
        $mobile = 0 === strpos($mobile, '+1') ? $mobile : '+1' . $mobile; // Prepend +1 if not present
        return $mobile;
    }
}
