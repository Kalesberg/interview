<?php


namespace ScriptSender\Services;

use Log;
use Auth;
use Agent;

class WebDAVInstallerService
{
    /**
     * Create OS-specific installer to install WebDAV network drive
     * @param string $davName           Name of webDAV specified in config/settings.php
     * @param string $installerFileName File name (without extension) to be downloaded
     * @return string|\Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function create($davName, $installerFileName)
    {
        $response = null;
        $email = Auth::user()->email;
        $site_url = config('settings.url');
        $installerFile = public_path() . "/files/${installerFileName}";

        if (Agent::is('Windows')) {
            $installerFile .= '.bat';

            $powershellLine =  isDemo()
                ? ''
                : 'powershell -Command $pword = read-host "Enter password for %user%" -AsSecureString ; $BSTR=[System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($pword) ; [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR) > .tmp.txt & set /p password=<.tmp.txt & del .tmp.txt';
            $password = isDemo() ?'' :'%password%';

            $dav_mapping_cmd = <<<"END"
                @echo off\n\r
                set user=$email\n\r
                $powershellLine
                @net use * "\\\\$site_url@ssl/$davName" /User:%user% $password /PERSISTENT:YES\n\r
                rem pause\n\r
END;
            file_put_contents($installerFile, trimHeredoc($dav_mapping_cmd));
            Log::info('WebDAV installer downloaded', ['os' => 'Windows', 'user' => $email, 'dav' => $davName]);
            $response = response()->download($installerFile);
        }
        elseif (Agent::is('OS X')) {
            $url = url('/') . ":443/$davName"; # e.g., "https://demo.scriptsender.com:443/reports/";
            $script = <<<"END"
                osascript -e ' mount volume "$url" '

                #read -p "Press [Enter] once you have entered your credentials and mapped the drive."
                if \[ -d /Volumes/Reports \]; then
                osascript -e 'tell application "System Events" to make new login item at end with properties {path:"/Volumes/Reports/", name:"dav", hidden:true}'
                fi
                osascript -e 'tell application "Terminal" to quit' &
                exit
END;

            $installerFile .= '.command';
            file_put_contents($installerFile, trimHeredoc($script));

            system("chmod 777 $installerFile"); # Make the file executable
            $tarredFile = doTar($installerFile); # Tar it to retain executability when sending over HTTP
            Log::info('WebDAV installer downloaded', ['os' => 'Mac', 'user' => $email, 'dav' => $davName]);
            $response = response()->download($tarredFile);
        }
        else {
            Log::warning('WebDAV installer requested for unsupported OS', [
                'os' => Agent::platform(), 'user' => $email, 'dav' => $davName]);
            $response = response('Sorry, your OS is not supported yet! You may still map ReportSender dav using'
                . ' your OS-specific mapping command/tool.', 415);
        }

        return $response;
    }
}
