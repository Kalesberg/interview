<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use Exception;
use File;
use Log;
use ScriptSender\Exceptions\FileAndDirectoryException;
use ScriptSender\Icd10;
use ScriptSender\Services\Parser\Parser;

/**
 * Class Document
 * Methods can be chained: (new Document($pdf))->parse()->addICD10Description(true)->addBase64()->toJson()
 *
 * @package ScriptSender\Services
 */
class Document
{
    protected $pdf;
    protected $textFile;
    protected $parsedArray;
    protected $orderService;

    /**
     * @var bool If the text conversion was OCRed
     */
    protected $ocr = false;

    /**
     * Document constructor.
     *
     * @param string $fileName Full path to PDF/Text file
     * @param OrderService $orderService
     * @throws FileAndDirectoryException
     * @throws \ScriptSender\Exceptions\PdfToTextException
     */
    public function __construct(string $fileName, OrderService $orderService)
    {
        if (!is_file($fileName)) {
            throw new FileAndDirectoryException("File $fileName not a regular file");
        }
        if (!is_readable($fileName)) {
            throw new FileAndDirectoryException("File $fileName not readable");
        }
        if (File::mimeType($fileName) === 'application/pdf') {
            $this->pdf = $fileName;
            [$this->textFile, $this->ocr] = pdfToText($this->pdf);
        }
        elseif (isTextFile($fileName)) {
            $this->textFile = $fileName;
        }
        else {
            throw new FileAndDirectoryException("File $fileName not a pdf or a text file. File type: " .
                File::mimeType($fileName));
        }
        $this->orderService = $orderService;
    }

    /**
     * Return text content
     *
     * @return null|string
     */
    public function toText(): ?string
    {
        return file_get_contents($this->textFile);
    }

    /**
     * Return the full path to text file this object is operating on
     *
     * @return string
     */
    public function getTextFile(): string
    {
        return $this->textFile;
    }

    /**
     * Return true/false based on whether the text was converted using OCR
     *
     * @return bool
     */
    public function isOCR(): bool
    {
        return $this->ocr;
    }
    /**
     * @return Document
     * @throws \Throwable
     */
    public function parse(): Document
    {
        try {
            $this->parsedArray = $this->parsedArray ?: (new Parser($this->toText()))->parse();
        } catch (Exception $e) {
            Log::error('Parsing aborted!', ['error' => getExceptionSummary($e)]);
            // $youTrackService = new YouTrackService();
            // if (env('CAN_CREATE_TICKETS') && !$youTrackService->ticketExists(md5_file($this->pdf))) {
            //     $this->createTicket($youTrackService);
            // }
            throw $e;
        }
        return $this;
    }

    /**
     * @return string
     * @throws \Throwable
     */
    public function toJson(bool $prettify = false): string
    {
        return json_encode($this->toArray(), $prettify ? JSON_PRETTY_PRINT : 0);
    }

    /**
     * @return array
     * @throws \Throwable
     */
    public function toArray(): array
    {
        $this->parse();
        return $this->parsedArray;
    }

    /**
     * Get type and format of the document
     *
     * @return array
     * @throws \Throwable
     */
    public function getTypeAndFormat(): array
    {
        $this->parse();
        $meta = $this->parsedArray['meta'];
        return ['type' => $meta['document_type'], 'format' => $meta['document_format']];
    }

    /**
     * @param bool $force
     * @return Document
     * @throws \Throwable
     */
    public function addIcd10Description(bool $force = false): Document
    {
        $this->parse();
        foreach ($this->parsedArray['exams'] as &$exam) {
            foreach ($exam['MultiDiagnosisList'] as &$diagnosis) {
                $code = trim(str_replace('.', '', $diagnosis['code']));
                $description = $diagnosis['description'];
                if (!$description || $force) {
                    $icd10Record = Icd10::where('code', $code);
                    $description = ($icd10Record->count() > 0) ? $icd10Record->first()->description : '';
                    $diagnosis['description'] = $description;
                }
            }
        }
        return $this;
    }

    /**
     * @return Document
     * @throws \Throwable
     */
    public function addBase64(): Document
    {
        $this->parse();
        if (!$this->pdf) {
            throw new FileAndDirectoryException('Require pdf property to be set to calculate base64');
        }
        array_set($this->parsedArray, 'meta.base64', encodeFileToBase64($this->pdf));
        return $this;
    }

    /**
     * @param bool $force
     * @return Document
     * @throws \ScriptSender\Exceptions\NpiLookupFailureException
     * @throws \Throwable
     */
    public function addNPI(bool $force = false): Document
    {
        $this->parse();
        $npi = array_get($this->parsedArray, 'referringDr.npi');
        if (!$npi || $force) {
            $npi = $this->orderService->lookUpNPI($this->parsedArray['referringDr']);
            array_set($this->parsedArray, 'referringDr.npi', (string) $npi);
        }
        return $this;
    }

    /**
     * If country is empty, use a default country name
     *
     * @param string $defaultCountry
     * @return Document
     * @throws \Throwable
     */
    public function addDefaultCountry(string $defaultCountry = 'USA'): Document
    {
        $this->parse();
        array_walk_recursive($this->parsedArray, function (&$element, $key) use ($defaultCountry) {
            if ($key === 'country' && empty($element)) {
                $element = $defaultCountry;
            }
        });
        return $this;
    }

    /**
     * @param YouTrackService $youTrackService
     */
    protected function createTicket(YouTrackService $youTrackService): void
    {
        try {
            $ticket = $youTrackService
                ->createTicket([
                    'title' => 'Parse: No Match',
                    'description' => '',
                    'assignee' => env('NO_MATCH_TICKET_ASSIGNEE'),
                    'priority' => 'Show-stopper',
                    'subsystem' => 'Document Parser',
                ]);
            if (env('CAN_ATTACH_FILES_TO_TICKET')) {
                $ticket->attachFiles([$this->pdf, $this->textFile]);
            }
        } catch (Exception $e) {
            Log::error('Failed to create ticket', ['error' => $e->getMessage()]);
        }
        $youTrackService->ticketCreated(md5_file($this->pdf));
    }
}
