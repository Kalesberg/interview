<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use Cache;
use Log;
use File;
use Exception;
use Redis;
use ScriptSender\Exceptions\FileAndDirectoryException;
use ScriptSender\Exceptions\ParseException;
use ScriptSender\Imageshare_study;

class StudyService
{
    protected $ch;

    protected $PACS_url;
    protected $studyJSONCacheDuration;
    private $redisFilesTracker;
    private $redis;

    public function __construct()
    {
        $this->redisFilesTracker = 'ss_StudyManager_files_processed';
        $this->redis = Redis::connection();
        $this->PACS_url = config('settings.PACS.url');
        $this->ch = curl_init();

        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);

        // This is equivalent to Curl command line option --insecure. This is required
        // when the site is https, and curl doesn't have certificate keys
        // TBD: No need for this when using a server with real purchased certificate
        if (preg_match('/https:/', $this->PACS_url)) {
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, 0);
        }
        $this->studyJSONCacheDuration = 30 * 24 * 60; // 30 days
    }

    /**
     * Create DB record of study from given report
     * @param string $report
     * @throws Exception
     */
    public function registerStudyFromReport(string $report): void
    {
        if (!is_readable($report)) {
            throw new Exception("File '$report' does not exist or not readable");
        }

        // $studyManagerScript = base_path('ss_toolbox/StudyManager.pm');
        // runCmd("perl $studyManagerScript --report='$report' > /tmp/study_manager 2>&1", true);
        if ($this->isAlreadyDone($report)) {
            return;
        }
        $this->saveReport($report);
        Log::info("Registered study in database for report '$report''");
    }

    /**
     * @param string $pid
     * @param string $studyId
     * @return string
     * @throws Exception
     */
    public function report(string $pid, string $studyId): string
    {
        $study = Imageshare_study::where(['pid' => $pid, 'study_id' => $studyId]);
        if ($study->exists()) {
            return $study->filename;
        }
        # If record not found, try to find it recursively in the reports directory and return as soon as found
        return $this->findReport($pid, $studyId, true);
    }

    /**
     * @param string $pid
     * @param string $studyId
     * @param bool $breakWhenFound
     * @return string
     * @throws FileAndDirectoryException
     * @throws ParseException
     * @throws \Throwable
     */
    public function findReport(string $pid, string $studyId, bool $breakWhenFound = false): string
    {
        foreach (File::allFiles(config('settings.base_folder')) as $report) {
            $report = $report->getPathname();
            if ($this->isAlreadyDone($report)) {
                continue;
            }
            $study = $this->saveReport($report);
            if ($breakWhenFound && $pid === $study->pid && $studyId === $study->study_id) {
                logger('Found report', compact(['pid', 'studyId']));
                break;
            }
        }
        $study = Imageshare_study::where(['pid' => $pid, 'study_id' => $studyId])->first();
        if (!$study) {
            throw new Exception("Failed to find report with pid $pid and study id $studyId");
        }
        return $study->filename;
    }

    /**
     * @param string $report
     * @return Imageshare_study
     * @throws FileAndDirectoryException
     * @throws ParseException
     * @throws \Throwable
     */
    public function saveReport(string $report): Imageshare_study
    {
        // [$parsedData] = (new OrderService())->parsePDF($report);
        if (Cache::has(realpath($report))) {
            $parsedData = Cache::get(realpath($report));
        }
        else {
            $document = new Document($report, new OrderService());
            $parsedData = $document->toArray();
        }
        $pid = $parsedData['report']['PID'] ?? $parsedData['PID']['id'];
        if (!$pid) {
            throw new Exception("pid not present for report $report");
        }
        if (!$parsedData['report']['accession']) {
            throw new Exception("study_id not present for report $report");
        }
        $now = now();
        $study = Imageshare_study::firstOrCreate(
            [
                'pid'               => $pid,
                'study_id'          => $parsedData['report']['accession'],
            ],
            [
                // 'study_description' => $parsedData['study'],
                // 'study_date'        => $utils->convertDateTimeFormat({ in_date => $DOS, in_format => "%m/%d/%Y %H:%M:%S", out_format => "%Y/%m/%d %H:%M:%S" }),
                'created_at'        => $now,
                'updated_at'        => $now,
            ]
        );
        // For some weird reason, filename isn't saving in the firstOrCreate statement!
        $study->filename = join_paths(basename(\dirname($report)), basename($report));
        $study->save();
        $this->markAsDone($report);
        return $study;
    }

    /**
     * @param string $reportFile
     * @return bool
     */
    public function isAlreadyDone(string $reportFile): bool
    {
        return (bool) $this->redis->hget($this->redisFilesTracker, md5_file($reportFile));
    }

    /**
     * @param string $reportFile
     */
    public function markAsDone(string $reportFile): void
    {
        $this->redis->hset($this->redisFilesTracker, md5_file($reportFile), '1');
        logger('Saved file md5 in Redis', ['report' => $reportFile]);
    }
}
