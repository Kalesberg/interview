<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use Log;
use Mail;
use ScriptSender\Mail\NotifyUnmatchedExam;
use ScriptSender\Exams;

class ExamService
{
    /**
     * Update 'exams' field in parsed data with mapped exams from customer. If no mapped exam exists, hard-code
     * procedure_code to '88888' and create a record for the unmatched exam (or update, if existing) (SS-281)
     *
     * @param array $parsedData
     * @return array $parsedData
     * @throws \Exception
     */
    public function matchExams(array $parsedData): array
    {
        if (empty($parsedData['exams'])) {
            throw new \Exception('No exams array found in parsed data');
        }
        foreach ($parsedData['exams'] as &$exam) {
            if (!(isset($exam['procedure_code']) || isset($exam['study']))) {
                Log::warning('Both code and description are missing in exam', compact('exam'));
                continue;
            }
            $originalCode = $exam['procedure_code'] ?? null;
            $originalDescription = $exam['study'] ?? null;
            $examRecord = Exams::getUsingDescriptionOrCode($originalDescription, $originalCode);

            $mappedExam = optional($examRecord)->mappedExamByCustomer();
            if ($mappedExam) {
                $exam['procedure_code'] = $mappedExam->code;
                $exam['study'] = $mappedExam->description ?: $exam['study']; // Prefer customer's description, if exists
                info('Added mapped info to exam', compact('exam'));
            }
            else {
                info('No matching exam found', ['code' => $originalCode, 'description' => $originalDescription]);
                $exam['procedure_code'] = '88888';
                $to = env('ADMIN_MAIL_ID', 'admin@scriptsender.com');
                Mail::to($to)->send(new NotifyUnmatchedExam());
                Exams::firstOrCreate(['code' => $originalCode, 'description' => $exam['study']]);
                info('Added/Updated unmatched exam to database', [
                    'code' => $originalCode, 'description' => $originalDescription]);
            }
        }
        unset($exam);
        return $parsedData;
    }
}
