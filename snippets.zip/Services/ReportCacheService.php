<?php

declare(strict_types=1);

namespace ScriptSender\Services;

use Cache;
use ScriptSender\Folders;
use InvalidArgumentException;

class ReportCacheService
{
    protected $reportService;

    public function __construct(ReportService $reportService)
    {
        $this->reportService = $reportService;
    }

    /**
     * @param string $report
     */
    public function addFileToReportsCache(string $report): void
    {
        $folder = basename(\dirname($report));
        $reportsTree = $this->getReportsTree();
        $folderId = 'folder-' . Folders::where('name', $folder)->first()->FolderId;
        $folderArrayIndex = array_search($folderId, array_column($reportsTree, 'id'), true);

        $basename = basename($report);

        if (!\in_array($basename, array_column($reportsTree[$folderArrayIndex]['children'], 'text'), true)) {
            $reportsTree[$folderArrayIndex]['children'][] = [
                'id' => 'report-' . $folder . "/{$basename}",
                'text' => $basename,
                'type' => 'report',
                'mode' => 'active',
            ];
            $this->setReportsTree($reportsTree);
        }
    }

    /**
     * @param $report
     */
    public function removeFileFromReportsCache($report): void
    {
        $folder = basename(\dirname($report));
        $reportsTree = $this->getReportsTree();
        $folderId = 'folder-' . Folders::where('name', $folder)->first()->FolderId;
        $folderArrayIndex = array_search($folderId, array_column($reportsTree, 'id'), true);

        $basename = basename($report);

        $reportsTree[$folderArrayIndex]['children'] =
            array_values(array_filter($reportsTree[$folderArrayIndex]['children'],
                    function ($child) use ($folder, $basename) {
                        return $child['id'] !== "report-{$folder}/{$basename}";
                    })
            );
        //
        // if (!empty($reportsTree[$folderArrayIndex]['children'])) {
        //     $reportsTree[$folderArrayIndex]['children'] =
        //         array_filter($reportsTree[$folderArrayIndex]['children'], function ($child) use ($folder, $basename) {
        //             return $child['id'] !== "report-{$folder}/{$basename}";
        //         });
        // }

        $this->setReportsTree($reportsTree);
    }

    /**
     * @param array $reports Array of reports
     * @param string $action Values should be 'archived' / 'active'
     * @throws \InvalidArgumentException
     */
    public function setReportStatusInCache(array $reports, string $action): void
    {
        if (!preg_match('/active|archived/', $action)) {
            throw new InvalidArgumentException("Second argument wrong: '$action'. Expected: 'active'/'archived'");
        }
        $reportsTree = $this->getReportsTree();
        $reportsTree = array_map(function ($el) use ($reports, $action) {
            foreach ($el['children'] as &$c) {
                $id = str_replace('report-', '', substr($c['id'], 0, strrpos($c['id'], '.')));
                if ($c['type'] === 'report' && \in_array($id, $reports, true)) {
                    $c['mode'] = $action;
                }
            }
            return $el;
        }, $reportsTree);

        $this->setReportsTree($reportsTree);
    }

    /**
     * Add given folder and its children to cached reports tree
     * @param string $folder Folder to be added in cache
     * @param array|null $reports List of reports inside this folder
     */
    public function addFolderToReportsCache(string $folder, array $reports = []): void
    {
        $folder = basename($folder);
        $reportsTree = $this->getReportsTree();
        $folderId = 'folder-' . Folders::where('name', $folder)->first()->FolderId;

        # Add to the beginning of the tree (if the folder not already present)
        if (!array_search($folderId, array_column($reportsTree, 'id'), true)) {
            array_unshift($reportsTree, [
                'type' => 'folder',
                'text' => $folder,
                'id' => $folderId,
            ]);
        }

        $folderArrayIndex = array_search($folderId, array_column($reportsTree, 'id'), true);

        $childrenArray = array_map(function ($pdfFile) use ($folder) {
            $basename = pathinfo($pdfFile, PATHINFO_BASENAME);
            return [
                'id' => 'report-'. $folder . "/{$basename}",
                'text' => $basename,
                'type' => 'report',
                'mode' => 'active',
            ];
        }, $reports);

        $reportsTree[$folderArrayIndex]['children'] = $childrenArray;
        $this->setReportsTree($reportsTree);
    }

    /**
     * @param string $folder
     */
    public function removeFolderFromReportsCache(string $folder): void
    {
        $folder = basename($folder);
        // Remove the element containing $folder from reportsTree
        $reportsTree = array_values(array_filter($this->getReportsTree(), function ($element) use ($folder) {
            return $element['text'] !== $folder;
        }));

        $this->setReportsTree($reportsTree);
    }

    public function flush()
    {
        Cache::forget('reportsTree');
        info('Busted reports cache');
    }

    /**
     * Create a tree of reports directory in a JSON format
     */
    private function createReportsTree(): array
    {
        $reportTree = [];
        $arr = [];
        foreach (Folders::all() as $dir) {
            $dirName = explode('/', $dir->path);
            $dirName = array_pop($dirName);
            $arr[$dirName] = $dir;
        }
        // ksort($arr); // Sort by keys

        foreach ($arr as $dirName => $dir) {
            $reports = [];

            $path = config('settings.base_folder') . '/' . $dir->path;

            $handle = opendir($path);
            while (false !== ($report = readdir($handle))) {
                if (!stripos($report, 'pdf')) {
                    continue;
                }
                $fileName = "{$dirName}/{$report}";
                $mode = $this->reportService->isArchived($fileName) ? 'archived' : 'active';
                $child = [
                    'id' => "report-{$fileName}",
                    'type' => 'report',
                    'text' => $report,
                    'mode' => $mode,
                ];
                $reports[$report] = $child;
            }
            closedir($handle);
            // ksort($reports);
            $reports = array_values($reports);
            $reportTree[] = [
                'id' => "folder-{$dir->FolderId}",
                'type' => 'folder',
                'text' => $dirName,
                'children' => $reports,
            ];
        }

        return $reportTree;
    }

    /**
     * Get reports tree from cache, or create one in cache and then return
     * @return array reports tree
     */
    public function getReportsTree(): array
    {
        return Cache::rememberForever('reportsTree', function () {
            return $this->createReportsTree();
        });
    }

    /**
     * Replace current reports tree in cache with the given one
     * @param array $reportsTree
     */
    private function setReportsTree(array $reportsTree): void
    {
        Cache::forever('reportsTree', $reportsTree);
    }
}
