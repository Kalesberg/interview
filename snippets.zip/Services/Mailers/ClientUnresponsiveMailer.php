<?php namespace ScriptSender\Services\Mailers;

use Log;
use Carbon\Carbon;
use Auth;

use Illuminate\Mail\Mailer as Mail;

class ClientUnresponsiveMailer extends Mailer
{
    protected $practiceName;

    public function __construct(Mail $mail)
    {
        parent::__construct($mail);
    }

    /**
      * Send notification mail to user as per signal status
      *
      * @return array
      */
    public function notifyAdmin($connection, $status)
    {
        $subject = config('settings.site_name') . " HL7 Connection Potentially Down";
        $mailData = ['to' => $status->email_id, 'from' => 'script@mailinator.com', 'subject' => $subject];

        $viewData = [
            'organization'      => 'test1',
            'customerName'      => 'test2',
            'downtime'          => $connection->default_interval * $status->no_of_failed_attempts,
            'interval'          => $connection->default_interval,
            'counter'           => $status->no_of_failed_attempts,
            'customerAddress'   => 'test6',
            'customerPhone'     => 'test7',
            'customerFax'       => 'test8',
            'ssLogo'            => 'test9',
        ];

        $this->send($mailData, 'emails.client_unresponsive', $viewData);
        // Log::info("Sent log history to: ". $mailData['to'] . " from " . $mailData['from']);
        return true;
    }
}
