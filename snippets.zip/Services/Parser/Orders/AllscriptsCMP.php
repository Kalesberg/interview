<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * AllscriptsCMP Order Parser
 * format: AllscriptsCMP
 * type: Order
 */
class AllscriptsCMP
{
    use HelperTrait;
    protected $format = 'AllscriptsCMP';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches AllscriptsCMP format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/\s*Procedure\sOrder/', $content)
            && preg_match('/Ordering\sSite/', $content)
            && preg_match('/Gender:.*Date\sof\sBirth:.*SSN:/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_site_start = 0;
        $line_site_end = 0;

        $line_patient_start = 0;
        $line_patient_end = 0;

        $line_insurance_start = 0;
        $line_insurance_end = 0;

        $line_procedure_start = 0;
        $line_procedure_end = 0;

        foreach ($this->lines as $no => $line) {
            if (preg_match('/^Ordering\sSite/', $line)) {
                $line_site_start = $no + 1;
            }

            if (preg_match('/^Patient Information/', $line)) {
                $line_site_end = $no;
                $line_patient_start = $no + 1;
            }

            if (preg_match('/^Patient\sInsurance\sInformation/', $line)) {
                $line_patient_end = $no;
                $line_insurance_start = $no + 1;
            }

            if (preg_match('/^Procedures\sOrdered/', $line)) {
                $line_insurance_end = $no;
                $line_procedure_start = $no + 1;
            }

            if ($line_procedure_start > 0
                && $no > $line_procedure_start
                && preg_match('/^[A-z\s]+,\s{1,8}[A-Z]{1,10}/', $line)) {
                $line_procedure_end = $no + 1;
            }
        }

        $site_length = $line_site_end - $line_site_start;
        $site = array_slice($this->lines, $line_site_start, $site_length);
        $site = $this->trimArray($site);

        $patient_length = $line_patient_end - $line_patient_start;
        $patient = array_slice($this->lines, $line_patient_start, $patient_length);
        $patient = $this->trimArray($patient);

        $insurance_length = $line_insurance_end - $line_insurance_start;
        $insurance = array_slice($this->lines, $line_insurance_start, $insurance_length);
        $insurance = $this->trimArray($insurance);

        $procedures_length = $line_procedure_end - $line_procedure_start;
        $procedures = array_slice($this->lines, $line_procedure_start, $procedures_length);
        $procedures = $this->trimArray($procedures);

        $normalized['doctor_facility'] = $site[0] ?? '';
        $normalized['doctor_address'] = $site[1] ?? '';

        if (preg_match('/.*,\s[A-Z]{2}\s\d{3,10}/', (string) $site[2])) {
            $normalized['doctor_address'] .= ', ' . $site[2];
        }

        foreach ($site as $line) {
            if (preg_match('/^\(\d{2,5}\)\s\d{2,10}-\d{2,10}/', $line)) {
                $normalized['doctor_phone'] = $line;
            }

            if (preg_match('/Fax:/', $line)) {
                $values = $this->parseKeyValues($line);
                $normalized['doctor_fax'] = $values['fax'] ?? '';
            }

            if (preg_match('/Report Date:/', $line)) {
                $values = $this->parseKeyValues($line);
                $normalized['order_date'] = $values['report-date'] ?? '';
            }
        }

        $normalized['patient_name'] = $patient[0] ?? '';
        $values = $this->parseMultiKeyValues([ $patient[1] ?? '' ]);

        $normalized['patient_gender'] = $values['gender'];
        $normalized['patient_dob'] = $values['date-of-birth'] ?? '';
        $normalized['patient_ssn'] = $values['ssn'];

        if (preg_match('/^[A-z\s]+,\s{1,8}[A-Z]{1,10}/', $procedures[count($procedures) - 1])) {
            $normalized['doctor_name'] = trim((string) $procedures[count($procedures) - 1]);
        }

        $normalized['exams'] = [];

        foreach ($procedures as $no => $line) {
            if (preg_match('/^[A-z\s-]+\(\d{3,8}\)/', $line)) {
                $exam = [];

                preg_match('/^([A-z\s-]+)\((\d{3,8})\)/', $line, $matches);

                $exam['study'] = trim((string) $matches[1]);
                $exam['procedure_code'] = trim((string) $matches[2]);

                preg_match('/^Diagnosis:([A-z,\s-]+)\s\(([A-Z0-9\s\.]{2,10})\)/', $procedures[$no + 1], $matches);
                $exam['diag_code'] = trim((string) $matches[1]);
                $exam['diag_desc'] = trim((string) $matches[2]);

                $normalized['exams'][] = $exam;
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = 'Order';
        $data['meta']['document_format'] = $this->format;

        if (!empty($normalized['order_date'])) {
            $date = Carbon::createFromFormat('m/d/Y', $normalized['order_date']);
            $data['order']['DateOfService'] = $date->format('Ymd') . '000000';
        }

        if (isset($normalized['patient_dob'])) {
            $date = Carbon::createFromFormat('m/d/Y', $normalized['patient_dob']);
            $patient_dob = $date->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['doctor_name']);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patient_dob ?? '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient_gender']);
        $data['patient']['SSN'] = $normalized['patient_ssn'];

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor_phone']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor_fax']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor_address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor_facility'];

        if (isset($normalized['exams'][0])) {
            $data['exams'][0]['study'] = $normalized['exams'][0]['study'];
            $data['exams'][0]['procedure_code'] = $normalized['exams'][0]['procedure_code'];

            $data['exams'][0]['MultiDiagnosisList'][0]['code'] = $normalized['exams'][0]['diag_code'];
            $data['exams'][0]['MultiDiagnosisList'][0]['description'] = $normalized['exams'][0]['diag_desc'];
            $data['exams'][0]['MultiDiagnosisList'][0]['coding_type'] = 'ICD10';
        }

        error_reporting(1);
        return $data;
    }
}
