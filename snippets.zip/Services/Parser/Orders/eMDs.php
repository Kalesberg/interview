<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * eMDs Order Parser
 * format: eMDs
 * type: Order
 */
class eMDs
{
    use HelperTrait;

    protected $format = 'eMDs';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches eMDs format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Requisition\s*#:/i', $content) &&
            preg_match('/\bCPT\b/', $content) &&
            preg_match('/In-House/', $content) &&
            preg_match('/STAT/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Order\s*Date:/i', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line1 = $line_number;
                $sep_pos1 = $matches[0][1] - 2; // -2 for skipping unwanted characters
            }
            elseif (preg_match('/Address:/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line2 = $line_number;
                $sep_pos2 = $matches[0][1];
            }
            elseif (preg_match('/Policy\s*Holder/i', $line)) {
                $sep_line3 = $line_number;
            }
            elseif (preg_match('/ICD\s*Code/i', $line)) {
                $sep_line4 = $line_number;
            }
            elseif (preg_match('/Electronically\s*signed\s*by/i', $line) || preg_match('/Signature/i', $line)) {
                $sep_line5 = $line_number;
            }
            elseif (preg_match('/Specimen\s+Collection\s+Information/i', $line)) {
                $sep_line5_1 = $line_number;
            }
        }
        if (isset($sep_line5_1)) {
            $sep_line5 = min($sep_line5, $sep_line5_1 - 1);
        }

        // Order information
        $llines = $rlines = [];
        for ($n = $sep_line1; $n < $sep_line2; $n ++) {
            $line = $this->lines[$n];

            $lstr = substr($line, 0, $sep_pos1);
            $rstr = substr($line, $sep_pos1);
            if ($rstr && trim($rstr) !== '') {
                $rlines[] = trim($rstr);
            }
            // Skip the first line of left parts
            if (count($rlines) > 0 && trim($lstr) !== '' && strpos($lstr, 'Radiology') === false) {
                if (empty($llines)) {
                    $llines[] = 'Facility:' . $lstr;
                }
                elseif (count($llines) === 1) {
                    $llines[] = 'Address:' . $lstr;
                }
                elseif (preg_match('/Fax:/', $lstr, $matches, PREG_OFFSET_CAPTURE)) {
                    $pos = $matches[0][1];
                    $llines[] = trim(substr($lstr, 0, $pos));
                    $llines[] = trim(substr($lstr, $pos));
                }
                else {
                    $llines[] = $lstr;
                }
            }
        }
        $normalized['order1'] = $this->parseKeyValues(implode("\n", $llines));
        $normalized['order2'] = $this->parseKeyValues(implode("\n", $rlines));
        $normalized['order2']['ordering-provider'] = preg_replace('/\b\s+([A-Z]+)\b/', ', $1', $normalized['order2']['ordering-provider']);

        // Patient information
        $llines = $rlines = '';
        for ($n = $sep_line2; $n < $sep_line3; $n++) {
            $line = $this->lines[$n];

            $lstr = substr($line, 0, $sep_pos2);
            $rstr = substr($line, $sep_pos2);
            $llines .= $lstr . "\n";
            $rlines .= $rstr . "\n";
        }
        $normalized['patient'] = $this->parseKeyValues($llines . $rlines);
        $normalized['patient']['patient'] = str_replace(',', ' ', $normalized['patient']['patient']);

        // Insurance
        $ins = \array_slice($this->lines, $sep_line3, $sep_line4 - $sep_line3);
        $normalized['insurance'] = $this->parseValuesUnderHeading($ins)['raw'];

        // Exams
        $lines = \array_slice($this->lines, $sep_line4, $sep_line5 - $sep_line4);
        $exams = [];
        foreach ($lines as &$line) {
            if (trim($line) !== '') {
                $exams[] = $line;
            }
        }
        // Set CPT as master column
        $exams['master_col'] = 1;
        $normalized['exams'] = $this->parseValuesUnderHeading($exams)['parsed'];
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['order2']['ordering-provider']);
        $data['referringDr']['npi'] = trim(explode('/', $normalized['order2']['provider-npi-upin'])[0]);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['order1']['phone']);
        $fax = $normalized['order1']['fax'] ?? false;
        if ($fax) {
            $data['referringDr']['phone2'] = $this->parsePhone($fax);
        }

        $data['referringDr']['address'] = $this->parseAddress($normalized['order1']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['order1']['facility'];

        $data['order']['accession'] = $normalized['order1']['requisition'];
        $data['order']['DateOfService'] = $normalized['order2']['order-date'] ? Carbon::parse($normalized['order2']['order-date'])->format('YmdHis') : '';
        $data['patient'] = $this->parseName($normalized['patient']['patient'], true);
        $data['patient']['code'] = $normalized['patient']['patient-acct'];
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['gender']);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']);

        $data['insuranceList'] = [];

        foreach ($normalized['insurance'] as $ins) {
            if (trim($ins[2]) === '') {
                continue;
            }

            $insurance_name = preg_replace('/^\d+\./', '', $ins[0]);
            $insurance_name = preg_replace('/\s-$/', '', $insurance_name);
            $insurance_name = trim($insurance_name);

            $item = [
                'name'          => $insurance_name,
                'insured'       => $this->parseName(str_replace(',', ' ', $ins[3]), true),
                'policy'        => $ins[2],
                'subscriber'    => $ins[1]
            ];
            $data['insuranceList'][] = $item;
        }

        $data['exams'] = [];
        $provider = $this->parseName($normalized['order2']['ordering-provider']);
        $provider['npi'] = $data['referringDr']['npi'];
        foreach ($normalized['exams'] as $exam) {
            $item = [
                'procedure_code' => $exam[1],
                'study'       => str_replace("\n", ' ', $exam[0]),
                'approving_provider'    => $provider
            ];
            $diagnoses = [];
            $str = trim((string) $exam[2]);
            if ($str && preg_match_all('/[^\s]+\s*ICD-\d{1,}/', $str, $matches, PREG_OFFSET_CAPTURE)) {
                $matches = $matches[0];
                foreach ($matches as $idx => $match) {
                    $diag = [];
                    $code = explode(' ', $match[0])[0];
                    $codetype = explode(' ', $match[0])[1];
                    $desc = ($idx + 1 < count($matches))
                        ? substr($str, $match[1] + \strlen($match[0]), $matches[$idx + 1][1] - \strlen($match[0]) - 1)
                        : substr($str, $match[1] + \strlen($match[0]));
                    $diag = [
                        'code'          => $code,
                        'coding_type'   => $codetype,
                        'description'   => strTrim($desc)
                    ];

                    $diagnoses[] = $diag;
                }
            }
            $item['MultiDiagnosisList'] = $diagnoses;
            $data['exams'][] = $item;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
