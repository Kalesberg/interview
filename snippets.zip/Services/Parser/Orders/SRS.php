<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * SRS Order Parser
 * format: SRS
 * type: Order
 */
class SRS
{
    use HelperTrait;
    protected $format = 'SRS';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/RADIOLOGY.TEST\s*ORDER\s*FORM/', $content) && true;
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @param  type|null $content (Content to parse)
     * @return boolean (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/ORDER\s+FORM/i', $line)) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/Signature/i', $line)) {
                $sep_line2 = $line_number;
            }
            elseif (preg_match('/Referral\s+To/i', $line)) {
                $sep_line3 = $line_number;
            }
            elseif (preg_match('/Comments:/i', $line)) {
                $sep_line4 = $line_number;
            }
        }

        // Facility
        $facility = '';
        for ($n = 0; $n < $sep_line1; $n ++) {
            $line = trim($this->lines[$n]);
            if ($line == '') continue;
            $facility .= $line . ' ';
        }
        $normalized['facility'] = trim($facility);

        // Order Form
        $v = [];
        for ($n = $sep_line1; $n < $sep_line2; $n ++) {
            $line = preg_replace('/_{3,}/', '        ', $this->lines[$n]);
            if (trim($line) == '') continue;
            $parts = preg_split('/\s{7,}/', $line, 2);
            $v = array_merge($v, $parts);
        }
        $normalized['order'] = $this->parseKeyValues(join("\n", $v));

        // Doctor name
        for ($n = $sep_line2+1; $n < $sep_line3; $n ++) {
            $line = trim($this->lines[$n]);
            if (trim($line) != '') {
                $normalized['doctor-name'] = $line;
                break;
            }
        }

        // Referral
        $v = [];
        for ($n = $sep_line3+1; $n < $sep_line4; $n ++) {
            $line = preg_replace('/_{5,}/', '     ', $this->lines[$n]);
            if (trim($line) == '') continue;
            $parts = preg_split('/\s{5,}/', $line);
            $v = array_merge($v, $parts);
        }
        $normalized['referral'] = $this->parseKeyValues(join("\n", $v));

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor-name']);
        // $data['referringDr']['sendingFacility'] = $normalized['facility'];
        $data['referringDr']['address'] = $this->parseAddress($normalized['referral']['address']);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['referral']['telephone']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['referral']['fax']);

        $data['order']['accession'] = $normalized['order']['order-id'];
        $data['order']['DateOfService'] = $normalized['order']['date'] ? Carbon::parse($normalized['order']['date'])->format('YmdHis') : '';

        $patient = $this->parseName(str_replace(',', ' ', $normalized['order']['patient-name']), true);
        $data['patient']['name'] = $patient['name'];
        $data['patient']['firstname'] = $patient['firstname'];
        $data['patient']['middlename'] = $patient['middlename'];
        $data['patient']['lastname'] = $patient['lastname'];
        $data['patient']['title'] = $patient['title'];
        $data['patient']['code'] = $normalized['order']['shared-id'];
        $dob = preg_replace('/([\d]+)-([\d]+)-([\d]+)/', '$3-$1-$2', $normalized['order']['dob']);
        $data['patient']['DOB'] = $dob ? Carbon::parse($dob)->format('YmdHis') : '';
        $data['patient']['phone1'] = trim($normalized['order']['phone-number']);

        $data['insuranceList'][0]['name'] = $normalized['order']['insurance-carrier'];
        $data['insuranceList'][0]['policy'] = $normalized['order']['policy-id'];
        $data['insuranceList'][0]['subscriber'] = $normalized['order']['group-id'];

        $provider = $this->parseName($normalized['doctor-name']);
        $data['exams'][0]['study'] = $normalized['order']['procedure'];
        $data['exams'][0]['approving_provider'] = $provider;
        $data['exams'][0]['MultiDiagnosisList'][0] = [
            'code'          => $normalized['order']['icd10'],
            'coding_type'   => 'ICD10',
            'description'   => $normalized['order']['diagnosis']
        ];

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
