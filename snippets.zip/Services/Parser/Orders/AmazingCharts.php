<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * AmazingCharts Order Parser
 * format: AmazingCharts
 * type: Order
 */
class AmazingCharts
{
    use HelperTrait;
    protected $format = 'AmazingCharts';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches AmazingCharts format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return (bool) preg_match('/Amazing\s*Charts/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $sep_line1 = $sep_line2 = $sep_line3 = null;
        $normalized = [];
        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/INSURANCE\s*INFORMATION/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line1 = $line_number;
                $sep_pos1 = $matches[0][1];
            }
            elseif (preg_match('/ORDERING\s*PROVIDER/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line2 = $line_number;
                $sep_pos2 = $matches[0][1];
            }
            elseif (preg_match('/REQUESTED\s*STUDIES/', $line)) {
                $sep_line3 = $line_number;
            }
        }

        // Facility
        $facility = [];
        for ($n = 0; $n < $sep_line1; $n++) {
            $line = trim($this->lines[$n]);
            if ($line === '') {
                continue;
            }
            if (preg_match('/ORDER\s*REQUISITION\s*FORM/', $line)) {
                break;
            }

            if (empty($facility)) {
                $facility['name'] = $line;
            }
            elseif (preg_match('/Phone:/i', $line)) {
                $pos = strpos($line, 'Fax:');
                $facility['phone'] = $this->getKeyValue(substr($line, 0, $pos))[1];
                $facility['fax'] = $this->getKeyValue(substr($line, $pos))[1];
                break;
            }
            else {
                if (!isset($facility['address']) && preg_match('/^\d+/', $line)) {
                    $address_type = 1;
                    $facility['address'] = $line;
                }
                elseif (isset($address_type) && $address_type == 1 && isset($facility['address'])) {
                    $facility['address'] .= ', ' . $line;
                }
                elseif (!isset($address_type) && preg_match('/^\d+/', $line)) {
                    $facility['address'] = $line;
                }
            }
        }
        $normalized['facility'] = $facility;

        // Order Date
        $normalized['order-date'] = $this->getValueBelow('ORDER REQUISITION FORM');

        // Patient and Insurance Information
        $patient = $insurance = [];
        for ($n = $sep_line1 + 1; $n < $sep_line2; $n++) {
            $line = $this->lines[$n];
            $lstr = trim(substr($line, 0, $sep_pos1));
            $rstr = substr($line, $sep_pos1) ? trim(substr($line, $sep_pos1)) : '';

            if ($lstr) {
                if (empty($patient)) {
                    preg_match('/([^()]+)\s*\(([^()]*)\)/', $lstr, $matches);
                    // $patient['name'] = trim(str_replace(',', ' ', $matches[1]));
                    $patient['name'] = trim($matches[1]);
                    preg_match('/([\d\/]+).*(M|F)$/', trim($matches[2]), $matches);
                    $patient['dob'] = $matches[1] ?? '';
                    $patient['sex'] = $matches[2] ?? '';
                }
                else {
                    if (strpos(trim($lstr), '(') === 0) {
                        $phone = preg_replace('/\D+/', ' ', $lstr);
                        $patient['phone'] = preg_replace('/\s+/', '-', trim($phone));
                    }
                    elseif (isset($patient['address'])) {
                        $patient['address'] .= ', ' . $lstr;
                    }
                    else {
                        $patient['address'] = $lstr;
                    }
                }
            }

            if ($rstr !== '') {
                if (isset($ins)) {
                    if (strpos($rstr, 'ID:')) {
                        $ins[] = $this->getKeyValue($rstr)[1];
                        $insurance[] = $ins;
                        unset($ins);
                    }
                    else {
                        $ins[] = $rstr;
                    }
                }
                else {
                    $ins = [];
                    $ins[] = $rstr;
                }
            }
        }
        $normalized['patient'] = $patient;
        $normalized['insurance'] = $insurance;

        // Exams and Provider Information
        $exams = [];
        $exam_counter = 0;

        for ($n = $sep_line2 + 1; $n < $sep_line3; $n++) {
            $line = $this->lines[$n];
            $lstr = trim(substr($line, 0, $sep_pos2));
            $rstr = substr($line, $sep_pos2) ? trim(substr($line, $sep_pos2)) : '';

            if ($lstr !== '') {
                if (preg_match('/:\s{1,}/', $lstr)) {
                    $pieces = explode(':', $lstr, 2);
                    $exams[$exam_counter] = [ $pieces[0], trim((string) $pieces[1]) ];
                    $exam_counter += 1;
                } else {
                    $exams[$exam_counter - 1][1] .= ' ' . $lstr;
                    $exams[$exam_counter - 1][1] = trim((string) $exams[$exam_counter - 1][1]);
                }
            }
            if (preg_match('/Electronically signed by/i', $rstr)) {
                $normalized['doctor'] = $this->getValueBelow(['search' => 'Electronically', 'from' => $n]);
            }
        }
        $normalized['exams'] = $exams;
        $normalized['exam-study'] = trim($this->lines[$sep_line3 + 1]);

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        // dd($normalized);
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor']);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['facility']['phone']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['facility']['fax']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['facility']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['facility']['name'];

        $data['order']['DateOfService'] = $normalized['order-date'] ? Carbon::parse($normalized['order-date'])->format('YmdHis') : '';

        // $data['patient'] = $this->parseName($normalized['patient']['name'], true);
        $data['patient']['name'] = $normalized['patient']['name'];
        $data['patient']['firstname'] = explode(',', $normalized['patient']['name'], 2)[1];
        $data['patient']['lastname'] = explode(',', $normalized['patient']['name'], 2)[0];
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';

        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex']);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']??'xxx-xxx-xxxx');
        $data['patient']['address'] = $normalized['patient']['address'] ? $this->parseAddress($normalized['patient']['address']) : null;
        unset($data['patient']['address']['address']);

        $data['insuranceList'] = [];
        foreach ($normalized['insurance'] as $ins) {
            $name = $ins[0];
            $addr = isset($ins[2]) ? trim($ins[1]) : '';
            $policy = $ins[2] ?? $ins[1];

            $insurance = [
                'name' => $name,
                'insurance-address' => $addr,
                'insured' => [
                    'firstname' => $data['patient']['firstname'],
                    'lastname' => $data['patient']['lastname'],
                    'address' => $data['patient']['address'],
                    'relation' => ''
                ],
                'policy' => $policy,
                'subscriber' => ''
            ];

            $data['insuranceList'][] = $insurance;
        }

        $exam = [];
        foreach ($normalized['exams'] as $key => $value) {
            $exam['MultiDiagnosisList'][] = [
                'code'          => $value[0],
                'coding_type'   => 'ICD10',
                'description'   => $value[1]
            ];

        }
        $provider = $this->parseName($normalized['doctor']);
        $exam['approving_provider'] = $provider;
        $exam['study'] = $normalized['exam-study'] ?? '';
        $data['exams'][0] = $exam;

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
