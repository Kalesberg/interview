<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * IBM Template for IntergyEMR Parser
 * format: IntergyEMR
 * type: Order
 */
class IntergyEMR
{
    use HelperTrait;
    protected $format = 'IntergyEMR';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    const RE_RX_DATE_DEA = '/Rx\s?Date:(.*?)DEA\s?#(.*)/i';
    const RE_RX_LIC = '/Rx\s?#(.*?)LIC\s?#(.*)/i';

    /**
     * Check if given files matches IntergyEMR format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        $content = str_replace("\r\n", PHP_EOL, $content);

        return preg_match(self::RE_RX_DATE_DEA, $content)
            && preg_match(self::RE_RX_LIC, $content)
            && preg_match('/Prescriber Signature/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode(PHP_EOL, $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $lineHeaderStart = 0;
        $lineHeaderEnd = 0;

        $linePatientStart = 0;
        $linePatientEnd = 0;

        $lineRxStart = 0;
        $lineRxEnd = 0;

        foreach ($this->lines as $no => $line) {
            if (preg_match(self::RE_RX_DATE_DEA, $line)) {
                $lineHeaderStart = $no;
            }

            if (preg_match('/.*Ph\s#.*/', $line)) {
                $lineHeaderEnd = $no + 1;
            }

            if (preg_match('/Name.*DOB.*/', $line)) {
                $linePatientStart = $no;
            }

            if (preg_match('/^Address.*/', $line)) {
                $linePatientEnd = $no + 1;
            }

            if (preg_match('/^Rx/', $line)) {
                $lineRxStart = $no + 1;
            }

            if (preg_match('/\s{30,}MAXIMUM\sDAILY\sDOSE/', $line)) {
                $lineRxEnd = $no;
            }
        }

        $headerLength = $lineHeaderEnd - $lineHeaderStart;
        $header = array_slice($this->lines, $lineHeaderStart, $headerLength);

        $patientLength = $linePatientEnd - $linePatientStart;
        $patient = array_slice($this->lines, $linePatientStart, $patientLength);

        $rxLength = $lineRxEnd - $lineRxStart;
        $rx = array_slice($this->lines, $lineRxStart, $rxLength);
        $rx = $this->trimArray($rx);

        // Header section
        foreach ($header as $no => $line) {
            // Rx Date and DEA line
            if (preg_match(self::RE_RX_DATE_DEA, $line, $matches)) {
                $rxDate = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $deaNo = isset($matches[2]) ? trim((string) $matches[2]) : '';

                $normalized['rx_date'] = $rxDate;
                $normalized['dea_no'] = $deaNo;
            }

            // Rx #, LIC and name line
            if (preg_match(self::RE_RX_LIC, $line, $matches)) {
                $rxNo = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $lic = isset($matches[2]) ? trim((string) $matches[2]) : '';

                $normalized['rx_no'] = $rxNo;
                $normalized['lic'] = $lic;

                $doctorName = isset($header[$no + 1]) ? trim((string) $header[$no + 1]) : '';
                $normalized['doctor_name'] = $doctorName;
                $normalized['doctor_npi'] = $lic;
            }

            // Address and phone number line
            if (preg_match('/\s+(.*)\s+Ph\s?#(.*)/i', $line, $matches)) {
                $doctorAddress = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $doctorPhone = isset($matches[2]) ? trim((string) $matches[2]) : '';

                $normalized['doctor_address'] = $doctorAddress;
                $normalized['doctor_phone'] = $doctorPhone;
            }
        }

        // Patient section
        foreach ($patient as $line) {
            // Patient name and date of birth
            if (preg_match('/Name\s+(.*)\s+DOB\s+(\d{2}.\d{2}.\d{4})/', $line, $matches)) {
                $patientName = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $patientDOB = isset($matches[2]) ? trim((string) $matches[2]) : '';

                $normalized['patient_name'] = $patientName;
                $normalized['patient_dob'] = $this->fixDateStr($patientDOB);
            }

            // Patient address
            if (preg_match('/Address(.*)/i', $line, $matches)) {
                $patientAddress = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $normalized['patient_address'] = $patientAddress;
            }
        }

        // Rx section
        foreach ($rx as $no => $line) {
            // Exam study, first line
            if (intval($no) === 0) {
                $normalized['exam_study'] = trim((string) $line);
            }

            // Exam comment, last line
            if (intval($no) === (count($rx) - 1)) {
                $normalized['exam_comment'] = trim((string) $line);
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = $this->type;
        $data['meta']['document_format'] = $this->format;

        $data['order']['placer_order_number'] = $normalized['rx_no'];

        if (isset($normalized['rx_date']) && strlen($normalized['rx_date']) > 0) {
            $data['order']['DateOfService'] = (new Carbon($normalized['rx_date']))->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['doctor_name']);

        if (isset($normalized['patient_dob']) && strlen($normalized['patient_dob']) > 0) {
            $date = Carbon::createFromFormat('m-d-Y', $normalized['patient_dob']);
            $patient_dob = $date->format('Ymd') . '000000';
        }

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patient_dob ?? '';

        if (isset($normalized['patient_address']) && strlen($normalized['patient_address']) > 0) {
            if (!($data['patient']['address'] = $this->parseAddress($normalized['patient_address']))) {
                $data['patient']['address'] = $this->parseGeoAddress($normalized['patient_address']);
            }
        }

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor_phone']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor_address']);
        $data['referringDr']['npi'] = $normalized['doctor_npi'];

        $data['exams'][0]['study'] = $normalized['exam_study'];
        $data['exams'][0]['comment'] = $normalized['exam_comment'];

        error_reporting(1);
        return $data;
    }

    /**
     * Makes sure that dates are formatted in the same way and prevents issues generated by
     * OCR parsing on dates.
     * E.g.:
     *  05/03/2017 becomes 05-03-2017
     *  05 03-2017 becomes 05-03-2017
     *
     * @param  string $date Date, pulled from the text file
     * @return string
     */
    private function fixDateStr(string $date) : string
    {
        return preg_replace('/\D/', '-', $date);
    }
}
