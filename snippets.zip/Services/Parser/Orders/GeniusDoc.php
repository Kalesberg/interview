<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * format: GeniusDoc
 * type: Order
 */
class GeniusDoc
{
    use HelperTrait;
    protected $format = 'GeniusDoc';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return (bool) preg_match_all('/LAB\s*\/\s*RADIOLOGY\s*\/\s*INJ\s*\/\s*DME\s*\/\s*ANCILLARY/', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (!isset($sep_line1) && preg_match('/\bTel\b/', $line) && preg_match('/\bFax\b/', $line)) {
                $sep_line1 = $line_number;
            }
            elseif (!isset($sep_line2) && preg_match('/DOB\s*\/\s*AGE\s*\/\s*SEX/i', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line2 = $line_number;
                $sep_pos2 = $matches[0][1];
            }
            elseif (!isset($sep_line3) && preg_match('/^Facility\b/', trim($line))) {
                $sep_line3 = $line_number;
            }
            elseif (preg_match('/Date\s+Code\s+Description/', $line)) {
                $sep_line4 = $line_number;
            }
        }

        // Doctor information
        $lines = $this->trimArray(array_slice($this->lines, 0, $sep_line1 + 1));
        $doctor['name'] = array_shift($lines);
        $line = array_pop($lines);
        preg_match('/^Tel\s*(.*)\s*Fax\s*(.*)/', $line, $matches);
        $doctor['phone1'] = $matches[1];
        $doctor['phone2'] = $matches[2];
        $address = join(',', $lines);
        $doctor['address'] = preg_replace('/([A-Z]{2})-([0-9\-]+)$/', '$1 $2', $address);
        $doctor['npi'] = $this->getValue('NPI\s*#\s*');
        $normalized['doctor'] = $doctor;

        // Patient information
        $lines = [];
        $lines0 = array_slice($this->lines, $sep_line2, $sep_line3 - $sep_line2);
        $left = $right = [];
        foreach ($lines0 as $line) {
            $l = trim((string) substr($line, 0, $sep_pos2));
            $l = preg_replace('/\s{3,}/', ': ', $l);
            $r = trim((string) substr($line, $sep_pos2));
            $r = preg_replace('/\s{3,}/', ': ', $r);
            if (!empty($l)) {
                if ($l == 'Address') {
                    $prev = array_pop($left);
                    if (stripos($prev, 'Name:') === false) {
                        $prev = 'Address: ' . $prev;
                        $left[] = $prev;
                    }
                    else {
                        array_push($left, $prev, 'Address: ');
                    }
                }
                else {
                    $left[] = $l;
                }
            }
            if (!empty($r)) {
                $right[] = $r;
            }
        }
        $lines = array_merge($left, $right);
        $lines1 = $this->trimArray(array_slice($this->lines, $sep_line3, $sep_line4 - $sep_line3));
        foreach ($lines1 as & $line) {
            if (preg_match('/\bTel\b/', $line) && preg_match('/\bFax\b/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $lines[] = substr($line, 0, $matches[0][1]);
                $lines[] = substr($line, $matches[0][1]);
            }
            else {
                $line = preg_replace('/\s{3,}/', ': ', $line);
                $lines[] = $line;
            }
        }
        $patient = $this->parseKeyValues(join("\n", $lines));
        preg_match('/(\d{2}\/\d{2}\/\d{4})\s*\/\s*(\d+)\s*\w\s*\/\s*(\w+)/', $patient['dob-age-sex'], $matches);
        $patient['dob'] = $matches[1];
        $patient['age'] = $matches[2];
        $patient['sex'] = $matches[3][0];
        $normalized['patient'] = $patient;

        // Chart ID = order -> PID
        $normalized['order_pid'] = $patient['chart-id'] ?? '';

        // Exams information
        $lines = [];
        $lines[] = $this->lines[$sep_line4];
        $lines0 = $this->trimArray(array_slice($this->lines, $sep_line4 + 1));
        foreach ($lines0 as $line) {
            if (!preg_match('/^\d{2}\/\d{2}\/\d{4}/', trim($line))) {
                break;
            }
            $lines[] = $line;
        }
        $exams = $this->parseValuesUnderHeading($lines)['raw'];
        $normalized['exams'] = $exams;

        $studies = [];
        foreach ($exams as $exam) {
            $icd_code = $exam[4];
            $study = preg_split('/\s{5,}/', $this->getValue(['search' => '\d+\.\s+ZOO\.00', 'delimiter' => '\s{5,}']))[1];
            $studies[$icd_code] = $study;
        }
        $normalized['studies'] = $studies;

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['order']['PID'] = $normalized['order_pid'];

        $data['referringDr'] = $this->parseName($normalized['doctor']['name']);
        $data['referringDr']['npi'] = $normalized['doctor']['npi'];
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone1']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor']['phone2']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor']['name'];

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['code'] = $normalized['patient']['chart-id'];
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex']);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['cell']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']);
        $data['patient']['age'] = $normalized['patient']['age'];

        if (isset($normalized['patient']['primary-insurance'])) {
            $data['insuranceList'][] = [
                'name'      => $normalized['patient']['primary-insurance'],
                'insured'   => $data['patient'],
                'policy'    => explode('/', $normalized['patient']['policy-group'])[0] ?? '',
                'subscriber'    => explode('/', $normalized['patient']['policy-group'])[1] ?? '',
            ];
        }

        foreach ($normalized['exams'] as $exam) {
            $data['exams'][] = [
                'procedure_code'    => $exam[1],
                'study'             => $exam[2],
                'MultiDiagnosisList'=> [[
                    'code'        => $exam[4],
                    'coding_type' => 'ICD',
                    'description' => $normalized['studies'][$exam[4]]
                ]]
            ];
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}