<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * MDSynergy Order Parser
 * format: MDSynergy
 * type: Order
 */
class MDSynergy
{
    use HelperTrait;
    protected $format = 'MDSynergy';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/RADIOLOGY\s*ORDER/', $content) && preg_match_all('/PATIENT\s*DEMOGRAPHICS/', $content) &&
               preg_match_all('/LAB\s*VENDOR\s*DETAILS/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @param  type|null $content (Content to parse)
     * @return boolean (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/RADIOLOGY\s*ORDER/', $line)) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/PATIENT\s*DEMOGRAPHICS/', $line)) {
                $sep_line1_1 = $line_number;
            }
            if (preg_match('/GUARANTOR.+INSURANCE\s*INFORMATION/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line1_2 = $line_number;
                $sep_pos1 = $matches[0][1] - 2;
            }
            if (preg_match('/LAB\s*VENDOR\s*DETAILS/', $line)) {
                $sep_line2_1 = $line_number;
            }
            if (preg_match('/ORDERING\s*PHYSICIAN\s*DETAILS/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line2_2 = $line_number;
                $sep_pos2 = $matches[0][1] - 2;
            }
            elseif (!isset($sep_line3) && preg_match('/Sr\.No\./i', $line)) {
                $sep_line3 = $line_number;
            }
            elseif (preg_match('/Comments:/', $line)) {
                $sep_line4 = $line_number;
            }
        }

        // Doctor information
        $doctor = [];
        $lines = array_slice($this->lines, 0, $sep_line1);
        $type1 = $this->getValue(['search' => 'Office', 'lines' => $lines]);
        $type2 = $this->getValue(['search' => 'Tel', 'lines' => $lines]);
        if (!empty($type1)) {
            foreach ($lines as $index => $line) {
                if (preg_match('/^\S+/', $line)) {
                    $sep_line0 = $index;
                    break;
                }
            }
            $lines = array_slice($lines, $index+1);
            foreach ($lines as $line) {
                if (!trim($line)) {
                    continue;
                }
                $str = preg_split('/\s{5,}/', trim($line))[0];
                if (empty($doctor)) {
                    $doctor[] = 'Address:' . $str;
                }
                else {
                    $doctor[] = $str;
                }
            }
        }
        elseif (!empty($type2)) {
            $lines = $this->trimArray($lines);
            $lines = array_slice($lines, -2);
            $doctor[] = 'Address:' . preg_replace('/[[:^print:]]+/', ',', $lines[0]);
            $chunks = preg_split('/\w+:/', $lines[1]);
            $doctor[] = 'Office:' . $chunks[1];
            if (count($chunks) > 2) {
                $doctor[] = 'Fax:' . $chunks[2];
            }
        }
        $doctor = $this->parseKeyValues(join("\n", $doctor));
        $normalized['doctor'] = $doctor;

        // Patient information
        $patient = [];
        for ($n = $sep_line1_1+1; $n < $sep_line2_1; $n ++) {
            $str = trim((string) substr($this->lines[$n], 0, $sep_pos1));
            $patient[] = $str;
        }
        $normalized['patient'] = $this->parseKeyValues(join("\n", $patient));

        // Insurance information
        $insurance = [];
        for ($n = $sep_line1_2+1; $n < $sep_line2_2; $n ++) {
            $str = trim((string) substr($this->lines[$n], $sep_pos1));
            $insurance[] = $str;
        }
        $normalized['insurance'] = $this->parseKeyValues(join("\n", $insurance));

        // Order information
        $order = [];
        for ($n = $sep_line2_2+1; $n < $sep_line3; $n ++) {
            $str = trim((string) substr($this->lines[$n], $sep_pos2));
            $order[] = $str;
        }
        $normalized['order'] = $this->parseKeyValues(join("\n", $order));

        // Exams information
        $lines = array_slice($this->lines, $sep_line3, $sep_line4 - $sep_line3);
        $exams0 = $this->parseValuesUnderHeading($lines)['raw'];
        $exams = [];
        $ex = [];
        foreach ($exams0 as $exam) {
            if (preg_match('/Sr\.No\./i', $exam[0])) {
                $exams[] = $ex;
                $ex = [];
                continue;
            }
            elseif (empty($ex)) {
                $ex = $exam;
                continue;
            }
            foreach ($exam as $index => $value) {
                if (empty(trim($value))) {
                    continue;
                }
                $ex[$index] .= ' ' . $value;
            }
        }
        if (!empty($ex)) {
            $exams[] = $ex;
        }
        $normalized['exams'] = $exams;

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $drName = $normalized['order']['ordering-physician-name'];
        $data['referringDr'] = $this->parseName(substr_replace($drName, ', ', strrpos($drName, ' '), 1));
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['office']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor']['fax']) ?? '';
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);

        $data['order']['accession'] = $normalized['order']['order'];
        $data['order']['DateOfService'] = $normalized['order']['order-date'] ? str_pad(Carbon::createFromFormat('m-d-Y', $normalized['order']['order-date'])->format('Ymd'), 14, '0') : '';
         
        $data['patient'] = $this->parseName($normalized['patient']['patient'], true);
        preg_match('/(.*)\s+Age:.*Sex:\s*(.*)/', $normalized['patient']['dob'], $matches);

        $data['patient']['DOB'] = $matches[1] ? str_pad(Carbon::createFromFormat('m-d-Y', $matches[1])->format('Ymd'), 14, '0') : '';
        $data['patient']['sex'] = $this->parseGender($matches[2]);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);
        $data['patient']['address']['address1'] = $normalized['patient']['address'];
        // Address parse ambigious ..

        $data['insuranceList'][] = [
            'name'      => $normalized['insurance']['insurance'],
            'insured'   => $this->parseName($normalized['insurance']['guarantor'])
        ];

        foreach ($normalized['exams'] as $ex) {
            $exam = [
                'study'     => $ex[1],
                'procedure_code'    => $ex[4],
                'status'    => $ex[3],
                'MultiDiagnosisList'    => [[
                    'code'  => $ex[5],
                    'coding_type'   => 'ICD-10'
                ]]
            ];
            $data['exams'][] = $exam;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
