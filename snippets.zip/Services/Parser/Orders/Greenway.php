<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * Class Greenway
 * @package ScriptSender\Services\Parsers\Order
 */
class Greenway
{
    use HelperTrait;

    protected $format = 'Greenway';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches Greenway format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Pt\s*ID/i', $content) &&
            preg_match('/Pt\s*Name/i', $content) &&
            preg_match('/Alt\s*ID/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     */
    public function parse(): array
    {
        $startLine1 = $startLine2 = $startLine3 = $startLine4 = null;

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Account\s*#/i', $line) || preg_match('/Pt\s*ID/i', $line) || preg_match('/Alt\s*ID/i', $line)) {
                if (!isset($startLine1)) {
                    $startLine1 = $line_number;
                }
            }
            elseif (preg_match('/Primary\s*Company/i', $line) || preg_match('/Secondary.*/i', $line)) {
                if (!isset($startLine2)) {
                    $startLine2 = $line_number;
                }
            }
            elseif (preg_match('/CODE/i', $line) && preg_match('/DIAGNOSIS/i', $line) && preg_match('/PRIORITY/i', $line)) {
                if (!isset($startLine3)) {
                    $startLine3 = $line_number;
                }
            }
            elseif (preg_match('/Please\s+Sign\s+and\s+Date/i', $line)) {
                $startLine4 = $line_number;
            }
        }

        if (!isset($startLine2)) {
            $startLine2 = $startLine3;
        }

        $section1 = ['Account\s*#:?', 'Physician:?', 'NPI:?', 'Prov\.?\s*#:?', 'Phys\.?\s*ID:?'];
        $section2 = ['Pt\s*ID:?', 'Pt\s*Name:?', 'Address:?', 'Pt\s*Phone:?', 'Name:?', 'RP\s*Phone:?'];
        $section3 = ['\bAlt\s*ID\b:?', '\bDOB\b:?', '\bSex\b:?', '\bRace\b:?', '\bAge\b:?', '\bSS#:?', '\bRelationship\b:?', '\bEmployer\b:?'];
        $section4 = ['Primary\s*Company:?', 'Primary\s*Plan:?', 'Company\s*ID:?', 'Address:?', 'Policy\s*#:?', 'Group\s*#:?', 'Insured:?', 'Ins\.?\s*Relationship:?', 'Worker.s\s*Comp:?'];
        $section5 = ['\bSecondary\s*Plan\b:?', '\bIns\.?\s*Relationship\b:?', '\bWorker.s\s*Comp\b:?'];

        $maxLen1 = $maxLen2 = $maxLen3 = 999;
        for ($l = $startLine1; $l < $startLine2; $l ++) {
            $line = $this->lines[$l];
            foreach ($section2 as $label) {
                $pattern = "/$label/";
                if (preg_match_all($pattern, $line, $matches, PREG_OFFSET_CAPTURE)) {
                    $matches = $matches[0];
                    $offset = $matches[count($matches) - 1][1];
                    $maxLen1 = ($maxLen1 > $offset) ? $offset : $maxLen1;
                }
            }
            foreach ($section3 as $label) {
                $pattern = "/$label/";
                if (preg_match_all($pattern, $line, $matches, PREG_OFFSET_CAPTURE)) {
                    $matches = $matches[0];
                    $offset = $matches[count($matches) - 1][1];
                    $maxLen2 = ($maxLen2 > $offset) ? $offset : $maxLen2;
                }
            }
        }

        if ($startLine2 < $startLine3) {
            for ($l = $startLine2; $l < $startLine3; $l ++) {
                $line = $this->lines[$l];
                foreach ($section5 as $label) {
                    $pattern = "/$label/";
                    if (preg_match_all($pattern, $line, $matches, PREG_OFFSET_CAPTURE)) {
                        $matches = $matches[0];
                        $offset = $matches[count($matches) - 1][1];
                        $maxLen3 = ($maxLen3 > $offset && $offset > 30) ? $offset : $maxLen3;
                    }
                }
            }
        }

        // Get Block1 content
        $block1 = ['Account:'];
        for ($l = $startLine1 + 1; $l < $startLine2; $l ++) {
            $string = (string) substr($this->lines[$l], 0, $maxLen1);
            if (count($block1) < 2 && !trim($string)) {
                continue;
            }
            // Ad-hoc bugfix: Disallow any commas except for City/State/Zip line
            if (count($block1) < 4) {
                $string = str_replace([',', ':'], ' ', $string);
            }
            $block1[] = $string;
        }

        $block1 = join("\n", $block1);

        // Get Block2 content
        $block2 = [];
        for ($l = $startLine1; $l < $startLine2; $l ++) {
            $string = (string) substr($this->lines[$l], $maxLen1, $maxLen2 - $maxLen1);
            if (!trim($string)) {
                continue;
            }
            $block2[] = $string;
        }
        $block2 = join("\n", $block2);

        // Get Block3 content
        $block3 = [];
        for ($l = $startLine1; $l < $startLine2; $l ++) {
            $string = (string) substr($this->lines[$l], $maxLen2);
            if (!trim($string)) {
                continue;
            }
            $block3[] = $string;
        }
        $patterns = ['/\b(Alt\s*ID)\s+/', '/\b(DOB)\s+/', '/\b(Sex)\s+/', '/\b(Race)\s+/', '/\b(Age)\s+/', '/\b(SS#)\s+/', '/\b(Relationship)\s+/', '/\b(Employer)\s+/'];
        foreach ($block3 as & $line) {
            $line = preg_replace($patterns, '$0:', $line);
        }
        $block3 = join("\n", $block3);

        $block4 = $block5 = [];
        if ($startLine2 < $startLine3) {
            // Get Block4 content
            for ($l = $startLine2; $l < $startLine3; $l ++) {
                $string = (string) substr($this->lines[$l], 0, $maxLen3);
                if (!trim($string)) {
                    continue;
                }
                $block4[] = $string;
            }
            $block4 = join("\n", $block4);
            // Get Block5 content
            $b5_fields = ['Secondary\s*Plan', 'Company\s*ID', 'Address', 'Policy\s*#', 'Group\s*#', 'Insured', 'Ins\.?\s*Relationship', 'Worker[^:]+Comp'];
            for ($l = $startLine2; $l < $startLine3; $l ++) {
                $string = (string) substr($this->lines[$l], $maxLen3);
                if (!trim($string)) {
                    continue;
                }
                if (empty($block5)) {
                    $string = str_ireplace('  Secondary ', 'Secondary:', $string);
                }
                $block5[] = $string;
            }
            $block5 = join("\n", $block5);
            foreach ($b5_fields as $field) {
                $pattern1 = '/' . $field . '/';
                $pattern2 = '/' . $field . '\s*:/';
                if (preg_match_all($pattern1, $block5) && !preg_match_all($pattern2, $block5)) {
                    $block5 = preg_replace($pattern1, '$0:', $block5);
                }
            }
        }

        $normalized = [];
        $normalized['column1'] = $this->parseKeyValues($block1);
        $normalized['column2'] = $this->parseKeyValues($block2);
        $normalized['column3'] = $this->parseKeyValues($block3);
        $normalized['column4'] = $this->parseKeyValues($block4);
        $normalized['column5'] = $this->parseKeyValues($block5);

        foreach ($normalized as $col => $col_data) {
            foreach ($col_data as $key => $value) {
                if (strpos($key, 'account-') !== false) {
                    $normalized[$col]['account'] = $value;
                    unset($normalized[$col][$key]);
                }
                elseif (strpos($key, 'prov-') !== false) {
                    $normalized[$col]['prov'] = $value;
                    unset($normalized[$col][$key]);
                }
                elseif (strpos($key, 'pt-id') !== false) {
                    $normalized[$col]['ptid'] = $value;
                    unset($normalized[$col][$key]);
                }
                elseif (strpos($key, 'policy-') !== false) {
                    $normalized[$col]['policy'] = $value;
                    unset($normalized[$col][$key]);
                }
                elseif (strpos($key, 'group-') !== false) {
                    $normalized[$col]['group'] = $value;
                    unset($normalized[$col][$key]);
                }
            }
        }

        // Exams
        // $header = $this->lines[$startLine3];
        // $pos = stripos($header, 'Clinical');
        // $params['header'] = preg_replace('/(Clinical\s*Comments).*/i', '   $1', $header);
        // for ($n = $startLine3 + 1; stripos($this->lines[$n], 'Authorization') === false && !preg_match('/DX\s*CODE/', $this->lines[$n]); $n ++) {
        //     $string = $this->lines[$n];
        //     $string = substr_replace($string, '   ', $pos, 0);
        //     if (!empty(trim($string))) {
        //         $params['cases'][] = $string;
        //     }
        // }
        $lines = [];
        for ($n = $startLine3; stripos($this->lines[$n], 'Authorization') === false && !preg_match('/DX\s*CODE/', $this->lines[$n]) && !preg_match('/Order\s*Requisition\s*for/', $this->lines[$n]); $n ++) {
            $string = $this->lines[$n];
            if ($n === $startLine3) {
                // Add few spaces between DIAGNOSIS and PRIORITY
                $pos0 = stripos($string, 'Priority');
                $string = preg_replace('/Priority/i', '   $0', $string);
                // Add few spaces between PRIORITY and CLINICAL COMMENTS/
                $pos = stripos($string, 'Clinical');
                $string = preg_replace('/(Clinical\s*Comments).*/i', '   $1', $string);
            }
            else {
                // Re-calculate the starting point of string
                // due to some bad OCR compilation
                if (strlen($string) > $pos0 && $string[$pos0] !== ' ' && $string[$pos0 - 1] !== ' ') {
                    $POS0 = intval(strrpos(substr($string, 0, $pos0), ' '));
                }
                else {
                    $POS0 = $pos0;
                }
                $string = substr_replace($string, '   ', $POS0, 0);
                if (strlen($string) > $pos && $string[$pos] !== ' ' && $string[$pos - 1] !== ' ') {
                    $POS = intval(strrpos(substr($string, 0, $pos), ' '));
                }
                else {
                    $POS = $pos;
                }
                $string = substr_replace($string, '   ', $POS, 0);
            }
            $lines[] = $string;
        }

        $exams = $this->parseValuesUnderHeading($lines)['parsed'];
        $normalized['exams'] = $exams;

        for ($l = $startLine4; $l < count($this->lines); $l ++) {
            $line = trim($this->lines[$l]);
            $date_pattern = '/(\d{1,2}\/\d{1,2}\/\d{4}\s*\d{1,2}.\d{1,2}.\d{1,2}[\sA-Za-z]{2,5})/';
            if (preg_match($date_pattern, $line, $matches)) {
                $normalized['DOS'] = $matches[1];
                $normalized['DOS'] = preg_replace('/^(\d{1,2}\/\d{1,2}\/\d{4}\s*\d{1,2}).(\d{1,2}).(\d{1,2})/', '$1:$2:$3', $normalized['DOS']);
            }
        }

        // Meta
        for ($i = 0; $i < 10; $i ++) {
            $line = $this->lines[$i];
            if (preg_match('/Req.Control\s*(?:#|ft)?(?::)?(.*)/i', $line, $matches)) {
                $normalized['control'] = trim($matches[1]);
            }
        }

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['order']['sendingApplication'] = 'greenway';
        $data['order']['accession'] = $normalized['control'];
        $data['order']['placer_order_number'] = $normalized['control'];
        $data['order']['PID'] = $normalized['column2']['ptid'];
        $data['order']['DateOfService'] = $normalized['DOS'] ? Carbon::parse($normalized['DOS'])->format('YmdHis') : '';

        $data['patient'] = $this->parseName($normalized['column2']['pt-name'] ?? '');
        $data['patient']['DOB'] = $normalized['column3']['dob'] ? Carbon::parse($normalized['column3']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['column3']['sex']);
        $data['patient']['language'] = 'English';
        $data['patient']['address'] = $this->parseAddress($normalized['column2']['address']);
        $data['patient']['phone1'] = $this->parsePhone($normalized['column2']['pt-phone']);
        $data['patient']['race'] = $normalized['column3']['race'] ?? '';
        $data['patient']['age'] = $normalized['column3']['age'] ?? '';
        $data['patient']['SSN'] = $normalized['column3']['ss'] ?? '';

        $name = $normalized['column1']['physician'];
        $name = preg_replace('/\s+([A-Z]+)$/', ', $1', $name);
        $data['referringDr'] = $this->parseName($name, true);
        $data['referringDr']['address'] = $this->_parseAccount((string) $normalized['column1']['account']);
        $data['referringDr']['phone1'] = $data['referringDr']['address']['phone1'];
        unset($data['referringDr']['address']['phone1']);
        $data['referringDr']['npi'] = $normalized['column1']['npi'] ?? $normalized['column1']['np1'] ?? '';
        $data['referringDr']['sendingFacility'] = $data['referringDr']['address']['sendingFacility'];
        unset($data['referringDr']['address']['sendingFacility']);

        $data['insuranceList'] = [];
        if (count($normalized['column4'])) {
            $data['insuranceList'][] = [
                'name'          => $normalized['column4']['primary-company'] ?? '',
                'companyID'     => $normalized['column4']['company-id'] ?? '',
                'plan'          => $normalized['column4']['primary-plan'] ?? '',
                'policy'        => $normalized['column4']['policy'] ?? '',
                'insured'       => [
                    'name'          => $normalized['column4']['insured'] ?? '',
                    'relationship'  => $normalized['column4']['ins-relationship'] ?? ''
                ],
                'insurance-address' => $normalized['column4']['address'] ?? '',
                'subscriber'    => $normalized['column4']['group'] ?? ''
            ];
        }
        if (count($normalized['column5']) && !preg_match('/No\s*Secondary\s*Company/', $normalized['column5']['secondary'])) {
            $data['insuranceList'][] = [
                'name'          => $normalized['column5']['secondary'] ?? '',
                'companyID'     => $normalized['column5']['company-id'] ?? '',
                'plan'          => $normalized['column5']['secondary-plan'] ?? '',
                'policy'        => $normalized['column5']['policy'] ?? '',
                'insured'       => [
                    'name'          => $normalized['column5']['insured'] ?? '',
                    'relationship'  => $normalized['column5']['ins-relationship'] ?? ''
                ],
                'insurance-address' => $normalized['column5']['address'] ?? '',
                'subscriber'    => $normalized['column5']['group'] ?? ''
            ];
        }

        $data['exams'] = [];
        $provider = $this->parseName($name);
        $provider['npi'] = $data['referringDr']['npi'];

        foreach ($normalized['exams'] as $case) {
            if (!$case[0] && !$case[1]) {
                continue;
            }
            if (!trim($case[0]) && !trim($case[1])) {
                continue;
            }
            if (preg_match('/Test:/i', $case[0])) {
                continue;
            }

            $prcode = preg_split('/\s*:\s*/', $case[0], 2)[1] ?? trim($case[0]);
            $exam['comment'] = $case[4];
            $exam['study'] = preg_replace('/^[^A-Za-z]+/', '', $case[1]);
            $exam['approving_provider'] = $provider;
            $exam['procedure_code'] = preg_replace('/[A-Za-z]+$/', '', $prcode);
            // $exam['stat'] = $case[2] ;
            $exam['priority'] = $case[3];
            $tip = $exam['comment'] ? preg_split('/\s+/', trim($exam['comment']))[0] : '';
            if (!trim($exam['priority']) && \strlen($tip) < 3) {
                $exam['priority'] = $tip;
                $exam['comment'] = trim(substr($exam['comment'], \strlen($tip)));
            }
            $exam['MultiDiagnosisList'] = [];
            if (preg_match('/ICD.*:/', $case[2])) {
                $codetype = preg_split('/\s*:\s*/', $case[2], 2)[0];
                $code = preg_split('/\s*:\s*/', $case[2], 2)[1];
                $description = '';
            }
            else {
                $code = explode(' ', $case[2])[0];
                $code = trim($code, ', ');
                $description = '';
            }
            $codes = explode(',', $code);
            foreach ($codes as $code) {
                $exam['MultiDiagnosisList'][] = [
                    'code'  => trim($code),
                    'coding_type'   => $codetype ?? 'ICD10',
                    'description'   => $description
                ];
            }

            $data['exams'][] = $exam;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }

    /**
     * Parse Account block partial of the first column
     * @param string $account
     * @return array
     */
    protected function _parseAccount(string $account)
    {
        if (!$account) {
            return [];
        }
        $pattern = '/(?:([^,]+),(?:\s*([^,]+),)\s*(?:([^,]+),)?\s*([^,]+),\s*)?([A-Z]{2})(?:\s+([A-Z0-9]{5}(?:[\-]?\d{4})?))?\s*,([()0-9\s\-]+)$/';
        preg_match($pattern, $account, $matches);

        $doctor = [];
        $doctor['sendingFacility'] = $matches[1] ? trim($matches[1]) : '';
        $doctor['address1'] = $matches[2] ? trim($matches[2]) : '';
        $doctor['address2'] = $matches[3] ? trim($matches[3]) : '';
        $doctor['city'] = $matches[4] ? trim($matches[4]) : '';
        $doctor['state'] = $matches[5] ? trim($matches[5]) : '';
        $doctor['zip'] = $matches[6];
        $doctor['phone1'] = $matches[7] ? $this->parsePhone($matches[7]) : '';

        return $doctor;
    }
}
