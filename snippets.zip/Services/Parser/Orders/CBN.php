<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * Center for Brain and Neuro Parser
 * format: CBN
 * type: Order
 */
class CBN
{
    use HelperTrait;
    protected $format = 'CBN';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches CBN format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        $content = str_replace("\r\n", PHP_EOL, $content);

        return preg_match('/Tel:.*Fax:.*\n{1,5}\s{30,}RADIOLOGY/', $content)
            && preg_match('/PATIENT\sDEMOGRAPHICS\s*GUARANTOR\s&\sINSURANCE\sINFORMATION/i', $content)
            && preg_match('/LAB\s*ORDERING\sPHYSICIAN/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_patient_start = 0;
        $line_patient_end = 0;

        $line_sender_start = 0;
        $line_sender_end = 0;

        $line_exams_start = 0;
        $line_exams_end = 0;

        foreach ($this->lines as $no => $line) {
            if (preg_match('/PATIENT\sDEMOGRAPHICS\s*GUARANTOR\s&\sINSURANCE\sINFORMATION/i', $line)) {
                $line_patient_start = $no + 1;
            }

            if (preg_match('/LAB\s*ORDERING\sPHYSICIAN/i', $line)) {
                $line_patient_end = $no - 1;
                $line_sender_start = $no + 1;
            }

            if (preg_match('/^Fax:/i', $line)) {
                $line_sender_end = $no + 1;
                $line_exams_start = $no + 1;
            }

            if (preg_match('/Comments:/i', $line)) {
                $line_exams_end = $no - 1;
            }
        }

        $patient_length = $line_patient_end - $line_patient_start;
        $patient = array_slice($this->lines, $line_patient_start, $patient_length);
        $patient = $this->trimArray($patient);

        $sender_length = $line_sender_end - $line_sender_start;
        $sender = array_slice($this->lines, $line_sender_start, $sender_length);
        $sender = $this->trimArray($sender);

        $exams_length = $line_exams_end - $line_exams_start;
        $exams = array_slice($this->lines, $line_exams_start, $exams_length);
        $exams = $this->trimArray($exams);

        $patient_values = $this->parseMultiKeyValues($patient);

        $normalized['patient_name'] = $patient_values['patient'] ?? '';

        $normalized['insurance_name'] = $patient_values['insurance'] ?? '';
        $normalized['insured'] = $patient_values['guarantor'] ?? '';

        if (isset($patient_values['dob-sex']) && !empty($patient_values['dob-sex'])) {
            $split = explode(' ', $patient_values['dob-sex']);

            $normalized['patient_sex'] = $split[0] ?? '';
            $normalized['patient_dob'] = $split[1] ?? '';
        }

        $lab = [];
        $physician = [];

        foreach ($sender as $line) {
            $split = preg_split('/\s{10,}/', $line, 2);

            if (isset($split[0])) {
                $lab[] = $split[0];
            }

            if (isset($split[1])) {
                $physician[] = $split[1];
            }
        }

        $physician_values = $this->parseKeyValues(implode(PHP_EOL, $physician));

        $normalized['physician_name'] = $physician_values['name'] ?? '';
        $normalized['order_number'] = $physician_values['order'] ?? '';
        $normalized['order_date'] = $physician_values['date'] ?? '';

        $lab_normalized = [];
        $lab_address = [];

        foreach ($lab as $line) {
            if (preg_match('/^Name:|^Phone:|^Fax:/i', $line)) {
                $lab_normalized[] = $line;
            } else {
                $str = preg_replace('/Address:/i', '', $line);
                $str = preg_replace('/\s([A-Z]{2}\s\d{4,10})/', ', ${1}', $str);
                $lab_address[] = $str;
            }
        }

        $lab_values = $this->parseKeyValues(implode(PHP_EOL, $lab_normalized));

        $normalized['physician_facility'] = $lab_values['name'] ?? '';
        $normalized['physician_phone'] = $lab_values['phone'] ?? '';
        $normalized['physician_fax'] = $lab_values['fax'] ?? '';
        $normalized['physician_address'] = implode(',', $this->trimArray($lab_address));

        $normalized['exams'] = [];

        foreach ($exams as $no => $line) {
            if (preg_match('/Sr.No.Test.Name\s*ICD\sCode/i', $line)) {
                $exam = [];

                $l1 = $exams[$no + 1];
                $l2 = $exams[$no + 2];

                $split1 = preg_split('/\s{10,}/', $l1);

                $exam['study'] = preg_replace('/\d{1,10}\s{4,}/i', '', (string) $split1[0]);
                $exam['icd'] = isset($split1[1]) ? explode(';', (string) $split1[1]) : '';

                $exam['comment'] = preg_replace('/^.*:\s/i', '', $l2);

                $normalized['exams'][] = $exam;
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        if (count($normalized['exams']) > 1) {
            for ($i = 1; $i <= count($normalized['exams']); $i++) {
                $data['exams'][$i] = $data['exams'][0];
            }
        }

        $data['meta']['document_type'] = 'Order';
        $data['meta']['document_format'] = $this->format;

        $data['order']['placer_order_number'] = trim((string) $normalized['order_number']);

        if (isset($normalized['order_date']) && strlen($normalized['order_date']) > 0) {
            $date = Carbon::createFromFormat('m-d-Y', $normalized['order_date']);
            $data['order']['DateOfService'] = $date->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['physician_name']);

        if (isset($normalized['patient_dob'])) {
            $date = Carbon::createFromFormat('m-d-Y', $normalized['patient_dob']);
            $patient_dob = $date->format('Ymd') . '000000';
        }

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patient_dob ?? '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient_sex']);

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['physician_phone']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['physician_fax']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['physician_address']);
        $data['referringDr']['sendingFacility'] = $normalized['physician_facility'];

        $data['insuranceList'][0]['name'] = $normalized['insurance_name'];

        if (isset($normalized['insured'])) {
            $insured = $this->parseName($normalized['insured']);

            $data['insuranceList'][0]['insured']['name'] = $insured['name'] ?? '';
            $data['insuranceList'][0]['insured']['firstname'] = $insured['firstname'] ?? '';
            $data['insuranceList'][0]['insured']['middlename'] = $insured['middlename'] ?? '';
            $data['insuranceList'][0]['insured']['lastname'] = $insured['lastname'] ?? '';
            $data['insuranceList'][0]['insured']['title'] = $insured['title'] ?? '';
        }

        foreach ($normalized['exams'] as $no => $exam) {
            $data['exams'][$no]['study'] = $exam['study'];
            $data['exams'][$no]['comment'] = $exam['comment'];

            foreach ($exam['icd'] as $code) {
                $data['exams'][$no]['MultiDiagnosisList'][] = [
                    'code' => trim((string) $code),
                    'coding_type' => 'ICD10',
                    'description' => ''
                ];
            }
        }

        error_reporting(1);
        return $data;
    }
}
