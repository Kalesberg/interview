<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * MicroMD Parser
 * format: MicroMD
 * type: Order
 */
class MicroMD
{
    use HelperTrait;
    protected $format = 'MicroMD';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches eRAD format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/^CHA\s[[:upper:]]+\s/', $content)
            && preg_match('/Order\sfor\sPatient:.*\(DOB:\s\d{1,2}\/\d{1,2}\/\d{4}\)/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_exams_start = 0;
        $line_exams_end = 0;

        $line_patient_start = 0;
        $line_patient_end = 0;

        $line_ins_start = 0;
        $line_ins_end = 0;

        $line_header_start = 0;
        $line_header_end = 0;

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Description:/', $line)) {
                $line_exams_start = $line_number;
            }

            if (preg_match('/Order\sto:/', $line)) {
                $line_exams_end = $line_number;
            }

            if (preg_match('/Patient Information:/', $line)) {
                $line_patient_start = $line_number;
            }

            if (preg_match('/Patient Insurance:/', $line)) {
                $line_patient_end = $line_number - 1;
            }

            if (preg_match('/Patient Insurance:/', $line)) {
                $line_ins_start = $line_number;
            }

            if (preg_match('/Authorized By:/', $line)) {
                // the order may not have an insurance section
                $line_patient_end = $line_patient_end ?: $line_number - 1;
                $line_ins_end = $line_number - 1;
            }

            if (preg_match('/Order for Patient:/', $line)) {
                $line_header_end = $line_number - 1;
            }

            if (preg_match('/\s*Authorized\sBy:.*/', $line)) {
                preg_match('/[A-Z][a-z]{2}\s\d{1,2},\s\d{4}/', $line, $matches);

                $normalized['date_of_service'] = $matches[0] ?? '';
            }
        }

        $header_array = array_slice($this->lines, $line_header_start, ($line_header_end - $line_header_start));
        $exams_array = array_slice($this->lines, $line_exams_start, ($line_exams_end - $line_exams_start));
        $patient_array = array_slice($this->lines, $line_patient_start, ($line_patient_end - $line_patient_start));
        $insurance_array = array_slice($this->lines, $line_ins_start, ($line_ins_end - $line_ins_start));

        $content_provider = '';
        $content_header = [];

        foreach ($header_array as $hline) {
            $split = preg_split('/\s{10,}/', $hline, -1, PREG_SPLIT_NO_EMPTY);
            if (isset($split[0])) {
                $content_header[] = $split[0];
            }

            if (isset($split[1]) && preg_match('/^.*:\s*.*$/i', $split[1])) {
                $content_provider .= $split[1] . PHP_EOL;
            }
        }

        $content_header = $this->trimArray($content_header);
        unset($content_header[2]); // map this value once we figure out what it is for
        $provider = $this->parseKeyValues($content_provider);

        $normalized['provider_name'] = $provider['provider'] ?? '';
        $normalized['provider_phone'] = $provider['phone'] ?? '';
        $normalized['provider_fax'] = $provider['fax'] ?? '';
        $normalized['provider_npi'] = $provider['npi'] ?? '';

        $pattern1 = '/^CHA.*/';
        $pattern2 = '/\d*-\d*-\d*/';

        $normalized['provider_address'] = '';
        $normalized['sending_facility'] = '';

        foreach ($content_header as $line) {
            if (!preg_match($pattern1, $line) && !preg_match($pattern2, $line)) {
                if (!empty($normalized['provider_address'])) {
                    $normalized['provider_address'] .= ', ';
                }

                $normalized['provider_address'] .= $line;
            }

            if (preg_match($pattern1, $line)) {
                $normalized['sending_facility'] = trim((string) $line);
            }
        }

        $normalized['provider_address'] = preg_replace('/\sUSA/', '', $normalized['provider_address']);

        $content_patient = '';
        $address_patient = '';

        foreach ($patient_array as $pline) {
            if (preg_match('/^.*\s{10,}DOB:\s*\d{1,2}\/\d{1,2}\/\d{4}/i', $pline)) {
                $split = preg_split('/\s{10,}/', $pline);

                if (isset($split[0]) && !empty($split[0])) {
                    $normalized['patient_name'] = trim((string) $split[0]);
                }

                if (isset($split[1]) && !empty($split[1])) {
                    $content_patient .= trim((string) $split[1]) . PHP_EOL;
                }
            }

            if (preg_match('/^.*\s{10,}Gender:\s.*/i', $pline)) {
                $split = preg_split('/\s{10,}/', $pline);

                if (isset($split[0]) && !empty($split[0])) {
                    $address_patient = trim((string) $split[0]);
                }

                if (isset($split[1]) && !empty($split[1])) {
                    $content_patient .= trim((string) $split[1]) . PHP_EOL;
                }
            }

            if (preg_match('/^.*,\s[A-Z]{2}\s[0-9]{3,}/', $pline)) {
                $address_patient .= ', ' . trim($pline);
            }

            if (preg_match('/^\s*?Phone:/', $pline)) {
                $content_patient .= trim($pline) . PHP_EOL;
            }
        }

        $patient = $this->parseKeyValues($content_patient);

        $normalized['patient_dob'] = $patient['dob'];
        $normalized['patient_gender'] = $patient['gender'];
        $normalized['patient_phone'] = $patient['phone'];
        $normalized['patient_address'] = trim($address_patient);

        $insurance_list = [];
        $insurance_counter = 0;

        foreach ($insurance_array as $no => $iline) {
            if (preg_match('/\s{1,}\([A-Z]\)\s{1,5}.*\s*Policy\s#:.*/i', $iline)) {
                $split = preg_split('/\s{10,}/', $iline, 2);

                if (isset($split[0]) && !empty($split[0])) {
                    $insurance_name = trim($split[0]);
                    $insurance_name = preg_replace('/^.*\([A-Z]\)\s|[^a-zA-z\s-]|\s\[\d*\]/', '', $insurance_name);

                    $insurance_list[$insurance_counter]['name'] = trim((string) $insurance_name);
                }

                if (isset($split[1]) && !empty($split[1])) {
                    $temp = $this->parseKeyValues($split[1]);
                    $insurance_list[$insurance_counter]['policy'] = $temp['policy'] ?? '';
                }

                if (isset($insurance_array[$no - 1])) {
                    preg_match('/Plan Set Name:(.*)/', $insurance_array[$no - 1], $matches);

                    if (!empty($matches)) {
                        $plan = isset($matches[1]) ? trim((string) $matches[1]) : '';
                        $insurance_list[$insurance_counter]['plan'] = $plan;
                    }
                }
            }

            if (preg_match('/\s{1,}.*\s*Group\s#:/', $iline)) {
                $split = preg_split('/\s{10,}/', $iline, 2);

                if (isset($split[0]) && !empty($split[0])) {
                    if (!preg_match('/OUTREACH USE ONLY/', $split[0])) {
                        $insurance_list[$insurance_counter]['address'] = trim((string) $split[0]);
                    }
                }

                if (isset($split[1]) && !empty($split[1])) {
                    $temp = $this->parseKeyValues($split[1]);
                    $insurance_list[$insurance_counter]['group'] = $temp['group'] ?? '';
                }
            }

            if (preg_match('/\s{1,}.*\s*Policyholder:/', $iline)) {
                $split = preg_split('/\s{10,}/', $iline, 2);

                if (isset($split[0]) && !empty($split[0])) {
                    $insurance_list[$insurance_counter]['address'] .= ' ' . trim((string) $split[0]);
                }

                if (isset($split[1]) && !empty($split[1])) {
                    $temp = $this->parseKeyValues($split[1]);
                    $insurance_list[$insurance_counter]['policyholder'] = $temp['policyholder'] ?? '';
                }
            }

            if (preg_match('/\s{1,}Phone:\s.*\s{10,}Policyholder\sDOB:/', $iline)) {
                $values = $this->parseMultiKeyValues([trim($iline)]);
                $insurance_list[$insurance_counter]['dob'] = $values['policyholder-dob'] ?? $values['dob'] ?? '';

                $phone = $this->parsePhone($values['phone'] ?? '');
                $insurance_list[$insurance_counter]['phone'] = $phone;
            }

            if (preg_match('/\s*Effective\sDate:/i', $iline)) {
                $temp = $this->parseKeyValues(trim($iline));
                $insurance_list[$insurance_counter]['effective_date'] = $temp['effective-date'] ?? '';
            }

            if (preg_match('/\s{1,}Expiration\sDate:/', $iline)) {
                $temp = $this->parseKeyValues(trim($iline));
                $insurance_list[$insurance_counter]['expiration_date'] = $temp['expiration-date'] ?? '';
                $insurance_counter += 1;
            }
        }

        $normalized['insurance'] = $insurance_list;

        $exams = $this->parseKeyValues(implode(PHP_EOL, $exams_array));

        $normalized['exam_study'] = $exams['description'];

        preg_match('/^\[G?\d{3,}\]/', $exams['order'], $matches);

        if (isset($matches[0])) {
            $normalized['exam_order'] = preg_replace('/[^G\d]/', '', $matches[0]);
        }

        $normalized['exam_comment'] = trim(preg_replace('/\[\d{3,}\]/', '', $exams['order']));

        preg_match('/^\(.*\)\s/', $exams['diagnoses'], $matches);

        if (isset($matches[0])) {
            $normalized['exam_diagnose_code'] = preg_replace('/\(|\)|\s/', '', $matches[0]);
        }

        $normalized['exam_diagnose_description'] = trim(preg_replace('/^\(.*\)\s/', '', $exams['diagnoses']));

        //dd($normalized);

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        if (count($normalized['insurance']) > 1) {
            for ($i = 1; $i < count($normalized['insurance']); $i++) {
                $data['insuranceList'][$i] = $data['insuranceList'][0];
            }
        }

        $data['meta']['document_type'] = 'Order';
        $data['meta']['document_format'] = $this->format;

        if (!empty($normalized['date_of_service'])) {
            $dos = Carbon::createFromFormat('M j, Y', $normalized['date_of_service']);
            $data['order']['DateOfService'] = $dos->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['provider_name']);
        $dob = Carbon::createFromFormat('m/d/Y', $normalized['patient_dob']);

        $gender = trim((string) $normalized['patient_gender']);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $dob->format('Ymd') . '000000';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient_phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient_address']);
        $data['patient']['sex'] = $this->parseGender($normalized['patient_gender']);

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $normalized['provider_phone'];
        $data['referringDr']['phone2'] = $normalized['provider_fax'];
        $data['referringDr']['npi'] = $normalized['provider_npi'];
        $data['referringDr']['address'] = $this->parseAddress($normalized['provider_address']);
        $data['referringDr']['sendingFacility'] = $normalized['sending_facility'];

        $data['referringDr']['title'] = trim((string) $data['referringDr']['title']);

        $data['exams'][0]['study'] = $normalized['exam_comment'];
        $data['exams'][0]['comment'] = $normalized['exam_study'];
        $data['exams'][0]['procedure_code'] = $normalized['exam_order'];

        $data['exams'][0]['MultiDiagnosisList'][0]['code'] = $normalized['exam_diagnose_code'];
        $data['exams'][0]['MultiDiagnosisList'][0]['description'] = $normalized['exam_diagnose_description'];
        $data['exams'][0]['MultiDiagnosisList'][0]['coding_type'] = 'ICD10';

        $holder = $this->parseName($normalized['insurance'][0]['policyholder']);

        if (!empty($normalized['insurance'][0]['dob'])) {
            $temp_dob = Carbon::createFromFormat('m/d/Y', $normalized['insurance'][0]['dob']);
            $holder_dob = $temp_dob->format('Ymd') . '000000';
        }

        if (count($normalized['insurance']) > 0) {
            $address_str = trim((string) $normalized['insurance'][0]['address']);

            $data['insuranceList'][0]['name'] = $normalized['insurance'][0]['name'];
            $data['insuranceList'][0]['insurance-address'] = strlen($address_str) > 3 ? $address_str : '';
            $data['insuranceList'][0]['plan'] = $normalized['insurance'][0]['plan'] ?? '';
            $data['insuranceList'][0]['policy'] = $normalized['insurance'][0]['policy'];
            $data['insuranceList'][0]['insured']['name'] = $holder['name'];
            $data['insuranceList'][0]['insured']['firstname'] = $holder['firstname'];
            $data['insuranceList'][0]['insured']['middlename'] = $holder['middlename'];
            $data['insuranceList'][0]['insured']['lastname'] = $holder['lastname'];
            $data['insuranceList'][0]['insured']['title'] = $holder['title'];
            $data['insuranceList'][0]['insured']['DOB'] = $holder_dob ?? '';

            if (isset($normalized['insurance'][1])) {
                $holder = $this->parseName($normalized['insurance'][1]['policyholder']);

                if (!empty($normalized['insurance'][0]['dob'])) {
                    $temp_dob = Carbon::createFromFormat('m/d/Y', $normalized['insurance'][1]['dob']);
                    $holder_dob = $temp_dob->format('Ymd') . '000000';
                }

                $address_str = trim($normalized['insurance'][1]['address']);

                $data['insuranceList'][1]['name'] = $normalized['insurance'][1]['name'];
                $data['insuranceList'][1]['insurance-address'] = strlen($address_str) > 3 ? $address_str : '';
                $data['insuranceList'][0]['plan'] = $normalized['insurance'][1]['plan'] ?? '';
                $data['insuranceList'][1]['policy'] = $normalized['insurance'][1]['policy'];
                $data['insuranceList'][1]['insured']['name'] = $holder['name'];
                $data['insuranceList'][1]['insured']['firstname'] = $holder['firstname'];
                $data['insuranceList'][1]['insured']['middlename'] = $holder['middlename'];
                $data['insuranceList'][1]['insured']['lastname'] = $holder['lastname'];
                $data['insuranceList'][1]['insured']['title'] = $holder['title'];
                $data['insuranceList'][1]['insured']['DOB'] = $holder_dob ?? '';
            }
        }

        error_reporting(1);
        return $data;
    }
}
