<?php

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * NextGenRadReq Order Parser
 * format: NextGenRadReq
 * type: Order
 */
class NextGenRadReq
{
    use HelperTrait;
    protected $format = 'NextGenRadReq';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/\bRadReq\b/', $content) || preg_match('/\bRad\s*Re.\b/', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        foreach ($this->lines as $line) {
            if (preg_match('/\bRadReq\b/', $line, $matches, PREG_OFFSET_CAPTURE) || preg_match('/\bRad\s*Re.\b/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_pos = $matches[0][1];
                break;
            }
        }

        // Pre-processing
        foreach ($this->lines as $line_number => $line) {
            // Erase portion of strings
            if (preg_match('/\bRadReq\b/', $line, $matches, PREG_OFFSET_CAPTURE) || preg_match('/\bRad\s*Re.\b/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $line = substr_replace($line, '       ', $matches[0][1], 7);
                $this->lines[$line_number] = $line;
            }
            elseif (preg_match('/Priority\s*:\s*[\d\w]+/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $length = \strlen($matches[0][0]);
                $padding = str_pad('', $length);
                $line = substr_replace($line, $padding, $matches[0][1], $length);
                $this->lines[$line_number] = $line;
            }
            elseif (preg_match('/Med\s*Rec\s*#/', $line)) {
                $line = str_replace('#', ':', $line);
                $this->lines[$line_number] = $line;
            }

            if (preg_match('/\bLocation\b/', $line) && !preg_match('/Location\s*:/', $line)) {
                $line = preg_replace('/\bLocation\b/', 'Location:', $line);
                $this->lines[$line_number] = $line;
            }
            elseif (preg_match('/Physician\s*Name/', $line) && !preg_match('/Physician\s*Name\s*:/', $line)) {
                $line = preg_replace('/Physician\s*Name/', 'Physician Name:', $line);
                $this->lines[$line_number] = $line;
            }
            elseif (preg_match('/\bNPI\b/', $line) && !preg_match('/NPI\s*:/', $line)) {
                $line = preg_replace('/\bNPI\b/', 'NPI:', $line);
                $this->lines[$line_number] = $line;
            }

        }
        $left = $right = [];
        foreach ($this->lines as $line_number => $line) {
            if (!isset($l_sep_line1) && preg_match('/Location\s*(:)?/', $line)) {
                $l_sep_line1 = $line_number;
            }
            elseif (!isset($l_sep_line2) && preg_match('/PATIENT\s*INFORMATION/', $line)) {
                $l_sep_line2 = $line_number;
            }
            elseif (preg_match('/DUPLICATE\s*REPORT/', $line)) {
                $l_sep_line3 = $line_number;
            }
            elseif (preg_match('/Clinical\s*Info:/', $line)) {
                $l_sep_line4 = $line_number;
            }
            elseif (preg_match('/PLEASE\s*BILL\s*TO/', $line)) {
                $l_sep_line5 = $line_number;
            }
            $left[] = substr($line, 0, $sep_pos);
        }
        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Control\s*#/', $line)) {
                $r_sep_line1 = $line_number;
            }
            elseif (preg_match('/ORDERING\s*PHYSICIAN\s*INFORMATION/', $line)) {
                $r_sep_line2 = $line_number;
            }
            elseif (preg_match('/ORDERING\s*PHYSICIAN\s*SIGNATURE/', $line)) {
                $r_sep_line3 = $line_number;
            }
            elseif (preg_match('/ICD\s*DX\s*CODES/', $line)) {
                $r_sep_line4 = $line_number;
            }
            elseif (preg_match('/Ordered\s*Date\s*and\s*Time:/', $line)) {
                $r_sep_line5 = $line_number;
            }
            elseif (preg_match('/Scheduled\s*Date/', $line)) {
                $r_sep_line6 = $line_number;
            }

            $line = preg_replace('/(NPI)(\s+)/', '$1:$2', $line);
            $right[] = substr($line, $sep_pos);
        }

        // Provider
        $provider = [];
        $lines = $this->trimArray(array_slice($left, $l_sep_line1, $l_sep_line2 - $l_sep_line1));

        $provider['name'] = trim($this->getKeyValue(array_shift($lines))[1]);
        $provider['phone'] = trim(array_pop($lines));
        $provider['address'] = str_replace('. ', ', ', trim(join(', ', $lines)));
        $normalized['provider'] = $provider;

        // Patient information
        $patient = [];
        $lines = $this->trimArray(array_slice($left, $l_sep_line2, $l_sep_line3 - $l_sep_line2));
        $patient = $this->parseMultiKeyValues($lines);
        $normalized['patient'] = $patient;

        // Exams
        $diagnoses = [];
        $lines = $this->trimArray(array_slice($right, $r_sep_line4 + 1, $r_sep_line5 - $r_sep_line4 - 1));
        foreach ($lines as $line) {
            $line = trim($line);
            $diag['code'] = preg_split('/\s{3,}/', $line)[0];
            $diag['coding_type'] = 'ICD 10';
            $diag['description'] = preg_split('/\s{3,}/', $line)[1];
            $diagnoses[] = $diag;
        }
        $normalized['diagnoses'] = $diagnoses;
        $exams = [];
        $lines = $this->trimArray(array_slice($left, $l_sep_line4 + 1, $l_sep_line5 - $l_sep_line4 - 1));
        foreach ($lines as $line) {
            $line = trim($line);
            $exam = preg_split('/\s{3,}/', $line);
            $normalized['exams'][] = $exam;
        }

        // Accession
        $accession = trim(preg_replace('/Control\s*#/', '', $right[$r_sep_line1]));
        $accession = ltrim(explode(' ', $accession, 2)[0], 'I|');
        $normalized['accession'] = $accession;

        // Physician information
        $physician = [];
        $lines = $this->trimArray(array_slice($right, $r_sep_line2 + 1, $r_sep_line3 - $r_sep_line2 - 1));
        $physician = $this->parseMultiKeyValues($lines);
        $physician['physician-name'] = str_replace('. ', ', ', $physician['physician-name']);
        $normalized['physician'] = $physician;

        // Ordered Date/Time
        $datetime = $this->getKeyValue($right[$r_sep_line5])[1] . ' ' . trim($right[$r_sep_line5+1]);
        $normalized['order-date'] = $datetime;

        // Scheduled Date
        $scheduledDate = $right[$r_sep_line6];
        $normalized['scheduled-date'] = preg_split('/\s{2,}/', trim($scheduledDate))[1];

        // Insurance information
        $ins_seps = [];
        $insurance = [];
        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/\bPatient\b/', $line) && preg_match('/\bInsurance\b/', $line) && preg_match('/Physician\s*Acct/', $line)) {
                $ins_seps[] = $line_number;
            }
        }
        $ins_seps[] = count($this->lines) - 1;
        for ($i = 0; $i < count($ins_seps) - 1; $i ++) {
            $lines = $this->trimArray(array_slice($this->lines, $ins_seps[$i] + 1, $ins_seps[$i+1] - $ins_seps[$i] - 1));
            if (!preg_match('/Policy\s*#:?/', trim($lines[0]))) {
                continue;
            }

            $ins = preg_split('/\s{5,}/', preg_replace('/Policy\s*#:?/', '', trim($lines[0])));
            $ins['relation'] = preg_split('/\s{5,}/', trim($lines[1]))[0];
            $tmp = preg_split('/\s{5,}/', trim($lines[3]));
            if (count($tmp) > 1) {
                $address1 = preg_split('/\s{5,}/', trim($lines[3]))[0];
            }
            $tmp = preg_split('/\s{5,}/', trim($lines[4]));
            if (count($tmp) > 1) {
                $address2 = preg_split('/\s{5,}/', trim($lines[4]))[0];
            }
            $ins['address'] = isset($address1, $address2) ? $address1 . ', ' . $address2 : '';
            $normalized['insurance'][] = $ins;
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['physician']['physician-name']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['provider']['address']);
        $data['referringDr']['npi'] = $normalized['physician']['npi'];
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['provider']['phone']);
        $data['referringDr']['sendingFacility'] = $normalized['provider']['name'];

        $data['order']['accession'] = $normalized['accession'];
        $data['order']['DateOfService'] = $normalized['order-date'] ? Carbon::parse($normalized['order-date'])->format('YmdHis') : '';
        $data['order']['ScheduledDate'] = $normalized['scheduled-date'] ? Carbon::parse($normalized['scheduled-date'])->format('YmdHis') : '';
        $data['order']['PID'] = $normalized['patient']['patient-id'];

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']);
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex']);
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);

        $data['insuranceList'] = [];
        foreach ($normalized['insurance'] as $ins) {
            $insurance = [
                'name'      => $ins[1],
                'insurance-address' => $ins['address'],
                'insured'   => $data['patient'],
                'policy'    => $ins[2]
            ];
            $insurance['insured']['relation'] = $ins['relation'];
            $data['insuranceList'][] = $insurance;
        }

        $data['exams'] = [];
        foreach ($normalized['exams'] as $exam) {
            $ex = [
                'procedure_code'    => $exam[0],
                'study'             => $exam[1],
            ];
            $ex['MultiDiagnosisList'] = $normalized['diagnoses'];
            $data['exams'][] = $ex;
        }

        if ($data['order']['ScheduledDate']) {
            $data['exams'][0]['comment'] = 'Scheduled Date:  ' . $data['order']['ScheduledDate'];
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
