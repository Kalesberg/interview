<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * Aprima Order Parser
 * format: Aprima
 * type: Order
 */
class Aprima
{
    use HelperTrait;
    protected $format = 'Aprima';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches Aprima format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Visit\s*Date(:|;)/', $content) &&
            preg_match('/Vital\s*Signs(:|;)/', $content) &&
               preg_match('/Progress\s*Notes(:|;)/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Patient(:|;)/i', $line) && !isset($sep_line1)) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/Date\s*of\s*Birth(:|;)/i', $line) && !isset($sep_line2)) {
                $sep_line2 = $line_number;
            }
            elseif (preg_match('/Visit\s*Date(:|;)/', $line, $matches, PREG_OFFSET_CAPTURE) && !isset($sep_line3)) {
                $sep_line3 = $line_number;
                $sep_pos3 = $matches[0][1];
            }
            elseif (preg_match('/Plan(:|;)/', $line) && !isset($sep_line4)) {
                $sep_line4 = $line_number;
            }
        }

        // Patient information
        $lines = \array_slice($this->lines, $sep_line1, $sep_line2 - $sep_line1 + 1);
        $normalized['patient'] = $this->parseKeyValues(implode("\n", $lines));

        // Doctor information
        $lines = [];
        for ($n = $sep_line2 + 1; $n < $sep_line3; $n++) {
            $line = trim($this->lines[$n]);
            if (!$line) {
                continue;
            }
            if (empty($lines)) {
                $pos = strrpos($line, ' ');
                $name = substr_replace($line, ',', $pos, 0);
                $lines['name'] = $name;
            }
            elseif (preg_match('/^[()\-0-9]+$/', $line)) {
                $lines['phone'] = $line;
            }
            else {
                $lines['address'] = isset($lines['address']) ? $lines['address'].', '.$line : $line;
            }
        }
        $normalized['doctor'] = $lines;

        // Other information
        $lines = [];
        for ($n = $sep_line3; $n < $sep_line4; $n++) {
            $line = $this->lines[$n];
            $str = trim((string) substr($line, $sep_pos3 - 2));
            if (!$str) {
                continue;
            }
            $lines[] = $str;
        }
        $normalized['other'] = $this->parseKeyValues(implode("\n", $lines));

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor']['name']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone']);

        $data['order']['DateOfService'] = $normalized['other']['visit-date'] ? Carbon::parse($normalized['other']['visit-date'])->format('YmdHis') : '';

        $data['patient'] = $this->parseName($normalized['patient']['patient']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']) ?? [];
        $data['patient']['DOB'] = $normalized['patient']['date-of-birth'] ? Carbon::parse($normalized['patient']['date-of-birth'])->format('YmdHis') : '';

        $proc_code = explode(' ', trim($normalized['other']['assessments']))[0];
        $study = explode(' ', trim($normalized['other']['assessments']))[1];
        $code = explode(' ', trim($normalized['other']['services-ordered']))[0];
        $description = explode(' ', trim($normalized['other']['services-ordered']))[1];
        $data['exams'][0] = [
            'procedure_code'     => $proc_code,
            'study'              => $study,
            'MultiDiagnosisList' => [
                [
                    'code'          => $code,
                    'description'   => $description
                ]
            ]
        ];

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
