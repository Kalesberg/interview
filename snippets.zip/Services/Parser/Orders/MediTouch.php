<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * MediTouch Order Parser
 * format: MediTouch
 * type: Order
 */
class MediTouch
{
    use HelperTrait;
    protected $format = 'MediTouch';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return (bool) preg_match('/MediTouch/i', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];

        $seps = [
            'Order Date and Time',
            ['Referred to Facility Location', 'Referred To Physician Information'],
            'Patient Information',
            'Test/Consult Requested',
            'Patient Diagnosis Requested',
            ['Ordering Practice Location', 'Ordering Physician Information'],
            'Comments',
            'Guarantor',
            ['Primary Insurance', 'Secondary Insurance'],
            ['Primary Insurance Policy Holder', 'Secondary Insurance Policy Holder']
        ];

        $sep_lines = $sep_middles = [];
        foreach ($seps as $sep) {
            if (\is_array($sep)) {
                $sep = $sep[1];
            }
            foreach ($this->lines as $line_number => $line) {
                $pos = stripos($line, $sep);
                if ($pos === false) {
                    continue;
                }
                $sep_lines[] = $line_number;
                $sep_middles[] = $pos;
                break;
            }
        }
        $blocks = [];
        foreach ($sep_lines as $line_number) {
            $b = [];
            for ($n = $line_number; $n < count($this->lines); $n++) {
                if ($n !== $line_number && \in_array($n, $sep_lines, true)) {
                    $blocks[] = $b;
                    continue 2;
                }
                $line = $this->lines[$n];
                if (trim($line) != '') {
                    $b[] = $line;
                }
            }
            $blocks[] = $b;
        }

        foreach ($seps as $idx => $sep) {
            $block = $blocks[$idx];
            // If there is no block (when line_number equals to last line number of content), give empty array
            if ($sep_lines[$idx] === count($this->lines)) {
                if (\is_array($sep)) {
                    $key1 = $this->slugify($sep[0]);
                    $key2 = $this->slugify($sep[1]);
                    $normalized[$key1] = $normalized[$key2] = [];
                }
                else {
                    $key = $this->slugify($sep);
                    $normalized[$key] = [];
                }
                continue;
            }
            // For Order date and time
            if ($sep === 'Order Date and Time') {
                $line = $block[0];
                $keyval = $this->getKeyValue(substr($line, stripos($line, $sep)));
                $normalized[$keyval[0]] = $keyval[1];
                continue;
            }
            // For comments, only one column
            if ($sep === 'Comments') {
                $lines = \array_slice($block, 1);
                $normalized['comments'] = $this->parseKeyValues(implode("\n", $lines));
                continue;
            }

            $lines = \array_slice($block, 1);
            $lstr = $rstr = '';
            if (\is_array($sep)) {
                $pos = $sep_middles[$idx];
                foreach ($lines as $line) {
                    $lstr .= substr($line, 0, $pos) . "\n";
                    $rstr .= substr($line, $pos) . "\n";
                }
                $left = $this->parseKeyValues($lstr);
                $right = $this->parseKeyValues($rstr);
                $key1 = $this->slugify($sep[0]);
                $key2 = $this->slugify($sep[1]);
                $normalized[$key1] = $left;
                $normalized[$key2] = $right;
            }
            else {
                foreach ($lines as $line) {
                    $parts = preg_split('/\s{5,}/', trim($line), 2);
                    $lstr .= $parts[0] . "\n";
                    $rstr .= ($parts[1] ?? '') . "\n";
                }
                $params = [
                    'content' => $lstr . $rstr
                ];
                // For these two blocks, set period as a delimiter
                if ($sep === 'Test/Consult Requested' || $sep === 'Patient Diagnosis Requested') {
                    $params['delimiter'] = '/\./';
                }
                $key = $this->slugify($sep);
                $normalized[$key] = $this->parseKeyValues($params);
            }
        }

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['order']['DateOfService'] = $normalized['order-date-and-time'] ? Carbon::parse($normalized['order-date-and-time'])->format('YmdHis') : '';
        $data['order']['sendingApplication'] = $normalized['referred-to-facility-location']['name'];
        $data['order']['PID'] = $normalized['patient-information']['chart-id'];

        $data['referringDr'] = $this->parseName($normalized['ordering-physician-information']['name']);
        $data['referringDr']['npi'] = $normalized['ordering-physician-information']['npi'];
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['ordering-practice-location']['phone']);
        $data['referringDr']['address']['address1'] = $normalized['ordering-practice-location']['address-1'];
        $data['referringDr']['address']['address2'] = $normalized['ordering-practice-location']['address-2'];
        preg_match('/^(.*) ([A-Z]{2}) ([A-Za-z0-9-]+)$/', $normalized['ordering-practice-location']['city-state-zip'], $parts);

        $data['referringDr']['address']['city'] = $parts[1];
        $data['referringDr']['address']['state'] = $parts[2];
        $data['referringDr']['address']['country'] = 'USA';
        $data['referringDr']['address']['zip'] = $parts[3];
        $data['referringDr']['sendingFacility'] = $normalized['ordering-practice-location']['name'];

        $data['patient'] = $this->parseName(str_replace(',', ' ', $normalized['patient-information']['name']), true);
        $data['patient']['address']['address1'] = $normalized['patient-information']['address-1'];
        $data['patient']['address']['address2'] = $normalized['patient-information']['address-2'];

        preg_match('/^(.*) ([A-Z]{2}) ([A-Za-z0-9-]+)$/', $normalized['patient-information']['city-state-zip'], $parts);
        $data['patient']['address']['city'] = $parts[1];
        $data['patient']['address']['state'] = $parts[2];
        $data['patient']['address']['country'] = 'USA';
        $data['patient']['address']['zip'] = $parts[3];
        $data['patient']['code'] = $normalized['patient-information']['auth-id'];
        $data['patient']['DOB'] = $normalized['patient-information']['dob'] ? Carbon::parse($normalized['patient-information']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient-information']['gender']);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient-information']['phone']);

        $data['insuranceList'] = [
            [
                'name'              => $normalized['primary-insurance']['name'],
                'insurance-address' => $normalized['primary-insurance']['address-1'] . ' ' . $normalized['primary-insurance']['address-2'] . ' ' . $normalized['primary-insurance']['city-state-zip'],
                'policy'            => $normalized['primary-insurance']['insured-id'],
                'insured'           => [
                    'name'          => $normalized['primary-insurance-policy-holder']['name'],
                    'address'       => $normalized['primary-insurance-policy-holder']['address-1'],
                    'relation'      => $normalized['primary-insurance-policy-holder']['relation-to-pt']
                ]
            ],
            [
                'name'              => $normalized['secondary-insurance']['name'],
                'insurance-address' => $normalized['secondary-insurance']['address-1'] . ' ' . $normalized['primary-insurance']['address-2'] . ' ' . $normalized['primary-insurance']['city-state-zip'],
                'policy'            => $normalized['primary-insurance']['insured-id'],
                'insured'           => [
                    'name'          => $normalized['secondary-insurance-policy-holder']['name'],
                    'address'       => $normalized['secondary-insurance-policy-holder']['address-1'],
                    'relation'      => $normalized['secondary-insurance-policy-holder']['relation-to-pt']
                ]
            ]
        ];

        $data['exams'] = [];
        $provider = $this->parseName($normalized['ordering-physician-information']['name']);
        $provider['npi'] = $data['referringDr']['npi'];
        foreach ($normalized['test-consult-requested'] as $idx => $case) {
            if (trim($case) == '') {
                continue;
            }
            $exam['procedure_code'] = explode(' ', $case, 2)[0];
            $exam['approving_provider'] = $provider;
            $exam['study'] = explode(' ', $case, 2)[1];
            $exam['MultiDiagnosisList'] = [];
            foreach ($normalized['patient-diagnosis-requested'] as $diagnosis) {
                if (trim($diagnosis) == '') {
                    continue;
                }
                $code = trim(explode(' ', $diagnosis, 2)[0]);
                $diag = [];
                $diag['code'] = $code;
                $diag['coding_type'] = 'ICD10';
                $diag['description'] = '';
                $exam['MultiDiagnosisList'][] = $diag;
            }
            $data['exams'][] = $exam;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
