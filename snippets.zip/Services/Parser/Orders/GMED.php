<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * GMED Order Parser
 * format: GMED
 * type: Order
 */
class GMED
{
    use HelperTrait;
    protected $format = 'GMED';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches Aprima format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/Present\s*Illness:/', $content) &&
               preg_match_all('/V?ital\s*Signs:/', $content) &&
               preg_match_all('/A?ssessment:/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (!isset($sep_line0) && preg_match('/^D?ate:/', $line)) {
                $sep_line0 = $line_number;
            }
            elseif (!isset($sep_line1) && preg_match('/^D?iagnostic\s*Studies/', trim($line))) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/P?rimary\s*Insurance\s*:/', $line)) {
                $sep_line1_1 = $line_number;
            }
            elseif (preg_match('/D?iagnostic\s*Studies\s*:/', $line)) {
                $sep_line1_2 = $line_number;
            }
            elseif (preg_match('/D?iagnoses:/', $line)) {
                $sep_line2 = $line_number;
            }
        }

        if (!isset($sep_line1)) {
            $sep_line1 = $sep_line0 - 2;
            $sep_line2 = count($this->lines) - 1;
        }

        // Doctor information
        $normalized['doctor'] = [];
        $lines = array_slice($this->lines, 1, $sep_line0 - 1);
        if (!$this->emptyArray($lines)) {
            $eof_address = 0;
            for ($i = 0; $i < count($lines); $i ++) {
                if (preg_match('/^Phone:/', trim($lines[$i]))) {
                    $eof_address = $i;
                }
            }
            $lines1 = array_slice($lines, 0, $eof_address - 3);
            $lines2 = $this->trimArray(array_slice($lines, $eof_address - 2, 2));
            preg_match('/Phone:\s*(.*)\s*Fax:\s*(.*)/', trim($lines[$eof_address]), $matches);

            // Sending facility
            $facility = array_reduce($lines1, function($carry, $line) {
                return trim($carry . ' ' . trim(substr($line, 0, 50)));
            }, '');
            $address = join(', ', $lines2);

            $normalized['doctor']['facility'] = $facility;
            $normalized['doctor']['address'] = $address;

            $normalized['doctor']['phone1'] = $matches[1];
            $normalized['doctor']['phone2'] = $matches[2];
        }

        // Extra information
        $lines = array_slice($this->lines, $sep_line1 + 2, $sep_line2 - $sep_line1 - 2);
        $regex = '/\b(?:(?!\s{3,})[^:;])+\s{0,3}(?::|;)(?:\s*(?:(?!(?:(?!\s{4,}).)+\s*[:;]).)+)?/';
        $lines['regex'] = $regex;
        $info = $this->parseMultiKeyValues($lines);
        $date = $this->getValue(['search' => 'D?ate', 'lines' => [$this->lines[$sep_line1+1]]]);
        $info['order-date'] = $date;

        foreach ($info as $key => $value) {
            if (preg_match('/p?atient-name/', (string) $key)) {
                $normalized['patient-name'] = $value;
            }
            elseif (preg_match('/a?ccount/', (string) $key)) {
                $normalized['account'] = $value;
            }
            elseif (preg_match('/age/i', (string) $key)) {
                $normalized['dob'] = !empty($normalized['dob']) ? $normalized['dob'] : explode(' ', $value)[0];
            }
            elseif (preg_match('/a?ddress/', (string) $key)) {
                $normalized['patient-address'] = $value;
            }
            elseif (preg_match('/p?rovider/', (string) $key)) {
                $normalized['doctor-name'] = $value;
            }
            elseif (preg_match('/p?rimary-insurance/', (string) $key)) {
                $normalized['insurance1'] = $value;
            }
            elseif (preg_match('/a?dditional-insurance/', (string) $key)) {
                $normalized['insurance2'] = $value;
            }
            elseif (preg_match('/d?iagnostic-studies/', (string) $key)) {
                $tmp = explode(',', $value, 2);
                $normalized['diag']['study'] = ($tmp[0] ?? '');
                $normalized['diag']['comment'] = ($tmp[1] ?? '');
            }
            else {
                $normalized[$key] = $value;
            }
        }

        // Insurance information
        $lines0 = [];
        if (isset($sep_line1_1, $sep_line1_2)) {
            $lines0 = array_slice($this->lines, $sep_line1_1, $sep_line1_2 - $sep_line1_1);
        }
        $lines = ['', ''];
        $index = 0;
        foreach ($lines0 as $line) {
            if (preg_match('/A?dditional\s*Insurance/', $line)) {
                $index = 1;
            }
            $lines[$index] .= trim($line);
        }
        $insList = $this->parseKeyValues(join("\n", $lines));
        foreach ($insList as $key => $ins) {
            if (preg_match('/p?rimary-insurance/', (string) $key)) {
                $insList['insurance1'] = $ins;
            }
            elseif (preg_match('/a?dditional-insurance/', (string) $key)) {
                $insList['insurance2'] = $ins;
            }
            unset($insList[$key]);
        }
        if (isset($insList['insurance1']) && !empty($insList['insurance1'])) {
            preg_match('/^([^,]+)/', $insList['insurance1'], $matches);
            $normalized['primary-insurance'][0] = $matches[1] ?? '';
            preg_match('/Policy\s*Number\s*:\s*([^,]+)/', $insList['insurance1'], $matches);
            $normalized['primary-insurance'][1] = $matches[1] ?? '';
            preg_match('/Group\s*Number\s*:\s*([^,]+)/', $insList['insurance1'], $matches);
            $normalized['primary-insurance'][2] = $matches[1] ?? '';
            preg_match('/Patient\s*Relationship\s*:\s*([^,]+)/', $insList['insurance1'], $matches);
            $normalized['primary-insurance'][3] = $matches[1] ?? '';
        }
        if (isset($insList['insurance2']) && !empty($insList['insurance2'])) {
            preg_match('/^([^,]+)/', $insList['insurance2'], $matches);
            $normalized['additional-insurance'][0] = $matches[1] ?? '';
            preg_match('/Policy\s*Number\s*:\s*([^,]+)/', $insList['insurance2'], $matches);
            $normalized['additional-insurance'][1] = $matches[1] ?? '';
            preg_match('/Group\s*Number\s*:\s*([^,]+)/', $insList['insurance2'], $matches);
            $normalized['additional-insurance'][2] = $matches[1] ?? '';
            preg_match('/Patient\s*Relationship\s*:\s*([^,]+)/', $insList['insurance2'], $matches);
            $normalized['additional-insurance'][3] = $matches[1] ?? '';
        }

        // Exam diagnoses information
        $exams = [];
        for ($n = $sep_line2; $n < count($this->lines); $n ++) {
            if ($n == $sep_line2) {
                $line = preg_split('/\s{5,}/', trim($this->lines[$n]))[1];
            }
            else {
                $line = trim($this->lines[$n]);
            }
            if (empty($line) || !strpos($line, ':')) {
                break;
            }

            $desc = trim(explode(':', $line)[0]);
            $codes = explode('-', trim(explode(':', $line)[1]));
            $exams[] = [$desc, $codes];
        }
        $normalized['exams'] = $exams;

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor-name']);
        $pattern = '/^([^,]+),(?:\s*([^,]+),)?(?:\s*([^,]+),)?\s*([A-Za-z]+)(?:[,\.]?\s*([A-Za-z0-9\-]+))?/';
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address'], '', $pattern);
        $data['referringDr']['address']['state'] = $this->abbreviateUSStateName($data['referringDr']['address']['state']);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone1']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor']['phone2']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor']['facility'];

        $data['order']['DateOfService'] = $normalized['order-date'] ? Carbon::parse($normalized['order-date'])->format('YmdHis') : '';
        $data['order']['PID'] = $normalized['account'];

        $data['patient'] = $this->parseName($normalized['patient-name']);
        $data['patient']['DOB'] = $normalized['dob'] ? Carbon::parse($normalized['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['gender'][0]);
        $data['patient']['phone1'] = $this->parsePhone($normalized['phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient-address']);
        if (empty($data['patient']['address']) && !empty($normalized['patient-address'])) {
            $data['patient']['address']['address1'] = explode(',', $normalized['patient-address'])[0];
            $data['patient']['address']['state'] = explode(',', $normalized['patient-address'])[1];
        }

        $data['insuranceList'] = [];
        if (isset($normalized['primary-insurance'])) {
            $data['insuranceList'][] = [
                'name'          => $normalized['primary-insurance'][0],
                'insured'       => $data['patient'],
                'policy'        => $normalized['primary-insurance'][1],
                'subscriber'    => $normalized['primary-insurance'][2]
            ];
            $data['insuranceList'][0]['insured']['relation'] = $normalized['primary-insurance'][3];
        }
        if (isset($normalized['additional-insurance'])) {
            $data['insuranceList'][] = [
                'name'          => $normalized['additional-insurance'][0],
                'insured'       => $data['patient'],
                'policy'        => $normalized['additional-insurance'][1],
                'subscriber'    => $normalized['additional-insurance'][2]
            ];
            $data['insuranceList'][1]['insured']['relation'] = $normalized['additional-insurance'][3];
        }

        $data['exams'] = [];
        if (isset($normalized['diag'])) {
            $data['exams'][0] = [
                'study'     => $normalized['diag']['study'],
                'comment'   => $normalized['diag']['comment']
            ];
            $diagnoses = [];
            foreach ($normalized['exams'] as $exam) {
                foreach ($exam[1] as $code) {
                    $diagnoses[] = [
                        'code'          => trim($code),
                        'coding_type'   => 'ICD',
                        'description'   => $exam[0]
                    ];
                }
            }
            $data['exams'][0]['MultiDiagnosisList'] = $diagnoses;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
