<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * Allscripts Order Parser
 * format: Allscripts
 * type: Order
 */
class Allscripts
{
    use HelperTrait;
    protected $format = 'Allscripts';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches Allscripts format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Originated From/i', $content) &&
            preg_match('/Performing Facility/i', $content) &&
            preg_match('/Lab Requisition/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];
        $startLine2 = 0;
        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Patient:/i', $line)) {
                $startLine1 = $line_number;
            }
            elseif (preg_match('/-\s*\[[^\[\]]+\]\s*-/i', $line)) {
                $startLine2 = $line_number;
                if (preg_match('/^\[[\d\w]+\]$/', trim($this->lines[$line_number+1]))) {
                    $line .= '    ' . trim($this->lines[$line_number+1]);
                    $this->lines[$line_number] = $line;
                    $this->lines[$line_number+1] = '';
                }
            }
            elseif (preg_match('/MRA Brain/i', $line)) {
                $startLine3 = $line_number;
                if (preg_match('/^\[[\d\w]+\]$/', trim($this->lines[$line_number+1]))) {
                    $line .= '    ' . trim($this->lines[$line_number+1]);
                    $this->lines[$line_number] = $line;
                    $this->lines[$line_number+1] = '';
                }
            }
        }

        /* Doctor */
        $left = $right = [];
        for ($n = 0; $n < $startLine1; $n ++) {
            $line = trim($this->lines[$n]);
            if(empty($line) || preg_match('/Originated/', $line) || preg_match('/Performing/', $line)) continue;

            $left[] = preg_split('/\s{5,}/', $line)[0];
            $right[] = (preg_split('/\s{5,}/', $line)[1]??'');
        }
        foreach ($left as $idx => $val1) {
            $val2 = $right[$idx];
            if (preg_match('/Lab Requisition/i', $val2)) {
                $tmp = true;
                $normalized['doctor']['order'] = trim(explode(':', $val2)[1]);
            }
            if(!isset($tmp)) {
                $normalized['doctor']['from'] = $normalized['doctor']['from'] ?? $val1;
                $normalized['doctor']['facility'] = $normalized['doctor']['facility'] ?? $val2;
            }
            elseif (isset($tmp) && !preg_match('/Account\s+#/i', $val1)) {
                $info = $info ?? '';
                $info .= $val1 . ',';
            }
            elseif(preg_match('/Account\s+#/i', $val1)) {
                $normalized['doctor']['account'] = trim(explode(':', $val1)[1]);
            }
        }
        $info = substr($info, 0, strlen($info) - 1);
        $normalized['doctor']['address'] = substr($info, 0, strrpos($info, ','));
        $normalized['doctor']['phone'] = substr(strrchr($info, ','),1);

        /* Patient */
        for ($n = $startLine1; $n < $startLine2; $n ++) {
            $line = $this->lines[$n];
            if (preg_match('/Name\s*of\s*Insured/i', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $offset = $matches[0][1];
                break;
            }
        }
        $lstr = $rstr = '';
        for ($n = $startLine1; $n < $startLine2; $n ++) {
            $line = $this->lines[$n];
            if(empty(trim($line))) continue;
            $lstr .= substr($line, 0, $offset - 1) . "\n";
            $rstr .= substr($line, $offset) . "\n";
        }

        $rstr = preg_replace("/Sex:/i", "\nSex:", $rstr);
        $rstr = preg_replace("/Bill\s*Type\s+/", "Bill Type:", $rstr);
        $normalized['patient'][] = $this->parseKeyValues($lstr);
        $normalized['patient'][] = $this->parseKeyValues($rstr);

        // Tweak few things..

        $patient = $normalized['patient'][0]['patient'];
        $normalized['patient'][0]['name'] = substr($patient, 0, strpos($patient, ','));
        $normalized['patient'][0]['address'] = substr(strstr($patient, ','), 1);
        unset($normalized['patient'][0]['patient']);

        $parts = explode(',', $normalized['patient'][1]['insurance'], 2);
        $normalized['patient'][1]['insurance'] = $parts[0];
        $normalized['patient'][1]['insurance-address'] = $parts[1];

        $guarantor = $normalized['patient'][1]['guarantor'];
        $pos1 = strpos($guarantor, '[');
        $pos2 = strpos($guarantor, ']') + 1;
        $pos3 = strrpos($guarantor, ',');
        $sub1 = trim(preg_replace('/[\W]+/', ' ', substr($guarantor, 0, $pos1)));
        $sub2 = trim(substr($guarantor, $pos1, $pos2 - $pos1), '[]');
        $sub3 = trim(substr($guarantor, $pos2, $pos3 - $pos2), ' ,');
        $sub3 = str_replace('|', ',', substr($sub3, 1));
        $sub4 = trim(substr($guarantor, $pos3), ' ,');

        $normalized['patient'][1]['guarantor'] = $this->parseName($sub1, true);
        $normalized['patient'][1]['guarantor']['relationship'] = $sub2;
        $normalized['patient'][1]['guarantor']['address'] = $this->parseAddress($sub3);
        $normalized['patient'][1]['guarantor']['phone'] = $this->parsePhone($sub4);

        /* Exam */
        $normalized['exams'] = [];
        if (!isset($startLine3))
            $startLine3 = count($this->lines) - 1;
        $fields = ['Date Ordered', 'Approving Provider', 'CPT4 Code', 'Patient Instructions', 'To Be Done Date', 'Priority', 'Status', 'Performing Location Comments', 'Encounter Date', 'Problems'];
        $lines = array_slice($this->lines, $startLine2, $startLine3 - $startLine2);
        $line = trim($this->lines[$startLine2]);
        if (preg_match_all('/\[([^\]]+)\]/', $line, $matches)) {
            $exam = [];
            $exam['study'] = trim($matches[1][0]);
            $exam['procedure_code'] = trim($matches[1][1]);
            $exam['order'] = $this->getValue(['Order\s*#', 'lines' => [$line], 'sticky' => false]);
            foreach ($fields as $f) {
                $k = $this->slugify($f);
                $exam[$k] = $this->getValueBelow(['search' => $f, 'lines' => $lines]);
            }
            $normalized['exams'][] = $exam;
        }
        $lines = array_slice($this->lines, $startLine3);
        $line = trim($this->lines[$startLine3]);
        if (preg_match_all('/\[([^\]]+)\]/', $line, $matches)) {
            $exam = [];
            $exam['study'] = trim($matches[1][0]);
            $exam['procedure_code'] = trim($matches[1][1]);
            $exam['order'] = $this->getValue(['Order\s*#', 'lines' => [$line], 'sticky' => false]);
            foreach ($fields as $f) {
                $k = $this->slugify($f);
                $exam[$k] = $this->getValueBelow(['search' => $f, 'lines' => $lines]);
            }
            $normalized['exams'][] = $exam;
        }

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['order'] = [
            'accession'             => $normalized['doctor']['order'],
            'sendingApplication'    => 'AllScripts',
            'DateOfService'         => $normalized['exams'][0]['date-ordered'] ? Carbon::parse($normalized['exams'][0]['date-ordered'])->format('YmdHis') : '',
            'PID'                   => $normalized['patient'][1]['patient-id']
        ];

        $doctor = trim(preg_split('/[^\w\s]/', $normalized['exams'][0]['approving-provider'], 2)[0]);
        $data['referringDr'] = $this->parseName($doctor);
        $data['referringDr']['npi'] = $normalized['patient'][0]['npi'];
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor']['facility'];

        $data['patient'] = $this->parseName($normalized['patient'][0]['name']);
        $data['patient']['DOB'] = $normalized['patient'][1]['dob'] ? Carbon::parse(str_replace('I', '1', $normalized['patient'][1]['dob']))->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient'][1]['sex']);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient'][0]['home']);
        $data['patient']['address'] = $this->parseAddress(trim($normalized['patient'][0]['address']));

        $insured = $normalized['patient'][1]['name-of-insured'];
        preg_match('/([^\[\]]+)(?:\[(.*)\])?/', $insured, $matches);
        $name = $matches[1];
        $relation = $matches[2] ?? '';
        $insured = $this->parseName($name);
        $insured['relation'] = $relation;
        $data['insuranceList'] = [
            [
                'name'      => $normalized['patient'][1]['insurance'],
                'insurance-address' => $normalized['patient'][1]['insurance-address'],
                'insured'   => $insured,
                'policy'   => $normalized['patient'][1]['policy-number'],
                'subscriber'    => $normalized['patient'][1]['group-number']
            ]
        ];

        $data['guarantor'] = $normalized['patient'][1]['guarantor'];

        $data['exams'] = [];
        foreach ($normalized['exams'] as $exam) {
            if (empty($exam['procedure_code'])) continue;

            $doctor = $this->parseName(trim(preg_split('/[^\w\s]/', $exam['approving-provider'], 2)[0]));
            preg_match('/NPI\s*:([^\]]+)/', $exam['approving-provider'], $matches);
            $npi = trim($matches[1]);
            preg_match_all('/\(([^()]+)\)/', $exam['problems'], $matches);
            $ex = [
                'procedure_code'    => $exam['procedure_code'],
                'study'             => $exam['study'],
                'placer_order_number' => $exam['order'],
                'priority' => $exam['priority'],
                'DateOfEncounter' => $exam['encounter-date'] ? Carbon::parse($exam['encounter-date'])->format('YmdHis') : '',
                'status' => $exam['status'],
                'approving_provider' => [
                    'firstname' => $doctor['firstname'],
                    'middlename' => $doctor['middlename'],
                    'lastname' => $doctor['lastname'],
                    'title' => $doctor['title'],
                    'npi' => $npi,
                ],
                'outside_reason_code'   => $exam['cpt4-code'],
                'comment'           => $exam['patient-instructions'],
                'stat'              => '',
                'MultiDiagnosisList'    => [[
                    'code'          => $matches[1][1],
                    'description'   => $exam['problems']
                ]]
            ];
            $data['exams'][] = $ex;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
