<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * GreenwayIntergy V2 for SDI Order Parser
 * format: GreenwayIntergy_v2
 * type: Order
 */
class GreenwayIntergy_v2
{
    use HelperTrait;
    protected $format = 'GreenwayIntergy_v2';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches GreenwayIntergyv2 format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Arizona\sPulmonary\sSpecialists,/', $content)
            && preg_match('/\s*ORDER\sSHEET/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_doctor_start = 1;
        $line_doctor_end = 0;

        $line_order_start = 0;
        $line_order_end = 0;

        $line_procedure_start = 0;
        $line_procedure_end = 0;

        $line_scheduling_start = 0;
        $line_scheduling_end = count($this->lines) - 1;

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/\s*ORDER\sSHEET/i', $line)) {
                $line_doctor_end = $line_number;
                $line_order_start = $line_number + 1;
            }

            if (preg_match('/\s*Procedure\sOrders/i', $line)) {
                $line_order_end = $line_number;
                $line_procedure_start = $line_number + 1;
            }

            if (preg_match('/\s*Scheduling\sChecklist/', $line)) {
                $line_procedure_end = $line_number;
                $line_scheduling_start = $line_number + 1;
            }
        }

        $doctor = array_slice($this->lines, $line_doctor_start, ($line_doctor_end - $line_doctor_start));
        $doctor = $this->trimArray($doctor);

        $order = array_slice($this->lines, $line_order_start, ($line_order_end - $line_order_start));
        $order = $this->trimArray($order);

        $procedure = array_slice($this->lines, $line_procedure_start, ($line_procedure_end - $line_procedure_start));
        $procedure = $this->trimArray($procedure);

        $scheduling_lines_count = $line_scheduling_end - $line_scheduling_start;
        $scheduling = array_slice($this->lines, $line_scheduling_start, $scheduling_lines_count);
        $scheduling = $this->trimArray($scheduling);

        $doctor_address = $doctor[1] ?? '';
        $doctor_address .= ', ' . ($doctor[2] ?? '');

        $normalized['doctor_name'] = $doctor[0] ?? '';
        $normalized['doctor_address'] = $doctor_address;

        $doctor_key_values = [];

        foreach ($doctor as $line) {
            if (preg_match('/^.*:\s{1,4}.*$/', $line)) {
                $doctor_key_values[] = $line;
            }
        }

        if (count($doctor_key_values) > 0) {
            $values = $this->parseKeyValues(implode(PHP_EOL, $doctor_key_values));

            $normalized['doctor_phone'] = $values['phone'] ?? '';
            $normalized['doctor_fax'] = $values['fax'] ?? '';
        }

        $order_values = $this->parseKeyValues(implode(PHP_EOL, $order));

        $normalized['order_date'] = $order_values['date'] ?? '';
        $normalized['patient_name'] = $order_values['patient-name'] ?? '';
        $normalized['patient_dob'] = $order_values['dob'] ?? '';

        $procedure_array = [];

        foreach ($procedure as $line_number => $line) {
            // Order & Order Due
            if (preg_match('/^Order:.*Order\sDue:.*/', $line)) {
                $split = preg_split('/\s{10,}/', $line);

                foreach ($split as $split_proc) {
                    $procedure_array[] = $split_proc;
                }
            // Order Instructions
            } elseif (preg_match('/Order\sInstructions:/', $line)) {
                $str = trim((string) $procedure[$line_number + 1]);
                $str = preg_replace('/^[A-Za-z0-9]{1,4}\s/', '', $str);

                $procedure_array[] = 'Order Instructions: ' . $str;
            // Diagnosis/ICD-9
            } elseif (preg_match('/Diagnosis\/ICD\-9/', $line)) {
                $procedure_array[] = $line;
            // NPI
            } elseif (preg_match('/NPI:/', $line)) {
                $procedure_array[] = $line;
            }
        }

        $procedure_values = $this->parseKeyValues(implode(PHP_EOL, $procedure_array));
        $normalized['doctor_npi'] = $procedure_values['npi'];
        $normalized['procedure_order'] = $procedure_values['order'];
        $normalized['procedure_comment'] = $procedure_values['order-instructions'];

        if (isset($procedure_values['diagnosis-icd-9'])) {
            $split = preg_split('/\s/', $procedure_values['diagnosis-icd-9'], 2);

            $normalized['diagnosis_code'] = $split[0] ?? '';
            $normalized['diagnosis_description'] = $split[1] ?? '';
        }

        foreach ($scheduling as $line) {
            if (preg_match('/Facility:/', $line)) {
                $values = $this->parseKeyValues($line);
                $normalized['doctor_facility'] = $values['facility'] ?? '';
            }

            if (preg_match('/Insurance\sCo:.*Insurance\sID:.*/', $line)) {
                $values = $this->parseMultiKeyValues([$line]);

                $normalized['insurance_name'] = $values['insurance-co'] ?? '';
                $normalized['insurance_policy'] = $values['insurance-id'] ?? '';
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = 'Order';
        $data['meta']['document_format'] = $this->format;

        $doctor_name = $this->fixDoctorTitle($normalized['doctor_name']);
        $doctor_address = $this->fixStateInAddress($normalized['doctor_address']);

        $patient = $this->parseName($normalized['patient_name']);

        if (!empty($normalized['patient_dob'])) {
            $dob = Carbon::createFromFormat('m/d/Y', $normalized['patient_dob']);
            $patient_dob = $dob->format('Ymd') . '000000';
        }

        if (!empty($normalized['order_date'])) {
            $dos = Carbon::createFromFormat('M j, Y', $normalized['order_date']);
            $data['order']['DateOfService'] = $dos->format('Ymd') . '000000';
        }

        $doctor = $this->parseName($doctor_name);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patient_dob ?? '';

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor_phone']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor_fax']);
        $data['referringDr']['address'] = $this->parseAddress($doctor_address);
        $data['referringDr']['sendingFacility'] = $normalized['doctor_facility'];
        $data['referringDr']['npi'] = $normalized['doctor_npi'];

        $data['exams'][0]['study'] = $normalized['procedure_order'];
        $data['exams'][0]['comment'] = $normalized['procedure_comment'];

        $data['exams'][0]['MultiDiagnosisList'][0]['code'] = $normalized['diagnosis_code'];
        $data['exams'][0]['MultiDiagnosisList'][0]['description'] = $normalized['diagnosis_description'];
        $data['exams'][0]['MultiDiagnosisList'][0]['coding_type'] = 'ICD9';

        $data['insuranceList'][0]['name'] = $normalized['insurance_name'];
        $data['insuranceList'][0]['policy'] = $normalized['insurance_policy'];

        error_reporting(1);
        return $data;
    }

}
