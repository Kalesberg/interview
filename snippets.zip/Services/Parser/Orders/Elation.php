<?php

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * Elation Order Parser
 * format: Elation
 * type: Order
 */
class Elation
{
    use HelperTrait;
    protected $format = 'Elation';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/\bElation\b/', $content) &&
            preg_match('/elationemr\.com/', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     * @throws \Exception
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Printout\s*-\s*Elation\s*EMR/i', $line) && !isset($sep_line1)) {
                $sep_line1 = $line_number;
            }
            elseif (trim($line) === 'Referral') {
                $sep_line2 = $line_number;
            }
            elseif (preg_match('/^1\s*of\s*\d{1,}\s+(.*)$/', trim($line), $matches)) {
                $sep_line3 = $line_number;
                $DOS = $matches[1];
            }
            elseif (preg_match('/Patient\s*Demographic\s*Information/', $line)) {
                $sep_line4 = $line_number;
            }
            elseif (preg_match('/Clinical\s*Profile/', $line)) {
                $sep_line5 = $line_number;
            }
        }

        // Doctor information
        $lines = \array_slice($this->lines, $sep_line1 + 1, $sep_line2 - $sep_line1 - 1);
        $doctor = [];
        foreach ($lines as $line) {
            if (!trim($line)) {
                continue;
            }
            if (empty($doctor)) {
                $doctor['name'] = trim($line);
            }
            elseif (preg_match('/Phone\s*:(.*)\s*Fax\s*:(.*)/', $line, $matches)) {
                $doctor['phone1'] = $matches[1];
                $doctor['phone2'] = $matches[2];
            }
            else {
                $doctor['address'] = $doctor['address'] ?? '';
                $doctor['address'] .= trim($line) . ', ';
            }
        }
        $doctor['address'] = trim($doctor['address'], ' ,');
        $normalized['doctor'] = $doctor;

        // Referral information
        $lines = \array_slice($this->lines, $sep_line2 + 1, $sep_line3 - $sep_line2 - 1);
        $referral = $this->parseKeyValues(implode("\n", $lines));
        $normalized['referral'] = $referral;

        // DOS information
        $normalized['DOS'] = $DOS;

        // Patient information
        $patient = $lines = [];
        for ($n = $sep_line4 + 1; $n < $sep_line5 - 10; $n ++) {
            if (trim($this->lines[$n])) {
                $lines[] = $this->lines[$n];
            }
        }
        foreach ($lines as $line_number => $line) {
            if (!isset($subsep_line1) && preg_match('/Patient\s*Name/', $line)) {
                $subsep_line1 = $line_number;
            }
            elseif (!isset($subsep_line2) && preg_match('/^Address$/', trim($line))) {
                $subsep_line2 = $line_number;
            }
            elseif (preg_match('/Contact\s*Details/', $line)) {
                $subsep_line3 = $line_number;
            }
            elseif (preg_match('/Primary\s*Provider/', $line)) {
                $subsep_line4 = $line_number;
            }
            elseif (preg_match('/Primary\s*Insurance/', $line)) {
                $subsep_line5 = $line_number;
            }
        }
        $sublines = \array_slice($lines, $subsep_line1, $subsep_line2 - $subsep_line1);
        $patient['basic'] = $this->parseValuesUnderHeading($sublines)['raw'][0];
        $sublines = \array_slice($lines, $subsep_line2, $subsep_line3 - $subsep_line2);
        $patient['address'] = $this->parseValuesUnderHeading($sublines)['raw'];
        $sublines = \array_slice($lines, $subsep_line3 + 1, $subsep_line4 - $subsep_line3 - 1);
        $patient['contact'] = $this->parseKeyValues(implode("\n", $sublines));
        $sublines = \array_slice($lines, $subsep_line4, $subsep_line5 - $subsep_line4);
        $patient['provider'] = $this->parseValuesUnderHeading($sublines)['raw'][0];
        $sublines = \array_slice($lines, $subsep_line5 + 1);
        $patient['insurance'] = $this->parseKeyValues(implode("\n", $sublines));
        $normalized['patient'] = $patient;

        // Clinical information
        $clinic['pid'] = $this->getValue('Patient\s*ID');
        $normalized['clinic'] = $clinic;

        $this->normalized = $normalized;
        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor']['name']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);
        $data['phone1'] = $this->parsePhone($normalized['doctor']['phone1']);
        $data['phone2'] = $this->parsePhone($normalized['doctor']['phone2']);

        $data['order']['DateOfService'] = $normalized['DOS'] ? Carbon::parse($normalized['DOS'])->format('YmdHis') : '';
        $data['order']['PID'] = $normalized['clinic']['pid'];

        $patient_name = $normalized['patient']['basic'][0] ?: $normalized['referral']['for'];
        $data['patient'] = $this->parseName($patient_name);
        $data['patient']['address'] = $this->parseAddress(implode(',', $normalized['patient']['address']));
        $data['patient']['code'] = $normalized['clinic']['pid'];
        $data['patient']['sex'] = $normalized['patient']['basic'][1];
        if (!$data['patient']['sex']) {
            $sex = preg_replace('/[^a-zA-Z]+/', '', $normalized['referral']['d-o-b'])[0];
            $data['patient']['sex'] = strtoupper($sex);
        }

        $data['patient']['sex'] = $this->parseGender($data['patient']['sex']);

        $dob = $normalized['patient']['basic'][2] ?: explode(' ', $normalized['referral']['d-o-b'])[0];
        $data['patient']['DOB'] = $dob ? Carbon::parse($dob)->format('YmdHis') : '';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['contact']['phone-1']);
        $data['patient']['phone2'] = $this->parsePhone($normalized['patient']['contact']['phone-2']);

        $data['exams'][0] = [
            'study'     => $normalized['referral']['reason-for-referral'],
            'MultiDiagnosisList'    => [
                [
                    'code'          => '',
                    'coding_type'   => '',
                    'description'   => $normalized['referral']['dx']
                ]
            ]
        ];

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
