<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * MedTrio Parser
 * format: MedTrio
 * type: Order
 */
class MedTrio
{
    use HelperTrait;
    protected $format = 'MedTrio';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches MedTrio format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Client\sInformation:/', $content)
            && preg_match('/Name:.*Phone\sNumber:.*/', $content)
            && preg_match('/Requisition\/Physician\sInformation:/', $content)
            && preg_match('/Patient Information:/', $content)
            && preg_match('/Tests\sOrdered:\s*Diagnosis\sCodes:/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_client_start = 0;
        $line_client_end = 0;

        $line_doctor_start = 0;
        $line_doctor_end = 0;

        $line_patient_start = 0;
        $line_patient_end = 0;

        $line_insurance_start = 0;
        $line_insurance_end = 0;

        $line_tests_start = 0;
        $line_tests_end = 0;

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Client\sInformation:/', $line)) {
                $line_client_start = $line_number + 1;
            }

            if (preg_match('/Requisition\/Physician\sInformation:/', $line)) {
                $line_client_end = $line_number - 1;
                $line_doctor_start = $line_number + 1;
            }

            if (preg_match('/Patient\sInformation:/', $line)) {
                $line_doctor_end = $line_number - 1;
                $line_patient_start = $line_number + 1;
            }

            if (preg_match('/Responsible\sParty\/Insured\'s\sInformation:/', $line)) {
                $line_patient_end = $line_number - 1;
                $line_insurance_start = $line_number + 1;
            }

            if (preg_match('/Tests\sOrdered:/', $line)) {
                $line_insurance_end = $line_number - 1;
                $line_tests_start = $line_number;
            }

            if (preg_match('/Authorization.*Please\sSign\sand\sDate/i', $line)) {
                $line_tests_end = $line_number;
            }
        }

        $length_lines_client = $line_client_end - $line_client_start;
        $array_client = array_slice($this->lines, $line_client_start, $length_lines_client);
        $array_client = $this->trimArray($array_client);

        $length_lines_doctor = $line_doctor_end - $line_doctor_start;
        $array_doctor = array_slice($this->lines, $line_doctor_start, $length_lines_doctor);
        $array_doctor = $this->trimArray($array_doctor);

        $length_lines_patient = $line_patient_end - $line_patient_start;
        $array_patient = array_slice($this->lines, $line_patient_start, $length_lines_patient);
        $array_patient = $this->trimArray($array_patient);

        $length_lines_insurance = $line_insurance_end - $line_insurance_start;
        $array_insurance = array_slice($this->lines, $line_insurance_start, $length_lines_insurance);
        $array_insurance = $this->trimArray($array_insurance);

        $length_lines_tests = $line_tests_end - $line_tests_start;
        $array_tests = array_slice($this->lines, $line_tests_start, $length_lines_tests);
        $array_tests = $this->trimArray($array_tests);

        $client = $this->parseMultiKeyValues($array_client);
        $doctor = $this->parseMultiKeyValues($array_doctor);
        $patient = $this->parseMultiKeyValues($array_patient);
        $insurance = $this->parseMultiKeyValues($array_insurance);

        $tests_heading_lines = [];
        $tests_last_line = [];

        foreach ($array_tests as $tline) {
            if (preg_match('/Tests\sOrdered:\s*Diagnosis\sCodes:/', $tline) ||
                preg_match('/\d{1,10}.*/', $tline)) {
                $tests_heading_lines[] = $tline;
            }

            if (preg_match('/PSC\sHOLD.*Stat:.*Fasting:.*Comments:/', $tline)) {
                $tests_last_line = preg_split('/\s{3,}/', $tline);
            }
        }

        $tests_heading = $this->parseValuesUnderHeading($tests_heading_lines);
        $tests_last_line = $this->parseKeyValues(implode(PHP_EOL, $tests_last_line));

        $normalized['referringDr'] = $doctor;
        $normalized['patient'] = $patient;
        $normalized['insurance'] = $insurance;
        $normalized['sendingFacility'] = $client;
        $normalized['exams'] = [
            'lastLine' => $tests_last_line,
            'procedureCode' => '',
            'study' => ''
        ];

        if (isset($tests_heading['parsed'][0][0])) {
            $split = preg_split('/\s-\s/', $tests_heading['parsed'][0][0], 2);
            $normalized['exams']['procedureCode'] = $split[0] ?? '';
            $normalized['exams']['study'] = $split[1] ?? '';
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = 'Order';
        $data['meta']['document_format'] = $this->format;

        if (!empty($normalized['referringDr']['order-date'])) {
            $dos = Carbon::createFromFormat('m/d/Y', $normalized['referringDr']['order-date']);
            $data['order']['DateOfService'] = $dos->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient']['name']);
        $doctor = $this->parseName($normalized['referringDr']['physician-name']);
        $dob = Carbon::createFromFormat('m/d/Y', $normalized['patient']['date-of-birth']);

        $address_str = $normalized['sendingFacility']['address'].','.$normalized['sendingFacility']['city-state-zip'];
        $doctor_address = $this->parseAddress($address_str);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $dob->format('Ymd') . '000000';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex']);
        $data['patient']['SSN'] = $normalized['patient']['ssn'];

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['sendingFacility']['phone-number']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['sendingFacility']['fax-number']);
        $data['referringDr']['sendingFacility'] = $normalized['sendingFacility']['name'];
        $data['referringDr']['npi'] = $normalized['referringDr']['physician-npi'];
        $data['referringDr']['address'] = $doctor_address;

        $data['exams'][0]['study'] = $normalized['exams']['study'];
        $data['exams'][0]['procedure_code'] = $normalized['exams']['procedureCode'];
        $data['exams'][0]['comment'] = $normalized['exams']['lastLine']['comments'];

        if (strtolower($normalized['insurance']['primary-billing']) !== 'patient') {
            $address_str = '';
            if (isset($normalized['insurance']['address']) && !empty($normalized['insurance']['address'])) {
                $address_str = $normalized['insurance']['address'] . ', ' . $normalized['insurance']['city-state-zip'];
            }

            $holder = $this->parseName($normalized['insurance']['name']);

            $data['insuranceList'][0]['name'] = $normalized['insurance']['insurance-carrier'];
            $data['insuranceList'][0]['insurance-address'] = $address_str;
            $data['insuranceList'][0]['policy'] = $normalized['insurance']['policy'];
            $data['insuranceList'][0]['insured']['name'] = $holder['name'];
            $data['insuranceList'][0]['insured']['firstname'] = $holder['firstname'];
            $data['insuranceList'][0]['insured']['middlename'] = $holder['middlename'];
            $data['insuranceList'][0]['insured']['lastname'] = $holder['lastname'];
            $data['insuranceList'][0]['insured']['title'] = $holder['title'];
            $data['insuranceList'][0]['insured']['relation'] = $normalized['insurance']['relationship'];
        }

        error_reporting(1);
        return $data;
    }
}
