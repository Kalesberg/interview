<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * format: NextGen
 * type: Order
 */
class NextGen
{
    use HelperTrait;
    protected $format = 'NextGen';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/Referral\s*Communication\s*Form/i', $content) &&
            preg_match_all('/Referral\s*Information/i', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     * @throws \Exception
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Patient\s*Information/i', $line)) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/\bOrder\b/', $line)) {
                $sep_line2 = $line_number;
            }
            elseif (preg_match('/Referral\s*Information/i', $line)) {
                $sep_line3 = $line_number;
            }
            elseif (preg_match('/Insurance\/Authorization\s*Information/i', $line)) {
                $sep_line4 = $line_number;
            }
            elseif (preg_match('/Current\s*Medications/i', $line) || preg_match('/Additional\s*Information/', $line)) {
                $sep_line5 = $line_number;
            }
            elseif (preg_match('/Problem\s*Description/i', $line)) {
                $sep_line6 = $line_number;
            }
            elseif (preg_match('/Patient\s*Appointment\s*Information/i', $line)) {
                $sep_line7 = $line_number;
            }
        }
        if (!isset($sep_line5)) {
            $sep_line5 = $sep_line6 ?? $sep_line7;
        }
        if (!isset($sep_line6)) {
            $sep_line6 = $sep_line7;
        }

        // Facility
        for ($n = 0; $n < $sep_line1; $n ++) {
            $line = trim($this->lines[$n]);
            if ($line == '') continue;
            $normalized['facility'] = $line;
            break;
        }

        // Patient Information
        $patient = [];
        for ($n = $sep_line1+1; $n < $sep_line2; $n ++) {
            $line = $this->lines[$n];
            if (trim($line) == '') continue;
            $parts = preg_split('/\s{10,}/', $line, 2);
            if (!isset($patient['name'])) {
                $patient['name'] = trim($parts[0]);
            }
            else {
                if (isset($patient['address'])) {
                    $patient['address'] .= ', ' . $parts[0];
                }
                else {
                    $patient['address'] = $parts[0];
                }
            }

            if ($this->getValue(['search' => 'DOB', 'lines' => [$line]])) {
                $patient['dob'] = $this->getValue(['search' => 'DOB', 'lines' => [$line]]);
            }
            elseif ($this->getValue(['search' => 'Cell', 'lines' => [$line]])) {
                $patient['phone'] = $this->getValue(['search' => 'Cell', 'lines' => [$line]]);
            }
        }
        $normalized['patient'] = $patient;

        // Order Information
        $order = '';
        for ($n = $sep_line2+1; $n < $sep_line3; $n ++) {
            $line = trim($this->lines[$n]);
            if ($line == '') continue;
            $order .= $line . "\n";
            if (strpos($line, 'Referrals:') !== false) {
                $order .= 'Address:';
            }
        }
        $normalized['order'] = $this->parseKeyValues($order);

        // Referral Information
        $referrals = '';
        for ($n = $sep_line3+1; $n < $sep_line4; $n ++) {
            $line = trim($this->lines[$n]);
            if ($line == '') continue;
            $referrals .= $line . "\n";
        }
        $normalized['referrals'] = $this->parseKeyValues($referrals);

        // Insurance-Authorization Information
        $info = '';
        for ($n = $sep_line4+1; $n < $sep_line5; $n ++) {
            $line = trim($this->lines[$n]);
            if ($line == '') continue;
            $info .= $line . "\n";
            if (preg_match('/Ordering\s*Provider/i', $this->lines[$n-1])) {
                $info .= 'Address:';
            }
        }
        $normalized['ins'] = $this->parseKeyValues($info);

        // Exams
        $lines = array_slice($this->lines, $sep_line5+1, $sep_line6-$sep_line5-2);
        $normalized['exams'] = $this->parseValuesUnderHeading($lines)['parsed'];

        // Problems
        for ($n = $sep_line6+1; $n < $sep_line7; $n ++) {
            $line = trim($this->lines[$n]);
            if ($line == '') continue;
            $normalized['problems'][] = $line;
        }

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $doctor = preg_replace('/\b([^,][A-Z]+)\b/', ',$1', $normalized['ins']['ordering-provider']);
        $data['referringDr'] = $this->parseName($doctor);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['ins']['phone']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['ins']['fax']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['ins']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['facility'];

        $data['order']['DateOfService'] = $normalized['order']['date-ordered'] ? Carbon::parse($normalized['order']['date-ordered'])->format('YmdHis') : '';

        $patient = $this->parseName($normalized['patient']['name']);
        $data['patient']['name'] = $patient['name'];
        $data['patient']['firstname'] = $patient['firstname'];
        $data['patient']['middlename'] = $patient['middlename'];
        $data['patient']['lastname'] = $patient['lastname'];
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']);

        $data['insuranceList'][0]['name'] = $normalized['ins']['insurance'];
        $data['insuranceList'][0]['policy'] = $normalized['ins']['policy'];

        $data['exams'] = [];
        $provider = $this->parseName($doctor);
        foreach ($normalized['exams'] as $exam) {
            $ex = [
                'study' => $exam[0],
                'approving_provider'    => $provider,
                'comment'   => str_replace("\n", " ", $exam[1]),
                'MultiDiagnosisList'    => [[
                    'description'   => str_replace("\n", " ", $exam[2])
                ]]
            ];
            $data['exams'][] = $ex;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
