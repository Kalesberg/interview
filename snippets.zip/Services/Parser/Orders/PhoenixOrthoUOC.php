<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * format: PhoenixOrthoUOC
 * type: Order
 */
class PhoenixOrthoUOC
{
    use HelperTrait;
    protected $format = 'PhoenixOrthoUOC';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
       return preg_match_all('/UNIVERSITY ORTHOPAEDIC CLINIC/i', $content) &&
               preg_match_all('/Imaging\s*Orders/i', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];

        $line_info_start = 0;
        $line_info_end = 0;

        $line_orders_start = 0;
        $line_orders_end = 0;

        $line_diagnosis_start = 0;
        $line_diagnosis_end = 0;

        foreach ($this->lines as $no => $line) {
            if (preg_match('/^Facility\s{10,}/', $line)) {
                $line_info_start = $no;
            }

            if (preg_match('/^Cellular\sPhone\s{10,}/', $line)) {
                $line_info_end = $no + 1;
            }

            if (preg_match('/^Imaging\sOrders/', $line)) {
                $line_orders_start = $no + 1;
            }

            if (preg_match('/^Diagnosis/', $line)) {
                $line_orders_end = $no;
                $line_diagnosis_start = $no + 1;
            }
        }

        if ($line_orders_end === 0) {
            $line_orders_end = $line_orders_start + 3;
        }

        if ($line_diagnosis_start > 0) {
            for ($i = $line_diagnosis_start; $i < count($this->lines); $i++) {
                $line = trim((string) $this->lines[$i]);

                if (strlen($line) === 0) {
                    $line_diagnosis_end = $i;
                    break;
                }
            }
        }

        $info_length = $line_info_end - $line_info_start;
        $info_tmp = array_slice($this->lines, $line_info_start, $info_length);
        $info_tmp = $this->trimArray($info_tmp);

        $info = [];

        foreach ($info_tmp as $line) {
            $str = preg_replace('/\s{10,}/', ':', $line);
            $str = preg_replace('/.{1,10}ate\sof\sBirth/', 'Date of Birth', $str);
            $info[] = $str;
        }

        $orders_length = $line_orders_end - $line_orders_start;
        $orders = array_slice($this->lines, $line_orders_start, $orders_length);
        $orders = $this->trimArray($orders);

        $diagnosis = [];

        if ($line_diagnosis_start > 0 && $line_diagnosis_end > 0) {
            $diagnosis_length = $line_diagnosis_end - $line_diagnosis_start;

            $diagnosis = array_slice($this->lines, $line_diagnosis_start, $diagnosis_length);
        }

        $info_values = $this->parseKeyValues(implode(PHP_EOL, $info));

        $normalized['doctor_facility'] = $info_values['facility'] ?? '';
        $normalized['order_date'] = $info_values['order-date'] ?? '';
        $normalized['doctor_name'] = $info_values['provider'] ?? '';
        $normalized['doctor_npi'] = $info_values['npi'] ?? '';
        $normalized['doctor_phone'] = $info_values['phone'] ?? '';

        $normalized['patient_name'] = $info_values['patient-name'] ?? '';
        $normalized['patient_dob'] = $info_values['date-of-birth'] ?? '';
        $normalized['patient_age'] = $info_values['patient-age'] ?? '';
        $normalized['patient_gender'] = $info_values['patient-gender'] ?? '';
        $normalized['patient_address'] = $info_values['address'] ?? '';
        $normalized['patient_phone'] = $info_values['cellular-phone'] ?? '';

        $normalized['exams'] = [];

        for ($i = 0; $i < count($orders); $i++) {
            $study = '';
            $procedure_code = '';

            if (preg_match('/^\d{4,10}\s{15,}.*/', $orders[$i])) {
                $split = preg_split('/\s{10,}/', $orders[$i]);

                $study = trim((string) $split[1]);
                $procedure_code = trim((string) $split[0]);
            }

            if (isset($orders[$i]) && isset($orders[$i + 1])
                && preg_match('/^[A-Z0-9\s\.\/]+/', $orders[$i])
                && preg_match('/^\d{4,10}\s{15,}.*/', $orders[$i + 1])
                && !preg_match('/^\d{4,10}\s{15,}.*/', $orders[$i])) {
                $study = trim((string) $orders[$i]);

                $split = preg_split('/\s{10,}/', $orders[$i + 1]);

                $study .= ' ' . trim((string) $split[1]);
                $procedure_code = trim((string) $split[0]);

                $study = trim($study);
                $i = $i + 1;
            }


            $normalized['exams'][] = [
                'study' => $study,
                'procedure_code' => $procedure_code
            ];
        }

        for ($i = 0; $i < count($diagnosis); $i++) {
            $diagnosis[$i] = preg_replace('/\r$/', '', $diagnosis[$i]);
        }

        $normalized['diagnosis'] = [];

        if (count($diagnosis) > 0) {
            for ($i = 0; $i < count($diagnosis); $i++) {
                $icd = '';
                $description = '';

                if (preg_match('/^\s{15,}.*/', $diagnosis[$i])) {
                    continue;
                }

                if (preg_match('/^[A-Z0-9\.]+\s{15,}.*/', $diagnosis[$i])) {
                    $split = preg_split('/\s{10,}/', $diagnosis[$i]);

                    $icd = trim((string) $split[0]);
                    $description = trim((string) $split[1]);
                }

                if (preg_match('/^[A-Z0-9\.]+$/', $diagnosis[$i])) {
                    $icd = trim((string) $diagnosis[$i]);

                    if (isset($diagnosis[$i - 1])) {
                        $description .= ' ' . trim((string) $diagnosis[$i - 1]);
                    }

                    if (isset($diagnosis[$i + 1])) {
                        $description .= ' ' . trim((string) $diagnosis[$i + 1]);
                    }

                    $description = trim($description);
                }

                $normalized['diagnosis'][] = [
                    'code' => $icd,
                    'description' => $description
                ];
            }
        }

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        if (count($normalized['exams']) > 1) {
            for ($i = 1; $i < count($normalized['exams']); $i++) {
                $data['exams'][$i] = $data['exams'][0];
            }
        }

        if (!empty($normalized['order_date'])) {
            $dos = Carbon::createFromFormat('m/d/Y', $normalized['order_date']);
            $data['order']['DateOfService'] = $dos->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['doctor_name']);

        if (isset($normalized['patient_dob']) && !empty($normalized['patient_dob'])) {
            $date = Carbon::createFromFormat('m/d/Y', $normalized['patient_dob']);
            $patient_dob = $date->format('Ymd') . '000000';
        }

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patient_dob ?? '';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient_phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient_address']);
        $data['patient']['sex'] = $this->parseGender($normalized['patient_gender']);
        $data['patient']['age'] = $normalized['patient_age'];

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $normalized['doctor_phone'];
        $data['referringDr']['npi'] = $normalized['doctor_npi'];
        $data['referringDr']['sendingFacility'] = $normalized['doctor_facility'];

        foreach ($normalized['exams'] as $i => $exam) {
            $data['exams'][$i]['study'] = $exam['study'] ?? '';
            $data['exams'][$i]['procedure_code'] = $exam['procedure_code'] ?? '';

            foreach ($normalized['diagnosis'] as $j => $diag) {
                $data['exams'][$i]['MultiDiagnosisList'][$j]['code'] = $diag['code'];
                $data['exams'][$i]['MultiDiagnosisList'][$j]['coding_type'] = 'ICD10';
                $data['exams'][$i]['MultiDiagnosisList'][$j]['description'] = $diag['description'];
            }
        }

        error_reporting(1);
        return $data;
    }
}
