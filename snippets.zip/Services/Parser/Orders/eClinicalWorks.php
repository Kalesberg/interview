<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * eClinicalWorks Order Parser
 * format: eClinicalWorks
 * type: Order
 */
class eClinicalWorks
{
    use HelperTrait;
    protected $format = 'eClinicalWorks';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/eClinicalWorks/i', $content)
            && preg_match('/Electronically\sSigned\sBy/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);

        foreach ($this->lines as $line_number => $line) {
            if (stripos($line, 'Req/Ctrl') !== false) {
                $startLine1 = $line_number;
            }
            elseif (!isset($startLine2) && (preg_match('/\bID\s*:/i', $line) || preg_match('/Today\s*:/i', $line))) {
                $startLine2 = $line_number;
            }
            elseif (stripos($line, 'Primary Insurance') !== false) {
                $startLine3 = $line_number;
            }
            elseif (stripos($line, 'Diagnostic Name') !== false) {
                $startLine4 = $line_number;
            }
            elseif (stripos($line, 'Electronically Signed By') !== false) {
                $startLine5 = $line_number;
            }
        }

        /** --- Section1 --- **/
        $section1 = [];
        $left = $right = [];
        for ($l = $startLine1; $l < $startLine2; $l ++) {
            $line = $this->lines[$l];
            $parts = preg_split('/\s{15,}/', $line);

            if (!empty($parts[0]) && trim($parts[0]) != '') {
                $left[] = trim($parts[0]);
            }
            if (!empty($parts[1]) && trim($parts[1]) != '') {
                $right[] = trim($parts[1]);
            }
        }
        $section1['org1'] = $left[0];
        if (preg_match('/,$/', (string) strTrim($left[1]))) {
            $location = strTrim($left[1]) . strTrim($left[2]);
        }
        else {
            $location = strTrim($left[1]) . ', ' . strTrim($left[2]);
        }
        if (strpos($location, '9 ') === 0) {
            $location = substr($location, 2);
        }
        $section1['location'] = $this->parseAddress($location);

        $number_str = preg_replace('/[^\d\-]+/', '', $left[3]);
        preg_match_all('/(\d{3}-\d{3}-\d{4})/', $number_str, $matches);
        $section1['phone1'] = $matches[0][0];
        $section1['phone2'] = $matches[0][1];

        $pair = $this->getKeyValue($right[0]);
        $section1[$pair[0]] = trim($pair[1]);
        $pair = $this->getKeyValue($right[2]);
        $section1[$pair[0]] = trim($pair[1]);
        $pair = $this->getKeyValue($right[3]);
        $section1[$pair[0]] = trim($pair[1]);
        $section1['name'] = $right[1];
        if (!strpos($section1['name'], ',') && count(explode(' ', $section1['name'])) > 2) {
            if (preg_match('/\s[^a-z]+$/', $section1['name'], $matches, PREG_OFFSET_CAPTURE)) {
                $section1['name'] = substr_replace($section1['name'], ',', $matches[0][1], 0);
            }
            else {
                $s_pos = strrpos($section1['name'], ' ');
                $section1['name'] = substr_replace($section1['name'], ',', $s_pos, 0);
            }
        }
        
        // Remove comma for titles
        if (preg_match('/,(\s*[^a-z]+)$/', $section1['name'], $matches, PREG_OFFSET_CAPTURE)) {
            $section1['name'] = substr($section1['name'], 0, $matches[1][1]) . str_replace(',', ' ', $matches[1][0]);
        }
        $section1['org2'] = ($right[4] ?? '');

        /** --- Section 2 --- **/
        $section2 = [];
        // First Line
        $l = $startLine2;
        $line = trim($this->lines[$l]);
        preg_match('/ID\s*:/', $line, $match, PREG_OFFSET_CAPTURE);
        $pos1 = $match[0][1] ?? false;
        if (!$pos1) {
            preg_match('/\s{5,}/i', $line, $match, PREG_OFFSET_CAPTURE);
            $pos1 = $match[0][1];
        }
        preg_match('/Today\s*:/i', $line, $match, PREG_OFFSET_CAPTURE);
        $pos2 = $match[0][1];
        $str = trim(substr($line, 0, $pos1 - 1));
        preg_match('/^([^,]+),\s*([^,]+),\s*([^,]+),\s*([\d\/]+)$/', $str, $matches);
        $section2['firstname'] = explode(' ', $matches[2], 2)[0];
        $section2['middlename'] = (explode(' ', $matches[2], 2)[1] ?? '');
        $section2['lastname'] = $matches[1];
        $section2['sex'] = $matches[3];
        $section2['dob'] = $matches[4];
        $str = trim(substr($line, $pos1, $pos2 - $pos1));
        $pair = $this->getKeyValue($str);
        $section2[$pair[0]] = trim($pair[1]);

        $str = trim(substr($line, $pos2));
        $pair = $this->getKeyValue($str);
        $section2[$pair[0]] = trim($pair[1]);

        // Second Line
        $l ++;
        $line = trim($this->lines[$l]);
        $pos = stripos($line, 'Order Date:');
        $left = trim(substr($line, 0, $pos - 1));
        $right = trim(substr($line, $pos));
        // We did not use CoreEngine's parseAddress function here due to
        // some bad translated OCR characters
        preg_match('/\b([\d\-]+)\b(.*)/', $left, $matches);
        $section2['phone1'] = $matches[1];
        $address = trim($matches[2]);
        if (strpos($address, '9 ') === 0) {
            // Remove badly translated characters
            $address = trim(substr($address, 2));
        }
        if (\strlen($section2['phone1']) < 11) {
            $address = $section2['phone1'] . ' ' . $address;
            $section2['phone1'] = '';
        }
        $section2['location'] = $this->parseAddress($address);
        $pair = $this->getKeyValue($right);
        $section2[$pair[0]] = trim($pair[1]);

        /** --- Section 3 --- **/
        $section3 = [];
        for ($l = $startLine3; $l < $startLine4; $l++) {
            $line = trim($this->lines[$l]);
            $pair = $this->getKeyValue($line);
            if (stripos($pair[0], 'address') !== false) {
                $pair[1] = str_ireplace(', US', '', $pair[1]);
                $pair[1] = str_replace('.', ',', $pair[1]);
            }
            $section3[$pair[0]] = $pair[1];
        }

        /** --- Section 4 --- **/
        $section4 = [];
        for ($l = $startLine4 + 1; $l < $startLine5; $l ++) {
            $line = trim($this->lines[$l]);
            if (trim($line) == '') {
                continue;
            }
            $parts = preg_split('/\s{3,}/', $line, 2);

            // if (count($parts) < 2) {
            //     continue;
            // }
            // if (count($parts) > 1 && strpos(trim($parts[1]), '-') !== 0) {
            //     continue;
            // }
            if (preg_match('/Notes\s*:/i', $parts[0])) {
                continue;
            }

            $p_code = explode(' ', trim($parts[0]), 2)[0];
            $comment = explode(' ', trim($parts[0]), 2)[1];
            if (!(preg_match('/^[A-Z0-9]+$/', $p_code) && preg_match('/\d+/', $p_code))) {
                $comment = $p_code . ' ' . $comment;
                $p_code = '';
            }
            if (count($parts) > 1) {
                $code = explode(' ', trim($parts[1], '- '), 2)[0];
                $code = substr($code, 0, strlen($code) - 1);
                $desc = explode(' ', trim($parts[1], '- '), 2)[1];
                $case = [$p_code, $comment, $code, $desc];
            }
            else {
                $case = [$p_code, $comment, '', ''];
            }
            $section4[] = $case;
        }

        error_reporting(1);
        $normalized = compact('section1', 'section2', 'section3', 'section4');
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        // Doctor Information
        $data['referringDr'] = $this->parseName($normalized['section1']['name']);
        $data['referringDr']['npi'] = $normalized['section1']['npi'] ?? $normalized['section1']['provider-code'] ?? '';
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['section1']['phone1']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['section1']['phone2']);
        $data['referringDr']['address'] = $normalized['section1']['location'];
        $data['referringDr']['sendingFacility'] = $normalized['section1']['org1'];

        $data['order']['sendingApplication'] = 'eClinicalWorks';
        $data['order']['accession'] = $normalized['section1']['req-ctrl-cd'];
        $data['order']['placer_order_number'] = $normalized['section1']['req-ctrl-cd'];
        $data['order']['DateOfService'] = $normalized['section2']['order-date'] ? Carbon::parse($normalized['section2']['order-date'])->format('YmdHis') : '';
        $data['order']['PID'] = $normalized['section2']['id'];

        // Patient Information
        $data['patient']['firstname'] = addslashes($normalized['section2']['firstname']);
        $data['patient']['middlename'] = addslashes($normalized['section2']['middlename']);
        $data['patient']['lastname'] = addslashes($normalized['section2']['lastname']);

        $data['patient']['name'] = $data['patient']['firstname'] . ' ' . $data['patient']['middlename'] . ' ' . $data['patient']['lastname'];
        $data['patient']['DOB'] = $normalized['section2']['dob'] ? Carbon::parse($normalized['section2']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = strtoupper($normalized['section2']['sex'][0]);
        $data['patient']['phone1'] = $this->parsePhone($normalized['section2']['phone1']);
        $data['patient']['address'] = $normalized['section2']['location'];

        // $data['submitTime'] = date('YmdHis', strtotime($normalized['section2']['today']));

        // Insurance List
        $data['insuranceList'] = [];
        $data['insuranceList'][] = [
            'name'              => $normalized['section3']['primary-insurance-name'],
            'insurance-address' => $normalized['section3']['insurance-address'],
            'insured'           => $this->parseName(str_replace(',', ' ', $normalized['section3']['insured-name']), true),
            'policy'            => $normalized['section3']['subscriber-number'],
            // 'address'           => $normalized['section3']['address']
        ];

        // Exams
        $data['exams'] = [];
        $provider = $this->parseName($normalized['section1']['name']);
        $provider['npi'] = $data['referringDr']['npi'];

        foreach ($normalized['section4'] as $case) {
            $exam = [
                'approving_provider'    => $provider,
                'procedure_code' => $case[0],
                'study'        => $case[1],
                'comment'      => $case[3]
            ];
            $exam['MultiDiagnosisList'] = [[
                'coding_type'       => 'ICD10',
                'code'              => $case[2],
                'description'       => ''
            ]];
            $data['exams'][] = $exam;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }

    /**
     * Parse column blocks in eClinicalWorks Order text file
     * @param array $block (array of strings in that block)
     * @param array $keys (array of keys in that block)
     * @return array
     */
    protected function _parseBlock(array $block, array $keys)
    {
        if (empty($block)) {
            return [];
        }
        $column = [];
        $value = '';
        foreach ($block as $string) {
            foreach ($keys as $key) {
                $pattern = "/$key/i";
                if (preg_match($pattern, $string, $matches)) {
                    if (!empty($field) && !empty($value)) {
                        $value = preg_replace('/\s+/', ' ', $value);
                        $value = trim($value, ', ');
                        if (isset($column[$field])) {
                            $column[$field.'1'] = $value;
                        }
                        else {
                            $column[$field] = $value;
                        }
                    }
                    $field = $this->slugify($matches[0]);
                    $value = trim(preg_replace($pattern, '', $string));
                    continue 2;
                }
            }
            $value .= ', ' . $string;
        }
        $column[$field] = $value;

        return $column;
    }
}
