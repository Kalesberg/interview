<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * format: PointNClick
 * type: Order
 */
class PointNClick
{
    use HelperTrait;
    protected $format = 'PointNClick';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return (bool) preg_match_all('/RADIOLOGY\s*SERVICE/', $content) &&
                      preg_match_all('/Patient\s*Gender/', $content) &&
                      preg_match_all('/EXAMINATION\(S\)\s*ORDERED/', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Patient\s*ID\s*No/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_pos0 = $matches[0][1] - 2;
            }
            elseif (preg_match('/EXAMINATION\(S\)\s*ORDERED/', trim($line))) {
                $sep_line1 = $line_number;
            }
            elseif (!isset($sep_line2) && preg_match('/^Diagnosis:/', trim($line))) {
                $sep_line2 = $line_number;
            }
        }

        // Doctor and Patient information
        $lines = array_slice($this->lines, 0, $sep_line1 - 1);
        $left = $right = [];
        foreach ($lines as $line) {
            $l = substr($line, 0, $sep_pos0);
            $r = substr($line, $sep_pos0);
            $left[] = $l;
            $right[] = $r;
        }
        $left = $this->trimArray($left);
        $right = $this->trimArray($right);

        $normalized['doctor']['facility'] = array_shift($left);
        $address = array_splice($left, 0, 3);
        $address[1] = preg_replace('/\s*MRN:?/', '', $address[1]);
        preg_match('/^([^,]+),\s*([^\d]+)([0-9\-\s]+)/', $address[2], $matches);
        $normalized['doctor']['address'] = [
            'address1'  => $address[0],
            'address2'  => $address[1],
            'city'      => $matches[1],
            'state'      => $matches[2],
            'zip'      => $matches[3],
        ];
        $normalized['doctor']['address']['state'] = $this->abbreviateUSStateName($normalized['doctor']['address']['state']);
        $normalized['doctor']['phone'] = array_pop($left);
        $normalized['accession'] = $this->getValue(['lines' => $left, 'search' => 'Req#', 'delimiter' => '\s+']);

        $temp = $this->parseKeyValues(join("\n", $right));
        $normalized['pid'] = $this->getValueBelow(['search' => 'Patient\s*ID\s*No', 'lines' => $right]);
        $normalized['patient']['name'] = $this->getValueBelow(['search' => 'Patient\s*Name', 'lines' => $right]);
        $normalized['patient']['dob'] = $this->getValueBelow(['search' => 'Patient\s*DOB', 'lines' => $lines]);
        $normalized['patient']['gender'] = $temp['patient-gender'];
        $normalized['dos'] = $temp['date-time-requested'];
        $normalized['insurance'] = $temp['insurance'];

        // Exams information
        $lines = $this->trimArray(array_slice($this->lines, $sep_line1 + 1, $sep_line2 - $sep_line1 - 1), true);
        $normalized['exams'] = $this->parseValuesUnderHeading($lines)['parsed'];
        $lines = $this->trimArray(array_slice($this->lines, $sep_line2));
        $temp = $this->parseKeyValues(join("\n", $lines));
        $diag_desc = substr($temp['diagnosis'], 0, strrpos($temp['diagnosis'], ' '));
        $diag_code = trim(substr($temp['diagnosis'], strrpos($temp['diagnosis'], ' ')));
        $normalized['diagnosis'] = [$diag_desc, $diag_code];
        $normalized['doctor']['name'] = $temp['ordering-practitioner'];

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor']['name']);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone']);
        $data['referringDr']['address'] = $normalized['doctor']['address'];
        $data['referringDr']['sendingFacility'] = $normalized['doctor']['facility'];

        $data['order']['accession'] = $normalized['accession'];
        $data['order']['DateOfService'] = $normalized['dos'] ? Carbon::parse($normalized['dos'])->format('YmdHis') : '';
        $data['order']['PID'] = $normalized['pid'];

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['gender']);

        foreach ($normalized['exams'] as $exam) {
            $data['exams'][] = [
                'procedure_code'    => $exam[1],
                'study'             => $exam[2],
                'MultiDiagnosisList'=> [[
                    'coding_type'   => 'ICD10',
                    'code'          => $normalized['diagnosis'][1],
                    'description'   => $normalized['diagnosis'][0]
                ]]
            ];
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
