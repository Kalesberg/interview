<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * PracticeFusion Order Parser
 * format: PracticeFusion
 * type: Order
 */
class PracticeFusion
{
    use HelperTrait;

    protected $format = 'PracticeFusion';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches PracticeFusion format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/practice\s*fusio/i', $content) &&
                preg_match('/Imaging|Vendor\s+order/i', $content) &&
               preg_match('/order\s*#/i', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $startLine = $stringLen = null;
        $endLine = 0;

        $allowed_sections = ['order', 'patient information', 'responsible party/guarantor information',
            'requesting provider information', 'primary insurance', 'secondary insurance'];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/order\s*#(:|;)?/i', $line)) {
                $startLine = $line_number;
            }
            elseif ($pos = stripos($line, 'requesting provider information')) {
                $stringLen = $pos - 3;
            }
            elseif (preg_match('/code\s+study name\s+stat\s+notes\s+dx/i', $line)) {
                $endLine = $line_number;
            }
        }
        if (!$endLine) {
            $endLine = count($this->lines);
        }
        $section = 'order';
        $normalized[] = "[$section]";
        // Parse left part of the document
        for ($n = $startLine; $n < $endLine; $n ++) {
            $string = substr($this->lines[$n], 0, $stringLen);
            if (!trim($string)) {
                continue;
            }
            if (preg_match('/(:|;|!)\s+/', $string)) {
                $normalized[] = preg_replace('/(:|;|!)\s+/', '=', trim($string));
            }
            elseif (preg_match('/^\s{5,}/', $string)) {
                $normalized[count($normalized) - 1] .= ', ' . trim($string);
            }
            elseif (\in_array(strtolower(trim($string)), $allowed_sections)) {
                $section = strtolower(trim($string));
                $normalized[] = "[$section]";
            }

        }
        // Parse right side of the document
        for ($n = $startLine; $n < $endLine; $n ++) {
            $string = substr($this->lines[$n], $stringLen);
            if (!$string || !trim($string)) {
                continue;
            }

            if (preg_match('/(:|;|!)\s+/', $string)) {
                $normalized[] = preg_replace('/(:|;|!)\s+/', '=', trim($string));
            }
            elseif (preg_match('/^\s{5,}/', $string)) {
                $normalized[count($normalized) - 1] .= ', ' . trim($string);
            }
            elseif (in_array(strtolower(trim($string)), $allowed_sections)) {
                $section = strtolower(trim($string));
                $normalized[] = "[$section]";
            }
        }

        // Parse exam sheet
        $lines = [];
        if ($endLine > 0 && $endLine < count($this->lines)) {
        //     $params['header'] = $this->lines[$endLine];
        //     for ($n = $endLine + 1; $n < count($this->lines) && !stripos($this->lines[$n], 'Signed By'); $n++) {
        //         $string = $this->lines[$n];
        //         if (!empty(trim($string))) {
        //             $params['cases'][] = $string;
        //         }
        //     }
        //     $exams = $this->parseExams($params);
        //     foreach ($exams['cases'] as $index => $case) {
        //         $normalized[] = "[exam-$index]";
        //         foreach ($exams['header'] as $subIndex => $label) {
        //             $value = $case[$subIndex];
        //             $normalized[] = $label . '=' . $value;
        //         }
        //     }
            for ($n = $endLine; $n < count($this->lines) && !stripos($this->lines[$n], 'Signed By'); $n++) {
                $string = $this->lines[$n];
                if (!empty(trim($string))) {
                    $lines[] = $string;
                }
            }
            $values = $this->parseValuesUnderHeading($lines);
            $headings = $values['headings'];
            $exams = $values['parsed'];
            foreach ($exams as $index => $exam) {
                $normalized[] = "[exam-$index]";
                foreach ($headings as $subIndex => $label) {
                    $value = $exam[$subIndex];
                    $normalized[] = trim($label) . '=' . $value;
                }
            }
        }

        // Parse service, signature
        $normalized[] = '[meta]';
        for ($n = 0; $n < count($this->lines); $n ++) {
            $string = trim($this->lines[$n]);
            if (preg_match('/Imaging Center name(?::|;)\s+(.*)/i', $string, $matches)) {
                $normalized[] = 'service=' . $matches[1];
            } elseif (preg_match('/Electronically Signed By(?::|;)\s+(.*)/i', $string, $matches)) {
                $normalized[] = 'signedby=' . $matches[1];
            }
        }

        $normalized = @parse_ini_string(join("\n", $normalized), true, INI_SCANNER_RAW);
        if (!$normalized) {
            return [];
        }
        foreach ($normalized as & $section) {
            foreach ($section as $key => $value) {
                $sanitized = trim(preg_replace('/[^a-z_\s\-0-9]/i', '', strtolower($key)));
                unset($section[$key]);
                $section[$sanitized] = $value;
            }
        }

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        // $data['servicingFacility'] = $normalized['meta']['service'];
        // $data['receivingFacility'] = 'Billing System';

        $data['order']['PID'] = $normalized['patient information']['id'] ?? '';
        $data['order']['accession'] = $normalized['order']['order'] ?? '';
        $data['order']['DateOfService'] = $normalized['order']['sent'] ? Carbon::parse($normalized['order']['sent'])->format('YmdHis') : '';
        $data['order']['sendingApplication'] = 'practice fusion';
        $data['order']['servicingFacility'] = $normalized['meta']['service'] ?? '';

        $data['referringDr'] = $this->parseName($normalized['requesting provider information']['provider name'] ?? '');
        $data['referringDr']['address'] = $this->parseAddress($normalized['requesting provider information']['address'] ?? '');
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['requesting provider information']['phone'] ?? '');
        $data['referringDr']['npi'] = $normalized['requesting provider information']['npi'] ?? '';
        $data['referringDr']['sendingFacility'] = $normalized['requesting provider information']['practice'] ?? '';

        $data['patient'] = $this->parseName($normalized['patient information']['name'] ?? '');
        $data['patient']['address'] = $this->parseAddress($normalized['patient information']['address'] ?? '');
        $data['patient']['DOB'] = $normalized['patient information']['dob'] ? Carbon::parse($normalized['patient information']['dob'])->format('YmdHis') : '';

        $gender = $normalized['patient information']['gender'] ?? '';
        $data['patient']['sex'] = $this->parseGender($gender);

        $data['patient']['phone1'] = $this->parsePhone($normalized['patient information']['phone'] ?? '');

        $data['insuranceList'] = [];
        if (isset($normalized['primary insurance'])) {
            $data['insuranceList'][0] = ($normalized['primary insurance'] ?? []);
        }
        if (isset($normalized['secondary insurance'])) {
            $data['insuranceList'][1] = ($normalized['secondary insurance'] ?? []);
        }

        foreach ($data['insuranceList'] as &$insurance) {
            $insurance['insurance-address'] = $insurance['address'];
            unset($insurance['address']);
            unset($insurance['insured']);
            $insurance['insured'] = $data['patient'];
        }

        $data['exams'] = [];
        $provider = $this->parseName($normalized['requesting provider information']['provider name']);
        $provider['npi'] = $data['referringDr']['npi'];
        foreach ($normalized as $sectionName => $section) {
            $exam = [];
            if (strpos($sectionName, 'exam-') === 0) {
                $exam['comment'] = $section['notes'];
                $exam['study'] = $section['study name'];
                $exam['approving_provider'] = $provider;
                $exam['procedure_code'] = $section['code'];
                $exam['stat'] = $section['stat'];
                $exam['MultiDiagnosisList'] = [];

                $dxs = isset($section['dx']) ? explode(',', $section['dx']) : [];
                foreach ($dxs as $dx) {
                    $dx = trim($dx);
                    $diagnosis = [
                        'description'   => '',
                        'coding_type'   => 'ICD10',
                        'code'          => $dx
                    ];
                    $exam['MultiDiagnosisList'][] = $diagnosis;
                }
                $data['exams'][] = $exam;
            }
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
