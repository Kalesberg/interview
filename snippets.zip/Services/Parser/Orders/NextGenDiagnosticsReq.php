<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * NextGenDiagnosticsReq Order Parser
 * format: NextGenDiagnosticsReq
 * type: Order
 */
class NextGenDiagnosticsReq
{
    use HelperTrait;
    protected $format = 'NextGenDiagnosticsReq';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/Diagnostics\s*Requisition/', $content) && preg_match_all('/Order\s*Information/', $content) &&
               preg_match_all('/Order\s*Description/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @param  type|null $content (Content to parse)
     * @return boolean (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (!isset($sep_line0) && preg_match('/Phone:/i', $line)) {
                $sep_line0 = $line_number - 2;
            }
            elseif (preg_match('/Patient\s*Information/', $line)) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/Secondary\s*Insurance/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line2 = $line_number;
                $sep_pos2 = $matches[0][1];
            }
            elseif (preg_match('/Order\s*Information/', $line)) {
                $sep_line3 = $line_number;
            }
        }

        // Doctor information
        $lines = array_slice($this->lines, $sep_line0, $sep_line1 - $sep_line0 - 1);
        $doctor = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if (!$line) {
                continue;
            }
            if (preg_match('/Phone:/i', $line)) {
                $partials = preg_split('/\S+:/', $line);
                if (count($partials)) {
                    $doctor['phone1'] = $partials[1] ?? '';
                    $doctor['phone2'] = $partials[2] ?? '';
                }
            }
            else {
                $doctor['address'] = isset($doctor['address']) ? $doctor['address'] . ', ' . $line : $line; 
            }
        }
        $normalized['doctor'] = $doctor;

        // Patient information
        $lines = array_slice($this->lines, $sep_line1, $sep_line2 - $sep_line1 - 3);
        $newlines = [];
        foreach ($lines as $line) {
            if (!trim($line)) {
                continue;
            }
            $subline = substr($line, 0, 50);
            $newlines[] = $subline;
        }
        foreach ($lines as $line) {
            if (!trim($line)) {
                continue;
            }
            $subline = substr($line, 50);
            $newlines[] = $subline;
        }
        $normalized['patient'] = $this->parseMultiKeyValues($newlines);

        // Insurance information
        $lines = array_slice($this->lines, $sep_line2 + 1, $sep_line3 - $sep_line2 - 1);
        $newlines = [];
        foreach ($lines as $line) {
            $left = substr($line, 0, $sep_pos2);
            $newlines[] = $left;
        }
        foreach ($lines as $line) {
            $right = substr($line, $sep_pos2);
            $newlines[] = $right;
        }
        $normalized['insurance'] = $this->parseMultiKeyValues($newlines);

        // Order information
        $lines = [];
        for ($n = $sep_line3 + 1; $n < count($this->lines); $n ++) {
            $line = trim($this->lines[$n]);
            if (!$line) {
                continue;
            }
            if (preg_match('/Code:/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $subline1 = substr($line, 0, $matches[0][1]);
                $subline2 = substr($line, $matches[0][1]);
                $lines[] = $subline1;
                $lines[] = $subline2;
            }
            else {
                $lines[] = $line;
            }
        }
        $order = $this->parseKeyValues(join("\n", $lines));
        $order['ordered-by'] = preg_replace('/\s\S+$/', ',$0', $order['ordered-by']);
        $normalized['order'] = $order;
        
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;
        
        $data['referringDr'] = $this->parseName($normalized['order']['ordered-by']);
        $data['referringDr']['code'] = $normalized['order']['npi'];
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone1']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor']['phone2']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);

        $data['order']['DateOfService'] = $normalized['order']['ordered-date'] ? Carbon::parse($normalized['order']['ordered-date'])->format('YmdHis') : '';

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['gender']);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['home']);
        $data['patient']['phone2'] = $this->parsePhone($normalized['patient']['work']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']);
        $data['patient']['SSN'] = $normalized['patient']['ss'];

        $ins = $normalized['insurance'];
        $insurance = [
            'name'      => $ins['name'],
            'insurance-address' => $ins['address'],
            'policy'    => $ins['policy'],
            'insured'   => $data['patient'],
            'subscriber'=> $ins['group']
        ];
        $data['insuranceList'][] = $insurance;
        if (isset($ins['name_'])) {
            $insurance = [
                'name'      => $ins['name_'],
                'insurance-address' => $ins['address_'],
                'policy'    => $ins['policy_'],
                'insured'   => $data['patient'],
                'subscriber'=> $ins['group_']
            ];
        }
        $data['insuranceList'][] = $insurance;

        preg_match('/\((.*)\)\s*(.*)/', $normalized['order']['dx-code-dx-description'], $matches);
        $data['exams'][0] = [
            'study'     => $normalized['order']['order-description'],
            'procedure_code'    => $normalized['order']['code'],
            'MultiDiagnosisList'=> [[
                'code'      => $matches[1],
                'coding_type'   => 'ICD-10',
                'description'   => $matches[2]
            ]]
        ];

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
