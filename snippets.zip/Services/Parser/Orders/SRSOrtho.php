<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * SRSOrtho Order Parser
 * format: SRSOrtho
 * type: Order
 */
class SRSOrtho
{
    use HelperTrait;
    protected $format = 'SRSOrtho';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches Allscripts format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/Requsition\s*ID/i', $content) &&
            preg_match('/Shared\s*ID/i', $content) &&
            preg_match('/Ordering\s*Location/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];
        
        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Requsition\s*ID/i', $line)) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/^Patient$/', trim($line))) {
                $sep_line2 = $line_number;
            }
            elseif (preg_match('/Secondary\s*Insurance/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line3 = $line_number;
                $sep_pos3 = $matches[0][1];
            }
            elseif (preg_match('/^Ordering\s*Provider$/', trim($line))) {
                $sep_line4 = $line_number;
            }
            elseif (preg_match('/Ordering\s*Location/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line5 = $line_number;
                $sep_pos5 = $matches[0][1];
            }
            elseif (preg_match('/^Orders$/', trim($line))) {
                $sep_line6 = $line_number;
            }
        }

        // Order information
        $lines = array_slice($this->lines, $sep_line1, $sep_line2 - $sep_line1);
        $order = $this->parseMultiKeyValues($lines);
        $normalized['order'] = $order;

        // Patient information
        $lines = array_slice($this->lines, $sep_line2 + 1, $sep_line3 - $sep_line2 - 1);
        // We need to have ':' after the key names to be properly parsed
        $keys_to_replace = ['/\b(Name)\s+/', '/(Shared\s+ID)\s+/', '/\b(DOB)\b\s+/', '/\b(Sex)\s+/', '/^(Address)\s+/', '/\b(Phone)\s+/'];
        foreach ($lines as & $line) {
            $line = preg_replace($keys_to_replace, '$1:', $line);
        }

        $patient = $this->parseMultiKeyValues($lines);
        $normalized['patient'] = $patient;

        // Insurance information
        $lines = array_slice($this->lines, $sep_line3, $sep_line4 - $sep_line3);
        $left = $right = [];
        foreach ($lines as $line) {
            $l = substr($line, 0, $sep_pos3);
            $r = substr($line, $sep_pos3);

            $left[] = $l;
            $right[] = $r;
        }
        $primary = $this->parseKeyValues(join("\n", $left));
        $secondary = $this->parseKeyValues(join("\n", $right));
        $normalized['primary-ins'] = $primary;
        $normalized['secondary-ins'] = $secondary;

        // Ordering Provider
        $lines = array_slice($this->lines, $sep_line4 + 1, $sep_line5 - $sep_line4 - 1);
        $normalized['order-provider'] = $this->parseMultiKeyValues($lines);

        // Facility/Location information
        $lines = array_slice($this->lines, $sep_line5 + 1, $sep_line6 - $sep_line5 - 1);
        $left = $right = [];
        foreach ($lines as $line) {
            $l = substr($line, 0, $sep_pos5);
            $r = substr($line, $sep_pos5);

            $left[] = $l;
            $right[] = $r;
        }
        $facility = $this->parseKeyValues(join("\n", $left));
        $location = $this->parseKeyValues(join("\n", $right));
        $normalized['facility'] = $facility;
        $normalized['location'] = $location;

        $normalized['exams'] = $this->getExamBlocks();

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['order-provider']['name']);
        $data['referringDr']['npi'] = $normalized['order-provider']['npi'];
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['facility']['phone']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['facility']['fax']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['facility']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['facility']['name'];

        $data['order'] = [
            'accession'     => $normalized['order']['requsition-id'],
            'placer_order_number'   => count($normalized['exams']) ? $normalized['exams'][0]['placer_order_number'] : '',
            'sendingApplication'    => 'SRS',
            'DateOfService'         => $normalized['order']['order-date'] ? Carbon::parse($normalized['order']['order-date'])->format('YmdHis') : ''
        ];

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';

        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex']);
        $data['patient']['code'] = $normalized['patient']['shared-id'] ?? '';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']);

        $data['exams'] = $normalized['exams'];

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }

    /**
     * Get order blocks as array of lines
     * @return array
     */
    public function getExamBlocks(): array
    {
        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/^Orders$/', trim($line))) {
                $startLine = $line_number + 1;
            }
            elseif (preg_match('/Ordering\s*Provider\s*Signature/i', trim($line))) {
                $endLine = $line_number;
            }
        }

        if (!isset($startLine, $endLine)) {
            return [];
        }
        $tmp_lines = $this->trimArray(array_slice($this->lines, $startLine, $endLine - $startLine));

        $lines = [];
        $line_concat = false;
        foreach ($tmp_lines as $line) {
            if (preg_match('/Patient\sName:.*DOB:.*Shared\sID:.*/', trim($line))) {
                continue;
            }

            if (preg_match('/^Order\s*Due:/', trim($line))) {
                $line_concat = false;
            }

            if ($line_concat) {
                $lines[count($lines) - 1] .= ' ' . $line;
            } else {
                $lines[] = $line;
            }

            if (preg_match('/^Diagnosis:/', trim($line))) {
                $line_concat = true;
            }
        }

        $orders = [];
        $order = [];
        foreach ($lines as $line_no => $line) {
            /*if ($line == 'Order Id: 1242') {
                dd($line);
            }*/

            if (preg_match('/^Order\s*Id:/', trim($line))) {
                if (!empty($order)) {
                    $orders[] = $order;
                }
                $order = [$line];
            }
            else {
                $order[] = $line;
            }

            if ($line_no === count($lines) - 1) {
                $orders[] = $order;
            }
        }

        $exams = [];

        foreach ($orders as $order) {
            $order = $this->parseKeyValues(join(PHP_EOL, $order));
            $exam = [];

            preg_match('/(.*)\(CPT:\s*(.*)\)/', $order['order-name'], $matches);

            $study = isset($matches[1]) ? trim((string) $matches[1]) : $order['order-name'];

            $exam['placer_order_number'] = $order['order-id'];
            $exam['study'] = $study;
            $exam['procedure_code'] = $matches[2] ?? '';
            $exam['comment'] = $order['special-instructions'] ?? '';
            $exam['status'] = $order['order-status'] ?? '';
            $exam['priority'] = $order['priority'] ?? '';
            $exam['MultiDiagnosisList'] = [];
            $diagnoses = explode(';', $order['diagnosis']);
            foreach ($diagnoses as $diag) {
                preg_match('/(.*)\(ICD9:\s*(.*)\)\s*\(ICD10:\s*(.*)\)/', trim($diag), $matches);

                $desc = isset($matches[1]) && is_string($matches[1]) ? trim($matches[1]) : $diag;

                $exam['MultiDiagnosisList'][] = [
                    'code'          => $matches[3] ?? '',
                    'coding_type'   => 'ICD10',
                    'description'   => $desc
                ];
            }
            $exams[] = $exam;
        }

        return $exams;
    }
}
