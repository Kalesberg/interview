<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use Log;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * GGastro Order Parser
 * format: GGastro
 * type: Order
 */
class GGastro
{
    use HelperTrait;
    protected $format = 'GGastro';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Diagnostic\s*Studies/', $content)
            && preg_match('/Referring\s*Physician/', $content)
            && !preg_match('/Present\s*Illness:/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Diagnostic\s*Studies/i', $line)) {
                if (!isset($sep_line1)) {
                    $sep_line1 = $line_number;
                }
                else {
                    $sep_line2 = $line_number;
                }
            }
            elseif (preg_match('/Provider:/', $line)) {
                $sep_line1_1 = $line_number;
            }
            elseif (preg_match('/Referring\s*Physician/', $line)) {
                $sep_line1_2 = $line_number;
            }
            elseif (preg_match('/Electronically\s*signed/', $line)) {
                $sep_line3 = $line_number - 3;
            }
        }

        $lines = \array_slice($this->lines, $sep_line1 + 1, $sep_line1_1 - $sep_line1);
        $patient = $this->parseMultiKeyValues($lines);

        // Hot fix for parsing date
        $tmpCnt = 0;
        foreach ($patient as $field => $value) {
            $tmpCnt++;
            if ($tmpCnt === 2) {
                $patient['date'] .= ' ' . $field . ':' . $value;
                unset($patient[$field]);
            }
        }

        $normalized['patient'] = $patient;

        $lines = \array_slice($this->lines, $sep_line1_2, $sep_line2 - $sep_line1_2);
        $other = [];
        foreach ($lines as $line) {
            if (preg_match('/Insurance:/', $line)) {
                $isInsurance = true;
            }
            if (count($other) === 1) {
                $other[] = 'Address:' . $line;
            }
            elseif (count($other) === 2) {
                $other[] = 'Phones:' . $line;
            }
            else {
                if (isset($isInsurance) && $isInsurance) {
                    $line = preg_replace('/\b((?:(?!Insurance)\S)+)\s*:/', '$1#', $line);
                }
                $other[] = $line;
            }
        }
        $other = $this->parseKeyValues(implode("\n", $other));
        $normalized['other'] = $other;

        $lines = \array_slice($this->lines, $sep_line2, $sep_line3 - $sep_line2);
        $exams = [];
        foreach ($lines as $index => $line) {
            // Hot fix:  Assuming the Diagnostic Studies occupies 1 line of space..
            // We catch comment as $index = 1 of $lines
            if ($index == 1 && !preg_match('/A?llergies/', $line)) {
                $line = 'Comment:' . $line;
            }
            if (preg_match('/Diagnoses:/i', $line)) {
                $isDiagnoses = true;
            }
            if (isset($isDiagnoses) && $isDiagnoses) {
                $line = preg_replace('/\b((?:(?!(D|d)iagnoses)\S)+)\s*:/', '$1#', $line);
            }
            $exams[] = $line;
        }
        $exams = $this->parseKeyValues(implode("\n", $exams));
        $normalized['exams'] = $exams;

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['patient']['provider']);
        $phones = explode(',', $normalized['other']['phones'], 2);
        $data['referringDr']['phone1'] = $this->parsePhone($phones[0]);
        $data['referringDr']['phone2'] = $this->parsePhone($phones[1]);
        [$data['referringDr']['address'], $data['referringDr']['npi'], $data['referringDr']['phone1'], $data['referringDr']['fax']] = $this->getPhysician($data['referringDr']);

        $data['order']['PID'] = $normalized['patient']['account'];
        $data['order']['DateOfService'] = $normalized['patient']['date'] ? Carbon::parse($normalized['patient']['date'])->format('YmdHis') : '';

        $data['patient'] = $this->parseName($normalized['patient']['patient-name']);
        $dob = explode(' ', $normalized['patient']['dob-age'])[0];
        $data['patient']['DOB'] = $dob ? Carbon::parse($dob)->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['gender'][0]);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']);

        if (isset($normalized['other']['primary-insurance'])) {
            $parts = explode(',', $normalized['other']['primary-insurance']);
            $data['insuranceList'][0]['name'] = array_shift($parts);
            $data['insuranceList'][0]['insured'] = $data['patient'];
            foreach ($parts as $part) {
                $keyvalue = explode('#', $part, 2);
                switch ($this->slugify($keyvalue[0])) {
                    case 'policy-number':
                        $data['insuranceList'][0]['policy'] = $keyvalue[1];
                        break;
                    case 'patient-relationship':
                        $data['insuranceList'][0]['insured']['relation'] = $keyvalue[1];
                        break;
                    default:
                        break;
                }
            }
        }
        if (isset($normalized['other']['additional-insurance'])) {
            $parts = explode(',', $normalized['other']['additional-insurance']);
            $data['insuranceList'][1]['name'] = array_shift($parts);
            $data['insuranceList'][1]['insured'] = $data['patient'];
            foreach ($parts as $part) {
                $keyvalue = explode('#', $part, 2);
                switch ($this->slugify($keyvalue[0])) {
                    case 'policy-number':
                        $data['insuranceList'][1]['policy'] = $keyvalue[1];
                        break;
                    case 'patient-relationship':
                        $data['insuranceList'][1]['insured']['relation'] = $keyvalue[1];
                        break;
                    default:
                        break;
                }
            }
        }

        $exam = [
            'study'     => $normalized['exams']['diagnostic-studies'],
            'comment'   => $normalized['exams']['comment'] ?? ''
        ];
        $parts = explode(',', $normalized['exams']['diagnoses']);
        $diagnoses = [];
        foreach ($parts as $part) {
            $keyvalue = explode('#', $part, 2);
            if (strpos((string) $keyvalue[1], '-')) {
                $icd9 = trim(preg_split('/\s*-\s*/', (string) $keyvalue[1])[0]);
                $icd10 = trim(preg_split('/\s*-\s*/', (string) $keyvalue[1])[1]);
                $diagnoses[] = [
                    'code'          => $icd9,
                    'coding_type'   => 'ICD-9',
                    'description'   => trim((string) $keyvalue[0])
                ];
                $diagnoses[] = [
                    'code'          => $icd10,
                    'coding_type'   => 'ICD-10',
                    'description'   => trim((string) $keyvalue[0])
                ];
            }
            else {
                $diagnoses[] = [
                    'code'          => trim((string) $keyvalue[1]),
                    'coding_type'   => 'ICD',
                    'description'   => trim((string) $keyvalue[0])
                ];
            }
        }
        $exam['MultiDiagnosisList'] = $diagnoses;
        $data['exams'][] = $exam;

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }

    /**
     * Hard coded address and NPI for referring Dr.
     * This was necessary as the banner containing referring Dr. info isn't parsable. Thankfully this banner contains
     * a constant list of 11 physicians and address.
     *
     * @param array $refDr
     * @return array
     */
    protected function getPhysician(array $refDr): array
    {
        $physicians = [
            ['firstname' => 'Joseph', 'lastname' => 'Kittinger', 'NPI' => '1205882180'],
            ['firstname' => 'William', 'lastname' => 'King', 'NPI' => '1437105327'],
            ['firstname' => 'Robert', 'lastname' => 'Henihan', 'NPI' => '1912950403'],
            ['firstname' => 'Steven', 'lastname' => 'Klein', 'NPI' => '1922054733'],
            ['firstname' => 'D.', 'lastname' => 'Carney', 'NPI' => '1588866362'],
            ['firstname' => 'Mary', 'lastname' => 'Sauer', 'NPI' => ''],
            ['firstname' => 'Kunal', 'lastname' => 'Dalal', 'NPI' => '1497065338'],
            ['firstname' => 'Jean', 'lastname' => 'Nichols', 'NPI' => '1285681692'],
            ['firstname' => 'Stacey', 'lastname' => 'Pennington', 'NPI' => '1104870328'],
            ['firstname' => 'Heather', 'lastname' => 'Goldstein', 'NPI' => '1447204631'],
            ['firstname' => 'Wendy', 'lastname' => 'Landrigan', 'NPI' => '1316903495'],
            ['firstname' => 'Jennifer', 'lastname' => 'Preston', 'NPI' => '1073542502'],
            ['firstname' => 'Lesley', 'lastname' => 'Nevenzel', 'NPI' => '1093023228'],
            ['firstname' => 'Justin', 'lastname' => 'Toth', 'NPI' => '1952785131'],
            ['firstname' => 'Sarah', 'lastname' => 'Rydock', 'NPI' => '1528291762'],
            ['firstname' => 'Kate', 'lastname' => 'Wilson', 'NPI' => '1942718721'],
            ['firstname' => 'Rheanna', 'lastname' => 'McKnight', 'NPI' => '1508369620'],
        ];

        $address = ['address1' => '5115 Oleander Drive', 'city' => 'Wilmington', 'state' => 'NC', 'zip' => '28403'];
        $phone = '910-362-1011';
        $fax = '910-362-1012';

        // Search for element
        $npi = null;
        foreach ($physicians as $p) {
            if (strtolower($p['firstname']) === strtolower($refDr['firstname']) && strtolower($p['lastname']) === strtolower($refDr['lastname'])) {
                $npi = $p['NPI'];
                break;
            }
        }
        if (!$npi) {
            Log::error('Physician address/NPI can\'t be determined', [
                'type' => $this->template, 'format' => $this->format, 'physician' => $refDr]);
            return [null, null, null, null];
        }
        return [$address, $npi, $phone, $fax];
    }
}
