<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * ScriptSender Order Parser
 * format: ScriptSender_order
 * type: Order
 */
class ScriptSender
{
    use HelperTrait;
    protected $format = 'ScriptSender_';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches ScriptSender_ format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Script\s*Sender/', $content) && preg_match('/TEST ORDER ONLY/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $exam = [
            'procedure_code'      => '',
            'priority'            => '',
            'modality'            => '',
            'requested_exam'      => '',
            'clinical_indication' => '',
            'diagnosis_code'      => []
        ];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/\sOrder:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $order = trim($pieces[1]);
                $normalized['order']['accession'] = $order;
                $normalized['order']['placer_order_number'] = $order;
            }

            if (preg_match('/Patient\sName:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $fullName = trim($pieces[1]);
                $normalized['patient']['name'] = $fullName;
            }

            if (preg_match('/DOB:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $dob = trim($pieces[1]);
                $normalized['patient']['date_of_birth'] = $dob;
            }

            if (preg_match('/Patient\sPhone:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $phone = trim($pieces[1]);
                $normalized['patient']['phone'] = $phone;
            }

            if (preg_match('/Patient\sAddress:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $address = trim($pieces[1]);
                $normalized['patient']['address'] = $address;
            }

            if (preg_match('/MRN:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $mrn = trim($pieces[1]);
                $normalized['mrn'] = $mrn;
            }

            if (preg_match('/Referring\sPhysician:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $fullName = trim($pieces[1]);
                $normalized['referringDr']['name'] = $fullName;
            }

            if (preg_match('/Referring\sPhysician\sPhone:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $phone = trim($pieces[1]);
                $normalized['referringDr']['phone'] = $phone;
            }

            if (preg_match('/Referring\sPhysician\sGroup:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $facility = trim($pieces[1]);
                $normalized['referringDr']['sendingFacility'] = $facility;
            }

            if (preg_match('/\sNPI:\s/i', $line)) {
                preg_match('/\s[0-9]{5,}\s/', $line, $matches);

                if (isset($matches[0])) {
                    $normalized['referringDr']['npi'] = trim($matches[0]);
                }
            }

            if (preg_match('/Insurance\sAddress:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $address = trim($pieces[1]);
                $normalized['insurance']['address'] = $address;
            }

            if (preg_match('/Priority:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $priority = trim($pieces[1]);
                $exam['priority'] = $priority;
            }

            if (preg_match('/Modality:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $modality = trim($pieces[1]);
                $exam['modality'] = $modality;
            }

            if (preg_match('/Requested\sExam:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $req_exam = strTrim($pieces[1]);

                $is_procedure_code = preg_match('/[0-9]{3,}/', $req_exam, $matches);
                if ($is_procedure_code === 1) {
                    $exam['procedure_code'] = $matches[0];
                }

                $req_exam = preg_replace('/\d{2,}/', '', $req_exam);

                $exam['requested_exam'] = strTrim($req_exam);
            }

            if (preg_match('/Clinical\sIndication:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $indication = strTrim($pieces[1]);
                $exam['clinical_indication'] = $indication;
            }

            if (preg_match('/Diagnosis\sCode:\s*/i', $line)) {
                $pieces = explode(':', $line);
                $codes_str = strTrim($pieces[1]);
                $codes = explode(',', $codes_str);

                foreach ($codes as $code) {
                    $exam['diagnosis_code'][] = strTrim($code);
                }
            }

            if (preg_match('/Electronically\ssigned\sby:\s*/i', $line)) {
                preg_match('/\d{1,2}\/\d{1,2}\/\d{3,4}\s\d{1,2}:\d{1,2}:\d{1,2}\s[A-Z]{2}/i', $line, $matches);

                if (isset($matches[0])) {
                    $normalized['order']['DateOfService'] = strTrim($matches[0]);
                }
            }
        }

        foreach ($this->lines as $line_number => $line) {
            if (!isset($insurance_start) && preg_match('/Payment\sPreference/', $line)) {
                $insurance_start = $line_number;
            }

            if (!isset($insurance_end) && preg_match('/Insurance\sAddress/', $line)) {
                $insurance_end = $line_number;
            }
        }

        if (isset($insurance_start) && isset($insurance_end)) {
            $insurance_lines = array_slice($this->lines, $insurance_start, ($insurance_end - $insurance_start));
            $insurance = array_merge($normalized['insurance'], $this->parseMultiKeyValues($insurance_lines));
            $normalized['insurance'] = $insurance;
        }

        $normalized['exam'] = $exam;

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = 'Order';
        $data['meta']['document_format'] = 'ScriptSender';

        $data['order']['accession'] = $normalized['order']['accession'];
        $data['order']['placer_order_number'] = $normalized['order']['accession'];
        $data['order']['PID'] = $normalized['mrn'];

        $dateOfService = $normalized['order']['DateOfService'];

        $data['order']['DateOfService'] = Carbon::createFromFormat('n/j/Y g:i:s A', $dateOfService)->format('YmdHis');

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);

        $DOB = Carbon::createFromFormat('mdY', $normalized['patient']['date_of_birth'])->format('Ymd') . '000000';

        $data['patient']['DOB'] = $DOB;
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);

        $data['referringDr'] = $this->parseName($normalized['referringDr']['name']);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['referringDr']['phone']);
        $data['referringDr']['sendingFacility'] = $normalized['referringDr']['sendingFacility'];
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['referringDr']['phone']);
        $data['referringDr']['npi'] = $normalized['referringDr']['npi'];

        $relation = '';

        if ($normalized['insurance']['policy-holder'] === 'Self') {
            $relation = 'self';
        } elseif ($normalized['insurance']['policy-holder'] === 'Patient') {
            $relation = 'self';
        }

        $data['insuranceList'][0] = [
            'name' => $normalized['insurance']['insurance'],
            'insurance-address' => $normalized['insurance']['address'],
            'policy' => $normalized['insurance']['policy'],
            'insured' => [
                'relation' => $relation
            ]
        ];

        $data['exams'][0] = [
            'procedure_code' => $normalized['exam']['procedure_code'],
            'placer_order_number' => $normalized['exam']['procedure_code'],
            'study' => $normalized['exam']['requested_exam'],
            'comment' => $normalized['exam']['clinical_indication'],
            'priority' => $normalized['exam']['priority'],
            'MultiDiagnosisList' => []
        ];

        foreach ($normalized['exam']['diagnosis_code'] as $diag_code) {
            $data['exams'][0]['MultiDiagnosisList'][] = [
                'code' => trim($diag_code),
                'coding_type' => 'ICD10'
            ];
        }

        error_reporting(1);
        return $data;
    }
}
