<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * eRAD Order Parser
 * format: eRAD
 * type: Order
 */
class eRAD
{
    use HelperTrait;
    protected $format = 'eRAD';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches eRAD format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Script\sSender/', $content)
                && preg_match('/Healthcare\sSystem EHR/', $content)
                && preg_match('/Radiology\sExam\sRequest/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $this->fixOCR($content);
        $this->lines = explode("\n", $this->content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_no_start = 0;
        $line_no_end = 0;

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Order\s#:\s*/i', $line)) {
                $line_no_start = $line_number;
            }

            if (preg_match('/Referrer\sNotes:\s*/i', $line)) {
                $line_no_end = $line_number;
            }
        }

        $content_lines = [];

        foreach ($this->lines as $line_number => $line) {
            if ($line_number >= $line_no_start && $line_number <= $line_no_end && strlen(trim($line)) > 0) {
                $content_lines[] = $line;
            }
        }

        $key_values = $this->parseKeyValues(implode("\n", $content_lines));

        $referring_physician = $key_values['referring-physician'] ?? '';

        $normalized['order'] = $key_values['order'] ?? '';
        $normalized['patient_name'] = $key_values['patient-name'] ?? '';
        $normalized['patient_dob'] = $key_values['dob'] ? preg_replace('/\D/', '-', $key_values['dob']) : '';
        $normalized['patient_phone'] = $key_values['patient-phone'] ?? '';
        $normalized['patient_address'] = $key_values['patient-address'] ?? '';
        $normalized['patient_city'] = $key_values['patient-city'] ?? '';
        $normalized['patient_state'] = $key_values['patient-state'] ?? '';
        $normalized['patient_zip'] = $key_values['patient-zip'] ?? '';
        $normalized['pid'] = $key_values['mrn'] ?? '';
        $normalized['appointment_number'] = $key_values['appointment-number'] ?? '';
        $normalized['referring_physician'] = $this->fixDoctorTitle($referring_physician);
        $normalized['referring_physician_npi'] = $key_values['referring-physician-npi'] ?? '';
        $normalized['referring_physician_group'] = $key_values['referring-physician-group'] ?? '';
        $normalized['priority'] = $key_values['priority'] ?? '';
        $normalized['requested_exam'] = $key_values['requested-exam'] ?? '';
        $normalized['clinical_indication'] = $key_values['clinical-indication'] ?? '';
        $normalized['diagnosis_code'] = $key_values['diagnosis-code'] ?? '';
        $normalized['pre_cert'] = $key_values['pre-cert'] ?? '';
        $normalized['payment_preference'] = $key_values['payment-preference'] ?? '';
        $normalized['policy_holder'] = $key_values['policy-holder'] ?? '';
        $normalized['insurance'] = $key_values['insurance'] ?? '';
        $normalized['policy'] = $key_values['policy'] ?? '';
        $normalized['insurance_address'] = $key_values['insurance-address'] ?? '';

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = 'Order';
        $data['meta']['document_format'] = 'eRAD';

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['referring_physician']);
        $dob = Carbon::createFromFormat('m-d-Y', $normalized['patient_dob']);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $dob->format('Ymd') . '000000';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient_phone']);
        $data['patient']['address']['address1'] = $normalized['patient_address'];
        $data['patient']['address']['city'] = $normalized['patient_city'];
        $data['patient']['address']['state'] = $normalized['patient_state'];
        $data['patient']['address']['zip'] = $normalized['patient_zip'];

        $data['order']['accession'] = $normalized['order'];
        $data['order']['PID'] = $normalized['pid'];

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['npi'] = $normalized['referring_physician_npi'];
        $data['referringDr']['sendingFacility'] = $normalized['referring_physician_group'];

        $data['referringDr']['title'] = trim((string) $data['referringDr']['title']);

        $data['exams'][0]['priority'] = $normalized['priority'];
        $data['exams'][0]['study'] = $normalized['requested_exam'];
        $data['exams'][0]['comment'] = $normalized['clinical_indication'];

        $data['exams'][0]['MultiDiagnosisList'][0]['code'] = $normalized['diagnosis_code'];
        $data['exams'][0]['MultiDiagnosisList'][0]['coding_type'] = 'ICD10';

        $data['insuranceList'][0]['name'] = $normalized['insurance'];
        $data['insuranceList'][0]['insurance-address'] = $normalized['insurance_address'];
        $data['insuranceList'][0]['policy'] = $normalized['policy'];
        $data['insuranceList'][0]['insured']['relation'] = $normalized['policy_holder'];
        $data['insuranceList'][0]['authorization'] = $normalized['pre_cert'];

        error_reporting(1);
        return $data;
    }

    /**
     * Fixes some OCR "artifacts"
     *
     * @param  string $content Text OCRed content
     * @return string
     */
    private function fixOCR($content)
    {
        // They forgot to add : afte NPI in template
        $content = preg_replace('/\sReferring\sPhysician\sNPI\s/', ' Referring Physician NPI:', $content);

        // Drop-down arrow
        $content = preg_replace('/\s{20,60}o/', '', $content);

        return $content;
    }
}
