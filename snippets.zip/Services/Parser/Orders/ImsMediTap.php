<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * IMS MediTap Order Parser
 * format: IMSMediTap
 * type: Order
 */
class ImsMediTap
{
    use HelperTrait;
    protected $format = 'IMSMediTap';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches IMSMediTap format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/\s{1,}order/', $content)
            && preg_match('/PATIENT:.*DOB:.*SS#:/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_patient_start = 0;
        $line_patient_end = 0;
        $line_diagnosis = 0;
        $line_test = 0;
        $line_insurance_start = 0;
        $line_insurance_end = 0;
        $line_doctor = 0;

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/^\s*\d{1,2}\/\d{1,2}\/\d{4}/i', $line, $matches)) {
                $normalized['date_of_service'] = $matches[0] ?? '';
            }

            if (preg_match('/PATIENT:.*DOB:.*SS#:/i', $line)) {
                $line_patient_start = $line_number;
            }

            if (preg_match('/DIAGNOSIS:/i', $line)) {
                $line_patient_end = $line_number - 1;
                $line_diagnosis = $line_number + 1;
            }

            if (preg_match('/\s*TEST\s*\(S\)\s*:/i', $line)) {
                $line_test = $line_number + 1;
            }

            if (preg_match('/PRIMARY\sINSURANCE:/i', $line)) {
                $line_insurance_start = $line_number;
            }

            if (preg_match('/PATIENT\sINSURANCE\sID:/i', $line)) {
                $line_insurance_end = $line_number;
            }

            if (preg_match('/Sincerely,/i', $line)) {
                $line_doctor = $line_number + 1;
            }
        }

        $array_patient = [];
        $array_insurance = [];
        $array_doctor = [];

        for ($i = $line_patient_start; $i <= $line_patient_end; $i++) {
            $array_patient[] = $this->lines[$i];
        }

        for ($j = $line_insurance_start; $j <= $line_insurance_end; $j++) {
            $array_insurance[] = $this->lines[$j];
        }

        for ($k = $line_doctor; $k < count($this->lines); $k++) {
            if (!preg_match('/^file:.*/', $this->lines[$k])) {
                $array_doctor[] = $this->lines[$k];
            }
        }

        $array_patient = $this->trimArray($array_patient);
        $array_insurance = $this->trimArray($array_insurance);
        $array_doctor = $this->trimArray($array_doctor);

        $patient = $this->parseMultiKeyValues($array_patient);
        $normalized['patient_name'] = $patient['patient'] ?? '';
        $normalized['patient_dob'] = $patient['dob'] ?? '';
        $normalized['patient_address'] = $patient['patient-address'] ?? '';
        $normalized['patient_ssn'] = $patient['ss'] ?? '';

        $diag_line = trim((string) $this->lines[$line_diagnosis]);
        $diag_pieces = preg_split('/\s{2,}/', $diag_line);

        $normalized['diagnosis_code'] = trim($diag_pieces[0] ?? '');
        $normalized['diagnosis_description'] = trim($diag_pieces[1] ?? '');
        $normalized['study'] = trim((string) $this->lines[$line_test]);

        $insurance = $this->parseKeyValues(implode("\n", $array_insurance));

        $normalized['insurance'] = $insurance['primary-insurance'];
        $normalized['policy'] = $insurance['patient-insurance-id'];

        $normalized['referring_physician'] = implode(" ", $array_doctor);

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = 'Order';
        $data['meta']['document_format'] = $this->format;

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['referring_physician']);
        $dob = Carbon::createFromFormat('m/d/Y', trim($normalized['patient_dob']));
        $dos = Carbon::createFromFormat('m/d/Y', trim($normalized['date_of_service']));

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $dob->format('Ymd') . '000000';
        $data['patient']['address'] = $this->parseAddress($normalized['patient_address']);
        $data['patient']['SSN'] = $normalized['patient_ssn'];

        $data['order']['DateOfService'] = $dos->format('Ymd') . '000000';

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['title'] = trim((string) $data['referringDr']['title']);

        $data['exams'][0]['study'] = $normalized['study'];

        $data['exams'][0]['MultiDiagnosisList'][0]['code'] = $normalized['diagnosis_code'];
        $data['exams'][0]['MultiDiagnosisList'][0]['description'] = $normalized['diagnosis_description'];
        $data['exams'][0]['MultiDiagnosisList'][0]['coding_type'] = 'ICD10';

        $data['insuranceList'][0]['name'] = $normalized['insurance'];
        $data['insuranceList'][0]['policy'] = $normalized['policy'];

        error_reporting(1);
        return $data;
    }
}
