<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * format: PhoenixOrtho
 * type: Order
 */
class PhoenixOrtho
{
    use HelperTrait;
    protected $format = 'PhoenixOrtho';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Impression:/i', $content) &&
                preg_match('/Ordered by and Reviewed by:/i', $content) &&
                preg_match('/Provider:/i', $content) &&
                preg_match('/Date of Birth/i', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/\d{3}-\d{3}-\d{4}/', $line)) {
                $sep_line1 = $line_number+1;
            }
            elseif (preg_match('/Date:/', $line)) {
                $sep_line2 = $line_number;
            }
            elseif (preg_match('/Order:/i', $line)) {
                $sep_line3 = $line_number;
            }
            elseif (preg_match('/Impression:/i', $line)) {
                $sep_line4 = $line_number;
            }
            elseif (preg_match('/Ordered by/i', $line)) {
                $sep_line5 = $line_number;
            }
            elseif (preg_match('/Electronically\s*signed\s*on/', $line)) {
                $sep_line6 = $line_number;
            }
        }

        // Institute
        // $institute = [];
        // for ($n = 0; $n < $sep_line1; $n ++) {
        //     $line = trim($this->lines[$n]);
        //     if ($line == '') continue;
        //     $institute[] = $line;
        // }

        // Facility
        $normalized['facility'] = '';
        for ($n = $sep_line1; $n < $sep_line2; $n ++) {
            $line = trim($this->lines[$n]);
            $line = preg_replace('/[^\w\s\d]+/', '', $line);
            if ($line == '') continue;
            $normalized['facility'] .= trim($line).' ';
        }

        // Provider and Patient
        $pp = '';
        for ($n = $sep_line2; $n < $sep_line3; $n ++) {
            $line = trim($this->lines[$n]);
            if ($line == '') continue;
            $pp .= $line . "\n";
        }
        $normalized['pp'] = $this->parseKeyValues($pp);

        // Order
        $normalized['order'] = [];
        for ($n = $sep_line3+1; $n < $sep_line4; $n ++) {
            $line = trim($this->lines[$n]);
            if ($line == '' || !preg_match('/^\d+/', $line)) break;

            $normalized['order'][] = [explode(' ', $line, 2)[0], explode(' ', $line, 2)[1]];
        }

        // Impressions
        $normalized['impressions'] = [];
        for ($n = $sep_line4+1; $n < $sep_line5; $n ++) {
            $line = trim($this->lines[$n]);
            if ($line == '') continue;
            if (preg_match('/^[A-Z\.\d]+/', $line)) {
                $normalized['impressions'][] = [explode(' ', $line, 2)[0], explode(' ', $line, 2)[1]];
            }
            elseif (count($normalized['impressions'])) {
                $impression = array_pop($normalized['impressions']);
                $impression[1] .= ' ' . $line;
                array_push($normalized['impressions'], $impression);
            }
        }

        // Ordered Time
        $line = $this->lines[$sep_line6];
        preg_match('/Electronically\s*signed\s*on(.*)/', $line, $matches);
        $normalized['order-date'] = trim($matches[1]);

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['pp']['provider']);
        $data['referringDr']['sendingFacility'] = $normalized['facility'];

        $data['order']['DateOfService'] = $normalized['order-date'] ? Carbon::parse($normalized['order-date'])->format('YmdHis') : '';

        $patient = $this->parseName($normalized['pp']['patient-name']);
        $data['patient']['name'] = $patient['name'];
        $data['patient']['firstname'] = $patient['firstname'];
        $data['patient']['middlename'] = $patient['middlename'];
        $data['patient']['lastname'] = $patient['lastname'];
        $data['patient']['DOB'] = $normalized['pp']['date-of-birth'] ? Carbon::parse($normalized['pp']['date-of-birth'])->format('YmdHis') : '';
        $data['patient']['address'] = $this->parseAddress($normalized['pp']['address']);

        // $data['exams'][0]['comment'] = $normalized['order'];
        $data['exams'] = [];
        $provider = $this->parseName($normalized['pp']['provider']);
        foreach ($normalized['order'] as $ex) {
            $exam = [
                'procedure_code'    => $ex[0],
                'study'             => trim($ex[1]),
                'approving_provider'=> $provider
            ];
            $diagnoses = [];
            foreach ($normalized['impressions'] as $impression) {
                $diagnoses[] = [
                    'code'          => $impression[0],
                    'description'   => trim($impression[1])
                ];
            }
            $exam['MultiDiagnosisList'] = $diagnoses;
            $data['exams'][] = $exam;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
