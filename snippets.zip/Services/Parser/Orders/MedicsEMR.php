<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * MedicsEMR Parser
 * format: MedicsEMR
 * type: Order
 */
class MedicsEMR
{
    use HelperTrait;
    protected $format = 'MedicsEMR';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches MedicsEMR format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/\s*RADIOLOGY\sORDERS/', $content)
            && preg_match('/Patient:.*Encounter Date:.*/i', $content)
            && preg_match('/DOB:.*Provider:.*/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_header_start = 0;
        $line_header_end = 0;

        $line_data_start = 0;
        $line_data_end = 0;

        $line_table_start = 0;
        $line_table_end = 0;

        $line_codes_start = 0;
        $line_codes_end = 0;

        foreach ($this->lines as $no => $line) {
            if (preg_match('/^\d{1,2}\/\d{1,2}\/\d{4}.*\(([0-9]{1,3})yrs\/(.*)\)/i', $line, $matches)) {
                if (count($matches) === 3) {
                    $normalized['patient_age'] = trim((string) $matches[1]);
                    $normalized['patient_gender'] = trim((string) $matches[2]);
                }

                $line_header_start = $no + 1;
            }

            if (preg_match('/\sRADIOLOGY\sORDERS/i', $line)) {
                $line_data_start = $no + 1;
                $line_header_end = $no - 1;
            }

            if (preg_match('/Patient Phone:/i', $line)) {
                $line_data_end = $no + 1;
            }

            if (preg_match('/Order\sDate\s*Description\s*Lab Name/i', $line)) {
                $line_table_start = $no;
            }

            if (preg_match('/ICD CODES/i', $line)) {
                $line_table_end = $no - 1;
                $line_codes_start = $no + 1;
            }

            if (preg_match('/\s?Code\s*Description/i', $line)) {
                $line_codes_start = $no + 1;
            }

            if (preg_match('/Medical\sNecessities:/i', $line)) {
                $line_codes_end = $no - 1;
            }
        }

        $header_length = $line_header_end - $line_header_start;
        $header = array_slice($this->lines, $line_header_start, $header_length);
        $header = $this->trimArray($header);

        $data_length = $line_data_end - $line_data_start;
        $data = array_slice($this->lines, $line_data_start, $data_length);

        $table_length = $line_table_end - $line_table_start;
        $table = array_slice($this->lines, $line_table_start, $table_length);

        $codes_length = $line_codes_end - $line_codes_start;
        $codes = array_slice($this->lines, $line_codes_start, $codes_length);

        $normalized['doctor_facility'] = $header[0] ?? '';

        if (isset($header[1]) && !empty($header[1])) {
            $normalized['doctor_address'] = str_replace('*', ',', $header[1]);
        }

        foreach ($header as $line) {
            if (preg_match('/Telephone(.*)\s\*\sFax(.*)/', $line, $matches)) {
                $normalized['doctor_phone'] = $matches[1] ?? '';
                $normalized['doctor_fax'] = $matches[2] ?? '';
            }
        }

        foreach ($data as $no => $line) {
            if (preg_match('/Patient:\s{1,}(.*)\s{10,}/i', $line, $matches)) {
                if (count($matches) === 2) {
                    $normalized['patient_name'] = trim((string) $matches[1]);
                }
            }

            if (preg_match('/DOB:\s{1,}(\d{2}\/\d{2}\/\d{4})\s{10,}/i', $line, $matches)) {
                if (count($matches) === 2) {
                    $normalized['patient_dob'] = trim((string) $matches[1]);
                }
            }

            if (preg_match('/Encounter Date:(.*)$/i', $line, $matches)) {
                if (count($matches) === 2) {
                    $normalized['order_date'] = trim((string) $matches[1]);
                }
            }

            if (preg_match('/Provider:(.*)$/i', $line, $matches)) {
                if (count($matches) === 2) {
                    $normalized['doctor_name'] = trim((string) $matches[1]);
                }
            }

            if (preg_match('/Patient Phone:(.*)$/i', $line, $matches)) {
                if (count($matches) === 2) {
                    $normalized['patient_phone'] = trim((string) $matches[1]);
                }
            }

            if (preg_match('/Address:(.*)$/i', $line, $matches)) {
                if (count($matches) === 2) {
                    $normalized['patient_address'] = trim((string) $matches[1]);

                    if (isset($data[$no + 1]) && !preg_match('/:/', $data[$no + 1])) {
                        $part = preg_replace('/\./', '', $data[$no + 1]);
                        $part = trim((string) $part);
                        $normalized['patient_address'] .= ' ' . $part;
                    }
                }
            }
        }

        $normalized['exams'] = [];

        $rows_start_line = [];
        $rows_dates = [];
        $icd_codes = [];

        foreach ($table as $no => $line) {
            if (preg_match('/\s{5,23}(\w*-|\w*\s-)/', $line)) {
                $rows_start_line[] = $no;
            }

            if (preg_match('/\s{1,}(\d{2}\/\d{2}\/\d{4})/', $line, $matches)) {
                if (isset($matches[1])) {
                    $rows_dates[] = trim((string) $matches[1]);
                }
            }

            if (preg_match('/\s{8,}(\d{4,7})\s+/', $line, $matches)) {
                if (isset($matches[1])) {
                    $rows_cpt[] = trim((string) $matches[1]);
                }
            }

            $table[$no] = preg_replace('@\d{2}/\d{2}/\d{4}@', str_repeat(' ', 10), $line);
        }

        foreach ($rows_start_line as $i => $line) {
            $date = trim((string) $rows_dates[$i]);

            if (strlen($date) === 0) {
                continue;
            }

            $table[$line] = preg_replace('/^(\s{1,4})(\s{10})/', '${1}' . $date, $table[$line]);
        }

        foreach ($table as $no => $line) {
            if (preg_match('/\s{8,}([A-z0-9]+\.[A-z0-9]+)-/', $line, $matches)) {
                if (isset($matches[1])) {
                    $dif_min = 100;
                    $closer_row = null;

                    foreach ($rows_start_line as $row_start) {
                        $dif = $row_start - $no;

                        if ($dif < 0) {
                            $dif = $dif * -1;
                        }

                        if ($dif < $dif_min) {
                            $dif_min = $dif;
                            $closer_row = $row_start;
                        }
                    }

                    $code = preg_replace('/^1/', 'I', $matches[1]);
                    $icd_codes[$closer_row][] = $code;
                }
            }
        }

        $order_column_start = strpos($table[0], 'Order Date');
        $description_column_start = strpos($table[0], 'Description');
        $lab_column_start = strpos($table[0], 'Lab Name');
        $side_column_start = strpos($table[0], 'Side');
        $cpt_column_start = strpos($table[0], 'CPT Code');
        $icd_column_start = strpos($table[0], 'ICD Code');

        foreach ($table as $no => $line) {
            if (strlen($line) > $icd_column_start) {
                $table[$no] = substr($line, 0, $icd_column_start - 1);
            }

            if (in_array($no, $rows_start_line)) {
                $table[$no][$lab_column_start] = '-';
                $table[$no][$side_column_start] = '-';
            }
        }

        $table_rows = [];
        $table_data = [];

        for ($i = 0; $i < count($rows_start_line); $i++) {
            if ($i === count($rows_start_line) - 1) {
                $max = count($table);
            } else {
                $max = $rows_start_line[$i + 1];
            }

            $length = $max - $rows_start_line[$i];
            $table_rows[] = array_slice($table, $rows_start_line[$i], $length);
        }

        $icd_codes_order = [];
        $c = 0;
        foreach ($icd_codes as $closer_row => $row_codes) {
            $icd_codes_order[$c] = $row_codes;
            $c++;
        }

        foreach ($table_rows as $j => $rows) {
            $tmp = [
                'order' => '',
                'description' => '',
                'lab' => '',
                'side' => '',
                'cpt' => '',
                'icd' => []
            ];

            foreach ($rows as $row) {
                $order = substr($row, 0, $description_column_start - 1);
                $description = substr($row, $description_column_start, ($lab_column_start - $description_column_start));
                $lab = substr($row, $lab_column_start, ($side_column_start - $lab_column_start));
                $side = substr($row, $side_column_start, ($side_column_start - $cpt_column_start));
                $cpt = substr($row, $cpt_column_start, ($icd_column_start - $cpt_column_start));

                $order = $order ? trim((string) $order) : '';
                $description = $description ? trim((string) $description) : '';
                $lab = $lab ? trim((string) $lab) : '';
                $side = $side ? trim((string) $side) : '';
                $cpt = $cpt ? trim((string) $cpt) : '';

                if (!empty($order)) {
                    $tmp['order'] .= $order;
                }

                if (!empty($description)) {
                    $tmp['description'] .= ' ' . $description;
                    $tmp['description'] = trim($tmp['description']);
                }

                if (!empty($lab) && $lab !== '-') {
                    $tmp['lab'] .= ' ' . $lab;
                    $tmp['lab'] = trim($tmp['lab']);
                }

                if (!empty($side) && $side !== '-') {
                    $tmp['side'] .= ' ' . $lab;
                    $tmp['side'] = trim($tmp['side']);
                }

                if (!empty($cpt) && $cpt !== '-') {
                    $tmp['cpt'] .= ' ' . $cpt;
                    $tmp['cpt'] = trim($tmp['cpt']);
                }
            }

            $tmp['icd'] = $icd_codes_order[$j];
            $table_data[] = $tmp;
        }

        $codes_data = [];

        for ($k = 0; $k < count($codes); $k++) {
            $code = '';
            $description = '';

            if (preg_match('/^\s{6,}.*/', $codes[$k])) {
                // multi row
                $description = trim((string) $codes[$k]);
                $description .= ' ' . trim((string) $codes[$k + 2]);
                $code = trim((string) $codes[$k + 1]);

                $k = $k + 2;
            } elseif (preg_match('/\s{1,5}([A-z0-9]+\.[A-z0-9]{1,3})\s*(.*)/', $codes[$k], $matches)) {
                // single row
                $code = $matches[1] ?? '';
                $description = $matches[2] ?? '';
            }

            $code = preg_replace('/^1/', 'I', $code);
            $codes_data[$code] = $description;
        }

        foreach ($table_data as $exam) {
            $exam_item = [
                'code' => $exam['cpt'],
                'study' => $exam['description'],
                'date' => $exam['order'],
                'diag_list' => []
            ];

            foreach ($exam['icd'] as $diag_code) {
                $exam_item['diag_list'][] = [
                    'code' => $diag_code,
                    'desc' => $codes_data[$diag_code]
                ];
            }

            $normalized['exams'][] = $exam_item;
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        if (count($normalized['exams']) > 1) {
            for ($i = 1; $i < count($normalized['exams']); $i++) {
                $data['exams'][$i] = $data['exams'][0];
            }
        }

        $data['meta']['document_type'] = 'Order';
        $data['meta']['document_format'] = $this->format;

        if (!empty($normalized['order_date'])) {
            $date = Carbon::createFromFormat('m/d/Y h:i:s A', $normalized['order_date']);
            $data['order']['DateOfService'] = $date->format('YmdHis');
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['doctor_name']);

        if (!empty($normalized['patient_dob'])) {
            $date = Carbon::createFromFormat('m/d/Y', $normalized['patient_dob']);
            $patient_dob = $date->format('Ymd') . '000000';
        }

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patient_dob ?? '';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient_phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient_address']);
        $data['patient']['age'] = $normalized['patient_age'];
        $data['patient']['sex'] = $this->parseGender($normalized['patient_gender']);

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor_phone']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor_fax']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor_address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor_facility'];

        unset($data['insuranceList'][0]);

        for ($i = 0; $i < count($normalized['exams']); $i++) {
            if (!empty($normalized['exams'][$i]['date'])) {
                $date = Carbon::createFromFormat('m/d/Y', $normalized['exams'][$i]['date']);
                $exam_date = $date->format('Ymd') . '000000';
            }

            $data['exams'][$i]['procedure_code'] = $normalized['exams'][$i]['code'];
            $data['exams'][$i]['DateOfEncounter'] = $exam_date ?? '';
            $data['exams'][$i]['study'] = $normalized['exams'][$i]['study'];
            $data['exams'][$i]['MultiDiagnosisList'] = [];

            if (count($normalized['exams'][$i]['diag_list']) > 0) {
                foreach ($normalized['exams'][$i]['diag_list'] as $diag) {
                    $data['exams'][$i]['MultiDiagnosisList'][] = [
                        'code' => $diag['code'],
                        'description' => $diag['desc'],
                        'coding_type' => 'ICD10'
                    ];
                }
            }
        }

        error_reporting(1);
        return $data;
    }
}
