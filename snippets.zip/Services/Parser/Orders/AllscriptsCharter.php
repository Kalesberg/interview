<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * AllscriptsCharter Order Parser
 * format: Allscripts
 * type: Order
 */
class AllscriptsCharter
{
    use HelperTrait;
    protected $format = 'AllscriptsCharter';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches AllscriptsCharter format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Bill\s*To\s*:/i', $content) &&
            preg_match('/Requisition\s*Date/i', $content) &&
            preg_match('/Code\/(Procedures|Tests)/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];
        
        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Req\s*#:?/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line1 = $line_number;
                $sep_pos1 = $matches[0][1];
            }
            elseif (preg_match('/Patient\s*Information/i', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line2 = $line_number;
                $sep_pos2 = $matches[0][1] - 2;
            }
            elseif (preg_match('/Insurance\s*-\s*Primary/', $line)) {
                $sep_line3 = $line_number;
                preg_match('/(Subscriber\s*-\s*Primary).*(Insurance\s*-\s*Secondary).*(Subscriber\s*-\s*Secondary)/', $line, $matches, PREG_OFFSET_CAPTURE);
                $sep_pos3_1 = $matches[1][1];
                $sep_pos3_2 = $matches[2][1];
                $sep_pos3_3 = $matches[3][1];
            }
            elseif (preg_match('/Code\/(Procedures|Tests)/i', $line)) {
                $sep_line4 = $line_number;
            }
            elseif (preg_match('/End\s*of\s*tests\s*ordered/', $line)) {
                $sep_line5 = $line_number;
            }
        }

        // Order information
        $lines = array_slice($this->lines, $sep_line1, $sep_line2 - $sep_line1);
        $order = $this->parseMultiKeyValues($lines);
        $normalized['order'] = $order;

        /* Doctor and Patient information */
        $lines = array_slice($this->lines, $sep_line2, $sep_line3 - $sep_line2);
        $left = $right = [];
        foreach ($lines as $line) {
            $l = substr($line, 0, $sep_pos2);
            $r = substr($line, $sep_pos2);
            $left[] = $l; $right[] = $r;
        }
        $left = $this->trimArray($left);
        $right = $this->trimArray($right);

        // Doctor infomation
        $doctor = [];
        $doctor['name'] = $this->getValue(['search' => 'ordering\s*physician', 'lines' => $left]);
        $doctor['name'] = preg_replace('/\s+\S+$/', ',$0', $doctor['name']);
        $doctor['npi'] = trim($this->getValue(['search' => '\bNPI\b', 'lines' => $left]), ')');
        $doctor['address'] = $left[2] . ', ' . $left[3];
        $doctor['phone'] = $left[4];
        $normalized['doctor'] = $doctor;
        // Patient information
        $patient = [];
        $lines = array_slice($right, 1, 4);
        $patient['id'] = $this->getValue(['search' => 'Patient\s*ID', 'lines' => $right]);
        if (empty($patient['id'])) {
            $id = $this->getValue(['search' => '\bID\b', 'lines' => $right]);
            $patient['id'] = explode(' ', $id)[0];
            $lines = array_slice($right, 2, 4);
        }
        $temp_pos = 0;
        foreach ($lines as $line) {
            if (preg_match('/DOB\s*:/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $temp_pos = $matches[0][1];
            }
        }
        $ll = $rr = [];
        foreach ($lines as $line) {
            $ll[] = substr($line, 0, $temp_pos);
            $rr[] = substr($line, $temp_pos);
        }
        $patient = array_merge($patient, $this->parseKeyValues(join("\n", $rr)));
        $patient['name'] = $ll[0];
        $patient['address'] = $ll[1] . ', ' . $ll[2];
        $patient['phone'] = $ll[3];
        $normalized['patient'] = $patient;

        // Insurance information
        $lines = $this->trimArray(array_slice($this->lines, $sep_line3 + 1, $sep_line4 - $sep_line3 - 1), true);
        $block1 = $block2 = $block3 = $block4 = [];
        foreach ($lines as $line) {
            $block1[] = (string) substr($line, 0, $sep_pos3_1);
            $block2[] = (string) substr($line, $sep_pos3_1, $sep_pos3_2 - $sep_pos3_1);
            $block3[] = (string) substr($line, $sep_pos3_2, $sep_pos3_3 - $sep_pos3_2);
            $block4[] = (string) substr($line, $sep_pos3_3);
        }
        $temp = $this->parseKeyValues(join("\n", $block1));
        if (!empty($temp['carrier-code'])) {
            $ins = $this->parseKeyValues(join("\n", $block2));
            $ins['ins-name'] = trim(preg_replace('/\s+/', ' ', $block1[1] . ' ' . $block1[2]));
            $ins['ins-addr'] = trim(preg_replace('/\s+/', ' ', $block1[3] . ', ' . $block1[4]));
            $ins['plan'] = trim(explode(',', $ins['plan'])[0]);
            $normalized['ins1'] = $ins;
        }
        $temp = $this->parseKeyValues(join("\n", $block3));
        if (!empty($temp['carrier-code'])) {
            $ins = $this->parseKeyValues(join("\n", $block4));
            $ins['ins-name'] = trim(preg_replace('/\s+/', ' ', $block3[1] . ' ' . $block3[2]));
            $ins['ins-addr'] = trim(preg_replace('/\s+/', ' ', $block3[3] . ', ' . $block3[4]));
            $ins['plan'] = trim(explode(',', $temp['plan'])[0]);
            $normalized['ins2'] = $ins;
        }

        // Exams information
        $lines = $this->trimArray(array_slice($this->lines, $sep_line4 + 1, $sep_line5 - $sep_line4 - 1));
        $normalized['exams'] = $exam = [];
        foreach ($lines as $line) {
            if (preg_match('/^Diagnosis\s*:\s*(.*)\((.*)\)$/', $line, $matches)) {
                $exam['desc'] = trim($matches[1]);
                $exam['icd'] = trim($matches[2]);
                $normalized['exams'][] = $exam;
                $exam = [];
            }
            elseif (preg_match('/^Note\s*:/', $line)) {
                $exam['note'] = explode(':', $line)[1];
            }
            else {
                $exam['code'] = trim(explode(':', $line)[0]);
                $exam['study'] = trim(explode(':', $line)[1]);
            }
        }

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor']['name']);
        $data['referringDr']['npi'] = $normalized['doctor']['npi'];
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);

        $data['order']['accession'] = $normalized['order']['req'];
        $data['order']['DateOfService'] = $normalized['order']['ordered'] ? Carbon::parse($normalized['order']['ordered'])->format('YmdHis') : '';
        $data['order']['PID'] = $normalized['patient']['id'];

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['code'] = $normalized['patient']['id'];
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address']);
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex'][0]);
        $data['patient']['SSN'] = $normalized['patient']['ssn'];
        $data['patient']['race'] = $normalized['patient']['race'];

        $data['insuranceList'] = [];
        if (isset($normalized['ins1'])) {
            $data['insuranceList'][] = [
                'name'              => $normalized['ins1']['ins-name'],
                'insurance-address' => $normalized['ins1']['ins-addr'],
                'insured'           => $data['patient'],
                'policy'            => $normalized['ins1']['plan'],
                'subscriber'        => $normalized['ins1']['group']
            ];
            $data['insuranceList'][0]['insured']['relation'] = $normalized['ins1']['insured'];
        }
        if (isset($normalized['ins2'])) {
            $data['insuranceList'][] = [
                'name'              => $normalized['ins2']['ins-name'],
                'insurance-address' => $normalized['ins2']['ins-addr'],
                'insured'           => $data['patient'],
                'policy'            => $normalized['ins2']['plan'],
                'subscriber'        => $normalized['ins2']['group']
            ];
            $data['insuranceList'][1]['insured']['relation'] = $normalized['ins2']['insured'];
        }

        foreach ($normalized['exams'] as $exam) {
            $data['exams'][] = [
                'procedure_code'    => $exam['code'],
                'study'             => $exam['study'],
                'comment'           => $exam['note'] ?? '',
                'MultiDiagnosisList'=> [[
                    'coding_type'   => 'ICD10',
                    'code'          => $exam['icd'],
                    'description'   => $exam['desc']
                ]],
                'approving_provider'=> $data['referringDr']
            ];
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
