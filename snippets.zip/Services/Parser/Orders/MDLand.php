<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * MDLand Order Parser
 * format: MDLand
 * type: Order
 */
class MDLand
{
    use HelperTrait;
    protected $format = 'MDLand';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches MDLand format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/phone: home.*work.*mobil.*email/i', $content)
            && preg_match('/NAME.*GENDER.*DOB.*AGE\sAS\sOF.*/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_patient_start = 0;
        $line_patient_end = 0;

        $line_clinic_start = 0;
        $line_clinic_end = 0;

        $line_billing_start = 0;
        $line_billing_end = 0;

        $line_imgorder_start = 0;
        $line_imgorder_end = 0;

        $line_order_start = 0;
        $line_order_end = 0;

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/NAME.*GENDER.*DOB/i', $line)) {
                $line_patient_start = $line_number;
            }

            if (preg_match('/Lab\sInformation/i', $line)) {
                $line_patient_end = $line_number;
            }

            if (preg_match('/Clinic\sInformation/i', $line)) {
                $line_clinic_start = $line_number + 1;
            }

            if (preg_match('/Patient\sInformation/i', $line)) {
                $line_clinic_end = $line_number;
            }

            if (preg_match('/Billing\sInformation/i', $line)) {
                $line_billing_start = $line_number + 1;
            }

            if (preg_match('/Imaging\sOrder/i', $line)) {
                $line_billing_end = $line_number;
                $line_imgorder_start = $line_number + 1;
            }

            if (preg_match('/Order\sDetail/i', $line)) {
                $line_imgorder_end = $line_number - 1;
                $line_order_start = $line_number + 1;
            }

            if (preg_match('/Electronically\ssigned\sby/i', $line)) {
                $line_order_end = $line_number;

                preg_match('/Electronically\ssigned\sby\s(.*)$/i', $line, $matches);
                $normalized['doctor_name'] = $matches[1] ?? '';
            }
        }

        $patient_length = $line_patient_end - $line_patient_start;
        $patient = array_slice($this->lines, $line_patient_start, $patient_length);
        $patient = $this->trimArray($patient);

        $clinic_length = $line_clinic_end - $line_clinic_start;
        $clinic = array_slice($this->lines, $line_clinic_start, $clinic_length);
        $clinic = $this->trimArray($clinic);

        $imgorder_length = $line_imgorder_end - $line_imgorder_start;
        $imgorder = array_slice($this->lines, $line_imgorder_start, $imgorder_length);
        $imgorder = $this->trimArray($imgorder);

        $billing_length = $line_billing_end - $line_billing_start;
        $billing = array_slice($this->lines, $line_billing_start, $billing_length);
        $billing = $this->trimArray($billing);

        $order_length = $line_order_end - $line_order_start;
        $order = array_slice($this->lines, $line_order_start, $order_length);

        $order[0] = str_replace('|', ' ', $order[0]);

        $header_columns = preg_split('/\s{3,}/', $order[0], -1, PREG_SPLIT_NO_EMPTY);
        $header_column_position = [];

        foreach ($header_columns as $column) {
            $header_column_position[$column] = strpos($order[0], $column);
        }

        $header_columns_available = [];

        $lines = [];

        for ($i = 1; $i < count($order); $i++) {
            $lines[] = $order[$i];

            foreach ($header_column_position as $column => $pos) {
                $char1 = trim((string) $order[$i][$pos]);
                $char2 = isset($order[$i][$pos - 1]) ? trim((string) $order[$i][$pos - 1]) : '';
                $char3 = isset($order[$i][$pos + 1]) ? trim((string) $order[$i][$pos + 1]) : '';
                $char4 = isset($order[$i][$pos - 2]) ? trim((string) $order[$i][$pos - 2]) : '';
                $char5 = isset($order[$i][$pos + 2]) ? trim((string) $order[$i][$pos + 2]) : '';

                if (strlen($char1) > 0
                    || strlen($char2) > 0
                    || strlen($char3) > 0
                    || strlen($char4) > 0
                    || strlen($char5) > 0) {
                    if (!in_array($column, $header_columns_available)) {
                        $header_columns_available[] = $column;
                    }
                }
            }
        }

        foreach ($header_columns as $column) {
            if (!in_array($column, $header_columns_available)) {
                $order[0] = str_replace($column, str_repeat(' ', strlen($column)), $order[0]);
            }
        }

        $order_rows = [];
        for ($i = 1; $i < count($order); $i++) {
            $split = preg_split('/\s{5,}/', trim($order[$i]));
            $tmp = [];

            for ($j = 0; $j < count($header_columns_available); $j++) {
                $tmp[$this->slugify($header_columns_available[$j])] = $split[$j] ?? '';
            }

            $order_rows[] = $tmp;
        }

        $normalized['exams'] = $order_rows;

        foreach ($patient as $pline_number => $pline) {
            if (preg_match('/NAME.*GENDER.*DOB/i', $pline)) {
                $str = $patient[$pline_number];
                $patient[$pline_number] = preg_replace('/AGE\sAS\sOF\s\d{1,2}\/\d{1,2}\/\d{4}:/i', 'AGE:', $str);
            }
        }

        $patient_values = $this->parseMultiKeyValues($patient);

        $normalized['order_pid'] = $patient_values['chart-num'] ?? '';

        $patient_address = $patient_values['address'] ?? '';

        if (!empty($patient_address)) {
            $patient_address = $this->fixAddressString($patient_address);
        }

        $normalized['patient_name']    = $patient_values['name'] ?? '';
        $normalized['patient_gender']  = $patient_values['gender'] ?? '';
        $normalized['patient_dob']     = $patient_values['dob'] ?? '';
        $normalized['patient_age']     = $patient_values['age'] ?? '';
        $normalized['patient_phone']   = $patient_values['tel'] ?? '';
        $normalized['patient_address'] = $patient_address;

        $clinic_key_values = [];
        $clinic_str_values = [];
        foreach ($clinic as $cline) {
            if (preg_match('/^Account\sNo|^Tel|^Fax/i', $cline)) {
                $clinic_key_values[] = $cline;
            } else {
                $clinic_str_values[] = $cline;
            }
        }
        $address = $clinic_str_values[1] ?? '';

        if (isset($clinic_str_values[2]) && !empty($clinic_str_values[2])) {
            $address .= (!empty($address) ? ', ' : '') . $clinic_str_values[2];
        }

        $normalized['doctor_facility'] = $clinic_str_values[0] ?? '';
        $normalized['doctor_address'] = $this->fixAddressString($address);

        $clinic_values = $this->parseKeyValues(implode(PHP_EOL, $clinic_key_values));

        $normalized['doctor_phone'] = $clinic_values['tel'];
        $normalized['doctor_fax'] = $clinic_values['fax'];

        $imgorder_values = $this->parseKeyValues(implode(PHP_EOL, $imgorder));
        $normalized['order_date'] = $imgorder_values['order-date'];

        $insurance_array = [];

        foreach ($billing as $no => $line) {
            if (preg_match('/First\sInsurance:/i', $line)) {
                $slice = array_slice($billing, $no + 1, 2);
                $insurance_array[] = implode(' ', $slice);
            }

            if (preg_match('/Secondary\sInsurance:/i', $line)) {
                $slice = array_slice($billing, $no + 1, 2);
                $insurance_array[] = implode(' ', $slice);
            }
        }

        $insurance_array = $this->trimArray($insurance_array);
        $normalized['insurance'] = [];

        foreach ($insurance_array as $line) {
            $tmp = [];

            preg_match('/^(.*)\([A-Z]\)\sInsured Name.*/i', $line, $matches);
            $tmp['name'] = isset($matches[1]) ? trim((string) $matches[1]) : '';

            preg_match('/Insured Name[:|;](.*)\sInsuredID[:|;]/i', $line, $matches);
            $tmp['insured'] = isset($matches[1]) ? trim((string) $matches[1]) : '';

            preg_match('/PolicyNumber[:|;](.*)\sExpDate[:|;]/i', $line, $matches);
            $tmp['policy'] = isset($matches[1]) ? trim((string) $matches[1]) : '';

            $normalized['insurance'][] = $tmp;
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = $this->type;
        $data['meta']['document_format'] = $this->format;

        $data['order']['PID'] = $normalized['order_pid'];

        if (count($normalized['insurance']) > 1) {
            for ($i = 1; $i < count($normalized['insurance']); $i++) {
                $data['insuranceList'][$i] = $data['insuranceList'][0];
            }
        }

        if (count($normalized['exams']) > 1) {
            for ($i = 1; $i < count($normalized['exams']); $i++) {
                $data['exams'][$i] = $data['exams'][0];
            }
        }

        if (!empty($normalized['order_date'])) {
            $dos = Carbon::createFromFormat('m/d/Y', $normalized['order_date']);
            $data['order']['DateOfService'] = $dos->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['doctor_name']);

        if (isset($normalized['patient_dob'])) {
            $date = Carbon::createFromFormat('m/d/Y', $normalized['patient_dob']);
            $patient_dob = $date->format('Ymd') . '000000';
        }

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patient_dob ?? '';
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient_phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient_address']);
        $data['patient']['sex'] = $this->parseGender($normalized['patient_gender']);
        $data['patient']['age'] = $normalized['patient_age'];

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $normalized['doctor_phone'];
        $data['referringDr']['phone2'] = $normalized['doctor_fax'];
        $data['referringDr']['npi'] = $normalized['provider_npi'];
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor_address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor_facility'];

        foreach ($normalized['insurance'] as $c => $i) {
            $holder = $this->parseName($i['insured']);

            $data['insuranceList'][$c]['name'] = $i['name'];
            $data['insuranceList'][$c]['policy'] = $i['policy'];
            $data['insuranceList'][$c]['insured']['name'] = $holder['name'];
            $data['insuranceList'][$c]['insured']['firstname'] = $holder['firstname'];
            $data['insuranceList'][$c]['insured']['middlename'] = $holder['middlename'];
            $data['insuranceList'][$c]['insured']['lastname'] = $holder['lastname'];
            $data['insuranceList'][$c]['insured']['title'] = $holder['title'];
        }

        foreach ($normalized['exams'] as $c => $e) {
            $data['exams'][$c]['comment'] = $e['category'] ?? '';
            $data['exams'][$c]['study'] = (string) $e['lab-name'];
            $data['exams'][$c]['procedure_code'] = isset($e['lab-code']) ? trim((string) $e['lab-code']) : '';

            if (isset($e['icd'])) {
                $data['exams'][$c]['MultiDiagnosisList'][0]['code'] = (string) $e['icd'];
                $data['exams'][$c]['MultiDiagnosisList'][0]['coding_type'] = 'ICD10';
            }
        }

        error_reporting(1);
        return $data;
    }

    /**
     * Makes sure the address contains a "," between the city and the state abbreviation, otherwise
     * the parseAddress method won't parse it correctly.
     *
     * @param  string $address Adress to fix
     * @return string
     */
    private function fixAddressString($address)
    {
        $address = preg_replace('/\s([A-Z]{2})(\s\d+)$/', ', ${1}$2', $address);

        return $address;
    }
}
