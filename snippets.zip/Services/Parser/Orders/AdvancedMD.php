<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * AdvancedMD Order Parser
 * format: AdvancedMD
 * type: Order
 */
class AdvancedMD
{
    use HelperTrait;
    protected $format = 'AdvancedMD';
    protected $type = 'Order';
    protected $content;
    protected $template;
    protected $lines;

    /**
     * Check if given files matches AdvancedMD format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/CLINICAL\s*REQUISITION/i', $content) &&
            preg_match('/Test\s*Requested\s*By/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Acct\s*#:/', $line)) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/Test\s*Requested\s*By/i', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line2 = $line_number;
                $sep_pos2 = $matches[0][1] - 1;
            }
            elseif (preg_match('/Ins\.\s*1:/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line3 = $line_number;
                $sep_pos3 = $matches[0][1] - 2;
            }
            elseif (preg_match('/Set\s*Name:/i', $line)) {
                $sep_line4 = $line_number;
            }
            elseif (preg_match('/\[\]\s*Bill\s*Provider/i', $line)) {
                $sep_line5 = $line_number;
            }
            elseif (preg_match('/Order\s*#:/', $line)) {
                $sep_line6 = $line_number;
            }
            elseif (preg_match('/Authenticated\s*by/i', $line) && !isset($sep_line7)) {
                $sep_line7 = $line_number;
            }
            elseif (preg_match('/Electrically\s*Signed/i', $line) && !isset($sep_line7)) {
                $sep_line7 = $line_number - 1;
            }
        }

        // Order information
        $lines = array_slice($this->lines, (int) $sep_line1, $sep_line2 - $sep_line1);
        $normalized['order'] = $this->parseKeyValues(implode("\n", $lines));

        // Patient and Doctor information
        $lines = array_slice($this->lines, $sep_line2, $sep_line3 - $sep_line2);
        // Remove the headings
        array_shift($lines);
        $patient = $doctor = [];
        foreach ($lines as $line) {
            if (!trim($line)) {
                continue;
            }
            $left = substr($line, 0, $sep_pos2);
            $right = substr($line, $sep_pos2);
            if (empty($patient)) {
                $patient[] = 'Name:' . trim($left);
            }
            else {
                $patient[] = $left;
            }
            if (empty($doctor)) {
                $right = preg_replace('/\s+\w+$/', ',$0', trim($right));
                $doctor[] = 'Name:' . $right;
            }
            else {
                if (count($doctor) == 1) {
                    $doctor[] = 'Address:' . trim($right);
                }
                else {
                    $right = preg_replace('/([^:;\s])\s{3,}/', '$1, ', $right);
                    $doctor[] = $right;
                }
            }
        }

        $normalized['patient'] = $this->parseMultiKeyValues($patient);
        $normalized['doctor'] = $this->parseMultiKeyValues($doctor);

        // Guarantor/Insurance information
        $lines = \array_slice($this->lines, $sep_line3, $sep_line4 - $sep_line3);
        $guarantor = $insurance = [];
        foreach ($lines as $line) {
            if (!trim($line)) {
                continue;
            }
            $left = substr($line, 0, $sep_pos3);
            $right = substr($line, $sep_pos3);
            // Guarantor
            if (trim($left) && strpos($left, 'Guarantor') === false) {
                if (empty($guarantor)) {
                    $guarantor['name'] = trim($left);
                }
                elseif (strpos($left, 'Relation') !== false) {
                    $guarantor['relation'] = trim($this->getKeyValue($left)[1]);
                }
                else {
                    if (!isset($guarantor['address'])) {
                        $guarantor['address'] = trim($left);
                    }
                    else {
                        $str = preg_replace('/\s{3,}/', ', ', trim($left));
                        $str = str_replace(',,', ',', $str);
                        $guarantor['address'] .= ', ' . $str;
                    }
                }
            }
            // Insurance
            $insurance[] = $right;
        }
        $normalized['guarantor'] = $guarantor;
        $normalized['insurance'] = $this->parseMultiKeyValues($insurance);

        // Other information
        $lines = \array_slice($this->lines, $sep_line4, $sep_line5 - $sep_line4);
        $left = $right = [];
        foreach ($lines as $line) {
            if (!trim($line)) {
                continue;
            }
            $l = substr($line, 0, $sep_pos3) ?? '';
            $r = substr($line, $sep_pos3) ?? '';
            if (trim($l)) {
                $left[] = trim($l);
            }
            if ($r && trim($r)) {
                $right[] = trim($r);
            }
        }
        $normalized['other'] = $this->parseKeyValues(implode("\n", array_merge($left, $right)));

        // Exams
        $lines = \array_slice($this->lines, (int) $sep_line6, $sep_line7 - $sep_line6);
        $normalized['order-number'] = $this->getKeyValue(array_shift($lines))[1];
        $normalized['exams'] = $this->parseValuesUnderHeading($lines)['raw'];

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor']['name']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone']);
        $data['referringDr']['sendingFacility'] = $normalized['other']['dept-name'];

        $data['order']['sendingApplication'] = 'Advanced MD';
        $data['order']['DateOfService'] = $normalized['order']['order-date'] ? Carbon::parse($normalized['order']['order-date'])->format('YmdHis') : '';

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address'] ?? '');
        $data['patient']['code'] = $normalized['patient']['patient-id'];
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex']);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone']);

        $data['insuranceList'][0] = [
            'name'      => '',
            'insurance-address' => '',
            'insured'   => [
                'firstname' => $this->parseName($normalized['guarantor']['name'])['firstname'],
                'lastname' => $this->parseName($normalized['guarantor']['name'])['lastname'],
                'address'   => $this->parseAddress($normalized['guarantor']['address']),
                'relation'  => preg_replace('/[\W\d]+/', '', $normalized['guarantor']['relation'])
            ],
            'policy'    => '',
            'subscriber' => ''
        ];

        $data['exams'] = [];
        foreach ($normalized['exams'] as $exam) {
            $diagList = [];
            for ($i = 3; $i < count($exam); $i ++) {
                if (!trim($exam[$i])) {
                    continue;
                }
                $diagList[] = [
                    'code'  => trim($exam[$i]),
                    'coding_type'   => '',
                    'description'   => ''
                ];
                $data['exams'][] = [
                    'procedure_code'     => $exam[0],
                    'comment'            => '',
                    'study'              => $exam[1],
                    'MultiDiagnosisList' => $diagList
                ];
            }
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
