<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * TreatNow Order Parser
 * format: TreatNow
 * type: Order
 */
class TreatNow
{
    use HelperTrait;
    protected $format = 'TreatNow';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches eClinicalWorks2 format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Note\sgenerated\sby\seClinicalWorks/', $content)
            && preg_match('/Reason\sfor\sAppointment/', $content)
            && preg_match('/Treatment/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $lineAppointmentStart = 0;
        $lineAppointmentEnd = 0;

        $lineAssessmentsStart = 0;
        $lineAssessmentsEnd = 0;

        $lineTreatmentStart = 0;
        $lineTreatmentEnd = 0;

        foreach ($this->lines as $no => $line) {
            if (preg_match('/Reason\sfor\sAppointment/', $line)) {
                $lineAppointmentStart = $no + 1;
            }

            if (preg_match('/Assessments/', $line)) {
                $lineAppointmentEnd = $no - 1;
                $lineAssessmentsStart = $no + 1;
            }

            if (preg_match('/Treatment/', $line)) {
                $lineAssessmentsEnd = $no;
                $lineTreatmentStart = $no;
            }

            if (preg_match('/Procedures/', $line)) {
                $lineTreatmentEnd = $no;
            }

            if (preg_match('/\s{1,}Patient:(.*)DOB:(.*)Provider:.*/', $line, $matches)) {
                $patientName = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $patientDOB = isset($matches[2]) ? trim((string) $matches[2]) : '';
                $patientDOB = preg_replace('/\D/', '-', $patientDOB);

                $normalized['patient_name'] = $patientName;
                $normalized['patient_dob'] = $patientDOB;
            }

            if (preg_match('/\s{60,}(\d{1,3})\s{1,}Y\sold\s{1,}([A-z]+),\s{1,}DOB/', $line, $matches)) {
                $patientAge = isset($matches[1]) ? intval($matches[1]) : '';
                $patientGender = isset($matches[2]) ? trim((string) $matches[2]) : '';

                $normalized['patient_age'] = $patientAge;
                $normalized['patient_sex'] = $patientGender;

                $patientAddress = isset($this->lines[$no + 1]) ? trim((string) $this->lines[$no + 1]) : '';
                $normalized['patient_address'] = $patientAddress;
            }

            if (preg_match('/\s{50,}Home:([0-9-\s]+)/', $line, $matches)) {
                $patientPhone = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $normalized['patient_phone'] = $patientPhone;
            }

            if (preg_match('/\s{50,}Provider:(.*)/', $line, $matches)) {
                $doctorName = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $normalized['doctor_name'] = $doctorName;
            }

            if (preg_match('/\s*Date:(.*)/', $line, $matches)) {
                $orderDate = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $orderDate = preg_replace('/\D/', '-', $orderDate);

                $normalized['order_date'] = $orderDate;
            }

            if (preg_match('/\s*Time:(.*)/', $line, $matches)) {
                $orderTime = isset($matches[1]) ? trim((string) $matches[1]) : '';

                $normalized['order_time'] = $orderTime;
            }
        }

        $appointmentsLength = $lineAppointmentEnd - $lineAppointmentStart;
        $appointments = array_slice($this->lines, $lineAppointmentStart, $appointmentsLength);
        $appointments = $this->trimArray($appointments);

        $assessmentsLength = $lineAssessmentsEnd - $lineAssessmentsStart;
        $assessments = array_slice($this->lines, $lineAssessmentsStart, $assessmentsLength);
        $assessments = $this->trimArray($assessments);

        $treatmentLength = $lineTreatmentEnd - $lineTreatmentStart;
        $treatment = array_slice($this->lines, $lineTreatmentStart, $treatmentLength);

        $icdCodes = [];

        foreach ($assessments as $line) {
            preg_match('/\s*\d{1,}\.(.*)-(.*)/', $line, $matches);

            if (isset($matches[1]) && isset($matches[2])) {
                $icdCodes[$this->fixIcdOCR((string) $matches[2])] = trim((string) $matches[1]);
            }
        }

        $reasons = [];
        foreach ($appointments as $line) {
            if (preg_match('/\d{1,}\.\s{1,}.*/', $line)) {
                $reason = preg_replace('/\d{1,}\./', '', $line);
                $reasons[] = trim((string) $reason);
            }
        }

        $normalized['exams'] = [];

        foreach ($treatment as $line) {
            if (preg_match('/\s*IMAGING:(.*)/', $line, $matches)) {
                if (isset($matches[1])) {
                    $exam = [];
                    $exam['study'] = trim((string) $matches[1]);
                    $exam['comment'] = implode(', ', $reasons);
                    $exam['dx'] = [];

                    foreach ($icdCodes as $code => $description) {
                        $exam['dx'][] = [
                            'code' => $code,
                            'description' => $description
                        ];
                    }

                    $normalized['exams'][] = $exam;
                }
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = $this->type;
        $data['meta']['document_format'] = $this->format;

        if (count($normalized['exams']) > 1) {
            for ($i = 1; $i < count($normalized['exams']); $i++) {
                $data['exams'][$i] = $data['exams'][0];
            }
        }

        if (!empty($normalized['order_date']) && strlen($normalized['order_date']) > 0) {
            if (isset($normalized['order_time']) && strlen($normalized['order_time']) > 0) {
                $dateTime = $normalized['order_date'] . ' ' . $normalized['order_time'];
                $date = Carbon::createFromFormat('m-d-Y h:i A', $dateTime);
                $data['order']['DateOfService'] = $date->format('Ymdhi') . '00';
            } else {
                $date = Carbon::createFromFormat('m-d-Y', $normalized['order_date']);
                $data['order']['DateOfService'] = $date->format('Ymd') . '000000';
            }
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['doctor_name']);

        if (isset($normalized['patient_dob']) && strlen($normalized['patient_dob']) > 0) {
            $date = Carbon::createFromFormat('m-d-Y', $normalized['patient_dob']);
            $patient_dob = $date->format('Ymd') . '000000';
        }

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patient_dob ?? '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient_sex']);
        $data['patient']['age'] = $normalized['patient_age'];
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient_phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient_address']);

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);

        for ($i = 0; $i < count($normalized['exams']); $i++) {
            $data['exams'][$i]['study'] = $normalized['exams'][$i]['study'];
            $data['exams'][$i]['comment'] = $normalized['exams'][$i]['comment'];

            foreach ($normalized['exams'][$i]['dx'] as $dx) {
                $data['exams'][$i]['MultiDiagnosisList'][] = [
                    'code'        => $dx['code'],
                    'coding_type' => 'ICD10',
                    'description' => $dx['description']
                ];
            }
        }

        error_reporting(1);
        return $data;
    }

    private function fixIcdOCR(string $icd) : string
    {
        $icd = preg_replace('/io/', '10', $icd);

        return trim($icd);
    }
}
