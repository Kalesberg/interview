<?php

namespace ScriptSender\Services\Parser\Orders;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * Athena Order Parser
 * format: Athena
 * type: Order
 */
class Athena
{
    use HelperTrait;
    protected $format = 'Athena';
    protected $type = 'Order';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/From\s*Provider/i', $content)
            && preg_match('/To\s*Provider/i', $content)
            && preg_match('/(Referral|Imaging)\s*Order/i', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/OrderData.php');
    }

    /**
     * Parse function
     * @throws \Exception
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if ((preg_match('/Imaging\s*Order/i', $line) || preg_match('/Referral\s*Order/i', $line)) && !isset($sep_line1)) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/From\s*Provider\s*(To\s*Provider)/i', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line1_1 = $line_number;
                $sep_pos1 = $matches[1][1];
                $provider_direction = 0;
            }
            elseif (preg_match('/To\s*Provider\s*(From\s*Provider)/i', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line1_1 = $line_number;
                $sep_pos1 = $matches[1][1];
                $provider_direction = 1;
            }
            elseif (preg_match('/Order\s*Information$/i', trim($line))) {
                $sep_line2 = $line_number;
            }
            elseif (preg_match('/Patient\s+Information/i', $line)) {
                $sep_line3 = $line_number;
            }
            elseif (preg_match('/Electronically\s+Signed/i', $line)) {
                $sep_line4 = $line_number;
            }
        }

        // Sending Facility
        $normalized['facility'] = trim(preg_split('/[^\w\d\s]/', $this->lines[0])[0]);

        // Order submission date
        for ($n = $sep_line1; $n < $sep_line1_1; $n ++) {
            $line = trim($this->lines[$n]);
            if (!trim($line)) {
                continue;
            }
            if (preg_match('/\d{2}\/\d{2}\/\d{4}/', $line, $matches)) {
                $normalized['order-date'] = $matches[0];
                break;
            }
        }

        // Doctor and Provider information
        $left = $right = [];
        for ($n = $sep_line1_1 + 1; $n < $sep_line2; $n++) {
            $line = $this->lines[$n];
            if (trim($line) === '') {
                continue;
            }
            $l = substr($line, 0, $sep_pos1);
            $r = substr($line, $sep_pos1);
            if (empty($left)) {
                $left[] = 'Name:' . $l;
            }
            elseif (count($left) === 1) {
                $left[] = 'Address:' . $l;
            }
            else {
                $left[] = $l;
            }
            if (empty($right)) {
                $right[] = 'Name:' . $r;
            }
            elseif (count($right) === 1) {
                $right[] = 'Address:' . $r;
            }
            else {
                $right[] = $r;
            }
        }
        if ($provider_direction === 1) {
            $normalized['to-provider'] = $this->parseKeyValues(implode("\n", $left));
            $normalized['from-provider'] = $this->parseKeyValues(implode("\n", $right));
        }
        else {
            $normalized['from-provider'] = $this->parseKeyValues(implode("\n", $left));
            $normalized['to-provider'] = $this->parseKeyValues(implode("\n", $right));
        }

        $normalized['pid'] = explode(',', $this->getValue(['search' => '\(id', 'delimiter' => '#']))[0];

        if ($sep_line2 < $sep_line3) {
            $exam_sep_line1 = $sep_line2 + 1;
            $exam_sep_line2 = $sep_line3;
            $patient_sep_line1 = $sep_line3 + 1;
            $patient_sep_line2 = $sep_line4;
        }
        else {
            $exam_sep_line1 = $sep_line2 + 1;
            $exam_sep_line2 = $sep_line4;
            $patient_sep_line1 = $sep_line3 + 1;
            $patient_sep_line2 = $sep_line2;
        }

        // Exams
        for ($n = $exam_sep_line1; $n < $exam_sep_line2; $n ++) {
            $line = $this->lines[$n];
            // if (preg_match('/Diagnosis/', $line)) {
            //     $sep_line2_1 = $n;
            // }
            if (preg_match('/Orders\s+Included/i', $line)) {
                $sep_line2_2 = $n;
            }
            elseif (strpos($line, 'Notes') !== false) {
                $sep_line2_3 = $n;
            }
        }
        $exams = [];
        // for ($n = $sep_line2_1; $n < $sep_line2_2; $n ++) {
        //     $line = trim($this->lines[$n]);
        //     if ($line == '') continue;
        //     if ($n == $sep_line2_1) {
        //         $line = preg_replace('/Diagnosis/', 'Diagnosis:', $line);
        //     }
        //     $exams[] = $line;
        // }
        for ($n = $sep_line2_2 + 1; $n < $sep_line2_3; $n++) {
            $line = trim($this->lines[$n]);
            if ($line == '') {
                continue;
            }
            if (preg_match('/\bCC\b/', $line)) {
                continue;
            }

            $delim = '/(ICD\s*-[^:]*):/';
            if (preg_match($delim, $line, $matches)) {
                // Split the line with `ICD-xx` as a delimiter
                $exams['type'] = trim($matches[1]);
                $chunks = preg_split($delim, $line);
                // $exams['comment'] = trim(substr($chunks[0], 0, -2));
                $exams['code'] = trim(explode(':', $chunks[1])[0]);
                $exams['description'] = trim(explode(':', $chunks[1])[1]);
            }
            elseif (preg_match('/^[^a-z]+$/', $line)) {
                $line = preg_replace('/[[:^print:]]/', '', $line);
                $exams['study'] = trim($line);
            }
            else {
                $exams['comment'] = $exams['comment'] ?? '';
                $exams['comment'] .= ' ' . trim($line);
            }
        }

        $exams['comment'] = preg_replace('/\s+/', ' ', $exams['comment'] ?? '');
        $exams['comment'] = preg_replace('/.*NOTE\s+TO\s+IMAGING\s+FACILITY:/', '', $exams['comment']);
        $v = '';
        for ($n = $sep_line2_3; $n < $exam_sep_line2; $n++) {
            $line = $this->lines[$n];
            if (trim($line) == '') {
                continue;
            }
            $v .= trim(substr($line, 15)) . "\n";
        }
        $exams['notes'] = $v;
        // $normalized['exams'] = $this->parseKeyValues(implode("\n", $exams));
        $normalized['exams'] = $exams;

        // Patient Information
        $patient = [];
        $suffix = '';
        for ($n = $patient_sep_line1; $n < $patient_sep_line2; $n ++) {
            $line = $this->lines[$n];
            if (!trim($line)) {
                continue;
            }
            if (preg_match('/Primary\s*Insurance/i', $line)) {
                $suffix = 'Primary ';
            }
            elseif (preg_match('/Secondary\s*Insurance/i', $line)) {
                $suffix = 'Secondary ';
            }
            $l = $suffix . trim(substr($line, 0, 30)) . ':';
            $r = trim(substr($line, 30));
            if ($l == $suffix . ':') {
                $patient[] = $suffix . $r;
            }
            else {
                $patient[] = $l . $r;
            }
        }
        $normalized['patient'] = $this->parseKeyValues(implode("\n", $patient));

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['from-provider']['name'] ?? '');
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['from-provider']['phone'] ?? '');
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['from-provider']['fax'] ?? '');
        $data['referringDr']['address'] = $this->parseAddress($normalized['from-provider']['address'] ?? '');
        $data['referringDr']['sendingFacility'] = $data['referringDr']['address']['address1'];

        $data['attendingDr'] = $this->parseName($normalized['to-provider']['name'] ?? '');
        $data['attendingDr']['phone1'] = $this->parsePhone($normalized['to-provider']['phone'] ?? '');
        $data['attendingDr']['phone2'] = $this->parsePhone($normalized['to-provider']['fax'] ?? '');
        $data['attendingDr']['address'] = $this->parseAddress($normalized['to-provider']['address'] ?? '');

        $data['order']['sendingApplication'] = 'Athena';
        $data['order']['DateOfService'] = $normalized['order-date'] ? Carbon::parse($normalized['order-date'])->format('YmdHis') : '';
        $data['order']['PID'] = $normalized['pid'];

        $patient = $this->parseName(str_replace(',', ' ', $normalized['patient']['patient-name'] ?? ''), true);
        $data['patient']['name'] = $patient['name'];
        $data['patient']['firstname'] = $patient['firstname'];
        $data['patient']['middlename'] = $patient['middlename'];
        $data['patient']['lastname'] = $patient['lastname'];
        $data['patient']['title'] = $patient['title'];

        $normalized['patient']['sex-dob-age'] = trim(preg_replace('/\w+:/', '', $normalized['patient']['sex-dob-age']));
        $sex = preg_split('/\s+/', $normalized['patient']['sex-dob-age'])[0];
        $data['patient']['sex'] = $this->parseGender($sex);
        $data['patient']['DOB'] = $normalized['patient']['sex-dob-age'] ? Carbon::parse(preg_split('/\s+/', $normalized['patient']['sex-dob-age'])[1])->format('YmdHis') : '';
        $data['patient']['address'] = $this->parseAddress($normalized['patient']['address'] ?? '');
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['phone'] ?? '');
        $data['patient']['phone2'] = $this->parsePhone($normalized['patient']['w'] ?? '');

        $data['insuranceList'] = [];
        if (array_key_exists('primary-primary-insurance', $normalized['patient'])) {
            $data['insuranceList'][0]['name'] = $normalized['patient']['primary-primary-insurance'];
            // $data['insuranceList'][0]['insurance-address'] = $normalized['patient']['address'];
            $data['insuranceList'][0]['policy'] = $normalized['patient']['primary-id'];
            $insured = $this->parseName(str_replace(',', ' ', $normalized['patient']['primary-policy-holder'] ?? ''), true);
            $data['insuranceList'][0]['insured']['firstname'] = $insured['firstname'];
            $data['insuranceList'][0]['insured']['lastname'] = $insured['lastname'];
            $data['insuranceList'][0]['insured'] = $this->parseName($normalized['patient']['primary-policy-holder'] ?? '', true);
            $data['insuranceList'][0]['subscriber'] = $normalized['patient']['primary-group'] ?? '';
        }
        if (array_key_exists('secondary-secondary-insurance', $normalized['patient'])) {
            $data['insuranceList'][1]['name'] = $normalized['patient']['secondary-secondary-insurance'];
            // $data['insuranceList'][1]['insurance-address'] = $normalized['patient']['address'];
            $data['insuranceList'][1]['policy'] = $normalized['patient']['secondary-id'];
            $insured = $this->parseName(str_replace(',', ' ', $normalized['patient']['secondary-policy-holder'] ?? ''), true);
            $data['insuranceList'][1]['insured']['firstname'] = $insured['firstname'];
            $data['insuranceList'][1]['insured']['lastname'] = $insured['lastname'];
            $data['insuranceList'][1]['insured'] = $this->parseName($normalized['patient']['secondary-policy-holder'] ?? '', true);
            $data['insuranceList'][1]['subscriber'] = $normalized['patient']['secondary-group'] ?? '';
        }

        $provider = $this->parseName($normalized['from-provider']['name'] ?? '');
        // $code = explode(':', $normalized['exams']['icd-10'])[0];
        $data['exams'] = [];
        $data['exams'][0]['study'] = $normalized['exams']['study'] ?? '';
        $data['exams'][0]['comment'] = $normalized['exams']['comment'] ?? '';
        $data['exams'][0]['approving_provider'] = $provider;
        $data['exams'][0]['MultiDiagnosisList'][0]['code'] = $normalized['exams']['code'] ?? '';
        $data['exams'][0]['MultiDiagnosisList'][0]['coding_type'] = $normalized['exams']['type'] ?? '';
        $data['exams'][0]['MultiDiagnosisList'][0]['description'] = $normalized['exams']['description'] ?? '';

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
