<?php

return [
    'report' => [
        'accession' => '',
        'PID'       => ''
    ],
    'patient' => [
        'sex'  => 'U',
        'dob'  => ''
    ]
];
