<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Summary;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * Allscripts Charter Clinical Summary Document Parser
 * format: AllscriptsCharter
 * type: Summary
 */
class AllscriptsCharter
{
    use HelperTrait;
    protected $format = 'AllscriptsCharter';
    protected $type = 'Summary';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches AllscriptsCharter format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Clinical\s{1,}Summary\s{1,}for(.*)\(Patient\s{1,}Copy\)/', $content)
            && preg_match('/\s{10,}Care\s{1,}provided\s{1,}by:/', $content)
            && preg_match('/\s*Demographic\s{1,}data\s{1,}on\s{1,}file:/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode(PHP_EOL, $content);
        $this->template = include app_path('Services/Parser/SummaryData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        foreach ($this->lines as $line) {
            if (preg_match('/Clinical\s{1,}Summary\s{1,}for(.*)\(Patient\s{1,}Copy\)/', $line, $matches)) {
                $patientName = isset($matches[1]) ? trim((string) $matches[1]) : '';

                $normalized['patient_name'] = $patientName;
            }

            if (preg_match('/DOB:(.*)Sex:/', $line, $matches)) {
                $patientDOB = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $patientDOB = preg_replace('/;/', '', $patientDOB);
                $patientDOB = preg_replace('/\D/', '-', $patientDOB);

                $normalized['patient_dob'] = $patientDOB;
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = $this->type;
        $data['meta']['document_format'] = $this->format;

        if (isset($normalized['patient_dob']) && strlen($normalized['patient_dob']) > 0) {
            $date = Carbon::createFromFormat('m-d-Y', $normalized['patient_dob']);
            $patientDOB = $date->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patientDOB ?? '';

        error_reporting(1);
        return $data;
    }
}
