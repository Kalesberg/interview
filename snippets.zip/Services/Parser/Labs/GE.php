<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Labs;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * GE Labs Parser
 * format: GE
 * type: Labs
 */
class GE
{
    use HelperTrait;
    protected $format = 'GE';
    protected $type = 'Labs';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/DOB\s*:/', $content) && preg_match_all('/Ins\s*:/', $content) &&
               preg_match_all('/Grp\s*:/', $content) && preg_match_all('/Lab\s*Report:/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/LabsData.php');
    }

    /**
     * Parse function
     *
     * @param  type|null $content (Content to parse)
     * @return boolean (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (!isset($sep_line1) && preg_match('/DOB\s*:/', $line) && preg_match('/Ins\s*:/', $line) && preg_match('/Grp\s*:/', $line)) {
                $sep_line1 = $line_number;
            }
        }

        // Patient information
        $patient = [];
        $patient['name'] = trim($this->lines[$sep_line1 - 1]);
        preg_match('/([^\s]+)\s*DOB\s*:\s*([^\s]+).*Ins\s*:(.*)\s*Grp\s*:(.*)/', $this->lines[$sep_line1], $matches);
        $patient['sex'] = $this->parseGender($matches[1][0]);
        $patient['DOB'] = trim($matches[2]);
        $normalized['patient'] = $patient;

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['sex'] = $normalized['patient']['sex'];
        $data['patient']['DOB'] = $normalized['patient']['DOB'] ? Carbon::parse($normalized['patient']['DOB'])->format('YmdHis') : '';

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
