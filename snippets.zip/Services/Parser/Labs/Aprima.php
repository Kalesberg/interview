<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Labs;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * Aprima Labs Parser
 * format: Aprima
 * type: Labs
 */
class Aprima
{
    use HelperTrait;
    protected $format = 'Aprima';
    protected $type = 'Labs';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/LabCorp/', $content) && preg_match_all('/Collection\s*Date/', $content) &&
               preg_match_all('/Collection\s*Tim(e)?/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/LabsData.php');
    }

    /**
     * Parse function
     *
     * @param  type|null $content (Content to parse)
     * @return boolean (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (!isset($sep_line1) && preg_match('/^Collection\s*Date/', $line)) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/Patient\s*Name/', $line, $matches, PREG_OFFSET_CAPTURE) || (preg_match('/Account\s*#/', $line) && preg_match('/Patient/', $line, $matches, PREG_OFFSET_CAPTURE))) {
                $sep_line2 = $line_number;
                $sep_pos2 = $matches[0][1];
            }
            elseif (preg_match('/Physician\s*Name/', $line)) {
                $sep_line3 = $line_number;
            }
            elseif (preg_match('/Relationship:/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line4 = $line_number;
                $sep_pos4 = $matches[0][1];
            }
            elseif (preg_match('/Secondary\s*Insurance/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line5 = $line_number;
                $sep_pos5 = $matches[0][1];
            }
            elseif (preg_match('/DIAG\s*CODE/', $line) || preg_match('/TESTS\s*ORDERED/', $line)) {
                $sep_line6 = $line_number;
            }
        }

        // Order information
        $lines = array_slice($this->lines, $sep_line1, 1);
        $normalized['order-date'] = $this->getValue(['search' => 'O(r)?der\s*Date', 'lines' => $lines, 'sticky' => false]);

        // Doctor and Patient information
        $doctor = $patient = [];
        $lines = array_slice($this->lines, $sep_line2, $sep_line3 - $sep_line2);
        foreach ($lines as $line) {
            $left = (string) substr($line, 0, $sep_pos2);
            $right = (string) substr($line, $sep_pos2);
            if (trim($left)) {
                if (count($doctor) == 1) {
                    $doctor[] = 'Facility:' . $left;
                }
                elseif (count($doctor) == 2) {
                    $left = str_replace('.', ',', $left);
                    $doctor[] = 'Address:' . $left;
                }
                else {
                    $left = preg_replace('/([^,\s]\s+)([A-Z]{2})\b/', '$1,$2', $left);
                    $left = preg_replace('/Phone\s*#/', 'Phone:', $left);
                    $doctor[] = $left;
                }
            }
            if (trim($right)) {
                $patient[] = $right;
            }
        }
        $normalized['doctor'] = $this->parseMultiKeyValues($doctor);
        $normalized['patient'] = $this->parseMultiKeyValues($patient);

        preg_match('/Physician\s*Name\s*:?\s*(.*)\s*NPI\s*#\s*:?\s*(.*)\s*Physician/', $this->lines[$sep_line3], $matches);
        $normalized['doctor']['name'] = $matches[1] ?? '';
        $normalized['doctor']['npi'] = $matches[2] ?? '';

        // Insurance information
        $lines = array_slice($this->lines, $sep_line5 + 1, $sep_line6 - $sep_line5 - 1);
        $primary = $secondary = [];
        foreach ($lines as $line) {
            $left = (string) substr($line, 0, $sep_pos5);
            $right = (string) substr($line, $sep_pos5);
            if (trim($left)) {
                $left = preg_replace('/Subscriber\s*#\s/i', 'Subscriber:', $left);
                $left = preg_replace('/Insurance\s*Group\s*#\s/i', 'Policy:', $left);
                $primary[] = $left;
            }
            if (trim($right)) {
                $right = preg_replace('/Subscriber\s*#\s/i', 'Subscriber:', $right);
                $right = preg_replace('/Insurance\s*Group\s*#\s/i', 'Policy:', $right);
                $secondary[] = $right;
            }
        }
        if (!preg_match('/Subscriber/', $primary[0])) {
            $primary[0] = 'Name:' . $primary[0];
        }
        if (!preg_match('/Subscriber/', $primary[0]) && !preg_match('/Subscriber/', $primary[1])) {
            $primary[1] = 'Address:' . $primary[1];
        }
        if (!preg_match('/Subscriber/', $secondary[0])) {
            $secondary[0] = 'Name:' . $secondary[0];
        }
        if (!preg_match('/Subscriber/', $secondary[0]) && !preg_match('/Subscriber/', $secondary[1])) {
            $secondary[1] = 'Address:' . $secondary[1];
        }
        $normalized['primary'] = $this->parseKeyValues(join("\n", $primary));
        $normalized['secondary'] = $this->parseKeyValues(join("\n", $secondary));
        
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor']['name'], true);
        $data['referringDr']['npi'] = $normalized['doctor']['npi'];
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor']['facility'];

        $data['order']['accession'] = $normalized['doctor']['account'];
        $data['order']['DateOfService'] = $normalized['order-date'] ? Carbon::parse($normalized['order-date'])->format('YmdHis') : '';

        $ptName = $normalized['patient']['patient-name'] ?? $normalized['patient']['patient-nan-e'] ?? '';
        $data['patient'] = $this->parseName($ptName, true);
        $data['patient']['code'] = $normalized['patient']['patient-id'];
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['gender'][0]);

        $data['insuranceList'] = [];
        if (isset($normalized['primary']['name']) || isset($normalized['primary']['address'])) {
            $data['insuranceList'][] = [
                'name'      => $normalized['primary']['name'],
                'insured-address'   => $normalized['primary']['address'],
                'insured'   => $data['patient'],
                'policy'    => $normalized['primary']['policy'],
                'subscriber'=> $normalized['primary']['subscriber']
            ];
        }
        if (isset($normalized['secondary']['name']) || isset($normalized['secondary']['address'])) {
            $data['insuranceList'][] = [
                'name'      => $normalized['secondary']['name'],
                'insured-address'   => $normalized['secondary']['address'],
                'insured'   => $data['patient'],
                'policy'    => $normalized['secondary']['policy'],
                'subscriber'=> $normalized['secondary']['subscriber']
            ];
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
