<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Referral;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * GE Referral Parser
 * format: GE
 * type: Referral
 */
class GE
{
    use HelperTrait;
    protected $format = 'GE';
    protected $type = 'Referral';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/Referral\s*Form/', $content) && preg_match_all('/Authorizing\s*Provider/', $content) &&
               preg_match_all('/Service\s*Provider/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/ReferralData.php');
    }

    /**
     * Parse function
     *
     * @param  type|null $content (Content to parse)
     * @return boolean (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Service\s*Provider/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line1 = $line_number;
                $sep_pos1 = $matches[0][1];
            }
            elseif (preg_match('/Patient\s*Name/', $line)) {
                $sep_line2 = $line_number;
            }
            elseif (preg_match('/Secondary\s*Ins/', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sep_line3 = $line_number;
                $sep_pos3 = $matches[0][1];
            }
            elseif (preg_match('/Code\s*Description\s*Diagnoses/', $line)) {
                $sep_line4 = $line_number;
            }
            elseif (preg_match('/Order\s*Number/', $line)) {
                $sep_line5 = $line_number;
            }
        }

        // Doctor information
        $doctor = [];
        $doctor['sendingFacility'] = preg_split('/\s{5,}/', $this->lines[0])[0];
        $doctor['address'] = preg_split('/\s{5,}/', $this->lines[1])[0];

        $referring = [];
        $lines = array_slice($this->lines, $sep_line1, $sep_line2 - $sep_line1);
        foreach ($lines as $line) {
            if (!trim($line)) {
                continue;
            }
            $left = substr($line, 0, $sep_pos1);
            $right = substr($line, $sep_pos1);
            $referring[] = $left;
        }
        $referring = $this->parseKeyValues(join("\n", $referring));
        $doctor = array_merge($doctor, $referring);
        $normalized['doctor'] = $doctor;

        // Patient information
        $lines = array_slice($this->lines, $sep_line2, $sep_line3 - $sep_line2);
        $patient = $this->parseMultiKeyValues($lines);
        $normalized['patient'] = $patient;

        // Insurance information
        $lines = array_slice($this->lines, $sep_line3, $sep_line4 - $sep_line3);
        $primaryIns = $secondaryIns = [];
        foreach ($lines as $line) {
            if (!trim($line)) {
                continue;
            }
            $left = substr($line, 0, $sep_pos3);
            $right = substr($line, $sep_pos3);
            $primaryIns[] = $left;
            $secondaryIns[] = $right;
        }
        $normalized['primary-ins'] = $this->parseKeyValues(join("\n", $primaryIns));
        $normalized['secondary-ins'] = $this->parseKeyValues(join("\n", $secondaryIns));

        // Exams information
        $lines = array_slice($this->lines, $sep_line4, $sep_line5 - $sep_line4);
        $exams = $this->parseValuesUnderHeading($lines)['raw'];
        $normalized['exams'] = $exams;

        $normalized['order']['date'] = $this->getValue(['search' => 'Start Date', 'sticky' => false]);

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $drName = preg_replace('/\s+\S+$/', ',$0', $normalized['doctor']['authorizing-provider']);
        $data['referringDr'] = $this->parseName($drName);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone'] ?? '');
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor']['fax'] ?? '');
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor']['sendingFacility'];

        $data['order']['accession'] = $this->getValue('Order\s*Number');
        $data['order']['placer_order_number'] = $this->getValue('Order\s*Number');
        $data['order']['DateOfService'] = $normalized['order']['date'] ? Carbon::parse($normalized['order']['date'])->format('YmdHis') : '';

        $data['patient'] = $this->parseName($normalized['patient']['patient-name']);
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex']);
        $data['patient']['SSN'] = $normalized['patient']['SSN'];
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['home-phone']??'');
        $data['patient']['phone2'] = $this->parsePhone($normalized['patient']['work-phone']??'');

        $data['insuranceList'] = [];
        if (!empty($normalized['primary-ins']['primary-ins'])) {
            $ins = [
                'name'      => $normalized['primary-ins']['primary-ins'],
                'insured'   => $data['patient'],
                'policy'    => $normalized['primary-ins']['insured-id'],
                'subscriber'=> $normalized['primary-ins']['group']
            ];
            $data['insuranceList'][] = $ins;
        }

        if (!empty($normalized['secondary-ins']['secondary-ins'])) {
            $ins = [
                'name'      => $normalized['secondary-ins']['secondary-ins'],
                'insured'   => $data['patient'],
                'policy'    => $normalized['secondary-ins']['insured-id'],
                'subscriber'=> $normalized['secondary-ins']['group']
            ];
            $data['insuranceList'][] = $ins;
        }

        foreach ($normalized['exams'] as $exam) {
            preg_match('/([^()]+)\s*(?:\(([^()]+)\))?\s*\(([^()]+)\)/', $exam[2], $matches);
            $diagnosis = $matches[3] ?? $matches[2];
            $description = $matches[1];
            $ex = [
                'procedure_code'    => $exam[0],
                'study'             => $exam[1],
                'MultiDiagnosisList'=> [[
                    'coding_type'   => explode('-', $diagnosis)[0],
                    'code'          => explode('-', $diagnosis)[1],
                    'description'   => $description
                ]]
            ];
            $data['exams'][] = $ex;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
