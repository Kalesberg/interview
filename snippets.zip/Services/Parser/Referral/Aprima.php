<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Referral;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * Aprima Referral Parser
 * format: Aprima
 * type: Referral
 */
class Aprima
{
    use HelperTrait;
    protected $format = 'Aprima';
    protected $type = 'Referral';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/Accounts\s*for/', $content) && preg_match_all('/Account\s*:/', $content) &&
               preg_match_all('/Current\s*Insurance/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/ReferralData.php');
    }

    /**
     * Parse function
     *
     * @param  type|null $content (Content to parse)
     * @return boolean (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/Accounts\s*for\s*(.*)/', $line, $matches)) {
                $sep_line1 = $line_number;
                $normalized['patient']['name'] = $matches[1];
            }
            elseif (preg_match('/Current\s*Insurance/', $line)) {
                $sep_line2 = $line_number;
            }
        }

        // Doctor information
        $doctor = [];
        for ($n = 0; $n < $sep_line1; $n ++) {
            $str = preg_split('/\s{5,}/', $this->lines[$n])[0];
            if (trim($str)) {
                $doctor[] = $str;
            }
        }
        $doctor[0] = 'Facility: ' . $doctor[0];
        $doctor[1] = 'Address: ' . $doctor[1];
        $v = $doctor[count($doctor) - 1];
        if (!preg_match('/[a-zA-Z]+/', $v)) {

            $doctor[count($doctor) - 1] = 'Phone: ' . $v;
        }
        $normalized['doctor'] = $this->parseKeyValues(join("\n", $doctor));

        // Patient information
        $normalized['patient']['dob'] = $this->getValue(['search' => 'DOB', 'sticky' => false]);

        // Insurance information
        $lines = array_slice($this->lines, $sep_line2 + 1, count($this->lines) - $sep_line2 - 1);
        $lines['glue'] = '     ';

        $insurance = $this->parseValuesUnderHeading($lines)['parsed'];
        foreach ($insurance as $ins) {
            if (!trim($ins[0])) {
                continue;
            }
            $parts = preg_split('/\s{5,}/', $ins[2]);
            $name = $parts[0];
            foreach ($parts as $part) {
                if (!preg_match('/Group\s*ID/', $part) && preg_match('/D:/', $part)) {
                    $policy = explode(':', $part)[1];
                }
            }
            $address = join(', ', array_slice($parts, -3, 2));
            $relation = $this->getValue(['search' => 'Relation', 'lines' => [$ins[1]], 'sticky' => false]);

            $normalized['insList'][] = [
                'name'      => $name,
                'policy'    => $policy ?? '',
                'address'   => $address,
                'relation'  => $relation
            ];
        }

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor']['phone']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor']['facility'];

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';

        foreach ($normalized['insList'] as $ins) {
            $ins['insured']['address'] = $this->parseAddress($ins['address']);
            $data['insuranceList'][] = $ins;
        }

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
