<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Referral;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * TreatNow Referral Parser
 * format: TreatNow
 * type: Note
 */
class TreatNow
{
    use HelperTrait;
    protected $format = 'TreatNow';
    protected $type = 'Referral';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches TreatNowReferral format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/\s*Patient\sInformation:/', $content)
            && preg_match('/\s*Referral\sFrom\sInformation:/', $content)
            && preg_match('/\s*Reason\sFor\sReferral:/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode(PHP_EOL, $content);
        $this->template = include app_path('Services/Parser/ReferralData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $linePatientStart = 0;
        $linePatientEnd = 0;

        foreach ($this->lines as $no => $line) {
            if (preg_match('/\s*Patient\sInformation:/', $line)) {
                $linePatientStart = $no + 1;
            }

            if (preg_match('/\s*Insurance\sInformation/', $line)) {
                $linePatientEnd = $no - 1;
            }
        }

        $patientLength = $linePatientEnd - $linePatientStart;
        $patient = array_slice($this->lines, $linePatientStart, $patientLength);
        $patient = $this->trimArray($patient);

        $patientValues = $this->parseKeyValues(implode(PHP_EOL, $patient));

        $patientDOB = $patientValues['patient-dob'] ?? '';

        $normalized['patient_name'] = $patientValues['patient-name'] ?? '';
        $normalized['patient_dob'] = preg_replace('/\D/', '-', $patientDOB);
        $normalized['patient_address'] = $patientValues['patient-address'] ?? '';

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = $this->type;
        $data['meta']['document_format'] = $this->format;

        if (isset($normalized['patient_dob']) && strlen($normalized['patient_dob']) > 0) {
            $date = Carbon::createFromFormat('m-d-Y', $normalized['patient_dob']);
            $patientDOB = $date->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patientDOB ?? '';
        $data['patient']['address'] = $this->parseAddress($normalized['patient_address']);

        error_reporting(1);
        return $data;
    }
}
