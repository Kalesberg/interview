<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\PatientInfo;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * MDSynergy PatientInfo Parser
 * format: MDSynergy
 * type: PatientInfo
 */
class MDSynergy
{
    use HelperTrait;
    protected $format = 'MDSynergy';
    protected $type = 'PatientInfo';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/PATIENT\s*INFORMATION\s*SHEET/', $content) &&
               preg_match_all('/Med\s*Rec\s*Num/', $content) &&
               preg_match_all('/Miscellaneous\s*Information/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/PatientInfoData.php');
    }

    /**
     * Parse function
     *
     * @param  type|null $content (Content to parse)
     * @return boolean (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        $patient = [];
        $patient['firstname'] = $this->getValueBelow('First:');
        $patient['middlename'] = $this->getValueBelow('Middle:');
        $patient['lastname'] = $this->getValueBelow('Patient\s*Last\s*Name');
        $patient['dob'] = $this->getValueBelow('DOB:');
        $normalized['patient'] = $patient;

        $pid = $this->getValueBelow('Med\s*Rec\s*Num');
        $normalized['pid'] = $pid;

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['order']['PID'] = $normalized['pid'];

        $data['patient']['name'] = $normalized['patient']['firstname'] . ' ' . $normalized['patient']['middlename'] . ' ' . $normalized['patient']['lastname'];
        $data['patient']['firstname'] = $normalized['patient']['firstname'];
        $data['patient']['middlename'] = $normalized['patient']['middlename'];
        $data['patient']['lastname'] = $normalized['patient']['lastname'];
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse(preg_replace('/\D+/', '/', $normalized['patient']['dob']))->format('YmdHis') : '';

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
