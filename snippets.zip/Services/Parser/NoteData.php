<?php

return [
    'referringDr'           => [
        'name'              => '',
        'firstname'         => '',
        'middlename'        => '',
        'lastname'          => '',
        'title'             => '',
        'npi'               => '',
        'phone1'            => '',
        'phone2'            => '',
        'address'           => [
            'address1'  => '',
            'address2'  => '',
            'city'      => '',
            'state'     => '',
            'country'   => '',
            'zip'       => ''
        ],
        'sendingFacility'   => '',
    ],
    'attendingDr'           => [
        'name'              => '',
        'firstname'         => '',
        'middlename'        => '',
        'lastname'          => '',
        'title'             => '',
        'npi'               => '',
        'phone1'            => '',
        'phone2'            => '',
        'address'           => [
            'address1'  => '',
            'address2'  => '',
            'city'      => '',
            'state'     => '',
            'country'   => '',
            'zip'       => ''
        ],
        'sendingFacility'   => '',
    ],
    'order' => [
        'accession'             => '',
        'placer_order_number'    => '',
        'sendingApplication'    => '',
        'servicingFacility'     => '',
        'DateOfService'         => '',
        'PID'                   => ''
    ],
    'patient'               => [
        'name'              => '',
        'firstname'         => '',
        'middlename'        => '',
        'lastname'          => '',
        'title'             => '',
        'code'              => '',
        'DOB'               => '',
        'sex'               => 'U',
        'phone1'            => '',
        'phone2'            => '',
        'address'           => [
            'address'  => '',
            'address1'  => '',
            'address2'  => '',
            'city'      => '',
            'state'     => '',
            'country'   => '',
            'zip'       => ''
        ],
        'language' => 'English',
        'race' => '',
        'age' => '',
        'SSN' => ''
    ],
    'insuranceList'         => [
        [
            'name'               => '',
            'insurance-address'  => '',
            'insured'            => [
                'name' => '',
                'relationship' => '',
                'firstname' => '',
                'middlename' => '',
                'lastname'  => '',
                'title'  => '',
                'DOB' => '',
                'sex' => '',
                'phone1' => '',
                'address'   => [
                    'address'  => '',
                    'address1'  => '',
                    'address2'  => '',
                    'city'      => '',
                    'state'     => '',
                    'country'   => '',
                    'zip'       => ''
                ],
                'relation'  => '',
            ],
            'policy'        => '',
            'subscriber'    => '',
            'plan' => '',
            'companyID' => '',
        ]
    ],
    'exams'                 => [
        [
            'procedure_code'    => '',
            'placer_order_number' => '', // Order # in case of AllScripts
            'priority' => '',
            'DateOfEncounter' => '',
            'status' => '',
            'study'  => '',
            'approving_provider' => [
                'name' => '',
                'firstname' => '',
                'middlename' => '',
                'lastname' => '',
                'title' => '',
                'npi' => '',
            ],
            'outside_reason_code'   => '', // CPT4 code in AllScripts
            'comment'           => '',
            'stat'              => '',
            'MultiDiagnosisList'    => [[
                'code'          => '',
                'coding_type'   => '',
                'description'   => ''
            ]]
        ]
    ],
    'meta'               => [
        'document_type'  => '',
        'document_format'  => '',
        'base64' => '',
    ]
];
