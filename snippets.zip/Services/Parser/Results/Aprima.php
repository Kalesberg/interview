<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Results;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * Aprima Results Parser
 * format: Aprima
 * type: Results
 */
class Aprima
{
    use HelperTrait;
    protected $format = 'Aprima';
    protected $type = 'Results';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/CC\s*To:/', $content) && preg_match_all('/MRN:/', $content) &&
               preg_match_all('/EXAM:/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/ResultsData.php');
    }

    /**
     * Parse function
     *
     * @param  type|null $content (Content to parse)
     * @return boolean (True: Parse succeeded
     *                  False: Parse failed)
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (preg_match('/^TO:$/', trim($line))) {
                $sep_line1 = $line_number;
            }
            elseif (preg_match('/^EXAM:/', trim($line))) {
                $sep_line2 = $line_number;
            }
        }

        $lines = array_slice($this->lines, $sep_line1, $sep_line2 - $sep_line1);
        $info = $this->parseKeyValues(join("\n", $lines));
        $parts = explode(', ', $info['to']);
        $normalized['facility'] = array_shift($parts);
        $normalized['phone'] = array_splice($parts, -1, 1)[0];
        $normalized['address'] = join(', ', $parts);
        $normalized['doctor'] = trim($info['ordering-provider'], ' ,');
        $normalized['patient'] = trim($info['patient-name']);
        $normalized['dob'] = explode(' ', $info['dob'])[0];
        $normalized['sex'] = trim(explode(' ', $info['dob'])[1], '()');
        $normalized['order-date'] = $info['exam-date'];
        $normalized['accession'] = $info['accession'];

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['referringDr'] = $this->parseName($normalized['doctor'], true);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['phone']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['address']);
        $data['referringDr']['sendingFacility'] = $normalized['facility'];

        $data['order']['accession'] = $normalized['accession'];
        $data['order']['DateOfService'] = $normalized['order-date'] ? Carbon::parse($normalized['order-date'])->format('YmdHis') : '';

        $data['patient'] = $this->parseName($normalized['patient']);
        $data['patient']['DOB'] = $normalized['dob'] ? Carbon::parse($normalized['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['sex']);

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
