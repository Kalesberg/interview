<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Notes;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * PracticeFusion ClinicalNote Parser
 * format: PracticeFusion
 * type: ClinicalNote
 */
class PracticeFusion
{
    use HelperTrait;
    protected $format = 'PracticeFusion';
    protected $type = 'Note';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/practice\s+fusion/i', $content) &&
            preg_match_all('/imaging\s+order/i', $content) &&
               preg_match_all('/chief\s+complaint/i', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/NoteData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        foreach ($this->lines as $line_number => $line) {
            if (strpos($line, 'FACILITY') && strpos($line, 'ENCOUNTER')) {
                $sep_line1 = $line_number;
                $sep_pos1_1 = strpos($line, 'PATIENT');
                $sep_pos1_2 = strpos($line, 'FACILITY');
                $sep_pos1_3 = strpos($line, 'ENCOUNTER');
            }
            elseif (preg_match('/Chief\s+complaint/', $line)) {
                $sep_line2 = $line_number;
            }
            elseif (strpos($line, 'FIRST NAME')) {
                $sep_line3 = $line_number;
            }
            elseif (strpos($line, 'CONTACT INFORMATION')) {
                $sep_line4 = $line_number;
            }
            elseif (strpos($line, 'FAMILY INFORMATION')) {
                $sep_line5 = $line_number;
            }
            elseif (strpos($line, 'PAYMENT INFORMATION')) {
                $sep_line6 = $line_number;
            }
            elseif (preg_match('/vitals\s+for\s+this\s+encounter/i', $line)) {
                $sep_line7 = $line_number;
            }
            elseif (preg_match('/vitals\s+flowsheet/i', $line)) {
                $sep_line8 = $line_number;
            }
            elseif (preg_match('/Chronic\s+Diagnoses/i', $line)) {
                $sep_line9 = $line_number;
            }
            elseif (preg_match('/Acute\s+Diagnoses/i', $line)) {
                $sep_line10 = $line_number;
            }
            elseif (preg_match('/Drug\s+Allergies/i', $line)) {
                $sep_line11 = $line_number;
            }
            elseif (preg_match('/Food\s+Allergies/i', $line)) {
                $sep_line12 = $line_number;
            }
            elseif (preg_match('/Environmental\s+Allergies/i', $line)) {
                $sep_line13 = $line_number;
            }
            elseif (preg_match('/Active\s+Medications/i', $line)) {
                $sep_line14 = $line_number;
            }
            elseif (preg_match('/Historical\s+Medications/i', $line)) {
                $sep_line15 = $line_number;
            }
            elseif (preg_match('/Immunizations/i', $line)) {
                $sep_line16 = $line_number;
            }
            elseif (preg_match('/Smoking\s+History/i', $line)) {
                $sep_line17 = $line_number;
            }
            elseif (preg_match('/Past\s+medical\s+history/i', $line)) {
                $sep_line18 = $line_number;
            }
            elseif (preg_match('/Family\s+health\s+history/i', $line)) {
                $sep_line19 = $line_number;
            }
            elseif (preg_match('/Active\s+Directive/i', $line)) {
                $sep_line20 = $line_number;
            }
            elseif (trim($line) === 'Subjective') {
                $sep_line21 = $line_number;
            }
            elseif (trim($line) === 'Objective') {
                $sep_line22 = $line_number;
            }
            elseif (trim($line) === 'Assessment') {
                $sep_line23 = $line_number;
            }
            elseif (trim($line) === 'Plan') {
                $sep_line24 = $line_number;
            }
            elseif (trim($line) === 'Orders') {
                $sep_line25 = $line_number;
            }
            elseif (stripos($line, 'screenings')) {
                $sep_line26 = $line_number;
            }
            elseif (trim($line) === 'Observations') {
                $sep_line27 = $line_number;
            }
            elseif (preg_match('/Quality\s+of\s+care/i', $line)) {
                $sep_line28 = $line_number;
            }
            elseif (preg_match('/Care\s+plan/i', $line)) {
                $sep_line29 = $line_number;
            }
        }

        // Patient, Facility, Encounter
        $patient = $facility = $encounter = [];
        for ($n = $sep_line1 + 1; $n < $sep_line2; $n ++) {
            $line = $this->lines[$n];
            if (trim($line) == '') {
                continue;
            }

            $chunk1 = trim(substr($line, $sep_pos1_1, $sep_pos1_2 - $sep_pos1_1));
            if ($chunk1 != '') {
                if (empty($patient)) {
                    $patient[] = 'NAME:' . $chunk1;
                }
                else {
                    $patient[] = preg_replace('/\s{3,}/', ':', $chunk1);
                }
            }
            $chunk2 = trim(substr($line, $sep_pos1_2, $sep_pos1_3 - $sep_pos1_2));
            if ($chunk2 != '') {
                if (empty($facility)) {
                    $facility[] = 'NAME:' . $chunk2;
                }
                elseif (count($facility) == 1) {
                    $facility[] = 'PHONE:' . $chunk2;
                    $facility[] = 'ADDRESS:';
                }
                else {
                    $facility[] = $chunk2;
                }

            }
            $chunk3 = trim(substr($line, $sep_pos1_3));
            if ($chunk3 != '') {
                $encounter[] = preg_replace('/\s{3,}/', ':', $chunk3);
            }
        }

        $normalized['patient'] = $this->parseKeyValues(implode("\n", $patient));
        $normalized['facility'] = $this->parseKeyValues(implode("\n", $facility));
        $normalized['encounter'] = $this->parseKeyValues(implode("\n", $encounter));

        // Patient identifying details and demographics
        $patient_details = \array_slice($this->lines, $sep_line3, $sep_line4 - $sep_line3);
        $normalized['patient']['details'] = $this->parseValuesWithoutDelim($patient_details);

        // Contact Information
        $contact = [];
        for ($n = $sep_line4 + 1; $n < $sep_line5; $n ++) {
            $line = $this->lines[$n];
            if (trim($line) == '') {
                continue;
            }
            if (!isset($sep_pos_2) && strpos($line, 'CONTACT BY')) {
                $sep_pos_2 = strpos($line, 'CONTACT BY');
            }
            $chunk1 = trim(substr($line, 0, $sep_pos_2));
            if (strpos($chunk1, 'STATE') !== false) {
                $chunk1 = 'STATE  ' . strtolower(substr($chunk1, 5));
            }
            $chunk2 = trim(substr($line, $sep_pos_2));
            if (strpos($chunk2, '@') === 0) {
                $chunk2 = 'EMAIL DOMAIN  ' . $chunk2;
            }
            if ($chunk1 != '') {
                $contact[] = $chunk1;
            }
            if ($chunk2 != '') {
                $contact[] = $chunk2;
            }
        }
        $params = [
            'lines'         => $contact,
            'key_pattern'   => '/\b([A-Z](?:(?!\s{2,})[^a-z])+)\b\s{2,}/'
        ];
        $normalized['patient']['contact'] = $this->parseValuesWithoutDelim($params);
        $normalized['patient']['contact']['email'] .= $normalized['patient']['contact']['email-domain'];

        // Family Information
        $family = \array_slice($this->lines, $sep_line5 + 1, $sep_line6 - $sep_line5 - 2);
        $normalized['patient']['family'] = $this->parseValuesWithoutDelim($family);

        // Insurance
        $insurance = \array_slice($this->lines, $sep_line6 + 1, $sep_line7 - $sep_line6 - 2);
        $params = [
            'lines'         => $insurance,
            'key_pattern'   => '/\b([A-Z](?:(?!\s{2,})[^\da-z])+)\b/'
        ];
        $normalized['insurance'] = $this->parseValuesWithoutDelim($params);

        // Vitals
        $vitals = [];
        for ($n = $sep_line8 + 2; $n < $sep_line9; $n ++) {
            $line = trim($this->lines[$n]);
            $parts = preg_split('/\s{10,}/', $line);
            $key = $this->slugify($parts[0]);
            $vitals[$key] = ($parts[1] ?? '');
        }


        // Chronic Diagnoses
        $chronic = \array_slice($this->lines, $sep_line9 + 1, $sep_line10 - $sep_line9 - 1);
        $diagnoses = $this->parseValuesUnderHeading($chronic)['raw'];

        $normalized['diagnoses']['chronic'] = [];
        foreach ($diagnoses as $d) {
            if (preg_match('/^\(([^)]+)\)(.*)$/', $d[0], $matches)) {
                $normalized['diagnoses']['chronic'][] = [
                    'code'          => $matches[1],
                    'description'   => $matches[2]
                ];
            }
        }

        if (preg_match('/Imaging Order (\S+)\s*added on ([\d\/]+)/i', implode('\n', $this->lines), $matched)) {
            $normalized['order']['order'] = $matched[1];
            $normalized['order']['sent'] = $matched[2];
        }

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        $data = $this->template;
        $data['order']['accession'] = $normalized['order']['order'] ?? '';
        $data['order']['DateOfService'] = $normalized['order']['sent'] ? Carbon::parse($normalized['order']['sent'])->format('YmdHis') : '';

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['code'] = $normalized['patient']['prn'];
        $data['patient']['DOB'] = date('YmdHis', strtotime($normalized['patient']['dob']));
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex'][0]);
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient']['contact']['home-phone']);
        $data['patient']['phone2'] = $this->parsePhone($normalized['patient']['contact']['mobile-phone']);
        $data['patient']['address'] = [
            'address1'  => $normalized['patient']['contact']['address-line-1'],
            'address2'  => $normalized['patient']['contact']['address-line-2'],
            'city'      => $normalized['patient']['contact']['city'],
            'state'     => strtoupper($normalized['patient']['contact']['state']),
            'country'   => 'USA',
            'zip'       => $normalized['patient']['contact']['zip-code']
        ];

        $data['referringDr'] = !empty($normalized['encounter']['seen-by']) ? $this->parseName($normalized['encounter']['seen-by']) : [];
        $data['referringDr']['sendingFacility'] = $normalized['facility']['name'];

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        $data['insuranceList'][0] = [
            'name' => $normalized['insurance']['guarantor-name'],
            'insured' => [
                'relation'  => $normalized['insurance']['patient-s-relationship-to'],
            ]
        ];

        $data['exams'] = [];
        foreach ($normalized['diagnoses'] as $procedure => $diagnoses) {
            $exam = [
                'comment'               => $procedure,
                'MultiDiagnosisList'    => $diagnoses
            ];
            $data['exams'][] = $exam;
        }

        return $data;
    }
}
