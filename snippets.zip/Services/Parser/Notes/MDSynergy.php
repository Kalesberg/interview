<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Notes;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * MDSynergy ClinicalNote Parser
 * format: MDSynergy
 * type: ClinicalNote
 */
class MDSynergy
{
    use HelperTrait;
    protected $format = 'MDSynergy';
    protected $type = 'Note';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/PROGRESS\s*NOTE/', $content) &&
            preg_match_all('/Patient\s*First\s*Name:/', $content) &&
            preg_match_all('/Patient\s*Last\s*Name:/', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/NoteData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];

        $normalized['firstname'] = $this->getValueBelow('Patient\s*First\s*Name');
        $normalized['lastname'] = $this->getValueBelow('Patient\s*Last\s*Name');
        $normalized['dob'] = $this->getValueBelow('Date\s*of\s*Birth');
        $normalized['sex'] = $this->getValueBelow('Sex:');
        $normalized['chart_no'] = $this->getValueBelow('Chart\s*No');

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['patient'] = $this->parseName($normalized['firstname'] . ' ' . $normalized['lastname']);
        $data['patient']['DOB'] = $normalized['dob'] ? Carbon::parse(preg_replace('/\D+/', '/', $normalized['dob']))->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['sex']);

        // $data['order']['accession'] = $normalized['chart_no'];

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
