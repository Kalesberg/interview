<?php

namespace ScriptSender\Services\Parser\Notes;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * GE ClinicalNote Parser
 * format: GE
 * type: Note
 */
class GE
{
    use HelperTrait;
    protected $format = 'GE';
    protected $type = 'Note';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/DOB\s*:/', $content) && preg_match_all('/Ins\s*:/', $content) &&
               preg_match_all('/Grp\s*:/', $content) && preg_match_all('/Chief\s*Complaint:/', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/NoteData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];

        foreach ($this->lines as $line_number => $line) {
            if (!isset($sep_line1) && preg_match('/Fax:/', $line)) {
                $sep_line1 = $line_number;
            }
            elseif (!isset($sep_line2) && preg_match('/DOB\s*:/', $line) && preg_match('/Ins\s*:/', $line) && preg_match('/Grp\s*:/', $line)) {
                $sep_line2 = $line_number;
            }
        }

        // Doctor information
        $lines = array_slice($this->lines, 0, $sep_line1 + 1);
        $lines = $this->trimArray($lines);
        $doctor = [];
        $doctor['facility'] = preg_split('/\s{5,}/', $lines[0])[0];
        $doctor['order-date'] = preg_split('/\s{5,}/', $lines[0])[1];
        $doctor['address'] = preg_split('/\s{5,}/', $lines[1])[0];
        $phones = preg_split('/\s{5,}/', $lines[2])[0];
        $doctor['phones'] = $this->trimArray(preg_split('/\D+/', $phones));
        $normalized['doctor'] = $doctor;

        // Patient information
        $patient = [];
        $patient['name'] = trim($this->lines[$sep_line2 - 1]);
        preg_match('/([^\s]+)\s*DOB\s*:\s*([^\s]+).*Ins\s*:(.*)\s*Grp\s*:(.*)/', $this->lines[$sep_line2], $matches);
        $patient['sex'] = $matches[1][0];
        $patient['dob'] = trim($matches[2]);
        $normalized['patient'] = $patient;

        // Insurance information
        $normalized['insurance']['name'] = $matches[3];
        $normalized['insurance']['group'] = $matches[4];

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $doctor = $this->getValue('Provider');
        $doctor = preg_replace('/\s+\S+$/', ',$0', $doctor);
        $data['referringDr'] = $this->parseName($doctor);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor']['address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor']['facility'];

        $data['order']['DateOfService'] = $normalized['doctor']['order-date'] ? Carbon::parse($normalized['doctor']['order-date'])->format('YmdHis') : '';

        $data['patient'] = $this->parseName($normalized['patient']['name']);
        $data['patient']['DOB'] = $normalized['patient']['dob'] ? Carbon::parse($normalized['patient']['dob'])->format('YmdHis') : '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient']['sex']);

        $data['insuranceList'][0] = [
            'name'      => trim($normalized['insurance']['name']),
            'insured'   => $data['patient'],
            'subscriber'=> trim($normalized['insurance']['group'])
        ];

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
