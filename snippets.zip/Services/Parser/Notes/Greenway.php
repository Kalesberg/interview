<?php

namespace ScriptSender\Services\Parser\Notes;

use ScriptSender\Services\Parser\HelperTrait;

/**
 * Greenway ClinicalNote Parser
 * format: Greenway
 * type: ClinicalNote
 */
class Greenway
{
    use HelperTrait;
    protected $format = 'Greenway';
    protected $type = 'Note';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match_all('/HISTORY\s*OF\s*PRESENT\s*ILLNESS/', $content) &&
            preg_match_all('/Encounter:/', $content) &&
            preg_match_all('/PLAN/', $content) &&
            preg_match_all('/ASSESSMENT/', $content);
    }

    /**
     * Parser constructor
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/NoteData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        $normalized = [];
        $boundaries = [];
        foreach ($this->lines as $line_number => $line) {
            if (!trim($line)) {
                continue;
            }
            if (preg_match('/^[^a-z:]+$/', trim($line), $matches)) {
                $boundaries[$line_number] = trim($matches[0]);
            }

        }

        $prev_sep_line = 0;
        $prev_heading = 'PATIENT';
        foreach ($boundaries as $line_number => $heading) {
            $slug = $this->slugify($prev_heading);
            $lines = array_slice($this->lines, $prev_sep_line, $line_number - $prev_sep_line);
            $normalized[$slug] = $this->parseKeyValues(join("\n", $lines));
            $prev_sep_line = $line_number + 1;
            $prev_heading = $heading;
        }
        $lines = array_slice($this->lines, $prev_sep_line);
        $normalized[$slug] = $this->parseKeyValues(join("\n", $lines));

        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    protected function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $name = preg_replace('/\s+/', ' ', (string) $normalized['patient']['provider']);
        if (substr_count($name, ' ') > 2 && !preg_match('/,\s[^\s]+$/', $name)) {
            $name = preg_replace('/\s[^\s]+$/', ',$0', $name);
        }
        $data['referringDr'] = $this->parseName($name);

        $name = trim(explode('-', $normalized['patient']['patient'])[1]);
        $data['patient'] = $this->parseName($name);
        $data['patient']['DOB'] = date('YmdHis', strtotime($normalized['patient']['dob']));
        $data['patient']['SSN'] = $normalized['patient']['ssn'];

        $data['order']['DateOfService'] = date('YmdHis', strtok($normalized['patient']['date']));

        $data['meta']['document_format'] = $this->format;
        $data['meta']['document_type'] = $this->type;

        error_reporting(1);
        return $data;
    }
}
