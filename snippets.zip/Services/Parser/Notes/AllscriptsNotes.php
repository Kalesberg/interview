<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Notes;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * AllscriptsNotes Order Parser
 * format: AllscriptsNotes
 * type: Order
 */
class AllscriptsNotes
{
    use HelperTrait;
    protected $format = 'AllscriptsNotes';
    protected $type = 'Note';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches AllscriptsNotes format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/.*Patient\s#:\s\d{4,10}\s*DOB:.*/', $content)
            && preg_match('/Date\sof\sEncounter:\s+.*/', $content)
            && preg_match('/History\sof\sPresent\sIllness/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode(PHP_EOL, $content);
        $this->template = include app_path('Services/Parser/NoteData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $lineHeaderStart = 0;
        $lineHeaderEnd = 0;
        $lineAssessmentsStart = 0;
        $lineAssessmentsEnd = 0;

        foreach ($this->lines as $no => $line) {
            if (preg_match('/^\s{80,}Fax:\s.*/', $line)) {
                $lineHeaderEnd = $no + 1;
            }

            if (preg_match('/^[A-z\s-\.]+\s*Patient\s#:\s\d{4,10}\s*DOB:.*/', $line)) {
                $patternLine  = '/^([A-z\s-\.]+)\s*'; // patient name
                $patternLine .= 'Patient\s#:\s(\d{4,10})\s*'; // patient number
                $patternLine .= 'DOB:\s(\d{2}\/\d{2}\/\d{4})\s\((\d{1,3})\syears\)/'; // patient date of birth and age

                preg_match($patternLine, $line, $matches);

                $patientName = $matches[1] ?? '';
                $patientNo = $matches[2] ?? '';
                $patientDOB = $matches[3] ?? '';
                $patientAge = $matches[4] ?? '';

                $normalized['patient_name'] = trim((string) $patientName);
                $normalized['patient_no'] = trim((string) $patientNo);
                $normalized['patient_dob'] = trim((string) $patientDOB);
                $normalized['patient_age'] = trim((string) $patientAge);
            }

            if (preg_match('/^Date\sof\sEncounter:\s{1,}(.*)/', $line, $matches)) {
                $orderDate = $matches[1] ?? '';
                $normalized['order_date'] = trim((string) $orderDate);
            }

            if (preg_match('/Assessments\s&\sPlans\s{5,}.*/', $line)) {
                $lineAssessmentsStart = $no + 1;
            }

            if (preg_match('/^Addendum/', $line)) {
                $lineAssessmentsEnd = $no - 1;
            }

            if (preg_match('/^History\sof\sPresent\sIllness\s{10,}(.*)\s\d{2}\/\d{2}\/\d{4}\s.*/', $line, $matches)) {
                $normalized['doctor_name'] = $matches[1] ?? '';
            }
        }

        $headerLength = $lineHeaderEnd - $lineHeaderStart;
        $header = array_slice($this->lines, $lineHeaderStart, $headerLength);
        $header = $this->trimArray($header);

        $normalized['doctor_facility'] = $header[0] ?? '';

        $doctorAddress = $header[1] ?? '';
        if (isset($header[2])) {
            $doctorAddress .= ', ' . $header[2];
        }

        $normalized['doctor_address'] = trim($doctorAddress);

        foreach ($header as $line) {
            if (preg_match('/^Phone:\s([0-9\(\)\s-]+)/', $line, $matches)) {
                $normalized['doctor_phone'] = $matches[1] ?? '';
            }

            if (preg_match('/^Fax:\s([0-9\(\)\s-]+)/', $line, $matches)) {
                $normalized['doctor_fax'] = $matches[1] ?? '';
            }
        }

        $assessmentsLength = $lineAssessmentsEnd - $lineAssessmentsStart;
        $assessments = array_slice($this->lines, $lineAssessmentsStart, $assessmentsLength);

        $normalized['exams'] = [];

        $exam = [];
        foreach ($assessments as $no => $line) {
            if (preg_match('/^([A-z-\.,\s\(\)]+)\s\((.*)\s\|\s(.*)\)/', $line, $matches)) {
                $diagnostic = $matches[1] ?? '';
                $icd9 = $matches[2] ?? '';
                $icd10 = $matches[3] ?? '';

                $exam['diag'] = trim((string) $diagnostic);
                $exam['icd9'] = trim((string) $icd9);
                $exam['icd10'] = trim((string) $icd10);
            }

            if (preg_match('/^\s{1,8}(.*)\s\((\d{3,10})\)/', $line, $matches)) {
                $study = $matches[1] ?? '';
                $code = $matches[2] ?? '';

                $exam['study'] = trim((string) $study);
                $exam['code'] = trim((string) $code);

                $normalized['exams'][] = $exam;
                $exam = [];
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = $this->type;
        $data['meta']['document_format'] = $this->format;

        if (count($normalized['exams']) > 1) {
            for ($i = 1; $i < count($normalized['exams']); $i++) {
                $data['exams'][$i] = $data['exams'][0];
            }
        }

        if (isset($normalized['patient_dob'])) {
            $date = Carbon::createFromFormat('m/d/Y', $normalized['patient_dob']);
            $patientDOB = $date->format('Ymd') . '000000';
        }

        if (isset($normalized['order_date'])) {
            $date = Carbon::createFromFormat('m/d/Y g:i A', $normalized['order_date']);
            $data['order']['DateOfService'] = $date->format('YmdHis');
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['doctor_name']);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patientDOB ?? '';
        $data['patient']['age'] = $normalized['patient_age'];

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor_phone']);
        $data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor_fax']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor_address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor_facility'];

        foreach ($normalized['exams'] as $i => $exam) {
            $data['exams'][$i]['study'] = $exam['study'];
            $data['exams'][$i]['procedure_code'] = $exam['code'];

            $data['exams'][$i]['MultiDiagnosisList'][0]['code'] = $exam['icd10'];
            $data['exams'][$i]['MultiDiagnosisList'][0]['description'] = $exam['diag'];
            $data['exams'][$i]['MultiDiagnosisList'][0]['coding_type'] = 'ICD10';
        }

        error_reporting(1);
        return $data;
    }
}
