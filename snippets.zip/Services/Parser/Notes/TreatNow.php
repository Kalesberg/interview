<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Notes;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * TreatNow Note Parser
 * format: TreatNow
 * type: Note
 */
class TreatNow
{
    use HelperTrait;
    protected $format = 'TreatNow';
    protected $type = 'Note';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches TreatNowNote format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/Summary\sView\sfor/', $content)
            && preg_match('/Current\sMedications\s*Reason\sfor\sAppointment/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/NoteData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        $line_header_start = 1;
        $line_header_end = 0;

        $line_assessments_start = 0;
        $line_assessments_end = 0;

        $line_treatment_start = 0;
        $line_treatment_end = 0;

        foreach ($this->lines as $no => $line) {
            if (preg_match('/Progress\sNotes:/', $line)) {
                $line_header_end = $no;
            }

            if (preg_match('/\s*Assessments\r/', $line)) {
                $line_assessments_start = $no;
            }

            if (preg_match('/\s*Treatment\r/', $line)) {
                $line_assessments_end = $no - 1;
                $line_treatment_start = $no;
            }

            if (preg_match('/\s*Electronically\ssigned\sby.*on/', $line)) {
                $line_treatment_end = $no - 1;
            }

            if (preg_match('/Patient:.*DOB:.*Progress\sNote:.*(\d{2}\/\d{2}\/\d{4})/', $line, $matches)) {
                $normalized['order_date'] = $matches[1] ?? '';
            }
        }

        $header_length = $line_header_end - $line_header_start + 1;
        $header_tmp = array_slice($this->lines, $line_header_start, $header_length);
        $header = [];

        foreach ($header_tmp as $line) {
            $header[] = preg_replace('/^\d{2}\/\d{2}\/\d{4}/', '', (string) $line);
        }

        $header = $this->trimArray($header);

        $assessments_length = $line_assessments_end - $line_assessments_start;
        $assessments_tmp = array_slice($this->lines, $line_assessments_start, $assessments_length);
        $assessments = [];

        $pos_assesment = strpos($assessments_tmp[0] ?? '', 'Assessments');

        foreach ($assessments_tmp as $line) {
            if (!preg_match('/\s*Assessments\r/', $line)) {
                $assessments[] = (string) substr((string) $line, $pos_assesment);
            }
        }

        $treatment_length = $line_treatment_end - $line_treatment_start;
        $treatment_tmp = array_slice($this->lines, $line_treatment_start, $treatment_length);
        $treatment = [];

        $pos_treatment = strpos($treatment_tmp[0] ?? '', 'Treatment');

        foreach ($treatment_tmp as $line) {
            if (!preg_match('/\s*Treatment\r/', $line)) {
                $treatment[] = (string) substr((string) $line, $pos_treatment);
            }
        }

        $treatment = $this->trimArray($treatment);

        //$normalized['patient_name'] = $header[0];

        foreach ($header as $no => $line) {
            if (preg_match('/DOB: (\d{2}\/\d{2}\/\d{4})/', $line, $matches)) {
                $normalized['patient_dob'] = $matches[1] ?? '';
            }

            if (preg_match('/(\d{1,3}Y\s\d{1,2}M|\d{1,3}Y)\sold/', $line, $matches)) {
                $normalized['patient_age'] = $matches[1] ?? '';

                $normalized['patient_name'] = isset($header[$no - 1]) ? trim((string) $header[$no - 1]) : '';
            }

            if (preg_match('/old\s(Female|Male),\sDOB/i', $line, $matches)) {
                $normalized['patient_sex'] = $matches[1] ?? '';
            }

            if (preg_match('/Account\sNumber:\s(.*)/', $line, $matches)) {
                $normalized['patient_account_no'] = $matches[1] ?? '';

                if (isset($header[$no + 1])) {
                    $normalized['patient_address'] = $header[$no + 1];
                }
            }

            if (preg_match('/Home:\s([0-9\-]+)/', $line, $matches)) {
                $normalized['patient_phone'] = $matches[1] ?? '';
            }

            if (preg_match('/Guarantor:(.*)Insurance:(.*)/', $line, $matches)) {
                $insured = $matches[1] ?? '';
                $insurance = $matches[2] ?? '';

                $normalized['insurance_name'] = trim((string) $insurance);
                $normalized['insured_name'] = trim((string) $insured);
            }

            if (preg_match('/(.*)\sPayer\sID:\s(\d{2,10})/', $line, $matches)) {
                $normalized['insurance_address'] = $matches[1] ?? '';
                $normalized['policy'] = $matches[2] ?? '';
            }

            if (preg_match('/Appointment\sFacility:(.*)/', $line, $matches)) {
                $facility = $matches[1] ?? '';
                $normalized['doctor_facility'] = trim((string) $facility);
            }

            if (preg_match('/Progress\sNotes:(.*)/', $line, $matches)) {
                $doctor = $matches[1] ?? '';
                $normalized['doctor_name'] = trim((string) $doctor);
            }
        }

        $icd_codes = [];

        foreach ($assessments as $line) {
            $line = preg_replace('/\(.*\)/', '', $line);

            preg_match('/^\d{1,2}\.\s(.*)\s-\s([A-Z0-9\.]+)/', $line, $matches);

            $code = $matches[2] ?? '';
            $desc = $matches[1] ?? '';

            if (!empty($code) && !empty($desc)) {
                $icd_codes[trim((string) $code)] = trim((string) $desc);
            }
        }

        $treatment_lines = [];

        foreach ($treatment as $no => $line) {
            if (preg_match('/\d{1,3}\.\s.*/', $line)) {
                $treatment_lines[] = $no;
            }
        }

        $normalized['exams'] = [];

        for ($i = 0; $i < count($treatment_lines); $i++) {
            $notes = '';

            $line_no = $treatment_lines[$i];

            preg_match('/IMAGING:\s(.*)/', $treatment[$line_no + 1], $matches);
            $study = $matches[1] ?? '';

            if (isset($treatment[$line_no + 2]) && preg_match('/Notes:.*/', $treatment[$line_no + 2])) {
                $notes = '';
                for ($j = $line_no + 2; $j < $treatment_lines[$i + 1]; $j++) {
                    $notes .= isset($treatment[$j]) ? ' ' . $treatment[$j] : '';
                }

                $notes = preg_replace('/Notes:/', '', $notes);
                $notes = trim((string) $notes);
            }

            $normalized['exams'][] = [
                'study'   => trim((string) $study),
                'comment' => $notes ?? '',
                'icd10'   => $icd_codes
            ];
        }

        foreach ($this->lines as $no => $line) {
            if ($no < $line_treatment_end) {
                continue;
            }

            if (preg_match('/' . preg_quote($normalized['doctor_facility']) . '/', $line)) {
                $address = trim((string) $this->lines[$no + 1]) . ', ' . trim((string) $this->lines[$no + 2]);

                $lines = trim((string) $this->lines[$no + 3]) . PHP_EOL . trim((string) $this->lines[$no + 4]);
                $values = $this->parseKeyValues($lines);

                $normalized['doctor_address'] = $address;
                $normalized['doctor_phone'] = $values['tel'] ?? '';
                $normalized['doctor_fax'] = $values['fax'] ?? '';
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = $this->type;
        $data['meta']['document_format'] = $this->format;

        if (count($normalized['exams']) > 1) {
            for ($i = 1; $i < count($normalized['exams']); $i++) {
                $data['exams'][$i] = $data['exams'][0];
            }
        }

        if (!empty($normalized['order_date'])) {
            $dos = Carbon::createFromFormat('m/d/Y', $normalized['order_date']);
            $data['order']['DateOfService'] = $dos->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);
        $doctor = $this->parseName($normalized['doctor_name']);

        if (isset($normalized['patient_dob'])) {
            $date = Carbon::createFromFormat('m/d/Y', $normalized['patient_dob']);
            $patient_dob = $date->format('Ymd') . '000000';
        }

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patient_dob ?? '';
        $data['patient']['sex'] = $this->parseGender($normalized['patient_sex']);
        $data['patient']['age'] = $normalized['patient_age'];
        $data['patient']['phone1'] = $this->parsePhone($normalized['patient_phone']);
        $data['patient']['address'] = $this->parseAddress($normalized['patient_address']);

        $data['referringDr'] = array_replace($data['referringDr'], $doctor);
        $data['referringDr']['phone1'] = $this->parsePhone($normalized['doctor_phone']);
        //$data['referringDr']['phone2'] = $this->parsePhone($normalized['doctor_fax']);
        $data['referringDr']['address'] = $this->parseAddress($normalized['doctor_address']);
        $data['referringDr']['sendingFacility'] = $normalized['doctor_facility'];

        $data['insuranceList'][0]['name'] = $normalized['insurance_name'];
        $data['insuranceList'][0]['insurance-address'] = $normalized['insurance_address'];
        $data['insuranceList'][0]['policy'] = $normalized['policy'];

        if (isset($normalized['insured_name']) && !empty($normalized['insured_name'])) {
            $insured = $this->parseName($normalized['insured_name']);

            $data['insuranceList'][0]['insured']['name'] = $insured['name'] ?? '';
            $data['insuranceList'][0]['insured']['firstname'] = $insured['firstname'] ?? '';
            $data['insuranceList'][0]['insured']['middlename'] = $insured['middlename'] ?? '';
            $data['insuranceList'][0]['insured']['lastname'] = $insured['lastname'] ?? '';
            $data['insuranceList'][0]['insured']['title'] = $insured['title'] ?? '';

            $data['insuranceList'][0]['subscriber'] = $normalized['insured_name'];
        }

        for ($i = 0; $i < count($normalized['exams']); $i++) {
            $data['exams'][$i]['study'] = $normalized['exams'][$i]['study'];
            $data['exams'][$i]['comment'] = $normalized['exams'][$i]['comment'];

            foreach ($normalized['exams'][$i]['icd10'] as $code => $description) {
                $data['exams'][$i]['MultiDiagnosisList'][] = [
                    'code'        => $code,
                    'coding_type' => 'ICD10',
                    'description' => $description
                ];
            }
        }

        error_reporting(1);
        return $data;
    }
}
