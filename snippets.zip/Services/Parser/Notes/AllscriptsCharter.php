<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Notes;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * AllscriptsCharter Note Parser
 * format: AllscriptsCharter
 * type: Note
 */
class AllscriptsCharter
{
    use HelperTrait;
    protected $format = 'AllscriptsCharter';
    protected $type = 'Note';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches AllscriptsCharter format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/.*Patient\s*#:.*DOB:.*/', $content)
            && preg_match('/Date\sof\sEncounter:\s+.*/', $content)
            && preg_match('/Assessments\s+&\s+Plans/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode(PHP_EOL, $content);
        $this->template = include app_path('Services/Parser/NoteData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        foreach ($this->lines as $line) {
            if (preg_match('/Patient\s*#/', $line)) {
                preg_match('/^(.*)Patient\s*#:.*DOB:\s{1,}(\d{2}\/\d{2}\/\d{4})/', $line, $matches);

                $patientName = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $patientDOB = isset($matches[2]) ? trim((string) $matches[2]) : '';
                $patientDOB = preg_replace('/\D/', '-', $patientDOB);

                $normalized['patient_name'] = $patientName;
                $normalized['patient_dob'] = $patientDOB;
            }

            if (preg_match('/Date\sof\sEncounter:/', $line)) {
                $pattern = '/Date\sof\sEncounter:\s{1,}(\d{2}\/\d{2}\/\d{4}\s{1,}\d{1,2}:\d{2}\s{1}[A-Z]{2})/';
                preg_match($pattern, $line, $matches);

                $orderDate = $matches[1] ?? '';
                $orderDate = trim((string) $orderDate);

                if (strlen($orderDate) > 0) {
                    $orderDate = preg_replace('/\s{2,}/', ' ', $orderDate);
                }

                $normalized['order_date'] = $orderDate;
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = $this->type;
        $data['meta']['document_format'] = $this->format;

        if (isset($normalized['patient_dob']) && strlen($normalized['patient_dob']) > 0) {
            $date = Carbon::createFromFormat('m-d-Y', $normalized['patient_dob']);
            $patientDOB = $date->format('Ymd') . '000000';
        }

        if (isset($normalized['order_date']) && strlen($normalized['order_date']) > 0) {
            $date = Carbon::createFromFormat('m/d/Y h:i A', $normalized['order_date']);
            $data['order']['DateOfService'] = $date->format('Ymdhi') . '00';
        }

        $patient = $this->parseName($normalized['patient_name']);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patientDOB ?? '';

        error_reporting(1);
        return $data;
    }
}
