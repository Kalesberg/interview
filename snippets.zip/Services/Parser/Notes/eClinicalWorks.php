<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Notes;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;


/**
 * eClinicalWorks Note Parser
 * format: eClinicalWorks
 * type: Note
 */
class eClinicalWorks
{
    use HelperTrait;
    protected $format = 'eClinicalWorks';
    protected $type = 'Note';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches eClinicalWorks format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return preg_match('/DOB:.*Age:.*Sex:.*/', $content) && preg_match('/Home:.*Primary Insurance:/', $content);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode(PHP_EOL, $content);
        $this->template = include app_path('Services/Parser/NoteData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $normalized = [];

        foreach ($this->lines as $no => $line) {
            if (preg_match('/DOB:(.*)Age:.*Sex:.*/', $line, $matches)) {
                $patientName = isset($this->lines[$no - 2]) ? trim((string) $this->lines[$no - 2]) : '';

                $patientDOB = isset($matches[1]) ? trim((string) $matches[1]) : '';
                $patientDOB = preg_replace('/\D/', '-', $patientDOB);

                $normalized['patient_name'] = $patientName;
                $normalized['patient_dob'] = $patientDOB;
            }
        }

        error_reporting(1);
        return $this->getArray($normalized);
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        error_reporting(0);
        $data = $this->template;

        $data['meta']['document_type'] = $this->type;
        $data['meta']['document_format'] = $this->format;

        if (isset($normalized['patient_dob']) && strlen($normalized['patient_dob']) > 0) {
            $date = Carbon::createFromFormat('m-d-Y', $normalized['patient_dob']);
            $patientDOB = $date->format('Ymd') . '000000';
        }

        $patient = $this->parseName($normalized['patient_name']);

        $data['patient'] = array_replace($data['patient'], $patient);
        $data['patient']['DOB'] = $patientDOB ?? '';

        error_reporting(1);
        return $data;
    }
}
