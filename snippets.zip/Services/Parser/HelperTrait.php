<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser;

/**
 * Trait HelperTrait
 */
trait HelperTrait
{
    /**
     * Specific function to parse exam cases
     * @param array $params (Contains header labels and exam data)
     * @return array
     */
    public function parseExams(array $params): array
    {
        $exams = [];
        $header = preg_split('/\s{3,}/', trim($params['header']));
        $exams['header'] = $header;

        $header_positions = [];
        foreach ($header as $label) {
            $sPos = stripos($params['header'], $label);
            $ePos = $sPos + \strlen($label);
            $header_positions[] = [$sPos, $ePos];
        }

        $exams['cases'] = [];
        foreach ($params['cases'] as $string) {
            $case = array_pad([], count($header), '');
            $pairs = preg_split('/\s{2,}/', $string, -1, PREG_SPLIT_OFFSET_CAPTURE);

            foreach ($pairs as $pair) {
                $value = $pair[0];
                if (empty(trim($value))) {
                    continue;
                }

                $sPos = $pair[1];
                $ePos = $sPos + \strlen($value);

                foreach ($header_positions as $index => $position) {
                    if (($sPos <= $position[0] && $ePos >= $position[0]) || ($sPos <= $position[1] && $ePos >= $position[1])
                        || ($position[0] <= $sPos && $position[1] >= $sPos) || ($position[0] <= $ePos && $position[1] >= $ePos)
                    ) {
                        $case[$index] = trim($value);
                        break;
                    }
                }
            }
            $exams['cases'][] = $case;
        }

        return $exams;
    }

    /**
     * Parse name and title from string data
     * @param string $input
     * @param $reverse (swap firstname and lastname)
     * Example: Caroline Day, MD
     * @return array
     */
    public function parseName(string $input = null, bool $reverse = false): array
    {
        if (!$input || !trim($input)) {
            return [];
        }
        $input = trim($input);

        if (strpos($input, ',') !== false && preg_match('/^\S+(,)/', $input, $matches, PREG_OFFSET_CAPTURE)) {
            $reverse = true;
            $input[$matches[1][1]] = ' ';
        }

        if (substr_count($input, ',') > 1) {
            $input = substr_replace($input, ' ', strpos($input, ','), 1);
        }
        $name = preg_split('/\s+/', explode(',', $input)[0], 3);
        $title = explode(',', $input)[1] ?? '';

        $input = preg_replace('/\s{2,}/', ' ', $input);

        $ret['name'] = trim($input);
        $ret['firstname'] = strTrim($name[0]);
        $ret['middlename'] = strTrim((count($name) === 3) ? $name[1] : '');
        $ret['lastname'] = strTrim((count($name) === 3) ? $name[2] : $name[1]);
        $ret['title'] = strTrim($title);

        if ($reverse) {
            $ret['name'] = preg_replace('/^[\S]+/', '$0,', $ret['name']);
            $firstname = $ret['firstname'];
            if ($ret['middlename'] != '') {
                $ret['firstname'] = $ret['middlename'];
                $ret['middlename'] = $ret['lastname'];
                $ret['lastname'] = $firstname;
            }
            else {
                $ret['firstname'] = $ret['lastname'];
                $ret['lastname'] = $firstname;
            }
        }

        foreach ($ret as & $v) {
            $v = addslashes((string) $v);
        }

        return $ret;
    }

    /**
     * Parse mobile phone numbers
     * @param string $input
     * @return string
     */
    public function parsePhone(string $input = null): string
    {
        if (!$input) {
            return '';
        }

        $number = preg_replace('/\D/', '', $input);
        if (preg_match('/^\d?(\d{3})(\d{3})(\d{4})$/', $number, $matches)) {
            $number = $matches[1].'-'.$matches[2].'-'.$matches[3];
        }

        return $number;
    }

    /**
     * Get part of the address string data
     *
     * @param  string $input (Full address)
     * @param  string|string $partial
     *
     * (indicates the part to extract .i.e Country, City, State etc)
     * @return array|bool|mixed
     */
    public function parseAddress(string $input = null, string $partial = '', string $pattern = '')
    {
        if (!$input) {
            return [];
        }

        $input = str_replace(' ,', ',', $input);
        $input = str_ireplace([', USA', ', US'], '', $input);
        $partial = trim($partial);

        if (empty($pattern)) {
            $pattern = '/^([^,]+),(?:\s*([^,]+),)?(?:\s*([^,]+),)?\s*([A-Za-z]{2})(?:[,\.]?\s*([A-Za-z0-9\-\s]+))?/';
        }

        if (!preg_match($pattern, $input, $matches)) {
            return false;
        }

        $location = [];
        $location['address'] = $matches[0];
        $location['address1'] = $matches[1];
        $location['address2'] = $matches[2];
        $location['city'] = $matches[3];
        $location['state'] = $matches[4];
        $location['country'] = '';
        $location['zip'] = trim((string) $matches[5], '- ');

        if (empty($location['city']) && !empty($location['address2']) && $this->isCityInUS($location['address2'])) {
            $location['city'] = $location['address2'];
            $location['address2'] = '';
        }

        if ($partial) {
            return $location[$partial];
        }

        return $location;
    }

    /**
     * @param string|null $input
     * @return array|bool|mixed
     */
    public function parseGeoAddress(string $input = null)
    {
        if (!strlen(trim($input))) {
            return [];
        }

        /* @var \Illuminate\Support\Collection $hits */
        $hits = app('geocoder')->geocode($input)->get();
        if (!$hits->count()) {
            return [];
        }

        /* @var \Geocoder\Provider\GoogleMaps\Model\GoogleAddress $hit */
        $hit = $hits->first();

        // address line 1 if necessary
        $address = $hit->getFormattedAddress();
        switch (substr_count($address, ',')) {
            case 0:
            case 1:
                return [];

            case 2:
                $address = 'N/A, ' . $address;

            default:
                return $this->parseAddress($address);
        }
    }

    /**
     * Function to parse certain block of text to (key,value) pairs
     * @param type|array $params
     * @return type|array $data
     * [USECASE]
     * Key1: Value1
     * Key2: Value2
     * ...
     */

    public function parseKeyValues($params)
    {
        if (empty($params)) {
            return [];
        }
        $params = (array) $params;
        $content = $params['content'] ?? $params[0];
        $delimiter = $params['delimiter'] ?? '/(:|;)/';

        $lines = explode("\n", $content);
        $data = [];
        $prev_key = $prev_val = '';
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) {
                continue;
            }

            if (preg_match($delimiter, $line)) {
                if (!empty($prev_key)) {
                    $data[$prev_key] = $prev_val;
                }
                $prev_key = trim(preg_split($delimiter, $line, 2)[0]);
                $prev_val = trim(preg_split($delimiter, $line, 2)[1]);
                $prev_key = $this->slugify($prev_key);
                while (array_key_exists($prev_key, $data)) {
                    $prev_key .= '_';
                }
            }
            else {
                if (empty(trim($prev_val))) {
                    $prev_val = $line;
                }
                else {
                    $prev_val .= ', ' . $line;
                }
            }
        }
        $data[$prev_key] = $prev_val;

        return $data;
    }

    /**
     * Provide extended function on top of `parseKeyValues`
     * Parse multiple key: value pairs on a single line
     * @param array $lines
     * @return array
     * [USECASE]
     * Key1: Value1         Key2: Value2
     * Key3: Value3
     */
    public function parseMultiKeyValues(array $params): array
    {
        $newlines = [];

        $regex = '/\b(?:(?!\s{3,})[^:;])+\s*(?::|;)(?:\s*(?:(?!\s{7,})(?!\S+\s*[:;]).)+)?/';
        if (isset($params['regex']) && !empty($params['regex'])) {
            $regex = $params['regex'];
            unset($params['regex']);
        }
        $lines = $params;

        foreach ($lines as $line) {
            $line = $line ? trim($line) : '';
            if (!$line) {
                continue;
            }
            if (preg_match_all($regex, $line, $matches)) {
                $newlines = array_merge($newlines, $matches[0]);
            }
            else {
                $newlines[] = $line;
            }
        }
        $newlines = implode("\n", $newlines);
        return $this->parseKeyValues($newlines);
    }

    /**
     * Make key/value pair from a single string
     * @param string $input
     * Example: Priority: high => ['priority', 'high']
     * @return array
     */
    public function getKeyValue(string $input): array
    {
        $input = trim($input);
        if (!strpos($input, ':')) {
            $key = $this->slugify($input);
            return [$key, $input];
        }

        $pairs = explode(':', $input, 2);
        $key = $this->slugify($pairs[0]);
        $value = trim($pairs[1]);

        return [$key, $value];
    }

    /**
     * Extract the value next bound to the search key
     * @param array $params : 0 - Search Key, 1 - array of string, 2 - Line index to start search
     *        string default: Search Key
     * @return string
     * @throws \Exception
     * @throws ParseException
     * [USECASE]
     * Key: Value
     */
    public function getValue($params)
    {
        $params = (array) $params;
        $search = $params['search'] ?? $params[0];
        if (!$search) {
            throw new ParseException('[getValue] You should provide search key.');
        }
        $lines = $params['lines'] ?? $this->lines;
        $from = $params['from'] ?? 0;
        $sticky = $params['sticky'] ?? true;
        $delimiter = $params['delimiter'] ?? '(:|;)';

        for ($n = $from; $n < count($lines); $n ++) {
            $line = $lines[$n];
            if (trim($line) === '') {
                continue;
            }
            if (preg_match('/'.$search.'\s*'.$delimiter.'/i', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $sPos = $matches[0][1];
                $catch = trim(preg_split('/'.$delimiter.'/', substr($line, $sPos), 2)[1]);
                if ($sticky) {
                    return $catch;
                }
                return preg_split('/\s{3,}/', $catch)[0];
            }
        }
        return '';
    }

    /**
     * Extract the value under heading
     * @param array $params : 0 - Search Key, 1 - array of string, 2 - Line index to start search
     *        string default: Search Key
     * @return string
     * @throws ParseException
     * [USECASE]
     * Key
     * Value
     */
    public function getValueBelow($params)
    {
        $params = (array) $params;
        $search = $params['search'] ?? $params[0] ?? '';
        if (!$search) {
            throw new ParseException('[getValueBelow] You should provide search key.');
        }
        $lines = $params['lines'] ?? $this->lines;
        $from = $params['from'] ?? 0;
        for ($n = $from; $n < count($lines); $n ++) {
            $line = $lines[$n];
            if (trim($line) === '') {
                continue;
            }
            if (preg_match('/'.$search.'/i', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $headPos = $matches[0][1];
                $tailPos = $headPos + \strlen($search) - 1;
                break;
            }
        }
        if (!isset($headPos)) {
            return '';
        }
        $str = trim($lines[$n + 1]) === '' ? $lines[$n + 2] : $lines[$n + 1];
        if (trim($str) === '') {
            return '';
        }

        $chunks = preg_split('/\s{3,}/', $str, -1, PREG_SPLIT_OFFSET_CAPTURE);
        foreach ($chunks as $c) {
            $pos1 = $c[1];
            $pos2 = $c[1] + \strlen($c[0]) - 1;
            if (($headPos <= $pos1 && $tailPos >= $pos2) || ($headPos >= $pos1 && $tailPos <= $pos2) ||
                ($headPos <= $pos1 && $tailPos >= $pos1) || ($headPos <= $pos2 && $tailPos >= $pos2)) {
                return trim($c[0]);
            }
        }

        return '';
    }

    /**
     * Parse multiple lines of data based on headings.
     * @param array $params (index-0: headings)
     * @return array
     * [USECASE]
     * Heading1     Heading2    Heading3
     * value1_1     value2_1    value3_1
     * value1_2     value2_2    value3_2
     *   ...          ...         ...
     * @headings - array of header labels
     * @raw - rows parsed by single line
     * @parsed - rows parsed by chunks of lines
     */
    public function parseValuesUnderHeading(array $params): array
    {
        if (empty($params) || !$params) {
            return [
                'headings'  => [],
                'raw'       => [],
                'parsed'    => []
            ];
        }

        $head_str = array_shift($params);
        $master_col = $params['master_col'] ?? 0;
        unset($params['master_col']);
        $glue = $params['glue'] ?? ' ';
        unset($params['glue']);

        $chunks = preg_split('/\s{3,}/', $head_str, -1, PREG_SPLIT_OFFSET_CAPTURE);
        $headings = $head_pos1 = $head_pos2 = [];
        foreach ($chunks as $c) {
            if (trim($c[0]) === '') {
                continue;
            }

            $headings[] = $c[0];
            $head_pos1[] = $c[1];
            $head_pos2[] = $c[1] + strlen($c[0]) - 1;
        }

        $data_raw = [];
        $data_parsed = [];

        $parsed_row = [];
        foreach ($params as $line) {
            if (trim($line) === '') {
                if (isset($parsed_row) && !empty($parsed_row)) {
                    $data_parsed[] = $parsed_row;
                    $parsed_row = [];
                }
                continue;
            }

            $row = [];

            for ($i = 0; $i < count($headings); $i ++) {
                $pos = $head_pos1[$i];
                // Re-calculate the starting point of string
                // due to some bad OCR compilation
                if (\strlen($line) > $pos && $line[$pos] !== ' ' && $line[$pos - 1] !== ' ') {
                    $pos = intval(strrpos(substr($line, 0, $pos), ' '));
                }
                if ($i === count($head_pos1) - 1) {
                    $str = substr($line, $pos);
                }
                else {
                    $str = substr($line, $pos, $head_pos1[$i + 1] - $pos);
                    if (\strlen($line) > $head_pos1[$i + 1] && $line[$head_pos1[$i + 1]] !== ' ' && $line[$head_pos1[$i + 1] - 1] !== ' ') {
                        $tmpPos = strrpos($str, ' ') ? strrpos($str, ' ') : strlen($str);
                        $str = substr($str, 0, $tmpPos);
                    }
                }
                $row[] = $str ? trim($str) : '';
            }
            $data_raw[] = $row;

            if (trim($row[$master_col]) !== '' && !empty($parsed_row)) {
                $data_parsed[] = $parsed_row;
                $parsed_row = $row;
            }
            else {
                if (empty($parsed_row)) {
                    $parsed_row = $row;
                }
                else {
                    for ($i = 0; $i < count($row); $i ++) {
                        if ($row[$i] == '' || $i === $master_col) {
                            continue;
                        }
                        $parsed_row[$i] .= $glue . $row[$i];
                        $parsed_row[$i] = ($parsed_row[$i] == $glue) ? '' : trim($parsed_row[$i]);
                    }
                }
            }
        }
        if (!empty($parsed_row)) {
            $data_parsed[] = $parsed_row;
        }

        $ret = [
            'headings'  => $headings,
            'raw'       => $data_raw,
            'parsed'    => $data_parsed
        ];

        return $ret;
    }

    /**
     * Parse values without any delimiter provided(:|;)
     * Uppercase phrases as key, normal strings as value
     * @param array $params
     * @return array
     * [USECASE]
     * FIRST NAME      Michelle         GENDER     Female        ETHNICITY     -
    SSN              -               PRN       MG875244       STATUS     Active patient
     * [OUTPUT]
     * first-name: Michell, gender: Female, ethnicity: -
     * ssn: -, prn: MG875224, status: Active patient
     */

    public function parseValuesWithoutDelim(array $params): array
    {
        $lines = $params['lines'] ?? $params;
        // pattern to match only Keys (negating numbers and lowercase letters and multiple spaces)
        $keyPattern = $params['key_pattern'] ?? '/\b([A-Z](?:(?!\s{2,})[^\da-z])+)\b\s{2,}/';

        $Keys = $Values = [];
        foreach ($lines as $line) {
            if (trim($line) === '') {
                continue;
            }

            preg_match_all($keyPattern, trim($line), $matches);
            $keys = $matches[0];
            $keys = array_map(function ($key) {
                return $this->slugify($key);
            }, $keys);

            $values = preg_split($keyPattern, trim($line));
            array_shift($values);
            $values = array_map('trim', $values);

            foreach ($keys as $key) {
                $Keys[] = $key;
            }
            foreach ($values as $value) {
                $Values[] = $value;
            }
        }

        return array_combine($Keys, $Values);
    }

    /**
     * Check if all the values in the array are empty string
     * @param array $values
     * @return bool
     */
    public function emptyArray(array $values): bool
    {
        foreach ($values as $v) {
            if (!empty(trim($v))) {
                return false;
            }
        }
        return true;
    }

    /**
     * Remove lines which are empty from arrays
     * @param array $lines
     * @return array
     */
    protected function trimArray(array $lines, $ignoreSingleLine = NULL)
    {
        $Lines = [];
        foreach ($lines as $line) {
            if ($line && trim($line)) {
                if ($ignoreSingleLine) {
                    $Lines[] = $line;
                }
                else {
                    $Lines[] = trim($line);
                }
            }
        }
        return $Lines;
    }

    public function slugify(string $input)
    {
        // replace non letter or digits by -
        $input = preg_replace('/[^\pL\d]+/u', '-', $input);

        // transliterate
        $input = iconv('utf-8', 'us-ascii//TRANSLIT', $input);

        // remove unwanted characters
        $input = preg_replace('/[^-\w]+/', '', $input);

        // trim
        $input = trim($input, '-');

        // remove duplicate -
        $input = preg_replace('/-+/', '-', $input);

        // lowercase
        $slug = strtolower($input);

        if (empty($input)) {
            return 'n-a';
        }
        return $slug;
    }

    /**
     * Looks up $city in CSV file of USA cities
     * @param string $city
     * @return bool
     */
    public function isCityInUS(string $city): bool
    {
        $contents = file_get_contents(__DIR__ . '/uscities.csv');
        $city = trim(preg_replace('/\s+/', ' ', $city));
        return preg_match_all('/\\n(?:\\r)?' . $city . '\|/i', $contents) ||
               preg_match_all('/\|' . $city . '\\n/i', $contents);
    }

    /**
     * Map full state names to corresponding abbreviation
     *
     * @param $state
     * @return string|void
     */
    public function abbreviateUSStateName($state)
    {
        if (!$state) {
            return;
        }
        $states = ['California' => 'CA', 'Maryland' => 'MD'];
        foreach ($states as $full => $abbr) {
            if (false !== stripos($state, $full)) {
                return $abbr;
            }
        }
        return 'Unknown';
    }

    /**
     * Parse the gender value extracted by parser and returns M, F or U:
     *   Male          -> M
     *   Female        -> F
     *   Anything else -> U
     *
     * @param mixed $gender
     * @return string
     */
    public function parseGender($gender): string
    {
        $gender = trim((string) $gender);

        if (strlen($gender) === 0 || $gender === 'U') {
            return 'U';
        }

        $genderShort = strtoupper(substr($gender, 0, 1));

        if (in_array($genderShort, ['M', 'F'])) {
            return $genderShort;
        }

        return 'U';
    }

    /**
     * Checks if a doctor name contains a comma before the title and
     * adds of if it's missing
     *
     * @param  string $nameStr Doctor name parsed from template
     * @return string
     */
    private function fixDoctorTitle(string $nameStr): string
    {
        if (preg_match('/,/', $nameStr)) {
            return $nameStr;
        }

        $titlesPatterns = [
            '/^aud$/i',         // AuD - Doctor of Audiology
            '/^dc$/i',          // DC - Doctor of Chiropractic
            '/^dds$/i',         // DDS - Doctor of Dental Surgery, Doctor of Dental Science
            '/^dmd$/i',         // DMD - Doctor of Dental Medicine, Doctor of Medical Dentistry
            '/^do$|^od$/i',     // DO or OD - Doctor of Optometry, Doctor of Osteopathic Medicine
            '/^dpm$/i',         // DPM - Doctor of Pediatric Medicine
            '/^dpt$/i',         // DPT - Doctor of Physical Therapy
            '/^dscpt$/i',       // DScPT - Doctor of Science in Physical Therapy
            '/^dsn$/i',         // DSN - Doctor of Science in Nursing
            '/^dvm$/i',         // DVM - Doctor of Veterinary Medicine
            '/^ent$/i',         // ENT - Ear, nose and throat specialist
            '/^gp$/i',          // GP - General Practitioner
            '/^gyn$/i',         // GYN - Gynecologist
            '/^md$/i',          // MD - Doctor of Medicine
            '/^ms$/i',          // MS - Master of Surgery
            '/^ob\/gyn$/i',     // OB/GYN - Obstetrician and Gynecologist
            '/^pharmd$/i',      // PharmD - Doctor of Pharmacy
            '/^dd$/i',          // DD - Doctor of Divinity
            '/^ded$|^edt$/i',   // DEd or EdD - Doctor of Education
            '/^dpa$/i',         // DPA - Doctor of Public Administration
            '/^dph$/i',         // DPH - Doctor of Public Health
            '/^dphil$|^phd$/i', // DPhil or PhD - Doctor of Philosophy
            '/^ffphm$/i',       // FFPHM - Fellow Faculty of Public Health Medicine
            '/^jd$/i',          // JD - Doctor of Jurisprudence
            '/^psych$/i',       // PSYCH - Psychologist
            '/^scd$/i',         // ScD - Doctor of Science
            '/^sscd$/i',        // SScD - Doctor of Social Science
            '/^thd$/i'          // ThD - Doctor of Theology
        ];

        $returnName = [];

        $nameArray = preg_split('/\s{1,}/', $nameStr);
        $namePiecesCount = count($nameArray);

        foreach ($nameArray as $index => $namePiece) {
            $namePieceClean = preg_replace('/[^a-z]/i', '', $namePiece);

            if ($index === $namePiecesCount - 1) {
                foreach ($titlesPatterns as $key => $pattern) {
                    if (preg_match($pattern, $namePieceClean)) {
                        $returnName[] = ',';
                    }
                }
            }

            $returnName[] = $namePiece;
        }

        $returnNameStr = implode(' ', $returnName);
        $returnNameStr = preg_replace('/\s{1,},/', ',', $returnNameStr);

        return $returnNameStr;
    }

    /**
     * Replaces full state name to abbreviation in addresses
     *
     * @param  string $address Address with complete state name
     * @return string
     */
    private function fixStateInAddress(string $address): string
    {
        if (preg_match('/\,\s*[a-z]{2}\s\d{4,}/i', $address)) {
            return $address;
        }

        $statesPatterns = [
            'ALABAMA'           => 'AL',
            'ALASKA'            => 'AK',
            'ARIZONA'           => 'AZ',
            'ARKANSAS'          => 'AR',
            'CALIFORNIA'        => 'CA',
            'COLORADO'          => 'CO',
            'CONNECTICUT'       => 'CT',
            'DELAWARE'          => 'DE',
            'FLORIDA'           => 'FL',
            'GEORGIA'           => 'GA',
            'HAWAII'            => 'HI',
            'IDAHO'             => 'ID',
            'ILLINOIS'          => 'IL',
            'INDIANA'           => 'IN',
            'IOWA'              => 'IA',
            'KANSAS'            => 'KS',
            'KENTUCKY'          => 'KY',
            'LOUISIANA'         => 'LA',
            'MAINE'             => 'ME',
            'MARYLAND'          => 'MD',
            'MASSACHUSETTS'     => 'MA',
            'MICHIGAN'          => 'MI',
            'MINNESOTA'         => 'MN',
            'MISSISSIPPI'       => 'MS',
            'MISSOURI'          => 'MO',
            'MONTANA'           => 'MT',
            'NEBRASKA'          => 'NE',
            'NEVADA'            => 'NV',
            'NEW HAMPSHIRE'     => 'NH',
            'NEW JERSEY'        => 'NJ',
            'NEW MEXICO'        => 'NM',
            'NEW YORK'          => 'NY',
            'NORTH CAROLINA'    => 'NC',
            'NORTH DAKOTA'      => 'ND',
            'OHIO'              => 'OH',
            'OKLAHOMA'          => 'OK',
            'OREGON'            => 'OR',
            'PENNSYLVANIA'      => 'PA',
            'RHODE ISLAND'      => 'RI',
            'SOUTH CAROLINA'    => 'SC',
            'SOUTH DAKOTA'      => 'SD',
            'TENNESSEE'         => 'TN',
            'TEXAS'             => 'TX',
            'UTAH'              => 'UT',
            'VERMONT'           => 'VT',
            'VIRGINIA'          => 'VA',
            'WASHINGTON'        => 'WA',
            'WEST VIRGINIA'     => 'WV',
            'WISCONSIN'         => 'WI',
            'WYOMING'           => 'WY'
        ];

        foreach ($statesPatterns as $state => $abbrev) {
            if (preg_match('/\,\s*' . $state . '\s\d{4,}/i', $address)) {
                $address = preg_replace('/' . preg_quote($state). '/i', $abbrev, $address);
            }
        }

        return $address;
    }
}
