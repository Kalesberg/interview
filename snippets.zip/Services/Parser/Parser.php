<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser;

use File;
use ScriptSender\Exceptions\DocumentUnknownException;
use ScriptSender\Exceptions\ParseException;
use ScriptSender\Logging\CustomizeLogger;

class Parser
{
    protected $text;
    protected $worker;
    protected $parsedData;

    /**
     * Parser constructor.
     * @param string $text
     */
    public function __construct(string $text)
    {
        (new CustomizeLogger())->setComponent('Parser');
        $this->text = $text;
    }

    /**
     * Detect the format and type of the given content
     *
     * @return void
     * @throws DocumentUnknownException
     */
    protected function detect(): void
    {
        $supportedTemplates = $this->getSupportedTypesAndFormats();
        foreach ($supportedTemplates as $type => $formats) {
            foreach ($formats as $format) {
                $className = "ScriptSender\\Services\\Parser\\$type\\$format";
                if (class_exists($className) && $className::matches($this->text)) {
                    $this->worker = new $className($this->text);
                    info('Document format & type identified', ['type' => $type, 'format' => $format]);
                    return;
                }
            }
        }
        throw new DocumentUnknownException('Failed to identify document');
    }

    /**
     * @return array
     * @throws \Exception
     * @throws DocumentUnknownException
     * @throws ParseException
     * @throws \Throwable
     */
    public function parse(): array
    {
        if (!$this->worker) {
            $this->detect();
        }
        $this->parsedData = $this->worker->parse();
        $templateView = $this->getTemplateView($this->parsedData['meta']['document_type']);
        $this->parsedData = $this->removeEmptyListElements($this->parsedData);
        $this->parsedData = json_decode(
            preg_replace('/[\r\n]/', '', view($templateView)->with(['data' => $this->parsedData])->render()),
            true
        );
        if (json_last_error()) {
            $json_errors = getJsonErrorStrings();
            throw new ParseException('Failed to decode JSON. Error: \'' . $json_errors[json_last_error()] . "'");
        }
        return $this->parsedData;
    }

    /**
     * @param array $data
     * @return array
     */
    public function removeEmptyListElements(array $data): array
    {
        foreach ($data['insuranceList'] as $i => $insurance) {
            if ($insurance && isListEmpty($insurance)) {
                array_splice($data['insuranceList'], $i, 1);
            }
        }
        foreach ($data['exams'] as $i => $exam) {
            foreach ($exam['MultiDiagnosisList'] as $j => $dx) {
                if ($dx && isListEmpty($dx)) {
                    array_splice($data['exams'][$i]['MultiDiagnosisList'], $j, 1);
                }
            }
        }
        foreach ($data['exams'] as $i => $exam) {
            if ($exam && isListEmpty($exam)) {
                array_splice($data['exams'], $i, 1);
            }
        }
        return $data;
    }

    /**
     * @return string
     * @throws DocumentUnknownException
     * @throws ParseException
     * @throws \Throwable
     */
    public function toJson(): string
    {
        if (!$this->parsedData) {
            $this->parse();
        }
        return preg_replace("/[\r\n]/", '', json_encode($this->parsedData, JSON_PRETTY_PRINT));
    }

    /**
     * @param string $docType
     * @return string
     * @throws ParseException
     */
    public function getTemplateView(string $docType): string
    {
        $docType = ucfirst(str_singular($docType));

        switch ($docType) {
            case 'Order':
                $template = 'parser.order_template';
                break;
            case 'Note':
                $template = 'parser.note_template';
                break;
            case 'Lab':
                $template = 'parser.labs_template';
                break;
            case 'Referral':
                $template = 'parser.referral_template';
                break;
            case 'Result':
                $template = 'parser.results_template';
                break;
            case 'PatientInfo':
                $template = 'parser.patientinfo_template';
                break;
            case 'Report':
                $template = 'parser.report_template';
                break;
            case 'Summary':
                $template = 'parser.summary_template';
                break;
            default:
                throw new ParseException("Unknown document type '{$docType}'");
        }
        return $template;
    }

    /**
     * Return a list of all supported types and formats
     *
     * @return array
     */
    public function getSupportedTypesAndFormats(): array
    {
        $templates = [];
        foreach (File::directories(__DIR__) as $type) { // Orders, Reports, Notes, Faxes etc.
            $workers = array_filter(File::files($type), function ($file) {
                return false !== strpos($file->getExtension(), 'php');
            });
            foreach ($workers as $file) { // PracticeFusion.php, eMDs.php etc.
                $format = $file->getBasename('.php');
                $type = basename($type);
                $templates[$type][] = $format;
            }
        }
        return $templates;
    }
}
