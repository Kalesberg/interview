<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser;

/**
 * Map standard data-tree to old type that Perl-based parsers are using. This class is used as a layer to smoothly
 * migrate from Perl-based parsing to PHP-based one.
 *
 * Class MigrateToNew
 * @package ScriptSender\Services\Parsers
 */
class MigrateToNew
{
    use HelperTrait;
    /**
     * Generate old data-structure from new one
     * @param string $parserOutput JSON formatted output from new parse engine
     * @param string $format Document format, if necessary
     * @return mixed
     */
    public function convertToOldStructure(string $parserOutput, string $format = 'json')
    {
        $newOutput = json_decode($parserOutput, true);

        $docFormat = $newOutput['meta']['document_format'];
        $function = 'old' . $docFormat;
        $oldOutput = method_exists($this, $function) ? $this->$function($newOutput) : $this->oldGreenway($newOutput);
        // try {
        //     $oldOutput = $this->$function($newOutput);
        // } catch(\Throwable $e) {
        //     Log::debug($e);
        //     $oldOutput = $newOutput;
        // }
        $oldOutput = $this->changeFormat($oldOutput, $format);

        return $oldOutput;
    }

    /**
     * Change output format of parsed document
     * @param array $output Input data to change the format
     * @param string $format Format type
     * @return mixed
     */
    public function changeFormat(array $output, string $format)
    {
        $ret = '';

        switch ($format) {
            case 'json':
                $ret = json_encode($output, JSON_PRETTY_PRINT);
                break;
            default:
                break;
        }

        return $ret;
    }

    /**
     * Generate perl script version of PracticeFusion Order parser from new output JSON
     * @param array $newOutput output of corresponding new parser
     * @return array
     */
    public function oldPracticeFusion_retired(array $newOutput) : array
    {
        $oldOutput = [
            'accession'             => $newOutput['order']['accession'] ?? '',
            'placer_order_number'   => $newOutput['order']['placer_order_number'] ?? '',
            'PID'                   => [
                'id'            => $newOutput['order']['PID'] ?? ''
            ],
            'format'                => $newOutput['meta']['document_format'],
            'document_type'         => $newOutput['meta']['document_type'],
            'submitTime'            => $newOutput['order']['DateOfService'] ?? '',
            'patient'               => [
                'firstname'         => $newOutput['patient']['firstname'] ?? '',
                'middlename'    => $newOutput['patient']['middlename'] ?? '',
                'lastname'          => $newOutput['patient']['lastname'] ?? '',
                'suffix'        => '',
                'phone'             => $newOutput['patient']['phone1'] ?? '',
                'DOB'               => $newOutput['patient']['DOB'] ?? '',
                'DOS'               => $newOutput['order']['DateOfService'] ?? '',
                'race'          => $newOutput['patient']['race'] ?? '',
                'sex'               => $newOutput['patient']['sex'] ?? '',
                'language'          => 'English',
                'address1'          => $newOutput['patient']['address']['address1'] ?? '',
                'address2'      => $newOutput['patient']['address']['address2'] ?? '',
                'city'              => $newOutput['patient']['address']['city'] ?? '',
                'state'             => $newOutput['patient']['address']['state'] ?? '',
                'country'           => $newOutput['patient']['address']['country'] ?? '',
                'zip'               => $newOutput['patient']['address']['zip'] ?? '',
                'name'              => $newOutput['patient']['name'] ?? '',
                'address'           => $newOutput['patient']['address']['address'] ?? '',
            ],
            'referringDr'           => [
                'firstname'         => $newOutput['referringDr']['firstname'] ?? '',
                'lastname'          => $newOutput['referringDr']['lastname'] ?? '',
                'code'              => $newOutput['referringDr']['npi'] ?? '',
                'phone'             => $newOutput['referringDr']['phone1'] ?? '',
                'address1'          => $newOutput['referringDr']['address']['address1'] ?? '',
                'city'              => $newOutput['referringDr']['address']['city'] ?? '',
                'state'             => $newOutput['referringDr']['address']['state'] ?? '',
                'country'           => $newOutput['referringDr']['address']['country'] ?? '',
                'zip'               => $newOutput['referringDr']['address']['zip'] ?? '',
                'sendingFacility'   => $newOutput['referringDr']['sendingFacility'] ?? '',
                'name'              => $newOutput['referringDr']['name'] ?? '',
                'address'           => $newOutput['referringDr']['address']['address'] ?? '',
            ],
            'attendingDr'           => [
                'firstname'     => $newOutput['referringDr']['firstname'] ?? '',
                'lastname'      => $newOutput['referringDr']['lastname'] ?? '',
                'code'          => $newOutput['referringDr']['npi'] ?? '',
            ],
            'receivingApplication'  => '',
            'servicingFacility'     => $newOutput['order']['servicingFacility'] ?? '',
            'receivingFacility'     => '',

            'sendingApplication'    => $newOutput['order']['sendingApplication'] ?? '',
            'exams'                 => $newOutput['exams'] ?? '',
            'insuranceList'         => [],
            'document_type'         => $newOutput['meta']['document_type'] ?? ''
        ];

        foreach ($newOutput['insuranceList'] as $ins) {
            $insured = $ins['insured'];
            $oldIns = [
                'providerNetwork'   => $ins['name'] ?? '',
                'group'             => $ins['group'] ?? '',
                'address'           => $ins['insurance-address'] ?? '',
                'policy'            => $ins['policy'] ?? '',
                'insured'           => [
                    'sex' => $insured['sex'] ?? '',
                    'name' => $insured['name'] ?? '',
                    'firstname' => $insured['firstname'] ?? '',
                    'lastname' => $insured['lastname'] ?? '',
                    'language' => 'English',
                    'DOB' => $insured['DOB'] ?? '',
                    'DOS' => $newOutput['order']['DateOfService'] ?? '',
                    'address' => $insured['address']['address'] ?? '',
                    'address1' => $insured['address']['address1'] ?? '',
                    'city' => $insured['address']['city'] ?? '',
                    'state' => $insured['address']['state'] ?? '',
                    'country' => 'USA',
                    'zip' => $insured['address']['zip'] ?? '',
                    'relationship' => 'Self',
                    'phone' => $insured['phone1'] ?? '',
                ]
            ];
            $oldOutput['insuranceList'][] = $oldIns;
        }

        return $oldOutput;
    }

    public function oldeMDs(array $newOutput) : array
    {
        $oldOutput = [
            'submitTime'    => $newOutput['order']['DateOfService'] ?? '',
            'document_type' => 'Order',
            'format'        => 'eMDs',
            'accession'     => $newOutput['order']['accession'] ?? '',
            'referringDr'   => [
                'firstname' => $newOutput['referringDr']['firstname'] ?? '',
                'lastname'  => $newOutput['referringDr']['lastname'] ?? '',
                'degree'    => $newOutput['referringDr']['title'] ?? '',
                'phone'     => $newOutput['referringDr']['phone1'] ?? '',
                'code'      => $newOutput['referringDr']['npi'] ?? '',
                'address1'  => $newOutput['referringDr']['address']['address1'] ?? '',
                'address2'  => $newOutput['referringDr']['address']['address2'] ?? '',
                'city'      => $newOutput['referringDr']['address']['city'] ?? '',
                'state'     => $newOutput['referringDr']['address']['state'] ?? '',
                'zip'       => $newOutput['referringDr']['address']['zip'] ?? '',
                'sendingFacility'   => $newOutput['referringDr']['sendingFacility'] ?? ''
            ],
            'patient'       => [
                'firstname' => $newOutput['patient']['firstname'] ?? '',
                'lastname'  => $newOutput['patient']['lastname'] ?? '',
                'suffix'    => $newOutput['patient']['middlename'] ?? '',
                'DOB'       => $newOutput['patient']['DOB'] ?? '',
                'DOS'       => $newOutput['order']['DateOfService'] ?? '',
                'phone'     => $newOutput['patient']['phone1'] ?? '',
                'sex'       => $newOutput['patient']['sex'] ?? '',
                'address1'  => $newOutput['patient']['address']['address1'] ?? '',
                'address2'  => $newOutput['patient']['address']['address2'] ?? '',
                'city'      => $newOutput['patient']['address']['city'] ?? '',
                'state'     => $newOutput['patient']['address']['state'] ?? '',
                'zip'       => $newOutput['patient']['address']['zip'] ?? '',
            ],
        ];

        $oldInsList = [];
        foreach ($newOutput['insuranceList'] as $ins) {
            $oldIns = [
                'group'     => $ins['subscriber'] ?? '',
                'policy'    => $ins['policy'] ?? '',
                'providerNetwork'   => $ins['name'] ?? '',
                'insured'   => [
                    'firstname' => $ins['insured']['firstname'] ?? '',
                    'lastname'  => $ins['insured']['lastname'] ?? '',
                    'suffix'    => $ins['insured']['middlename'] ?? '',
                ]
            ];
            $oldInsList[] = $oldIns;
        }
        $oldExams = [];
        foreach ($newOutput['exams'] as $exam) {
            $oldExam = [
                'procedure_code'    => $exam['procedure_code'] ?? '',
                'study'             => $exam['study'] ?? '',
            ];
            $diagnoses = [];
            foreach ($exam['MultiDiagnosisList'] as $diag) {
                $d = [
                    'code'      => $diag['code'] ?? '',
                    'method'    => $diag['coding_type'] ?? '',
                    'description'   => $diag['description'] ?? ''
                ];
                $diagnoses[] = $d;
            }
            $oldExam['MultiDiagnosisList'] = $diagnoses;
            $oldExams[] = $oldExam;
        }

        $oldOutput['insuranceList'] = $oldInsList;
        $oldOutput['exams'] = $oldExams;

        return $oldOutput;
    }

    public function oldGreenway(array $newOutput) : array
    {
        $oldOutput = [
            'accession'     => $newOutput['order']['accession'] ?? '',
            'placer_order_number'   => $newOutput['order']['placer_order_number'] ?? '',
            'PID'   => [
              'id'  => $newOutput['order']['PID'] ?? ''
            ],
            'format'    => $newOutput['meta']['document_format'],
            'document_type' => $newOutput['meta']['document_type'],
            'submitTime'    => $newOutput['order']['DateOfService'] ?? '',
            'patient'   => [
                'firstname'     => $newOutput['patient']['firstname'] ?? '',
                'middlename'    => $newOutput['patient']['middlename'] ?? '',
                'lastname'      => $newOutput['patient']['lastname'] ?? '',
                'suffix'        => '',
                'phone'         => $newOutput['patient']['phone1'] ?? '',
                'DOB'           => $newOutput['patient']['DOB'] ?? '',
                'DOS'           => $newOutput['order']['DateOfService'] ?? '',
                'race'          => $newOutput['patient']['race'] ?? '',
                'sex'           => $newOutput['patient']['sex'] ?? '',
                'language'      => $newOutput['patient']['language'] ?? '',
                'address1'      => $newOutput['patient']['address']['address1'] ?? '',
                'address2'      => $newOutput['patient']['address']['address2'] ?? '',
                'city'          => $newOutput['patient']['address']['city'] ?? '',
                'state'         => $newOutput['patient']['address']['state'] ?? '',
                'country'       => $newOutput['patient']['address']['country'] ?? '',
                'zip'           => $newOutput['patient']['address']['zip'] ?? ''
            ],
            'referringDr'       => [
                'firstname'     => $newOutput['referringDr']['firstname'] ?? '',
                'lastname'      => $newOutput['referringDr']['lastname'] ?? '',
                'code'          => $newOutput['referringDr']['npi'] ?? '',
                'phone'         => $newOutput['referringDr']['phone1'] ?? '',
                'address1'      => $newOutput['referringDr']['address']['address1'] ?? '',
                'address2'      => $newOutput['referringDr']['address']['address2'] ?? '',
                'city'          => $newOutput['referringDr']['address']['city'] ?? '',
                'state'         => $newOutput['referringDr']['address']['state'] ?? '',
                'zip'           => $newOutput['referringDr']['address']['zip'] ?? '',
                'sendingFacility'   => $newOutput['referringDr']['sendingFacility'] ?? ''
            ],
            'attendingDr'       => [
                'firstname'     => $newOutput['referringDr']['firstname'] ?? '',
                'lastname'      => $newOutput['referringDr']['lastname'] ?? '',
                'code'          => $newOutput['referringDr']['npi'] ?? ''
            ]
        ];

        $oldExams = [];
        foreach ($newOutput['exams'] as $exam) {
            $oldExam = [
                'procedure_code'    => $exam['procedure_code'] ?? '',
                'study'             => $exam['study'] ?? '',
                'comment'           => $exam['comment'] ?? '',
                'priority'          => $exam['priority'] ?? '',
            ];
            $diagnoses = [];
            foreach ($exam['MultiDiagnosisList'] as $d) {
                $diag = [
                    'coding_method' => !empty($d['coding_type']) ? str_replace('-', '', $d['coding_type']) : 'ICD10',
                    'code'          => $d['code'] ?? '',
                    'description'   => $d['description'] ?? ''
                ];
                $diagnoses[] = $diag;
            }
            $oldExam['MultiDiagnosisList'] = $diagnoses;
            $oldExams[] = $oldExam;
        }

        $oldInsList = [];
        foreach ($newOutput['insuranceList'] as $ins) {
            if (!strTrim($ins['name'])) {
                continue;
            }

            $oldIns = $this->parseAddress($ins['insurance-address']);
            $name = $this->parseName(str_replace(',', ' ', $ins['insured']['name']), true);
            $oldIns['insured']['firstname'] = $name['firstname'] ?? '';
            $oldIns['insured']['middlename'] = $name['middlename'] ?? '';
            $oldIns['insured']['lastname'] = $name['lastname'] ?? '';
            $oldIns['insured']['relationship'] = $ins['insured']['relationship'] ?? '';
            $oldIns['providerNetwork'] = $ins['name'] ?? '';
            $oldIns['group'] = $ins['subscriber'] ?? '';
            $oldIns['companyID'] = $ins['companyID'] ?? '';
            $oldIns['policy'] = $ins['policy'] ?? '';
            $oldIns['authorization'] = $ins['authorization'] ?? '';

            $oldInsList[] = $oldIns;
        }

        $oldOutput['exams'] = $oldExams;
        $oldOutput['insuranceList'] = $oldInsList;

        return $oldOutput;
    }

    public function oldAllscripts(array $newOutput) : array
    {
        $oldOutput = [
            'order'     => [
                'order_id'  => $newOutput['order']['accession'] ?? '',
                'Outside_Order_Code'    => $newOutput['exams'][0]['procedure_code'] ?? '',
                'Outside_Reason_Description'    => $newOutput['exams'][0]['study'] ?? '',
                'Outside_Reason_Code'   => null,
                'Outside_Request_Stat'  => 'Y'
            ],
            'referringDr'   => [
                'firstname' => $newOutput['referringDr']['firstname'] ?? '',
                'lastname'  => $newOutput['referringDr']['lastname'] ?? '',
                'name'      => $newOutput['referringDr']['firstname'] . ' ' . $newOutput['referringDr']['lastname'],
                'code'      => $newOutput['referringDr']['npi'] ?? '',
                'phone'     => $newOutput['referringDr']['phone1'] ?? '',
                'address1'  => $newOutput['referringDr']['address']['address1'] ?? '',
                'address2'  => $newOutput['referringDr']['address']['address2'] ?? '',
                'city'      => $newOutput['referringDr']['address']['city'] ?? '',
                'state'     => $newOutput['referringDr']['address']['state'] ?? '',
                'country'   => $newOutput['referringDr']['address']['country'] ?? '',
                'zip'       => $newOutput['referringDr']['address']['zip'] ?? '',
            ],
            'PID'   => [
                'id'    => $newOutput['order']['PID'] ?? ''
            ],
            'sendingApplication'    => 'AllScripts',
            'receivingFacility' => '',
            'submitTime'    => $newOutput['order']['DateOfService'] ?? '',
            'receivingApplication'  => 'ScriptSender',
            'servicingFacility' => '',
            'accession' => $newOutput['order']['accession'] ?? '',
            'insuranceList' => [[
                'providerNetwork'   => $newOutput['insuranceList'][0]['name'] ?? '',
                'policy'    => $newOutput['insuranceList'][0]['policy'] ?? ''
            ]],
            'Outside_Facility_Code' => $newOutput['order']['accession'] ?? '',
            'document_type' => $newOutput['meta']['document_type'] ?? '',
            'guarantor' => [
                'firstname' => $newOutput['guarantor']['firstname'] ?? '',
                'lastname' => $newOutput['guarantor']['lastname'] ?? '',
                'zip'   => $newOutput['guarantor']['address']['zip'] ?? '',
                'state' => $newOutput['guarantor']['address']['state'] ?? '',
                'address1'   => $newOutput['guarantor']['address']['address1'] ?? '',
                'hphone'    => $newOutput['guarantor']['phone'] ?? '',
                'GuarRelToPatient'  => $newOutput['guarantor']['relationship'] ?? '',
                'city'  => $newOutput['guarantor']['address']['city'] ?? ''
            ],
            'patient'   => [
                'state' => $newOutput['patient']['address']['state'] ?? '',
                'firstname' => $newOutput['patient']['firstname'] ?? '',
                'zip'   => $newOutput['patient']['address']['zip'] ?? '',
                'country'   => $newOutput['patient']['address']['country'] ?? '',
                'DOS'   => $newOutput['order']['DateOfService'] ?? '',
                'address1'  => $newOutput['patient']['address']['address1'] ?? '',
                'city'  => $newOutput['patient']['address']['city'] ?? '',
                'phone' => $newOutput['patient']['phone1'] ?? '',
                'lastname'  => $newOutput['patient']['lastname'] ?? '',
                'language'  => 'English',
                'sex'   => $newOutput['patient']['sex'] ?? '',
                'DOB'   => $newOutput['patient']['DOB'] ?? ''
            ],
            'exams' => $newOutput['exams']
        ];
        $oldOutput['attendingDr'] = $oldOutput['referringDr'];

        return $oldOutput;
    }

    public function oldAmazingCharts_retired(array $newOutput) : array
    {
        $oldOutput = [
            'referringDr'   => [
                'firstname' => $newOutput['referringDr']['firstname'] ?? '',
                'middlename' => $newOutput['referringDr']['middlename'] ?? '',
                'lastname'  => $newOutput['referringDr']['lastname'] ?? '',
                'degree'    => $newOutput['referringDr']['title'] ?? '',
                'phone'     => $newOutput['referringDr']['phone1'] ?? '',
                'address1'  => $newOutput['referringDr']['address']['address1'] ?? '',
                'address2'  => $newOutput['referringDr']['address']['address2'] ?? '',
                'city'      => $newOutput['referringDr']['address']['city'] ?? '',
                'state'     => $newOutput['referringDr']['address']['state'] ?? '',
                'country'   => $newOutput['referringDr']['address']['country'] ?? '',
                'zip'       => $newOutput['referringDr']['address']['zip'] ?? ''
            ],
            'patient'       => [
                'firstname' => $newOutput['patient']['firstname'] ?? '',
                'middlename' => $newOutput['patient']['middlename'] ?? '',
                'lastname'  => $newOutput['patient']['lastname'] ?? '',
                'sex'       => $newOutput['patient']['sex'] ?? '',
                'DOB'       => $newOutput['patient']['DOB'] ?? '',
                'DOS'       => $newOutput['order']['DateOfService'] ?? '',
                'address1'  => $newOutput['patient']['address']['address1'] ?? '',
                'address2'  => $newOutput['patient']['address']['address2'] ?? '',
                'city'      => $newOutput['patient']['address']['city'] ?? '',
                'state'     => $newOutput['patient']['address']['state'] ?? '',
                'country'   => $newOutput['patient']['address']['country'] ?? '',
                'zip'       => $newOutput['patient']['address']['zip'] ?? ''
            ],
            'exams'         => $newOutput['exams'] ?? '',
            'submitTime'    => $newOutput['order']['DateOfService'] ?? '',
            'format'        => $newOutput['meta']['document_format'] ?? '',
            'document_type' => $newOutput['meta']['document_type'] ?? '',
            'PID'           => [
                'id'       => $newOutput['order']['PID'] ?? ''
            ]
        ];
        foreach ($oldOutput['exams'] as & $exam) {
            foreach ($exam['MultiDiagnosisList'] as & $diagnosis) {
                $diagnosis['method'] = $diagnosis['coding_type'];
                unset($diagnosis['coding_type']);
            }
        }
        $oldInsList = [];
        foreach ($newOutput['insuranceList'] as $ins) {
            $state = trim(preg_replace('/[^\s\d\w]+/', ' ', $ins['insurance-address']));
            $oldIns = [
                'providerNetwork'   => $ins['name'] ?? '',
                'state'             => $state,
                'policy'            => $ins['policy'] ?? ''
            ];
            $oldInsList[] = $oldIns;
        }
        $oldOutput['insuranceList'] = $oldInsList;

        return $oldOutput;
    }

    public function oldSRS(array $newOutput) : array
    {
        $oldOutput = [
            'insuranceList' => [[
                'group'     => $newOutput['insuranceList'][0]['subscriber'] ?? '',
                'providerNetwork'   => $newOutput['insuranceList'][0]['name'] ?? '',
                'policy'    => $newOutput['insuranceList'][0]['policy'] ?? ''
            ]],
            'patient'   => [
                'firstname' => $newOutput['patient']['firstname'] ?? '',
                'lastname'  => $newOutput['patient']['lastname'] ?? '',
                'DOB'       => $newOutput['patient']['DOB'] ?? '',
                'DOS'       => $newOutput['order']['DateOfService'] ?? '',
                'language'  => 'English',
                'country'   => $newOutput['patient']['address']['country'] ?? ''
            ],
            'exams' => $newOutput['exams'] ?? '',
            'referringDr'   => [
                'firstname' => $newOutput['referringDr']['firstname'] ?? '',
                'middlename' => $newOutput['referringDr']['middlename'] ?? '',
                'lastname' => $newOutput['referringDr']['lastname'] ?? '',
                'degree'    => $newOutput['referringDr']['title'] ?? '',
                'address1'  => $newOutput['referringDr']['address']['address1'] ?? '',
                'city'  => $newOutput['referringDr']['address']['city'] ?? '',
                'state'  => $newOutput['referringDr']['address']['state'] ?? '',
                'country'  => $newOutput['referringDr']['address']['country'] ?? '',
                'zip'  => $newOutput['referringDr']['address']['zip'] ?? '',
                'sendingFacility'   => $newOutput['referringDr']['sendingFacility'] ?? ''
            ],
            'submitTime'    => $newOutput['order']['DateOfService'] ?? '',
            'receivingApplication'  => 'ScriptSender',
            'accession' => $newOutput['order']['accession'] ?? '',
            'format'    => $newOutput['meta']['document_format'] ?? '',
            'document_type' => $newOutput['meta']['document_type'] ?? '',
            'PID'   => [
                'id'    => $newOutput['patient']['code'] ?? ''
            ],
            'sendingApplication'    => 'SRS'
        ];
        foreach ($oldOutput['exams'] as & $exam) {
            foreach ($exam['MultiDiagnosisList'] as & $diagnosis) {
                $diagnosis['coding_method'] = $diagnosis['coding_type'];
                unset($diagnosis['coding_type']);
            }
        }

        return $oldOutput;
    }

    public function oldAthena(array $newOutput) : array
    {
        $oldOutput = [
            'PID'   => [
                'id'    => $newOutput['order']['PID'] ?? ''
            ],
            'format'    => $newOutput['meta']['document_format'] ?? '',
            'attendingDr'   => [
                'firstname' => $newOutput['attendingDr']['firstname'] ?? '',
                'middlename' => $newOutput['attendingDr']['middlename'] ?? '',
                'lastname' => $newOutput['attendingDr']['lastname'] ?? '',
                'degree' => $newOutput['attendingDr']['title'] ?? '',
                'phone' => $newOutput['attendingDr']['phone1'] ?? '',
                'fax' => $newOutput['attendingDr']['phone2'] ?? '',
                'address1'  => $newOutput['attendingDr']['address']['address1'] ?? '',
                'address2'  => $newOutput['attendingDr']['address']['address2'] ?? '',
                'city'  => $newOutput['attendingDr']['address']['city'] ?? '',
                'state'  => $newOutput['attendingDr']['address']['state'] ?? '',
                'zip'  => $newOutput['attendingDr']['address']['zip'] ?? '',
            ],
            'referringDr'   => [
                'firstname' => $newOutput['referringDr']['firstname'] ?? '',
                'middlename' => $newOutput['referringDr']['middlename'] ?? '',
                'lastname' => $newOutput['referringDr']['lastname'] ?? '',
                'degree' => $newOutput['referringDr']['title'] ?? '',
                'phone' => $newOutput['referringDr']['phone1'] ?? '',
                'fax' => $newOutput['referringDr']['phone2'] ?? '',
                'address1'  => $newOutput['referringDr']['address']['address1'] ?? '',
                'address2'  => $newOutput['referringDr']['address']['address2'] ?? '',
                'city'  => $newOutput['referringDr']['address']['city'] ?? '',
                'state'  => $newOutput['referringDr']['address']['state'] ?? '',
                'zip'  => $newOutput['referringDr']['address']['zip'] ?? '',
                'sendingFacility'  => $newOutput['referringDr']['sendingFacility'] ?? '',
            ],
            'document_type' => $newOutput['meta']['document_type'] ?? '',
            'patient'   => [
                'firstname' => $newOutput['patient']['firstname'] ?? '',
                'middlename' => $newOutput['patient']['middlename'] ?? '',
                'lastname' => $newOutput['patient']['lastname'] ?? '',
                'sex'   => $newOutput['patient']['sex'] ?? '',
                'phone' => $newOutput['patient']['phone1'] ?? '',
                'DOB'   => $newOutput['patient']['DOB'] ?? '',
                'DOS'   => $newOutput['order']['DateOfService'] ?? '',
                'address1'  => $newOutput['patient']['address']['address1'] ?? '',
                'city'  => $newOutput['patient']['address']['city'] ?? '',
                'state'  => $newOutput['patient']['address']['state'] ?? '',
                'country'  => $newOutput['patient']['address']['country'] ?? '',
                'zip'  => $newOutput['patient']['address']['zip'] ?? '',
            ],
            'exams' => $newOutput['exams'] ?? '',
            'submitTime'    => $newOutput['order']['DateOfService'] ?? ''
        ];

        $oldInsList = [];
        foreach ($newOutput['insuranceList'] as $ins) {
            $oldIns = [
                'policy'    => $ins['policy'] ?? '',
                'insured'   => [
                    'firstname' => $ins['insured']['firstname'] ?? '',
                    'lastname' => $ins['insured']['lastname'] ?? ''
                ],
                'providerNetwork'   => $ins['name'] ?? ''
            ];
            $oldInsList[] = $oldIns;
        }
        $oldOutput['insuranceList'] = $oldInsList;

        foreach ($oldOutput['exams'] as & $exam) {
            foreach ($exam['MultiDiagnosisList'] as & $diagnosis) {
                $diagnosis['method'] = ($diagnosis['coding_type'] ?? '');
                unset($diagnosis['coding_type']);
            }
            unset($exam['stat']);
            unset($exam['comment']);
            unset($exam['procedure_code']);
        }

        return $oldOutput;
    }

    public function oldeClinicalWorks_retired(array $newOutput) : array
    {
        $oldOutput = [
            'referringDr'   => [
                'firstname'     => $newOutput['referringDr']['firstname'] ?? '',
                'lastname'      => $newOutput['referringDr']['lastname'] ?? '',
                'code'          => $newOutput['referringDr']['npi'] ?? '',
                'phone'         => $newOutput['referringDr']['phone1'] ?? '',
                'address1'      => $newOutput['referringDr']['address']['address1'] ?? '',
                'address2'      => $newOutput['referringDr']['address']['address2'] ?? '',
                'city'          => $newOutput['referringDr']['address']['city'] ?? '',
                'state'         => $newOutput['referringDr']['address']['state'] ?? '',
                'zip'           => $newOutput['referringDr']['address']['zip'] ?? '',
            ],
            'accession'         => $newOutput['order']['accession'] ?? '',
            'receivingFacility' => 'Billing System',
            'submitTime'        => $newOutput['order']['DateOfService'] ?? '',
            'receivingApplication'  => 'Billing System',
            'document_type'     => 'Order',
            'sendingFacility'   => $newOutput['referringDr']['sendingFacility'] ?? '',
            'patient'       => [
                'firstname'     => $newOutput['patient']['firstname'] ?? '',
                'lastname'      => $newOutput['patient']['lastname'] ?? '',
                'sex'           => $newOutput['patient']['sex'] ?? '',
                'DOB'           => $newOutput['patient']['DOB'] ?? '',
                'DOS'           => $newOutput['order']['DateOfService'] ?? '',
                'phone'         => $newOutput['patient']['phone1'] ?? '',
                'address1'      => $newOutput['patient']['address']['address1'] ?? '',
                'address2'      => $newOutput['patient']['address']['address2'] ?? '',
                'city'          => $newOutput['patient']['address']['city'] ?? '',
                'state'         => $newOutput['patient']['address']['state'] ?? '',
                'country'       => $newOutput['patient']['address']['country'] ?? '',
                'zip'           => $newOutput['patient']['address']['zip'] ?? '',
            ],
            'PID'           => [
                'id'        => $newOutput['order']['PID'] ?? ''
            ],
            'exams'         => $newOutput['exams'] ?? [],
            'sendingApplication'    => 'eClinicalWorks'
        ];
        $oldOutput['attendingDr'] = $oldOutput['referringDr'];

        foreach ($oldOutput['exams'] as & $exam) {
            foreach ($exam['MultiDiagnosisList'] as & $diagnosis) {
                $diagnosis['coding_method'] = $diagnosis['coding_type'];
                unset($diagnosis['coding_type']);
            }
            unset($exam['approving_provider']);
        }

        $oldInsList = [];
        foreach ($newOutput['insuranceList'] as $ins) {
            $oldIns = [
                'providerNetwork'   => $ins['name'] ?? '',
                'address'           => $ins['insurance-address'] ?? '',
                'insured'           => $oldOutput['patient'] ?? '',
                'policy'            => $ins['policy'] ?? ''
            ];
            $oldInsList[] = $oldIns;
        }
        $oldOutput['insuranceList'] = $oldInsList;

        return $oldOutput;
    }

    public function oldPhoenixOrtho(array $newOutput) : array
    {
        $oldOutput = [
            'sendingApplication'    => 'ScriptSender',
            'placer_order_number'   => $newOutput['order']['accession'],
            'submitTime'            => $newOutput['order']['DateOfService'] ?? '',
            'document_type'         => 'Order',
            'exams'                 => $newOutput['exams'] ?? '',
            'servicingFacility'     => 'ScriptSender',
            'referringDr'           => [
                'firstname'     => $newOutput['referringDr']['firstname'] ?? '',
                'middlename'    => $newOutput['referringDr']['middlename'] ?? '',
                'lastname'      => $newOutput['referringDr']['lastname'] ?? ''
            ],
            'receivingApplication'  => 'ScriptSender',
            'patient'               => [
                'firstname'     => $newOutput['patient']['firstname'],
                'lastname'      => $newOutput['patient']['lastname'],
                'language'      => 'English',
                'address1'      => $newOutput['patient']['address']['address1'],
                'address2'      => $newOutput['patient']['address']['address2'],
                'city'          => $newOutput['patient']['address']['city'],
                'state'         => $newOutput['patient']['address']['state'],
                'country'       => $newOutput['patient']['address']['country'],
                'zip'           => $newOutput['patient']['address']['zip'],
                'DOB'           => $newOutput['patient']['DOB'],
                'DOS'           => $newOutput['order']['DateOfService'],
            ],
            'PID'                   => [
                'id'            => $newOutput['order']['PID'] ?? ''
            ],
            'sendingApplication'    => 'ScriptSender',
            'receivingFacility'     => 'CorePoint'
        ];


        return $oldOutput;
    }

    public function oldMediTouch(array $newOutput) : array
    {
        $oldOutput = [
            'sendingFacility'   => 'Radiology Clinic',
            'receivingFacility' => 'CorePoint',
            'sendingApplication' => 'ScriptSender',
            'submitTime'        => $newOutput['order']['DateOfService'],
            'PID'               => [
                'id'            => $newOutput['order']['PID']
            ],
            'referringDr'       => [
                'firstname'     => $newOutput['referringDr']['firstname'],
                'lastname'      => $newOutput['referringDr']['lastname'],
                'address1'      => $newOutput['referringDr']['address']['address1'],
                'address2'      => $newOutput['referringDr']['address']['address2'],
                'city'          => $newOutput['referringDr']['address']['city'],
                'state'         => $newOutput['referringDr']['address']['state'],
                'country'       => $newOutput['referringDr']['address']['country'],
                'zip'           => $newOutput['referringDr']['address']['zip'],
                'phone'         => $newOutput['referringDr']['phone1'],
                'code'          => $newOutput['referringDr']['npi'],
                'sendingFacility'   => $newOutput['referringDr']['sendingFacility']
            ],
            'accession'         => $newOutput['order']['accession'],
            'patient'           => [
                'firstname'     => $newOutput['patient']['firstname'],
                'middlename'    => $newOutput['patient']['middlename'],
                'lastname'      => $newOutput['patient']['lastname'],
                'suffix'        => $newOutput['patient']['title'],
                'address1'      => $newOutput['patient']['address']['address1'],
                'address2'      => $newOutput['patient']['address']['address2'],
                'city'          => $newOutput['patient']['address']['city'],
                'state'         => $newOutput['patient']['address']['state'],
                'country'       => $newOutput['patient']['address']['country'],
                'zip'           => $newOutput['patient']['address']['zip'],
                'phone'         => $newOutput['patient']['phone1'],
                'DOS'           => $newOutput['order']['DateOfService'],
                'DOB'           => $newOutput['patient']['DOB'],
                'sex'           => $newOutput['patient']['sex'],
                'language'      => 'English'
            ],
            'insuranceList'     => [],
            'exams'             => []
        ];
        foreach ($newOutput['insuranceList'] as $ins) {
            $insured = $this->parseName($ins['name']);
            $insured['address1'] = $ins['insured']['address'];
            $insured['relationship'] = $ins['insured']['relation'];
            $oldIns = [
                'policy'        => $ins['policy'],
                'providerNetwork' => $ins['name'],
                'address'      => $ins['insurance-address'],
                'insured'       => $insured
            ];
            $oldOutput['insuranceList'][] = $oldIns;
        }
        foreach ($newOutput['exams'] as $exam) {
            unset($exam['approving_provider']);
            $oldOutput['exams'][] = $exam;
        }

        return $oldOutput;
    }

    public function oldNextGenRadReq(array $newOutput) : array
    {
        $oldOutput = [
            'attendingDr'           => [
                'code'          => $newOutput['referringDr']['npi'] ?? '',
                'firstname'     => $newOutput['referringDr']['firstname'] ?? '',
                'lastname'      => $newOutput['referringDr']['lastname'] ?? ''
            ],
            'PID'                   => [
                'id'            => $newOutput['order']['PID'] ?? ''
            ],
            'receivingApplication'  => '',
            'servicingFacility'     => $newOutput['order']['servicingFacility'] ?? '',
            'submitTime'            => $newOutput['order']['DateOfService'] ?? '',
            'patient'               => [
                'name'              => $newOutput['patient']['name'] ?? '',
                'firstname'         => $newOutput['patient']['firstname'] ?? '',
                'lastname'          => $newOutput['patient']['lastname'] ?? '',
                'address'           => $newOutput['patient']['address']['address'] ?? '',
                'address1'          => $newOutput['patient']['address']['address1'] ?? '',
                'city'              => $newOutput['patient']['address']['city'] ?? '',
                'state'             => $newOutput['patient']['address']['state'] ?? '',
                'country'           => $newOutput['patient']['address']['country'] ?? '',
                'zip'               => $newOutput['patient']['address']['zip'] ?? '',
                'phone'             => $newOutput['patient']['phone1'] ?? '',
                'DOB'               => $newOutput['patient']['DOB'] ?? '',
                'DOS'               => $newOutput['order']['DateOfService'] ?? '',
                'language'          => 'English',
                'sex'               => $newOutput['patient']['sex'] ?? ''
            ],
            'receivingFacility'     => '',
            'referringDr'           => [
                'name'              => $newOutput['referringDr']['name'] ?? '',
                'firstname'         => $newOutput['referringDr']['firstname'] ?? '',
                'lastname'          => $newOutput['referringDr']['lastname'] ?? '',
                'address'           => $newOutput['referringDr']['address']['address'] ?? '',
                'address1'          => $newOutput['referringDr']['address']['address1'] ?? '',
                'city'              => $newOutput['referringDr']['address']['city'] ?? '',
                'state'             => $newOutput['referringDr']['address']['state'] ?? '',
                'country'           => $newOutput['referringDr']['address']['country'] ?? '',
                'zip'               => $newOutput['referringDr']['address']['zip'] ?? '',
                'phone'             => $newOutput['referringDr']['phone1'] ?? '',
                'code'              => $newOutput['referringDr']['npi'] ?? '',
                'sendingFacility'   => $newOutput['referringDr']['sendingFacility'] ?? ''
            ],
            'sendingApplication'    => $newOutput['order']['sendingApplication'] ?? '',
            'exams'                 => $newOutput['exams'] ?? '',
            'insuranceList'         => [],
            'accession'             => $newOutput['order']['accession'] ?? '',
            'document_type'         => $newOutput['meta']['document_type'] ?? ''
        ];

        foreach ($newOutput['insuranceList'] as $ins) {
            $insured = $ins['insured'];
            $oldIns = [
                'providerNetwork'   => $ins['name'] ?? '',
                'group'             => $ins['group'] ?? '',
                'address'           => $ins['insurance-address'] ?? '',
                'policy'            => $ins['policy'] ?? '',
                'insured'           => [
                    'sex' => $insured['sex'] ?? '',
                    'name' => $insured['name'] ?? '',
                    'firstname' => $insured['firstname'] ?? '',
                    'lastname' => $insured['lastname'] ?? '',
                    'language' => 'English',
                    'DOB' => $insured['DOB'] ?? '',
                    'DOS' => $newOutput['order']['DateOfService'] ?? '',
                    'address' => $insured['address']['address'] ?? '',
                    'address1' => $insured['address']['address1'] ?? '',
                    'city' => $insured['address']['city'] ?? '',
                    'state' => $insured['address']['state'] ?? '',
                    'country' => 'USA',
                    'zip' => $insured['address']['zip'] ?? '',
                    'relationship' => 'Self',
                    'phone' => $insured['phone1'] ?? '',
                ]
            ];
            $oldOutput['insuranceList'][] = $oldIns;
        }

        return $oldOutput;
    }

    /**
     * @param string $pdf
     * @throws \ScriptSender\Exceptions\FileAndDirectoryException
     */
    public function compareNewToOld(string $pdf): void
    {
        $orderService = new \ScriptSender\Services\OrderService();
        [$new] = $orderService->parsePDF($pdf, true);
        $new = json_decode(json_encode($new), true);
        [$old] = $orderService->parsePDF($pdf);
        $old = json_decode(json_encode($old), true);
        print_r(array_merge($this->array_diff_assoc_recursive($old, $new), $this->array_diff_assoc_recursive($new, $old)));
    }

    public function array_diff_assoc_recursive($array1, $array2)
    {
        $difference = [];
        foreach ($array1 as $key => $value) {
            if (\is_array($value)) {
                if (!isset($array2[$key]) || !\is_array($array2[$key])) {
                    $difference[$key] = $value;
                }
                else {
                    $new_diff = $this->array_diff_assoc_recursive($value, $array2[$key]);
                    if (!empty($new_diff)) {
                        $difference[$key] = $new_diff;
                    }
                }
            }
            else if (!array_key_exists($key,$array2) || $array2[$key] !== $value) {
                $difference[$key] = $value;
            }
        }
        return $difference;
    }
}
