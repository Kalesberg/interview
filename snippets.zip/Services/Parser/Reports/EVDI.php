<?php
declare(strict_types=1);

namespace ScriptSender\Services\Parser\Reports;

use Carbon\Carbon;
use ScriptSender\Services\Parser\HelperTrait;

/**
 * eClinicalWorks Order Parser
 * format: eClinicalWorks
 * type: Order
 */
class EVDI
{
    use HelperTrait;
    protected $format = 'EVDI';
    protected $type = 'Reports';
    protected $content;
    protected $lines;
    protected $template;

    /**
     * Check if given files matches this format
     *
     * @param  string $content (content converted from PDF)
     * @return boolean
     */
    public static function matches(string $content): bool
    {
        return (bool) preg_match('/Patient.*?DOB.*?Gender.*?Location.*?Exam Date.*?Ordering Physician.*?MRN.*?Accession No./s',$content, $matches);
    }

    /**
     * Parser constructor
     *
     * @param string $content
     */
    public function __construct(string $content)
    {
        $this->content = $content;
        $this->lines = explode("\n", $content);
        $this->template = include app_path('Services/Parser/ReportData.php');
    }

    /**
     * Parse function
     *
     * @return array
     */
    public function parse(): array
    {
        error_reporting(0);
        $matches = [];
        $data = $this->template;

        $data['meta']['document_type'] = 'Report';
        $data['meta']['document_format'] = 'EVDI';

        preg_match('/MRN:(.*)Accession No./', $this->content, $matches['pid']);
        //preg_match('/Accession No.:.*?(\d+).*Exam/', $this->content, $accessionMatches);
        preg_match('/Accession No.:.*?(\d+)/', $this->content, $matches['accession']);
        //preg_match('/DOB:(.*)Gender\/Age:/', $this->content, $dobMatches);
        preg_match('/DOB:(.*)/', $this->content, $matches['dob']);
        preg_match('/Gender\/Age:.*(M|F)\/.*Location/', $this->content, $matches['sex']);


        $matches = array_map(function($v) {
            return trim($v[1]);
        }, $matches);

        $data['report']['pid'] = $matches['pid'];
        $data['report']['accession'] = $matches['accession'];
        $data['patient']['dob'] = Carbon::createFromFormat('m/d/Y', $matches['dob'])->format('Ymd') . '000000';
        $data['patient']['sex'] = $this->parseGender($matches['sex']);

        error_reporting(1);
        return $data;
    }

    /**
     * @param array $normalized
     * @return array
     */
    public function getArray(array $normalized): array
    {
        // not currently used
    }
}
