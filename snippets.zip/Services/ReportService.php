<?php

declare(strict_types=1);

namespace ScriptSender\Services;

use Log;
use Auth;
use Exception;
use ScriptSender\Exceptions\FileAndDirectoryException;
use ScriptSender\Exceptions\InsufficientDataInReportException;
use ScriptSender\Logging\CustomizeLogger;
use ScriptSender\Logins;
use ScriptSender\Folders;
use ScriptSender\Report_Activities;
use ScriptSender\Account_Activities;
use ScriptSender\Sites\SitesInterface;
use ScriptSender\User;
use Cache;
use ScriptSender\Child;
use Illuminate\Support\Collection;

class ReportService
{
    protected $basePath;
    protected $reportCacheService;
    protected $usageAuditService;

    public function __construct()
    {
        (new CustomizeLogger())->setComponent('rs');
        $this->basePath = config('settings.base_folder') . '/';
        $this->reportCacheService = new ReportCacheService($this);
        $this->usageAuditService = new UsageAuditService();
    }

    /**
     * Return true if the given report is archived
     * TODO: Use "soft delete", but keeping a record of delete/undelete?
     *
     * @param string $fileName
     * @return bool
     */
    public function isArchived(string $fileName): bool
    {
        // Get the last archived id; get the last unarchived id
        // Whichever is greater, the report is in that state
        $report = $this->fileNameToReportName($fileName);
        $archived_id = Report_Activities::where('Report_Name', $report)
            ->where('Archived', '1')
            ->orderBy('id', 'desc');

        $unarchived_id  = Report_Activities::where('Report_Name', $report)
            ->where('Unarchived', '1')
            ->orderBy('id', 'desc');

        $archived = false;
        if ($archived_id->exists()) {
            $archived = true; // This will be overwritten if it is unarchived
            if ($unarchived_id->exists()) {
                $archived = ($archived_id->first()->id > $unarchived_id->first()->id);
            }
        }
        return $archived;
    }

    /**
     * Return true if give report is seen by given user
     * @param $user
     * @param $fileName
     * @return bool
     */
    public function isReportSeenByUser(User $user, string $fileName): bool
    {
        $reportActivities = Cache::remember("reportActivities-{$user->id}", 1, function () use ($user) {
            return $user->reportActivities()->where('Seen', 1)->get();
        });
        return ($reportActivities
                ->where('Report_Name', $this->fileNameToReportName($fileName))
                ->count() > 0);
    }

    /**
     * Return number of unread reports for given user
     * @param User $user
     * @return int
     */
    public function getNoOfUnreadReports(User $user): int
    {
        $unreadReportCount = 0;

        foreach ($user->folders as $dir) {
            $dirName = explode('/', $dir->path);
            $dirName = array_pop($dirName);

            // for all the reports belonging to the logged in user
            $path = $this->basePath . $dir->path;
            $reports = array_diff(scandir($path, SCANDIR_SORT_NONE), array('..', '.'));

            foreach ($reports as $report) {
                $reportName = $dirName . '/' . $report;
                if ($this->isArchived($reportName) || $this->isReportSeenByUser($user, $reportName)) {
                    continue;
                }
                $unreadReportCount++;
            }
        }

        return $unreadReportCount;
    }

    /**
     * Mark a report as 'downloaded' in the DB
     * @param string $fileName
     * @param Logins $login
     */
    public function setReportAsDownloaded(string $fileName, Logins $login): void
    {
        // Since the user may download a file multiple times in a single login, creating a new record for each download
        //  is redundant. Instead just increment the Downloaded field. 'updated_at' will anyway contain the last
        // Downloaded time. So if the record is already present for current login, increment the Downloaded field, else
        // create a new one.

        $reportActivity = null;
        $report = $this->fileNameToReportName($fileName);
        if ($reportActivity = Report_Activities::where('Report_Name', $report)->where('login_id', $login->id)->first()) {
            $reportActivity->increment('Downloaded');
            $reportActivity->Seen = '1';
        }
        else {
            $reportActivity = new Report_Activities(['Report_Name' => $report, 'Downloaded' => '1', 'Seen' => '1']);
            $reportActivity->login()->associate($login);
        }

        $reportActivity->save();
        $this->logReportActivity($reportActivity, $report, 'Downloaded');
    }

    /**
     * Given the report filename, add a new Report_Activity, with Viewed = 1
     *
     * @param string $fileName
     * @param Logins $login
     * @return void
     * @internal param int $id
     */
    public function setReportAsSeen(string $fileName, Logins $login): void
    {
        // Since the user may view a file multiple times in a single login, creating a new record for each view is
        // redundant. Instead just increment the Viewed field. 'updated_at' will anyway contain the last viewed time.
        // So if the record is already present for current login, increment the Viewed field, else create a new one.

        // While the above logic makes sense, there is an issue - Logging\GetLogs.php/user() fetches the logs since
        // last updated_at, and checks what was the action done. if($log->Viewed) doesn't hold good since it's
        //  incremented every time! Think how to have 'Viewed' as integrer and solve the issue of logging the right one.

        $reportActivity = null;
        $report = $this->fileNameToReportName($fileName);

        // Do not delete this commented part! Read the above comments ...
        // if ($reportActivity = Report_Activities::where('Report_Name', $report)->where('login_id', $this->currentLogin->id)->first()) {
        //  $reportActivity->increment('Viewed');
        // }
        // else {
        //  $reportActivity = new Report_Activities(['Report_Name' => $report, 'Viewed' => '1', 'Seen' => '1']);
        //  $reportActivity->login()->associate($this->currentLogin);
        // }

        $reportActivity = new Report_Activities(['Report_Name' => $report, 'Viewed' => '1', 'Seen' => '1']);
        $reportActivity->login()->associate($login);
        $reportActivity->save();
        $this->logReportActivity($reportActivity, $report, 'Viewed');
    }

    /**
     * Set given report(s) as unseen
     *
     * @param array $IDs
     * @param User $user
     * @return void
     * @internal param int $id
     */
    public function setReportAsUnseen(array $IDs, User $user): void
    {
        foreach ($IDs as $id) {
            if (preg_match('/report-(.+)/i', $id, $match)) {
                $fileName = $match[1];
                $report = $this->fileNameToReportName($fileName);

                // In all the report activities, mark seen as false
                // if ($reportActivities = Report_Activities::where('Report_Name', $reportName)->where('login_id', $this->currentLogin->id)) {
                //  foreach ($reportActivities as $reportActivity) {
                //      $reportActivity->Seen = false;
                //      $reportActivity->save();
                //  }
                // }

                // For this user, for all logins, set the report Seen = false
                // TBD: This works, but is not the right way - we are losing data from all previous logins! Ideally
                // We should get the data from the last login to know whether it is seen or unseen. Then again, what if
                // user views it and logs out? It should still be marked as 'seen', isn't it?
                $done = false;
                foreach ($user->logins as $login) {
                    foreach ($login->report_activities as $reportActivity) {
                        if ($reportActivity->Report_Name === $report) {
                            $reportActivity->Seen = false;
                            $reportActivity->save();
                            if (!$done) {
                                $this->logReportActivity($reportActivity, $report, 'Set as unseen');
                                $done = true;
                            }
                        }
                    }
                }
            }
            else {
                // Throw exception
            }
        }
    }

    /**
     * Set given nodes as 'archived'
     * @param array $IDs
     * @param Logins $login
     * @throws \InvalidArgumentException
     */
    public function archiveNodes(array $IDs, Logins $login): void
    {
        $reports = [];
        foreach ($IDs as $id) {
            if (preg_match('/report-(.+)/i', $id, $match)) {
                $fileName = $match[1];
                $report = $this->fileNameToReportName($fileName);
                $reportActivity = new Report_Activities(['Report_Name' => $report, 'Archived' => true]);
                $reportActivity->login()->associate($login);
                $reportActivity->save();
                $this->logReportActivity($reportActivity, $report, 'Archived');
                $reports[] = $report;
            }
            else {
                // throw new Exception("ID isn't of expected form. Expected: report-<filename>, received: $id");
            }
        }
        $this->reportCacheService->setReportStatusInCache($reports, 'archived');
    }

    /**
     * Unarchive given nodes
     * @param array $IDs
     * @param Logins $login
     * @throws \InvalidArgumentException
     */
    public function unarchiveNodes(array $IDs, Logins $login): void
    {
        $reports = [];
        foreach ($IDs as $id) {
            if (preg_match('/report-(.+)/i', $id, $match)) {
                $fileName = $match[1];
                $report = $this->fileNameToReportName($fileName);
                $reportActivity = new Report_Activities(['Report_Name' => $report, 'Unarchived' => true]);
                $reportActivity->login()->associate($login);
                $reportActivity->save();
                $this->logReportActivity($reportActivity, $report, 'Unarchived');
                $reports[] = $report;
            }
            else {
                // Throw exception
            }
        }
        $this->reportCacheService->setReportStatusInCache($reports, 'active');
    }

    /**
     * Given a path or a filename, this method removes extension and returns the DB-friendly name of the report
     * @param string $fileName Full path of report file
     *                         Partial path of report containing only the immediate parent
     *                         Just the report filename
     *                         All above with or with or without extension, with or without output_format
     * @return string
     */
    public function fileNameToReportName(string $fileName): string
    {
        $pathParts = pathSplit($fileName);
        $fileName = array_pop($pathParts);
        $parentFolder = array_pop($pathParts);
        $reportName = preg_replace("/.(pdf|hl7)$/i", '', $fileName); // Strip off .pdf or .hl7
        foreach (output_formats() as $output_format) {
            $reportName = preg_replace("/_$output_format$/i", '', $reportName);
        }
        return $parentFolder ? "$parentFolder/$reportName" : $reportName;
    }

    /**
     * Log activity (seen / downloaded / unseen / archived etc.) on the given report
     * @param Report_Activities $reportActivity
     * @param string $report
     * @param string $msg
     */
    private function logReportActivity(Report_Activities $reportActivity, string $report, string $msg): void
    {
        $user = $reportActivity->login->user;
        $msg = strtolower($msg);
        Log::info("Report $msg by user", [
            'report' => $report, 'user' => "$user->FirstName $user->LastName ($user->email)"]);
    }

    /**
     * Sync assigned/unassigned folders to given user
     * @param array $folderIDs
     * @param User $user
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function assignFoldersToUser(array $folderIDs, User $user): void
    {
        foreach ($folderIDs as $id => $checked) {
            $folderName = Folders::findOrFail($id)->name;
            if (true === $checked) {
                $user->folders()->attach($id);
                $performed = 'Assigned';
            }
            else {
                $user->folders()->detach($id);
                $performed = 'Un-assigned';
            }
            Log::info("$performed folder", ['directory' => $folderName, 'user' => "$user->FirstName $user->LastName"]);
        }
    }

    /**
     * Set folder-assigned flag
     * @param string $email
     */
    public function setUserAssignedFlag(string $email): void
    {
        Account_Activities::create(['User_Email' => $email, 'Assigned' => '1', 'Performed_By' => Auth::user()->email]);
    }

    /**
     * Traverse through all sub-folders under RS directory, and process those
     *
     * @throws \Exception
     */
    public function processAllRSFolders(): void
    {
        $folderBase = config('settings.base_folder');

        # Get all the nodes (except '.' and '..')
        $folders = array_diff(scandir($folderBase, SCANDIR_SORT_NONE), ['..', '.']);

        foreach ($folders as $folder) {
            $fullPath = $folderBase . '/' . $folder;
            if (is_dir($fullPath)) {
                $this->registerFolder($fullPath);
            }
        }

        // If there is an entry in the DB but the folder doesn't exist, remove the entry
        foreach (Folders::all() as $folderEntry) {
            $name = $folderEntry->name;

            $fullPath = "$folderBase/" . $folderEntry->path;
            if (!is_dir($fullPath)) {
                if ($folderEntry->delete()) {
                    Log::info('Removed directory entry from DB', ['directory' => $name]);
                }
                else {
                    Log::error('Could not remove directory entry from DB', ['directory' => $name]);
                }
            }
        }
    }

    /**
     * Register given folder (i.e., add to DB, change permissions etc.)
     * @param $folder
     * @throws FileAndDirectoryException
     * @throws Exception
     */
    public function registerFolder($folder): void
    {
        if (!is_dir($folder)) {
            throw new FileAndDirectoryException("'$folder' not a directory!");
        }

        changePerms($folder, '0777', 'www-data', 'www-data', true, true);

        // For each PDF inside the folder...
        $reports = [];
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($folder));
        foreach ($iterator as $node) {
            $node = $folder . '/' . $node->getBasename();
            if (preg_match("/\.pdf$/i", $node)) {
                $reports[] = fileExtensionToLowerCase($node);
            }
        }

        # Add entry in DB, if not already present
        $basename = basename($folder);
        if (Folders::where('name', $basename)->count() === 0) {
            Folders::create(['name' => $basename, 'path' => $basename, 'seen' => false]);
        }

        $this->reportCacheService->addFolderToReportsCache($folder, $reports);
    }

    /**
     * Remove a folder entry from database
     * @param $folder
     * @throws Exception
     */
    public function deregisterFolder($folder): void
    {
        $basename = basename($folder);
        $entryInDB = Folders::where('name', $basename)->first();
        if (!$entryInDB) {
            return;
        }

        $entryInDB->delete()
            ? Log::info("Removed directory entry '$basename' from DB.")
            : Log::error("Could not remove '$basename' entry from DB!");

        $this->reportCacheService->removeFolderFromReportsCache($folder);
    }

    /**
     * Handle report file when it's added for the first time
     *
     * @param string $report
     * @throws \BadMethodCallException
     * @throws Exception
     * @throws \Throwable
     */
    public function fileAdded(string $report): void
    {
        // HyperlinkService adds the link in a temporary copy of the file, and then moves it to original directory.
        // Hence watch_rs.pl thinks it's been re-copied and re-calls this method...
        if ($this->wasRecentlyAdded($report)) { # Avoid re-adding when hyperlink is added to the PDF
            return;
        }
        changePerms($report, '0770', 'www-data', 'www-data', true);
        try {
            (new HyperlinkService(new ImageViewerService()))->setPdf($report)->insert();
        }
        catch (Exception $e) {
            Log::error('Failed to insert hyperlink into report', [
                'report' => $report, 'exception' => getExceptionSummary($e)]);
        }
        (new StudyService())->registerStudyFromReport($report);
        resolve(SitesInterface::class)->handleReport($report); // Site-specific handling
        $this->reportCacheService->addFileToReportsCache($report);
        $this->usageAuditService->setCountForService('RS');
    }

    /**
     * Return true if the report was recently (1 minutes) processed. This is to avoid the scenario where after
     * hyperlink is added, the report is thought to be a new one and attempted to re-process!
     * @param string $report
     * @return bool
     * @throws \BadMethodCallException
     */
    public function wasRecentlyAdded(string $report): bool
    {
        if (Cache::tags(['ProcessedReport'])->has($report)) {
            return true;
        }
        Cache::tags(['ProcessedReport'])->put($report, true, 1);
        return false;
    }

    /**
     * Process when a single file is removed from a RS directory
     * @param $report
     */
    public function fileRemoved($report): void
    {
        $this->reportCacheService->removeFileFromReportsCache($report);
    }

    /**
     * Build a JSON suitable for viewing with jsTree
     * @param User $user
     * @param string $mode
     * @return string
     */
    public function buildJsTree(User $user, string $mode = 'active'): string
    {
        $folder_open_icon = '/images/folder-open-48.png';
        $text_file_icon = '/images/document-128.png';
        $text_file_new_icon = '/images/document-new2-128.png';

        $reportsTree = $this->reportCacheService->getReportsTree();

        // Keep report belonging to this user (or all, for admins)
        if (!isUserAdmin($user)) {
            $reportsTree = array_values(array_filter($reportsTree, function ($folder) use ($user) {
                return ($user->folders()->where('name', $folder['text'])->count() > 0);
            }));
        }

        // Keep only reports with requested $mode
        if ($mode !== 'all') {
            $reportsTree = array_map(function ($folderArray) use ($user, $mode) {
                $folderArray['children'] = array_values(
                    array_filter($folderArray['children'], function ($child) use ($mode) {
                        return $child['mode'] === $mode; # Filter out every child array that do not meet $mode criteria
                    })
                );

                // $folderArray['children'] = $children
                //     ? array_combine(range(0, count($children) -1), array_values($children)) // Reindex
                //     : [];
                return $folderArray;
            }, $reportsTree);
        }

        $childrenPID = [];
        if ($user->isPatient()) {
            foreach (Child::where('parent_id', $user->id)->get() as $child) {
                $childrenPID[] = $child->PID;
                $childrenPID[] = $child->lname;
            }
            $childrenPID[] = $user->Patient->PID;
            $childrenPID[] = $user->LastName;
        }

        $of = $user->output_format;
        $ext = "_$of.hl7";
        if ($of === 'pdf') {
            $ext = '.pdf';
        }
        elseif ($of === 'JPEG') {
            $ext = 'jpg';
        }

        foreach ($reportsTree as &$folderArray) {
            # If output_format is of type HL7, from the list of PDF files generate corresponding HL7 filenames and send
            # to user. No need to check if the HL7 file exists or not. We'll create it when the user tries to view it.

            if (array_key_exists('children', $folderArray)) {
                foreach ($folderArray['children'] as &$node) {
                    $report = pathinfo($node['text'], PATHINFO_FILENAME) . $ext; // e.g., somefile_HL7_GE.hl7
                    $fileName = $folderArray['text'] . '/' . $report;
                    $seen = $this->isReportSeenByUser($user, $fileName);
                    $icon = $seen ? $text_file_icon : $text_file_new_icon; # TBD: Display PDF/HL7 Icon as per $ext
                    $reportID = 'report-' . $fileName; # Change $fileName to $reportName
                    $mode = $node['mode'];
                    $node = [];
                    if (!$user->isPatient() || count(array_filter($childrenPID,
                            create_function('$e', 'return strstr("' . $report . '", $e);'))) > 0) {
                        $node = [
                            'id' => $reportID,
                            'type' => 'report',
                            'text' => $report,
                            'icon' => $icon,
                            'seen' => $seen,
                            'mode' => $mode,
                        ];
                    }
                }
                unset($node);
            }

            if (!$user->isPatient() || count($folderArray['children']) > 0) {
                $folderArray = [
                    'id' => $folderArray['id'],
                    'type' => 'folder',
                    'text' => $folderArray['text'],
                    'icon' => $folder_open_icon,
                    'state' => ['opened' => true],
                    'children' => array_key_exists('children', $folderArray) ? $folderArray['children'] : [],
                ];
            }
        }

        return json_encode($reportsTree);
    }

    /**
     * Return all reports in active state for given RS directory
     * @param string $folder
     * @param string $outputFormat
     * @param bool $simulate When true, generate and return a list of HL7 filenames from each PDF in this directory
     * @return Collection Collection of active PDF (or HL7, when simulated) reports
     */
    public function getActiveReportsInDirectory(string $folder, string $outputFormat, $simulate = false): Collection
    {
        $reportsTree = $this->reportCacheService->getReportsTree();
        $folderArrayIndex = array_search(basename($folder), array_column($reportsTree, 'text'), true);
        $activeChildren = array_values(
            array_filter($reportsTree[$folderArrayIndex]['children'], function ($child) {
                return $child['mode'] === 'active'; # Filter out every child array that do not meet $mode criteria
            })
        );
        $rsDir = rtrim(config('settings.base_folder'), '/') . '/'; # Append trailing / if not present
        $ext = "_$outputFormat.hl7";
        $activeReports = array_map(function ($report) use ($simulate, $rsDir, $ext) {
            $reportFullPath = $rsDir . substr($report['id'], 7);
            return $simulate
                ? replaceFileExtension($reportFullPath, $ext)
                : $reportFullPath;
        }, $activeChildren);

        return collect($activeReports);
    }
}
