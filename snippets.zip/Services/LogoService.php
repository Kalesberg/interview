<?php namespace ScriptSender\Services;

use Log;
use File;

class LogoService {

	public function addCustomerUrl($url)
	{
	    if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
	        $url = "http://" . $url;
	    }
		$urlFile = public_path('files/site_url.txt');
		return File::put($urlFile, $url);
	}

	public function getCustomerLogoPath()
	{
		// return the default logo file if the file/logo is not found (i.e., admin hasn't uploaded the logo)
		$customerLogo = '/images/logo.png';

		if (File::exists(public_path('files/logo.jpeg'))) {
			$customerLogo = '/files/logo.jpeg';
		}
		elseif (File::exists(public_path('files/logo.jpg'))) {
			$customerLogo = '/files/logo.jpg';
		}
		elseif (File::exists(public_path('files/logo.png'))) {
			$customerLogo = '/files/logo.png';
		}
		elseif (File::exists(public_path('files/logo.gif'))) {
			$customerLogo = '/files/logo.gif';
		}

		return $customerLogo;
	}

	public function getCustomerUrl()
	{
		$urlFile = public_path('files/site_url.txt');
		$customerUrl = "#";
		if (File::exists($urlFile)) {
			try {
			    $customerUrl = File::get($urlFile);
			}
			catch (Illuminate\Filesystem\FileNotFoundException $exception) {
			    Log::error("Couldn't read file containing customer URL: '$urlFile'");
			}
		}
		else {
		    Log::error("Couldn't find file containing customer URL: '$urlFile'");
		}
		return $customerUrl;
	}

	// ScriptSender Logo
	public function getSSLogoPath()
	{
		return '/images/ss_logo.jpeg';
	}
}
