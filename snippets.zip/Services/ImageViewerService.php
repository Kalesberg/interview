<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use Log;
use File;
use Cache;
use Exception;
use ScriptSender\Exceptions\PACSException;
use ScriptSender\Sites\SitesInterface;
use ZipArchive;
use Carbon\Carbon;
use ScriptSender\Imageshare_study;
use Illuminate\Support\Facades\Redis;
use ScriptSender\Jobs\GetStudiesFromRemotePACS;
use ScriptSender\Services\PACS\CoActivService;
use ScriptSender\Services\PACS\OrthancService;
use ScriptSender\Exceptions\FileAndDirectoryException;

/**
 * Communicate with a PACS server (configured through config/settings.php) and receive required data
 */
class ImageViewerService
{
    protected $ch;
    protected $PACS_url;
    protected $studyCacheLife;
    protected $studyRefreshOnAccess;
    protected $CoActivService;
    protected $OrthancService;

    public function __construct()
    {
        $this->PACS_url = config('settings.PACS.url');
        $this->ch = curl_init();

        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);

        // This is equivalent to Curl command line option --insecure. This is required
        // when the site is https, and curl doesn't have certificate keys
        // TBD: No need for this when using a server with real purchased certificate
        if (preg_match('/https:/', $this->PACS_url)) {
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, 0);
        }
        $this->studyCacheLife = config('settings.study.cache_life');
        $this->studyRefreshOnAccess = config('settings.study.refresh_on_access');
        $this->CoActivService = new CoActivService();
        $this->OrthancService = new OrthancService();
    }

    // /**
    //  * @param string $uuid UUID of instance
    //  * @return string Full path of downloaded DICOM file
    //  */
    // public function imageFile(string $uuid): string
    // {
    //     // TBD: If patient is deleted from PACS server, delete all instances from cache here and throw exception
    //     $fileName = "$uuid.dicom";
    //     $fullPath = config('settings.output_paths.dicomCache') . "/$fileName";
    //     if (File::exists($fullPath)) {
    //         return $fullPath;
    //     }
    //     $this->getDicomFile($uuid, $fullPath);
    //     return $fullPath;
    // }

    /**
     * Get patient JSON from PACS server (or from cache, if present)
     * @param string $pid Example: "708891"
     * @param null $accession
     * @param string|null $DOB
     * @param string|null $sex
     * @return string
     * @throws Exception
     */
    public function patientJSON(string $pid, $accession = null, $DOB = null, $sex = null): string
    {
        $patientUUID = $this->getPatientUUID($pid, $accession, $DOB, $sex);
        return $this->getPatientJSON($patientUUID);
    }

    /**
     * Return true if study is available in PACS. Else query it in remote PACS
     *
     * @param string $accession
     * @param $pid
     * @param string $DOB
     * @param string $sex
     * @return bool
     * @throws Exception
     */
    public function searchStudy(string $accession, string $pid, $DOB = null, $sex = null): bool
    {
        if ($this->getStudyUUIDFromPACS($accession, $DOB, $sex)) {
            return true;
        }

        Log::debug('Study not found in local PACS', compact('accession', 'pid', 'DOB', 'sex'));
        if ($this->queryStudyAtRemote($accession, $pid, $DOB, $sex)) {
            Log::debug('Study found in remote PACS', compact('accession', 'pid', 'DOB', 'sex'));
            $this->queueJobToGetStudy($accession, $DOB, $sex);
            return true;
        }
        Log::warning('Study not found in remote PACS', compact('accession', 'pid', 'DOB', 'sex'));
        return false;
    }

    /**
     * Find the PACS UUID that corresponds to pid. Keep caching all ids and corresponding PIDs till its found.
     * @param string $target_pid
     * @param string|null $accession
     * @param string $DOB
     * @param string $sex
     * @return string $patientUUID patient UUID at PACS
     * @throws Exception
     * @throws \ScriptSender\Exceptions\CoActivException
     */
    public function getPatientUUID(string $target_pid, $accession = null, $DOB = null, $sex = null): string
    {
        if ($accession) {
            $studyUUID = $this->getStudyUUIDFromPACS($accession, $DOB, $sex);
            if ($studyUUID) {
                $studyJSON = $this->OrthancService->pacsAPI("$this->PACS_url/studies/$studyUUID");
                return $studyJSON['ParentPatient'];
            }

            Log::debug('Study not found in PACS!', compact('accession', 'DOB', 'sex'));
            Redis::set('image_viewer:reasonfordelay', '88888888888888888'); // TBD: Emit event, which notifies browser?
            $patientUUID = $this->getStudyFromRemote($accession, $target_pid, $DOB, $sex);
            // $pid = $this->getPIDFromPatientUUID($patientUUID);
            #if ($target_pid !== $pid) {
            #    throw new Exception("Study $accessionNumber belongs to wrong PID! Expected: '$target_pid',  Found: '$pid'");
            #}
            Redis::del('image_viewer:reasonfordelay');
            return $patientUUID;
        }

        $ssn = $this->getSSNFromPid($target_pid);
        Log::debug("SSN $ssn!");
        foreach ($this->getAllPatientUUIDsAtPACS() as $patientUUID) {
            $pid = $this->getPIDFromPatientUUID($patientUUID);
            if (($target_pid === $pid) || ($ssn && $ssn === $pid)) {
                Log::debug('Found Patient UUID in PACS', compact('pid', 'patientUUID', 'ssn'));
                return $patientUUID;
            }
        }

        abort(404, "Patient with id $target_pid not found in PACS (URL: $this->PACS_url)");
    }

    /**
     * Return corresponding PID (if any) or null
     *
     * @param string $pid
     * @return mixed
     */
    public function getSSNFromPid(string $pid)
    {
        return Cache::tags(['pid_ssn_map'])->get($pid);
    }

    /**
     * Get a list of all patient IDs at PACS
     *
     * @return array $UUIDs Array of patient UUIDs at PACS
     * @throws Exception
     */
    protected function getAllPatientUUIDsAtPACS(): array
    {
        $UUIDs = $this->OrthancService->pacsAPI("$this->PACS_url/patients");
        if (empty($UUIDs)) {
            $msg = 'No patients found at PACS';
            Log::error($msg);
            abort(404, $msg);
        }
        Log::debug('Found patients at PACS', ['count' => count($UUIDs)]);
        return $UUIDs;
    }

    /**
     * @param string $uuid
     * @return string $pid
     * @throws Exception
     */
    private function getPIDFromPatientUUID(string $uuid): string
    {
        $pid = Cache::tags(['DICOM', 'patient', 'IDs'])->rememberForever($uuid, function () use ($uuid) {
            $patientJSON = $this->OrthancService->pacsAPI("$this->PACS_url/patients/$uuid");
            Log::debug("Found patient JSON in PACS corresponding to $uuid");
            if (!array_key_exists('MainDicomTags', $patientJSON)) {
                Log::debug($patientJSON);
                throw new Exception("No 'MainDicomTags' key in Patient JSON");
            }

            $pid = $patientJSON["MainDicomTags"]["PatientID"];
            if (empty($pid)) {
                throw new Exception("Could not find PID corresponding to PACS ID: $uuid at PACS $this->PACS_url");
            }
            Log::debug('Found pid in PACS corresponding to Patient UUID', ['pid' => $pid, 'UUID' => $uuid]);
            return $pid;
        });

        # TBD: This is to avoid full series not loading issue. This un-caches just cached pacs_id
        Cache::tags(['DICOM', 'patient', 'IDs'])->flush(); // Commented at NERAD!
        return $pid;
    }

    /**
     * Get Patient JSON from PACS server. Recursively replace study IDs, series IDs, instance IDs with their JSONs,
     * so that finally we end up with a large JSON data.
     * Do not cache this JSON, as a patient's info can get updated and have new studies.
     *
     * @param  string $uuid PACS ID for the patient
     * @return string $patient  Complete JSON containing entire patient + studies + series + instances
     * @throws Exception
     */
    protected function getPatientJSON(string $uuid): string
    {
        $patientJSON = $this->OrthancService->pacsAPI("$this->PACS_url/patients/$uuid");

        if (empty($patientJSON)) {
            throw new Exception("No patients with id '$uuid' found in PACS");
        }
        foreach ($patientJSON['Studies'] as $index => $studyUUID) {
            $patientJSON['Studies'][$index] = $this->getStudyJSON($studyUUID);
        }
        return json_encode($patientJSON);
    }

    /**
     * @param string $uuid
     * @return mixed $studyJSON
     * @throws \Exception
     */
    public function getStudyJSON(string $uuid)
    {
        $studyJSON = Cache::tags(['DICOM','study'])
            ->remember($uuid, $this->studyCacheLife * 24 * 60, function () use ($uuid) {
                $studyJSON = $this->OrthancService->pacsAPI("$this->PACS_url/studies/$uuid");
                foreach ($studyJSON["Series"] as $index => $seriesUUID) {
                    $studyJSON['Series'][$index] = $this->getSeriesJSON($seriesUUID);
                }
                return $studyJSON;
            });
        # TBD: This is to avoid full series not loading issue. This de-caches just cached $id
        Cache::tags(['DICOM','study'])->flush();

        return $studyJSON;
    }

    /**
     * @param string $uuid
     * @return mixed $studyJSON
     * @throws \ScriptSender\Exceptions\PACSException
     */
    protected function getStudyAccession(string $uuid)
    {
        return $this->OrthancService->pacsAPI("$this->PACS_url/studies/$uuid");
    }

    /**
     * @param string $uuid
     * @return mixed
     * @throws Exception
     */
    protected function getSeriesJSON(string $uuid)
    {
        $seriesJSON = $this->OrthancService->pacsAPI("$this->PACS_url/series/$uuid");
        foreach ($seriesJSON["Instances"] as $index => $instanceUUID) {
            $seriesJSON['Instances'][$index] = $this->getInstanceJSON($instanceUUID);
        }
        return $seriesJSON;
    }

    /**
     * @param string $uuid
     * @return mixed $instanceJSON
     * @throws Exception
     */
    protected function getInstanceJSON(string $uuid)
    {
        return $this->OrthancService->pacsAPI("$this->PACS_url/instances/$uuid");
    }

    /**
     * @param string $encryptedString
     * @return string
     * @throws \ScriptSender\Exceptions\PACSException
     * @throws Exception
     */
    public function getStudyInstanceUidFromEncryptedString(string $encryptedString): string
    {
        $decryptedString = $this->decrypt(urldecode($encryptedString));

        // Shared URLs are of format <Share ID>|pid/accession/...
        $image_viewer_url_path = optional(explode('|', $decryptedString))[1] ?? $decryptedString;

        $accession = explode('/', $image_viewer_url_path)[1];
        $studyUUID = $this->getStudyUUIDFromPACS($accession);
        $studyJson = $this->getStudyJSON($studyUUID);
        return $studyJson['MainDicomTags']['StudyInstanceUID'];
    }

    /**
     * @param string $accession
     * @param string $DOB
     * @param string $sex
     * @return string|null Study UUID
     * @throws \ScriptSender\Exceptions\PACSException
     */
    public function getStudyUUIDFromPACS(string $accession, $DOB = null, $sex = null): ?string
    {
        $allStudies = $this->OrthancService->pacsAPI("$this->PACS_url/studies");
        $index = collect($allStudies)->search(function ($studyUUID) use ($accession, $DOB, $sex) {
            $studyJSON = $this->getStudyJSON($studyUUID); // At NERAD: $this->getStudyAccession($studyUUID);
                return ($studyJSON['MainDicomTags']['AccessionNumber'] === $accession) &&
                    ($DOB ? $studyJSON['PatientMainDicomTags']['PatientBirthDate'] === $DOB : true) &&
                    ($sex ? $studyJSON['PatientMainDicomTags']['PatientSex'] === $sex : true);
        });
        return (is_numeric($index) ? $allStudies[$index] : null);
    }

    /**
     * @param string $accession
     * @param null $pid
     * @param string $DOB
     * @param string $sex
     * @param bool $queue
     * @return string TODO: Returns $patientUUID or $studyUUID! Could be a code smell!
     * @throws Exception
     * @throws \ScriptSender\Exceptions\CoActivException
     */
    public function getStudyFromRemote(string $accession, $pid = null, $DOB = null, $sex = null, $queue = true): string
    {
        if (!config('settings.remotePACS.enable_QR')) {
            throw new PACSException('Can not query/retrieve study as no remote PACS defined');
        }

        $studyUUID = $this->getStudyUUIDFromPACS($accession, $DOB, $sex);
        if ($studyUUID) {
            Log::debug('Study exists. Skipping re-retrieval from remote', compact('accession', 'DOB', 'sex'));
            return $studyUUID;
        }
        Log::debug('Attempting to retrieve study from remote', compact('accession', 'DOB', 'sex'));
        Redis::set("image_viewer:study_in_queue:$accession", '1');

        // Get last change in PACS, so we can calculate delta after Q-R process
        $last_seq_number = null;
        for ($i = 0, $chunk = 40;; $i += $chunk) {
            $changeLog = $this->OrthancService->pacsAPI("$this->PACS_url/changes?since=$i&limit=$chunk");
            if ($changeLog['Done'] === 'true' || empty($changeLog['Changes'])) {
                $last_seq_number = $changeLog['Last'];
                break;
            }
        }
        if (config('settings.remotePACS.enable_QR')) {
            $this->CoActivService->retrieveStudy($accession, $pid, $DOB, $sex);
        }
        $changeLog = $this->OrthancService->pacsAPI("$this->PACS_url/changes?since=$last_seq_number&limit=1000");
        if (empty($changeLog['Changes'])) {
            Redis::del("image_viewer:study_in_queue:$accession");
            abort('404', 'No change in PACS after Query-Retrieve!');
        }
        $newInstanceUUID = collect($changeLog['Changes'])
            ->where('ResourceType', 'Instance')
            ->where('ChangeType', 'NewInstance')
            ->last()['ID'];
        $patientUUID = $this->OrthancService->getPatientFromInstance($newInstanceUUID);
        $pid = $this->getPIDFromPatientUUID($patientUUID);

        // Update study table with cached_at etc.
        $studyRow = Imageshare_study::firstOrCreate(['study_id' => $accession]);
        // TODO: Fill-up rest of the information on study, e.g. description, study time etc.
        $studyRow->update([
            'pid' => $pid,
            'cached_at' => 'now()',
        ]);

        info('Retrieved and stored study from remote PACS', compact('accession'));

        if ($queue === true) {
            $this->queueJobToGetAllStudies($pid, $DOB, $sex); // Commented at NERAD!
        }
        Redis::del("image_viewer:study_in_queue:$accession");
        return $patientUUID;
    }

    /**
     * @param string $pid
     * @param string $DOB
     * @param string $sex
     * @throws \ScriptSender\Exceptions\CoActivException
     */
    public function getStudiesFromRemote(string $pid, $DOB = null, $sex = null): void
    {
        Redis::set("image_viewer:pid_in_queue:$pid", '1');
        $this->CoActivService
            ->queryAllStudiesForPatient($pid)
            ->each(function ($accession) use ($pid, $DOB, $sex) {
                if ($this->getStudyUUIDFromPACS($accession, $DOB, $sex)) {
                    return;
                }
                $this->getStudyFromRemote($accession, $pid, $DOB, $sex, false);
            });

        Redis::del("image_viewer:pid_in_queue:$pid");
    }

    /**
     * @param string $accession
     * @param $pid
     * @param string $DOB
     * @param string $sex
     * @return bool
     * @throws Exception
     * @throws \ScriptSender\Exceptions\CoActivException
     */
    public function queryStudyAtRemote(string $accession, string $pid, $DOB = null, $sex = null): bool
    {
        Log::debug('Querying remote PACS for study...', compact('accession', 'pid', 'DOB', 'sex'));
        if (!config('settings.remotePACS.enable_QR')) {
            throw new PACSException('No remote PACS defined.');
        }
        return $this->CoActivService->queryStudy($accession, $pid, $DOB, $sex);
    }

    /**
     * If a study is eligible to be removed from local cache, remove it and update decached_at
     *
     */
    public function checkAndBustStudyCache(): void
    {
        Imageshare_study::where('cached_at', '<=', Carbon::today()->subDays($this->studyCacheLife)->toDateString())
            ->where('accessed_at', '<=', Carbon::today()->subDays($this->studyRefreshOnAccess)->toDateString())
            ->get()
            ->each(function ($study) {
                $this->deleteStudyFromPACS($study->study_id);
                $study->update(['decached_at' => 'now()']);
            });
    }

    /**
     * Delete a study from local PACS
     *
     * @param string $accession
     * @param null $DOB
     * @param null $sex
     * @return void
     * @throws Exception
     * @throws \ScriptSender\Exceptions\PACSException
     */
    public function deleteStudyFromPACS(string $accession, $DOB = null, $sex = null): void
    {
        $studyUUID = $this->getStudyUUIDFromPACS($accession, $DOB, $sex);
        if (!$studyUUID) {
            throw new Exception("Study with accession $accession not found in PACS");
        }
        $this->OrthancService->pacsAPI("$this->PACS_url/studies/$studyUUID", 'DELETE');
        Log::info('Deleted study from PACS', compact('accession'));
    }

    /**
     * @param string $accession
     * @param string $DOB
     * @param string $sex
     */
    private function queueJobToGetStudy(string $accession, $DOB = null, $sex = null): void
    {
        if (Redis::exists("image_viewer:study_in_queue:$accession")) {
            Log::debug('There is already a job to retrieve study', compact('accession'));
            return;
        }
        $job = new GetStudiesFromRemotePACS(null, $accession, $DOB, $sex);
        dispatch($job);
        Log::info('Added a queued job to retrieve study', compact('accession'));
    }

    /**
     * @param string $pid
     * @param null $DOB
     * @param string $sex
     */
    private function queueJobToGetAllStudies(string $pid, $DOB = null, $sex = null): void
    {
        if (Redis::exists("image_viewer:pid_in_queue:$pid")) {
            logger('There is already a queued job to retrieve all studies for patient', compact('pid', 'DOB', 'sex'));
            return;
        }
        $job = new GetStudiesFromRemotePACS($pid, null, $DOB, $sex);
        dispatch($job);
        info('Added a queued job to retrieve all studies of patient', compact('pid', 'DOB', 'sex'));
    }

    /**
     * Download DICOM file from Orthanc
     *
     * @param string $uuid Instance UUID at PACS
     * @param string $fullPath
     */
    public function getDicomFile(string $uuid, string $fullPath): void
    {
        $ch = $this->ch;
        $file_url = "$this->PACS_url/instances/$uuid/file";
        curl_setopt($ch, CURLOPT_URL, $file_url);
        $fileContent = curl_exec($ch);
        // TBD: if $fileContent == error message, throw exception - resourceNotFoundException
        curl_close($ch);
        $dirname = \dirname($fullPath);
        if (!is_dir($dirname)) {
            File::makeDirectory($dirname, 0775, true);
        }
        File::put($fullPath, $fileContent);
    }

    /**
     * Laravel's in-built decrypt function fails if app key changes, rendering all image links invalid!
     * Use this function instead.
     *
     * @param string $string
     * @return string
     */
    public function encrypt(string $string): string
    {
        $this->site = resolve(SitesInterface::class);
        if (method_exists($this->site, 'getKey') && $this->site->getKey()) {
            $originalKey = config('app.key');
            config(['app.key', $this->site->getKey()]);  // Temporarily set a known key
            $encrypted = encrypt($string);
            config(['app.key', $originalKey]); // Restore original app key
        }
        else {
            $encrypted = encrypt($string);
        }
        return $encrypted;
    }

    /**
     * Laravel's in-built decrypt function fails if app key changes, rendering all image links invalid!
     * Use this function instead.
     *
     * @param string $string
     * @return string
     */
    public function decrypt(string $string): string
    {
        $this->site = resolve(SitesInterface::class);
        if (method_exists($this->site, 'getKey') && $this->site->getKey()) {
            $originalKey = config('app.key');
            config(['app.key', $this->site->getKey()]); // Temporarily set a known key
            $decrypted = decrypt($string);
            config(['app.key', $originalKey]); // Restore original app key
        }
        else {
            $decrypted = decrypt($string);
        }
        return $decrypted;
    }
    /**
     * Returns patient name string
     *
     * @return string
     */
    public function patientName(string $pid, $accession = null, $DOB = null, $sex = null): string
    {
        $patientUUID = $this->getPatientUUID($pid, $accession, $DOB, $sex);
        return $this->getPatientName($patientUUID);
    }
    /**
     * Returns patient name string
     *
     * @return string
     */
    protected function getPatientName(string $uuid): string
    {
        $patientJSON = $this->OrthancService->pacsAPI("$this->PACS_url/patients/$uuid");
        if (empty($patientJSON)) {
            throw new Exception("No patients with id '$uuid' found in PACS");
        }
        return $patientJSON['MainDicomTags']['PatientName'];
    }
}
