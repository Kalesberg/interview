<?php
declare(strict_types=1);

namespace ScriptSender\Services;

use File;
use Illuminate\Support\Facades\Redis;
use ScriptSender\Exceptions\FileAndDirectoryException;
use ScriptSender\Exceptions\PdfToTextException;
use ScriptSender\Services\Parser\Orders\AllscriptsCharter;
use ScriptSender\Services\Parser\Orders\GGastro;
use ScriptSender\Services\Parser\Orders\TreatNow;

/**
 * Class PdfToTextService
 * @package ScriptSender\Services
 */
class PdfToTextService
{
    protected $pdf;
    protected $cacheDir;
    protected $redisFilesTracker;
    protected $pdftotext;

    /**
     * PdfToTextService constructor.
     * @throws FileAndDirectoryException
     * @throws PdfToTextException
     */
    public function __construct()
    {
        $this->cacheDir = storage_path('archives/pdfToText/');
        if (!File::exists($this->cacheDir) || !File::isDirectory($this->cacheDir)) {
            File::makeDirectory($this->cacheDir, 775, true, true);
        }
        $this->redisFilesTracker = 'ss_pdf_to_text_converted';
        $this->redis = Redis::connection();
        $this->getPdfToTextCommand();
    }

    /**
     * Set PDF file path
     *
     * @param string $pdfFile
     * @return PdfToTextService
     * @throws FileAndDirectoryException
     */
    public function setPdf(string $pdfFile): PdfToTextService
    {
        if (!File::exists($pdfFile)) {
            throw new FileAndDirectoryException("File $pdfFile not found");
        }
        if (!File::isReadable($pdfFile)) {
            $currentUser = ''; // TODO: Find out
            throw new FileAndDirectoryException("File $pdfFile is not readable (Current user: $currentUser)");
        }

        $this->pdf = $pdfFile;
        return $this;
    }

    /**
     * @param bool $force
     * @return array
     * @throws FileAndDirectoryException
     * @throws PdfToTextException
     * @throws \Exception
     */
    public function convert(bool $force = false): array
    {
        $tempFile = $cachedFile = tempnam($this->cacheDir, 'pdfTotext_') . '.txt';
        if ($this->isAlreadyConverted()) {
            [$cachedFile, $isOcr] = $this->getConvertedFile();
            if ($force) {
                info('Overwriting cached text file', compact('cachedFile', 'isOcr'));
                $isOcr = $this->convertFile($cachedFile);
            }
            elseif (File::exists($cachedFile) && isTextFile($cachedFile) && File::size($cachedFile) > 0) {
                logger('Already converted to text', compact('cachedFile'));
                File::exists($tempFile) ? unlink($tempFile) : null;
            }
            else {
                info('Cached file not found or empty. Re-generating...', compact('cachedFile'));
                $isOcr = $this->convertFile($cachedFile);
            }
        }
        else {
            $isOcr = $this->convertFile($cachedFile);
        }

        if (isTextFile($cachedFile)) {
            info('Converted PDF to Text', ['pdf' => $this->pdf, 'text' => $cachedFile, 'ocr' => $isOcr ? 'Yes' : 'No']);
            changePerms($cachedFile, '0666', 'www-data', 'www-data', true);
        }
        else {
            throw new PdfToTextException("Failed to convert from PDF ({$this->pdf}) to text");
        }
        return [$cachedFile, $isOcr];
    }

    /**
     * @return bool
     */
    public function isAlreadyConverted(): bool
    {
        return (bool) $this->redis->hget($this->redisFilesTracker, md5_file($this->pdf));
    }

    /**
     * @return array
     */
    public function getConvertedFile(): array
    {
        $redisValue = $this->redis->hget($this->redisFilesTracker, md5_file($this->pdf));
        [$cachedFile, $isOcr] = explode(':', $redisValue);
        return [$cachedFile, (bool) $isOcr];
    }

    /**
     * Check if the given text file is a Practice Fusion note
     * TODO: This should be in OrderService()?
     *
     * @param string $textFile
     * @return bool
     */
    public function isPFNote(string $textFile): bool
    {
        $contents = file_get_contents($textFile);
        return (preg_match('/\d+ of \d+/', $contents)
            && preg_match('|https://static.practicefusion.com|', $contents)
            && preg_match('/Encounter/', $contents));
    }

    /**
     * Check if the given text file is a Practice Fusion note
     * TODO: This should be in OrderService()?
     *
     * @param string $textFile
     * @return bool
     */
    public function isGGastro(string $textFile): bool
    {
        return GGastro::matches(file_get_contents($textFile));
    }

    /**
     * @param string $textFile
     * @return bool
     */
    public function isTreatNow(string $textFile): bool
    {
        return TreatNow::matches(file_get_contents($textFile));
    }

    /**
     * @param string $textFile
     * @return bool
     */
    public function isAllScriptsCharter(string $textFile): bool
    {
        return AllscriptsCharter::matches(file_get_contents($textFile));
    }

    public function markAsDone(string $textFile, bool $isOcr)
    {
        $md5 = md5_file($this->pdf);
        $value = "{$textFile}:{$isOcr}";
        $this->redis->hdel($this->redisFilesTracker, [$md5]);
        if (!$this->redis->hset($this->redisFilesTracker, $md5, $value)) {
            throw new PdfToTextException("Failed to store '$md5' : '$value' in redis: ");
        }
        logger('Stored PDf to text info in Redis', ['md5' => $value]);
    }

    /**
     * @param string $textFile
     * @return bool
     * @throws \Exception
     */
    private function convertFile(string $textFile): bool
    {
        $isOcr = false;
        runCmd("{$this->pdftotext} -eol dos -nopgbrk -layout '{$this->pdf}' '$textFile'");
        $this->removeNonAsciiChars($textFile);
        if ($this->isTextFileInvalid($textFile)) {
            $tempPdf = $this->normalizePDF();
            runCmd("{$this->pdftotext} -eol dos -nopgbrk -layout $tempPdf '$textFile'");
            $isOcr = true;
            unlink($tempPdf);
        }
        $this->markAsDone($textFile, $isOcr);
        return $isOcr;
    }

    /**
     * Sometimes PDF to text conversion retains stray non-ascii characters (^C/^D etc.) in the file. This causes the
     * file to be detected as a "data" file, even though it may have texts. Use this method to remove those unwanted
     * control chars.
     * @param string $file
     */
    private function removeNonAsciiChars(string $file)
    {
        $lines = file_get_contents($file);
        $tempFile = storage_path('app/temp/removeNonAsciiChars.txt');
        file_put_contents($tempFile, preg_replace('/[\x00-\x09\x0b\x0c\x0e-\x1f\x7f-\xff]/', '', $lines));
        File::move($tempFile, $file);
    }

    /**
     * @return string
     * @throws PdfToTextException
     */
    protected function normalizePDF(): string
    {
        $tempPdf = '/tmp/abbyy_temp.pdf'; # TBD: Create a random temp file
        $this->runABBYY($tempPdf);
        if (!File::exists($tempPdf)) {
            throw new PdfToTextException("ABBYY failed to create $tempPdf");
        }
        if (!preg_match('|application/pdf|i', File::mimeType($tempPdf))) {
            throw new PdfToTextException("ABBYY-generated file '$tempPdf' is not a PDF document (it is " .
                shell_exec("file $tempPdf") . ')');
        }
        logger('Normalized PDF', ['pdf' => $this->pdf]);
        return $tempPdf;
    }

    /**
     * @throws PdfToTextException
     */
    protected function getPdfToTextCommand(): void
    {
        if (0 === stripos(PHP_OS, 'WIN')) {
            $this->pdftotext = 'pdftotext.exe'; // Assuming winGit or MinGW is installed, and mingw/bin/ is in path
        }
        elseif (strtoupper(PHP_OS) === 'LINUX') {
            $this->pdftotext = '/usr/bin/pdftotext';
        }
        if (!File::exists($this->pdftotext)) {
            throw new PdfToTextException("pdftotext not found! Checked in {$this->pdftotext}");
        }
    }

    /**
     * @param $tempPdf
     */
    protected function runABBYY($tempPdf): void
    {
        $abbyy = '/usr/local/bin/abbyyocr11';
        if (File::exists($abbyy)) {
            runCmd("$abbyy -pi -if '{$this->pdf}' -adp -rl English -rldm No -f PDF -trl -pwtm Write -of $tempPdf 2>&1 >> /tmp/kkk.txt");
        }
        else {
            # runCmd("curl --cacert server.crt -X POST -F 'pdf=\@$pdf_file' https://demo.scriptsender.com:5000/pdf-to-text -o $tempPdf 2>&1 >> /tmp/kkk.txt");
            runCmd("curl --insecure -X POST -F 'pdf=@{$this->pdf}' -F 'file=pdf' https://104.237.132.188:5000/pdf-to-text -o $tempPdf");
        }
    }

    /**
     * Check if the generated text file is not valid and can't be used
     *
     * @param string $textFile
     * @return bool
     */
    protected function isTextFileInvalid(string $textFile): bool
    {
        $invalid = false;
        if (!File::exists($textFile)) {
            $invalid = true;
            logger('Generated text file does not exist', ['pdf' => $this->pdf, 'text' => $textFile]);
        }
        elseif (!preg_match('/ASCII text/', runCmd("/usr/bin/file $textFile"))) { # Regular text file?
            $invalid = true;
            logger('Generated text file is not a ASCII text', ['pdf' => $this->pdf, 'text' => $textFile]);
        }
        elseif ($this->isPFNote($textFile)) {
            $invalid = true;
            logger('File is a PF Clinical Note, which is always OCRed', [
                'pdf' => $this->pdf, 'text' => $textFile]);
        }
        elseif ($this->isGGastro($textFile) && (File::size($textFile) < 200)) {
            $invalid = true;
            logger('File is a GGastro and less than 200 bytes, which needs to be OCRed', [
                'pdf' => $this->pdf, 'text' => $textFile]);
        }
        elseif ($this->isAllScriptsCharter($textFile) && (File::size($textFile) < 200)) {
            $invalid = true;
            logger('File is a AllScriptsCharter and less than 200 bytes, which needs to be OCRed', [
                'pdf' => $this->pdf, 'text' => $textFile]);
        }
        elseif ($this->isTreatNow($textFile) && (File::size($textFile) < 200)) {
            $invalid = true;
            logger('File is a TreatNow and less than 200 bytes, which needs to be OCRed', [
                'pdf' => $this->pdf, 'text' => $textFile]);
        }
        elseif (($this->isTreatNow($textFile) || !$this->isGGastro($textFile) || !$this->isAllScriptsCharter($textFile)) && (File::size($textFile) < 1600)) {
            $invalid = true;
            logger('Generated text file less than desired size! Probably the PDF contains image instead of text', [
                'pdf' => $this->pdf, 'text' => $textFile]);
        }
        return $invalid;
    }
}
